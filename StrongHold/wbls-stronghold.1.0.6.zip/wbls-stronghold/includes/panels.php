<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts
 *
 * @param $layouts
 */ 
if (!function_exists('wbls_stronghold_prebuilt_page_layouts') ) {   
function wbls_stronghold_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-stronghold'),
    'description' => __('Pre Built Layout for  home page', 'wbls-stronghold'),
    'widgets' =>  array(
     0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '2',
            'type' => 'separator',
            'content' => 'Our Services',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'c9e16130-b803-4dcf-bcb4-41b0e11e634a',
              'style' => 
              array (
                'class' => 'headline-center',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Responsive Layout',
            'text' => 'Stronghold is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '2x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '8e3059b6-4cf2-4fad-ba43-bbf4bd090c71',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Awesome Slider',
            'text' => 'Stronghold includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
            'icon' => 'fa-random',
            'icon_background_color' => '',
            'icon_size' => '2x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '0c051c6a-a5b5-4cb4-9fc2-f2207746fce4',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Font Awesome',
            'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
            'icon' => 'fa-flag',
            'icon_background_color' => '',
            'icon_size' => '2x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '410d81ff-b0f2-4942-b946-926f1b182424',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '0px',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
        ),
      ),
      'builder_id' => '578cd1c46fe70',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '54951119-dc2a-49d6-a06c-1ca409225c71',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '[headline level="2" type="normal" align="tcenter"]Our Team[/headline]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '6a8a6ba7-848c-42b9-8547-1250a810356f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2016/02/ourteam-three.png',
            'title' => 'John Deo',
            'designation' => 'Founder & Partner',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'https://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'f8ef07c0-4d07-42cb-ba74-c57154c1e380',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2015/04/ourteam-two.png',
            'title' => 'Bella',
            'designation' => 'Manager',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'https://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => 'eacd2e09-b7b1-42c8-b080-e5e43d314c9a',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2015/04/ourteam-one.png',
            'title' => 'Krish Doe',
            'designation' => 'Developer',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'https://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => 'f4cd30c0-3f70-48a1-b071-f2352589a59f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2016/02/ourteam-four.png',
            'title' => 'Kate Smith',
            'designation' => 'CEO',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'https://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => '82f9b510-9e61-46ab-8e3c-ff490356aab4',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577a5a2fd07f9',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '9d129919-cb59-46ad-971f-fc45f607d68e',
        'style' => 
        array (
          'background_display' => 'tile',
          'font_color' => '#00c1cf',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Skills',
      'panels_info' => 
      array (
        'class' => 'Wbls_Skill_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'b181f086-46ea-4b11-9bbf-be2bf291feba',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '<h2>Our Services</h2>
<p>Lorem Ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<p>
[button link="http://webulousthemes.com/" target="_self" color="btn-white" size="btn-normal"]Read More[/button]
</p>',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'ae618bdb-1477-4c0a-bc50-0984a1e328e7',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'cover',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://stronghold.webulous.in/wp-content/uploads/2016/07/Our-service-img.png',
            'href' => 'http://stronghold.webulous.in/wp-content/uploads/2016/07/Our-service-img.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'd6abb9e3-bbfb-4348-bef1-805c21365a4f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '577caf405aba1',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '7a5d4571-dd32-42bb-8c3c-5a745f307790',
        'style' => 
        array (
          'class' => 'features',
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '2',
            'type' => 'separator',
            'content' => 'Tabs & Accordion',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '9beb523c-a995-4821-a1f0-85e868511427',
              'style' => 
              array (
                'class' => 'headline-center',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[tabs_group type="normal"][tabs title="Tab One"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.[/tabs][tabs title="Tab Two"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.  The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.[/tabs][tabs title="Tab Three"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.  The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.  The generated Lorem Ipsum is therefore always free from repetition, [/tabs][/tabs_group]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'd8c02d52-6712-4385-bf6a-ae279bc337e3',
              'style' => 
              array (
                'class' => 'ui-tabs-panel ui-widget-content ui-corner-bottom',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => '[accordion_group][accordion title="2011"]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. Cras venenatis a nibh ut placerat. Vivamus a mauris non quam pretium lobortis non ac odio. [/accordion][accordion title="2012"] Sed nec massa lorem. Phasellus ut tincidunt velit, id scelerisque lorem. Nullam nisl tortor, mollis ut massa in, dapibus tincidunt libero. Pellentesque pretium posuere turpis eget dignissim. Curabitur sapien lorem, feugiat et velit et, vehicula aliquet urna. Vivamus pellentesque lorem at urna suscipit, at vulputate est ultricies. Aliquam ultrices nec massa sed adipiscing. Pellentesque feugiat sodales tellus. Ut tempus aliquam felis, quis consequat nunc hendrerit eget. Praesent sollicitudin nunc eu sollicitudin placerat. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="2013"]Aliquam non lacus in lacus aliquet blandit. Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. Sed ut augue vitae augue vestibulum pulvinar. Fusce commodo ultricies volutpat. Vivamus quis nulla porta, faucibus metus eu, tempus dolor. Ut sed faucibus mi, ac volutpat lectus. Morbi a rhoncus erat. Mauris et metus posuere, imperdiet urna at, congue risus. Nunc at ante sed ipsum porttitor scelerisque semper non libero. Vivamus feugiat nisl sit amet mi tristique dictum. Donec id magna facilisis, euismod sem bibendum, interdum lorem. [/accordion][accordion title="2014"]Fusce vehicula risus lorem, sed ultricies neque pellentesque at. Ut dapibus aliquam leo non cursus. Donec eros dui, fringilla vel lacinia id, tincidunt ac eros. Ut ultrices elit nec viverra adipiscing. Aliquam suscipit viverra luctus. Vivamus rhoncus molestie hendrerit. Aenean id lacinia odio. Nullam sit amet dui accumsan, ornare nisi at, ornare elit. Proin ut dolor risus. Cras quis pellentesque felis, at venenatis nibh. Quisque tincidunt id enim a aliquam. [/accordion][/accordion_group]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '7a65fa1d-6906-4b75-9b5b-ff1662eee678',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '577caf637b817',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '3ecf4b15-6251-41f0-af5c-c4c3d5b382c1',
        'style' => 
        array (
          'class' => 'panel grid',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '2',
            'type' => 'separator',
            'content' => 'Our Running Facts',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'a58ef5fd-2a27-45b3-8ec9-2fc3341b4dca',
              'style' => 
              array (
                'class' => 'headline-center',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => 'ffffff',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '1710',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'e84a00c8-d12a-4c38-b2fe-fc908df0f0f0',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '1709',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => 'c4414534-701d-43f2-a708-964f9882f113',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '1708',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '7872c4a5-f636-4d37-bd19-960ce80fb2f6',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '1707',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => '20952ec4-e2ea-4366-be8a-8265eaed2a72',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577caf637b86d',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 5,
        'widget_id' => 'f771d959-d400-4084-87ef-de0f84415bb6',
        'style' => 
        array (
          'class' => 'features2',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Recent Works',
      'count' => '12',
      'type' => 'isotope',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Work_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '6f17de0b-d9b5-4bfb-9bfa-61bd183f49d1',
        'style' => 
        array (
          'class' => 'txt-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'level' => '2',
      'type' => 'separator',
      'content' => 'Our Testimonials',
      'panels_info' => 
      array (
        'class' => 'Wbls_Heading_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '9117ae35-4106-42a3-8ec0-d2b63844ca3b',
        'style' => 
        array (
          'class' => 'headline-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Testimonials',
      'count' => '5',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 8,
        'widget_id' => '542110cb-b2d2-4cc1-a7e4-b4f35428d753',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'tcenter',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-black',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-black',
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    
    ),

  );

  $layouts['home-style2'] = array(
    'name' => __('Home Page2', 'wbls-stronghold'),
    'description' => __( 'Pre Built layout for home page2', 'wbls-stronghold'),
    'widgets' => array(
           0 => 
    array (
      'title' => 'Lightning Fast',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard',
      'icon' => 'fa-bolt',
      'icon_size' => '5x',
      'more' => '',
      'more_url' => '',
      'all_linkable' => true,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '7abcec5e-af5b-4fd6-9246-28dd62eab71b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Built with Care',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard',
      'icon' => 'fa-heart',
      'icon_size' => '5x',
      'more' => '',
      'more_url' => '',
      'all_linkable' => true,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => 'a547621c-995f-4020-8f1e-599b4128fcab',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Mobile Ready',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => '',
      'more_url' => '',
      'all_linkable' => true,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 2,
        'widget_id' => 'd0ef9dc4-297d-4ac3-a201-e5850f31eada',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '[headline level="3" type="normal" align="tcenter"]Our Team[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '99819e5f-5c05-4a4a-b326-235013cb5007',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2015/04/ourteam-one.png',
            'title' => 'John Deo',
            'designation' => 'Founder & Partner',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'https://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'b25614d5-7a24-4491-8513-e17411518d23',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2015/04/ourteam-two.png',
            'title' => 'Bella',
            'designation' => 'Manager',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'https://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '7a1f41c3-a1fe-45b6-b2ca-7d166d8ab65e',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2016/02/ourteam-three.png',
            'title' => 'Jane Doe',
            'designation' => 'Developer',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'https://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '493e1ab8-59bf-407e-8829-9353c8b7fa42',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2016/02/ourteam-four.png',
            'title' => 'Michelle Doe',
            'designation' => 'CEO',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'https://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => '1533ac18-9d4f-4000-bccd-6868a4808fc5',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '57c3bd4e59a4c',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 1,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '68e1bb60-788a-4ced-8b3d-2e84c3e74386',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
          'font_color' => '#00c1cf',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Skills',
      'panels_info' => 
      array (
        'class' => 'Wbls_Skill_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '356f05d4-499b-4dcc-8531-79cf52a2038b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '<h2>Wonderful digital things require a good mix of combined skills</h2>
<p>Lorem Ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<p>
[button link="http://webulousthemes.com/" target="_self" color="btn-default" size="btn-normal"]See Features[/button]
[button link="http://webulousthemes.com/" target="_self" color="btn-white" size="btn-normal"]Learn More[/button]
</p>',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'c80c05f1-7ba7-41f2-b72f-a719dffaf1da',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'cover',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://stronghold.webulous.in/wp-content/uploads/2016/07/Our-service-img.png',
            'href' => 'http://stronghold.webulous.in/wp-content/uploads/2016/07/Our-service-img.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '8d07a1c8-4657-4583-a15a-295d34f256f3',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '57c3bcf250113',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '53b066af-6433-4d09-bc45-0921f4acf1ad',
        'style' => 
        array (
          'class' => 'features',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '[tabs_group type="normal"][tabs title="Tab One"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.[/tabs][tabs title="Tab Two"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.  The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.[/tabs][tabs title="Tab Three"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.  The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.  The generated Lorem Ipsum is therefore always free from repetition, [/tabs][/tabs_group]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'ui-tabs-panel ui-widget-content ui-corner-bottom',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[accordion_group][accordion title="2011"]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. Cras venenatis a nibh ut placerat. Vivamus a mauris non quam pretium lobortis non ac odio. [/accordion][accordion title="2012"] Sed nec massa lorem. Phasellus ut tincidunt velit, id scelerisque lorem. Nullam nisl tortor, mollis ut massa in, dapibus tincidunt libero. Pellentesque pretium posuere turpis eget dignissim. Curabitur sapien lorem, feugiat et velit et, vehicula aliquet urna. Vivamus pellentesque lorem at urna suscipit, at vulputate est ultricies. Aliquam ultrices nec massa sed adipiscing. Pellentesque feugiat sodales tellus. Ut tempus aliquam felis, quis consequat nunc hendrerit eget. Praesent sollicitudin nunc eu sollicitudin placerat. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="2013"]Aliquam non lacus in lacus aliquet blandit. Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. Sed ut augue vitae augue vestibulum pulvinar. Fusce commodo ultricies volutpat. Vivamus quis nulla porta, faucibus metus eu, tempus dolor. Ut sed faucibus mi, ac volutpat lectus. Morbi a rhoncus erat. Mauris et metus posuere, imperdiet urna at, congue risus. Nunc at ante sed ipsum porttitor scelerisque semper non libero. Vivamus feugiat nisl sit amet mi tristique dictum. Donec id magna facilisis, euismod sem bibendum, interdum lorem. [/accordion][accordion title="2014"]Fusce vehicula risus lorem, sed ultricies neque pellentesque at. Ut dapibus aliquam leo non cursus. Donec eros dui, fringilla vel lacinia id, tincidunt ac eros. Ut ultrices elit nec viverra adipiscing. Aliquam suscipit viverra luctus. Vivamus rhoncus molestie hendrerit. Aenean id lacinia odio. Nullam sit amet dui accumsan, ornare nisi at, ornare elit. Proin ut dolor risus. Cras quis pellentesque felis, at venenatis nibh. Quisque tincidunt id enim a aliquam. [/accordion][/accordion_group]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '56b82f7f3b6de',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '28f9b5a2-0a6e-46e5-bc43-00df69cb257f',
        'style' => 
        array (
          'class' => 'panel grid',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '1710',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '1709',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '1708',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '1707',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '56b82f7f3b745',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '5eb8b3cc-5e69-4aa4-9446-51aae6785846',
        'style' => 
        array (
          'class' => 'features2',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Latest Projects',
      'count' => '9',
      'type' => 'isotope',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Work_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'be316a55-f27c-4eef-bf5e-c8a860d8515a',
        'style' => 
        array (
          'class' => 'txt-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Testimonials',
      'count' => '5',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '8f49c905-1156-4461-86a7-6db70371a8ab',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'class' => 'attachment-full_width wp-post-image',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-black',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-black',
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ), 
    ),
  );    

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-stronghold'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-stronghold'),
    'widgets' => array(
            0 => 
    array (
      'src' => 'http://stronghold.webulous.in/wp-content/uploads/2016/07/about-us.png',
      'href' => 'http://stronghold.webulous.in/wp-content/uploads/2016/07/about-us.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'a864df1c-2f49-415c-9944-4eeeff40ba46',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Lorem Ipsum is Simply!',
      'text' => '[headline level="5" type="normal" align="tleft"]It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.[/headline]

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randiomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embaraassing hidden',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => '970afe0f-50f2-49e1-ac19-2d6bcc376710',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'content' => 'Lorem Ipsum is Simply Dummy Text of the Printing and Typesetting.',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2016/02/ourteam-three.png',
            'title' => 'John Deo',
            'designation' => 'Foundar & Partner',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'c0d5a9e2-9be3-4905-a2a8-b0383c9d1de3',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2015/04/ourteam-two.png',
            'title' => 'Bella',
            'designation' => 'Manager',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '21388675-6fa1-4ebb-8aa1-bfa76a8d77a9',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Lorem Ipsum is Simply Dummy Text of the Printing and Typesetting.',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2015/04/ourteam-one.png',
            'title' => 'Jane Doe',
            'designation' => 'CEO',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '7ff5ef7e-eea5-4fe6-ae2a-258410c88f0c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Lorem Ipsum is Simply Dummy Text of the Printing and Typesetting.',
            'image_url' => 'http://stronghold.webulous.in/wp-content/uploads/2016/02/ourteam-four.png',
            'title' => 'Kate Smith',
            'designation' => 'Designer',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'widget_id' => '2fdaa662-d3ec-4ffa-bde2-75b6c72a0e95',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577a2c2844fc4',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '4a9029b2-babb-4b7a-b119-87aaec402b03',
        'style' => 
        array (
          'class' => 'features',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '1707',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '1708',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '1709',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '1710',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '567bca4d7d934',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '080db37a-eeab-4484-931b-c94b064a0813',
        'style' => 
        array (
          'class' => 'features2',
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Testimonials',
      'count' => '5',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '2fccfb0c-1d92-46f1-bf1b-dc3d161456b1',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-black',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.5,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.5,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'wbls-stronghold'),
      'description' => __( 'Pre Built layout for features page', 'wbls-stronghold'),
      'widgets' => array(
        0 => 
    array (
      'title' => 'Responsive Layout',
      'text' => 'Stronghold is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '30590dbb-4053-4add-b59e-ef80427b4972',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Awesome Slider',
      'text' => 'Stronghold includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => '246fb9a3-ab85-458d-b126-dcfd32df3d0a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Font Awesome',
      'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 2,
        'widget_id' => '5e432e6c-1541-4545-89df-d8dd7bef38ad',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Typography',
      'text' => 'Stronghold loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '81b3e27c-a027-4d91-a12f-3adfc06462a3',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Retina Ready',
      'text' => 'Stronghold is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 4,
        'widget_id' => '4730843e-75aa-4148-a3a2-1a5fc71127ca',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Excellent Support',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
      'icon' => 'fa-support',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 5,
        'widget_id' => '7be787d0-0f4f-4ac8-b660-cfe73efe12f6',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com/?add-to-cart=33',
      'anchor_text' => 'Buy Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '0e8732a4-9dab-4bff-b29c-a8ff172b3bd0',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Customization',
      'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
      'icon' => 'fa-cog',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'widget_id' => 'ecdc6f0e-a231-4a45-b56d-6dfc6ee7a81b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Page Builder',
      'text' => 'Stronghold supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 8,
        'widget_id' => 'b35d5b01-5da6-41db-8773-758485d34fdb',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Page Layout',
      'text' => 'Stronghold offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 9,
        'widget_id' => '3ee8ea56-ee1a-4f8d-9583-ebc667261c7f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Custom Widget',
      'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
      'icon' => 'fa-beer',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 10,
        'widget_id' => '440011f2-a454-48d8-86b9-4b8961aeb9e4',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Shortcode Builder',
      'text' => 'Stronghold includes lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
      'icon' => 'fa-check',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 11,
        'widget_id' => '434c99f5-6c6c-465b-8778-12b22455f2cc',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Page Layout',
      'text' => 'Stronghold offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 12,
        'widget_id' => 'aee8b794-7ec4-43d2-9895-c3d5b753e8d3',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com/?add-to-cart=33',
      'anchor_text' => 'Buy Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 13,
        'widget_id' => '5e78694c-ee0f-4a78-ab1d-ec2b19271371',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'title' => 'Woo Commerce',
      'text' => 'Stronghold has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!',
      'icon' => 'fa-shopping-cart',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 14,
        'widget_id' => '5ea368a1-7747-4d9e-8b60-2ad738d95ebc',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'title' => 'Testimonials',
      'text' => 'With our testimonial post type, shortcode and widget, Displaying testimonials is a breeze.',
      'icon' => 'fa-rocket',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 1,
        'id' => 15,
        'widget_id' => 'a240b46b-d054-4730-87a0-7719d3d09c0a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => 'Social Media',
      'text' => 'Want your users to stay in touch? No problem, Stronghold has Social Media icons all throughout the theme!',
      'icon' => 'fa-skype',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 2,
        'id' => 16,
        'widget_id' => '0bcf6201-9381-47bb-925e-c43e40e08e24',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'title' => 'Google Map',
      'text' => 'Stronghold includes Google Map as shortcode and widget. So, you can use it anywhere in your site!',
      'icon' => 'fa-map-marker',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 17,
        'widget_id' => '4016f590-f4bd-40ae-be05-cc5c2ca2b89e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'title' => 'Multiple Portfolio',
      'text' => '7 portfolio layouts, 3 blog layouts and multiple other alternate layouts for interior pages!',
      'icon' => 'fa-list-alt',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 18,
        'widget_id' => 'e1c38b18-9221-4040-a8f8-d5a324df6b4e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'title' => 'Multiple Sidebar',
      'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
      'icon' => 'fa-columns',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 2,
        'id' => 19,
        'widget_id' => '8955b1e6-d2c4-43b7-810d-dec58fa610ec',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'bottom_margin' => '40px',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'bottom_margin' => '40px',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'cta',
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'bottom_margin' => '40px',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'bottom_margin' => '40px',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'cta',
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'bottom_margin' => '40px',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'bottom_margin' => '40px',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    8 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    9 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    10 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    11 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    12 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    13 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    14 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    15 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    16 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    17 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    18 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    19 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-stronghold'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-stronghold'),
      'widgets' => array(
        0 => 
    array (
      'title' => '',
      'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3560.057424374254!2d152.9590360147493!3d-26.838125796560888!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b9384b3394378fb%3A0x912d04a1146aed33!2sAustralia+Zoo!5e0!3m2!1sen!2sin!4v1467784285615" width="1280" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '1bb691f0-43c9-461c-8ee7-d78cd4712e52',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    1 => 
    array (
      'title' => 'Stay Connected',
      'text' => '<ul>
<li>
<i class="fa fa-facebook"></i>
<h4>Facebook</h4>
<p>stronghold/facebook</p>
</li>
<li>
<i class="fa fa-twitter"></i>
<h4>Twitter</h4>
<p>@stronghold</p>
</li>
<li><i class="fa fa-envelope"></i>
<h4>Mail</h4>
<p>stronghold@gmail.com</p>
</li>
<li><i class="fa fa-phone"></i>
<h4>Contact</h4>
<p>+123 456 7890</p>
</li>
</ul>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '7ecf874b-c74d-48d6-815b-49146438efa1',
        'style' => 
        array (
          'class' => 'stay-connect',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => '',
      'text' => '[contact-form-7 id="304" title="Contact form 1"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'bd55a515-1198-4e21-8a30-9c2e366b5a2e',
        'style' => 
        array (
          'class' => 'cnt-form',
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-black',
        'bottom_margin' => '80px',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wpcf7-form',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-stronghold'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-stronghold'),
    'widgets' =>  array(
      0 => 
    array (
      'title' => '',
      'text' => '[toggle title="How long do they last?" open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="How do update the theme?" open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="Are you hiring?" open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="Do you themes include support?" open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="Where can I find your offices?" open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle]
',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'e0737624-a0b6-40fc-9549-0bc7767b1d98',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '200px',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-stronghold'),
    'description' => __('Pre Built Layout for services page', 'wbls-stronghold'),
    'widgets' =>  array(
     0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '2',
            'type' => 'separator',
            'content' => 'Tabs & Accordion',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '3b15ee13-9758-419c-a26e-35f4b383c88a',
              'style' => 
              array (
                'class' => 'headline-center',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[tabs_group type="normal"][tabs title="Tab One"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.[/tabs][tabs title="Tab Two"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.  The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.[/tabs][tabs title="Tab Three"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.  The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.  The generated Lorem Ipsum is therefore always free from repetition, [/tabs][/tabs_group]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'c487bda2-2783-4f4f-bfef-1390140db49a',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => '[accordion_group][accordion title="2011"]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. Cras venenatis a nibh ut placerat. Vivamus a mauris non quam pretium lobortis non ac odio. [/accordion][accordion title="2012"] Sed nec massa lorem. Phasellus ut tincidunt velit, id scelerisque lorem. Nullam nisl tortor, mollis ut massa in, dapibus tincidunt libero. Pellentesque pretium posuere turpis eget dignissim. Curabitur sapien lorem, feugiat et velit et, vehicula aliquet urna. Vivamus pellentesque lorem at urna suscipit, at vulputate est ultricies. Aliquam ultrices nec massa sed adipiscing. Pellentesque feugiat sodales tellus. Ut tempus aliquam felis, quis consequat nunc hendrerit eget. Praesent sollicitudin nunc eu sollicitudin placerat. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="2013"]Aliquam non lacus in lacus aliquet blandit. Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. Sed ut augue vitae augue vestibulum pulvinar. Fusce commodo ultricies volutpat. Vivamus quis nulla porta, faucibus metus eu, tempus dolor. Ut sed faucibus mi, ac volutpat lectus. Morbi a rhoncus erat. Mauris et metus posuere, imperdiet urna at, congue risus. Nunc at ante sed ipsum porttitor scelerisque semper non libero. Vivamus feugiat nisl sit amet mi tristique dictum. Donec id magna facilisis, euismod sem bibendum, interdum lorem. [/accordion][accordion title="2014"]Fusce vehicula risus lorem, sed ultricies neque pellentesque at. Ut dapibus aliquam leo non cursus. Donec eros dui, fringilla vel lacinia id, tincidunt ac eros. Ut ultrices elit nec viverra adipiscing. Aliquam suscipit viverra luctus. Vivamus rhoncus molestie hendrerit. Aenean id lacinia odio. Nullam sit amet dui accumsan, ornare nisi at, ornare elit. Proin ut dolor risus. Cras quis pellentesque felis, at venenatis nibh. Quisque tincidunt id enim a aliquam. [/accordion][/accordion_group]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '70a1b359-b2d5-4a2f-8337-8b59c3d75ec4',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'animation_class' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '577cafdddbf27',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '2bfc2888-c971-473b-8ea5-b86c3f0d5e63',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '<h2>Our Services</h2>
<p>Lorem Ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<p>
[button link="http://webulousthemes.com/" target="_self" color="btn-white" size="btn-normal"]Read More[/button]
</p>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '7339dfd3-2f28-4631-8e2a-fac23347dd04',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'src' => 'http://stronghold.webulous.in/wp-content/uploads/2016/07/Our-service-img.png',
      'href' => 'http://stronghold.webulous.in/wp-content/uploads/2016/07/Our-service-img.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'widget_id' => '2f763458-3341-4788-b107-e7e545f6c8cc',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Skills',
      'panels_info' => 
      array (
        'class' => 'Wbls_Skill_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '3bd74387-ba38-4572-81a4-9f3c81865a2d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'wide-black',
        'cell_class' => 'features',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.5,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.5,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'wbls_stronghold_prebuilt_page_layouts');

function wbls_stronghold_panels_row_style_fields($fields) {  

    $stronghold_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-stronghold'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-stronghold' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-stronghold' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-stronghold' ),
        'bounce-animation' => __('bounce-animation','wbls-stronghold' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-stronghold' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-stronghold' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-stronghold' ),
        'expandUp-animation' => __('expandUp-animation','wbls-stronghold' ),
        'fade-animation' => __('fade-animation','wbls-stronghold' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-stronghold' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-stronghold' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-stronghold' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-stronghold' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-stronghold' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-stronghold' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-stronghold' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-stronghold' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-stronghold' ),
        'flip-animation' => __('flip-animation','wbls-stronghold' ),
        'flipInX-animation' => __('flipInX-animation','wbls-stronghold' ),
        'flipInY-animation' => __('flipInY-animation','wbls-stronghold' ),
        'floating-animation' => __('floating-animation','wbls-stronghold' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-stronghold' ),
        'hatch-animation' => __('hatch-animation','wbls-stronghold' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-stronghold' ),
        'puffIn-animation' => __('puffIn-animation','wbls-stronghold' ),
        'pullDown-animation' => __('pullDown-animation','wbls-stronghold' ),
        'pullUp-animation' => __('pullUp-animation','wbls-stronghold' ),
        'pulse-animation' => __('pulse-animation','wbls-stronghold' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-stronghold' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-stronghold' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-stronghold' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-stronghold' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-stronghold' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-stronghold' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-stronghold' ),
        'scale-down-animation' => __('scale-down-animation','wbls-stronghold' ),
        'scale-up-animation' => __('scale-up-animation','wbls-stronghold' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-stronghold' ),
        'slide-left-animation' => __('slide-left-animation','wbls-stronghold' ),
        'slide-right-animation' => __('slide-right-animation','wbls-stronghold' ),
        'slide-top-animation' => __('slide-top-animation','wbls-stronghold' ),
        'slideDown-animation' => __('slideDown-animation','wbls-stronghold' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-stronghold' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-stronghold' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-stronghold' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-stronghold' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-stronghold' ),
        'slideRight-animation' => __('slideRight-animation','wbls-stronghold' ),
        'slideUp-animation' => __('slideUp-animation','wbls-stronghold' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-stronghold' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-stronghold' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-stronghold' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-stronghold' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-stronghold' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-stronghold' ),
        'swap-animation'  => __('swap-animation','wbls-stronghold' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-stronghold' ),
        'swing-animation'  => __('swing-animation','wbls-stronghold' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-stronghold' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-stronghold' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-stronghold' ), 
        'tossing-animation'  => __('tossing-animation','wbls-stronghold' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-stronghold' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-stronghold' ), 
        'wobble-animation' => __('wobble-animation','wbls-stronghold' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-stronghold' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'stronghold'),
            'type' => 'select',
            'options' => $stronghold_animation_name,
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_stronghold_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_stronghold_panels_row_style_fields');

function wbls_stronghold_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_stronghold_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_stronghold_panels_panels_row_style_attributes', 10, 2);

function wbls_stronghold_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Animation', 'wbls-stronghold'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_stronghold_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_stronghold_row_style_groups' );