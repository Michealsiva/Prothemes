<?php
/**
 * Pro customizer options     
 */

add_action('wbls-stronghold_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() { 
   
   
// pro home page section 

		Stronghold_Kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-stronghold' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-stronghold'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) );

		Stronghold_Kirki::add_field( 'stronghold', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-stronghold' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch',
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
				'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-stronghold'),
			'default'  => 'off',
		) );
		Stronghold_Kirki::add_field( 'stronghold', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-stronghold' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-stronghold'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-stronghold'),
		) );

//  animation section 

Stronghold_Kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-stronghold' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-stronghold'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-stronghold' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Stronghold_Kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-stronghold' ),
	'description'    => __( 'Custom JS', 'wbls-stronghold'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-stronghold' ),
	'section'  => 'custom_js_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
) ); 



// Tracking section 

Stronghold_Kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-stronghold' ),
	'description'    => __( 'Tracking Code', 'wbls-stronghold'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'analytics',
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-stronghold' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-stronghold' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'2' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-stronghold'),
) );

// color scheme section 

Stronghold_Kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-stronghold' ),
	'description'    => __( 'Select your color scheme', 'wbls-stronghold'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'color_scheme',
	'label'    => __( 'Select your color scheme', 'wbls-stronghold' ),
	'section'  => 'multiple_color_section',
	'type'     => 'palette',
	'choices'     => array(  
		    '1' => array( 
				'#00c1cf',
			),
			'2' => array(
				'#6aa0e5',
			),
			'3' => array(
				'#87d37b',  
			),
			'4' => array(
				'#c060f5',
			),
			'5' => array(
				'#c04935',
			),
			'6' => array(
				'#f19504',
			),
			'7' => array(
				'#3498db',
			),
	),
    'default' => '1',
) );

//social network URL
Stronghold_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-stronghold' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-stronghold'),
	'panel'			 => 'social_panel',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text', 
	'tooltip' => __('Enter Your Google Plus link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-stronghold' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-stronghold'),
) );

// flexslider section //

Stronghold_Kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-stronghold' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-stronghold'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-stronghold' ),
		'2' => esc_attr__( 'Slide', 'wbls-stronghold' )
	),
	'default'  => '2',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-stronghold' ),
		'2' => esc_attr__( 'Vertical', 'wbls-stronghold' )
	),
	'default'  => '1',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => 'on',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => 'on',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => 'on',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => 'on',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => 'off',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => 'off',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => 'off',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'off' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-stronghold' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Stronghold_Kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-stronghold' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-stronghold'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-stronghold' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'2' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => '2',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-stronghold' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-stronghold' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-stronghold' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'2' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => '2',
) );

//  portfolio settings //

Stronghold_Kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-stronghold' ),
) );

$post_per_page = get_option('posts_per_page');
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-stronghold' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-stronghold' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-stronghold' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-stronghold' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-stronghold'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-stronghold' ),
		2 => __( 'Show Without "All"', 'wbls-stronghold' ),
		3 => __( 'Hide', 'wbls-stronghold' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Stronghold_Kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-stronghold' ),
	'description'    => __( 'Light Box Settings', 'wbls-stronghold'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-stronghold' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-stronghold' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-stronghold' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-stronghold' ),
		'4' => esc_attr__( 'light-square', 'wbls-stronghold' ),
		'5' => esc_attr__( 'dark-square', 'wbls-stronghold' ),
		'6' => esc_attr__( 'facebook', 'wbls-stronghold' ),
	),
	'default'  => '1',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-stronghold' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-stronghold' ),
		'slow' => esc_attr__( 'Slow', 'wbls-stronghold' ),
		'normal' => esc_attr__( 'Normal', 'wbls-stronghold' ),
	),
	'default'  => 'fast',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-stronghold' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-stronghold' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'2' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => '2',
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-stronghold' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-stronghold'),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-stronghold' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-stronghold' ),
		'2' => esc_attr__( 'Disable', 'wbls-stronghold' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-stronghold' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#00c1cf',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'button,.dropcap-box,.dropcap-book,.widget_image-box-widget a.more-button:hover,
							input[type="button"],.ui-accordion .ui-accordion-header-active,.cnt-form .wpcf7-form input[type="text"]:focus,
							.cnt-form .wpcf7-form input[type="email"]:focus,.sidebar .dropcap-book,
							.cnt-form .wpcf7-form input[type="tel"]:focus,
							.cnt-form .wpcf7-form input[type="url"]:focus,
							.cnt-form .wpcf7-form input[type="password"]:focus,
							.cnt-form .wpcf7-form input[type="number"]:focus,
							.cnt-form .wpcf7-form textarea:focus,.icon-horizontal .fa-stack, .icon-vertical .fa-stack,
							input[type="reset"],.widget_recent-work-widget .portfolio3col .img-wrap > a:before,
							input[type="submit"],input[type="text"]:focus,.icon-horizontal,
							.icon-vertical,.widget_testimonial-widget ul li img,.widget_image-box-widget .image-box img,
							input[type="email"]:focus,.widget_recent-work-widget .portfolio3col .overlay_icon a,
							input[type="url"]:focus, #filters ul.filter-options li a:hover::before, #filters ul.filter-options li a.selected::before,
							input[type="password"]:focus,.ui-accordion h3:hover,.tabs .tabs_container,
							input[type="search"]:focus,.portfolioeffects:hover .portfolio_link_icons a:hover,
							textarea:focus,.sticky,.tabs-container .ui-tabs-panel,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a',
			'property' => 'border-color',
		),
		array(
			'element'  => '.tabs-container ul.ui-tabs-nav li.ui-tabs-active a:after,
.tabs-container ul.ui-tabs-nav li a:hover:after,#filters ul.filter-options li a:hover::after, #filters ul.filter-options li a.selected::after,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a:after',
			'property' => 'border-left-color',
		),
		array(
			'element'  => '.widget.widget_skill-widget .skill-container .skill .skill-percentage:after,.pullleft,
.pullright',
			'property' => 'border-top-color',
		),
		/*array(
			'element'  => ' .widget_calendar table caption:before,
						    a.btn:before,
			  				.widget_button-widget .btn:before,
			  				a.btn-mini:before,
			  				.widget_button-widget .btn.mini:before,
			  				a.btn.btn-small:before,
			  				.widget_button-widget .btn.small:before,
			  				a.btn-large:before,
			  				.widget_button-widget .btn.large:before,
			  				.callout-widget .call-btn a:hover:before,
			  				.wide-dark-grey .callout-widget p.call-btn a:before',
			'property' => 'border-right-color',
		),
		
		array(
			'element'  => '.home .site-content #primary .post-wrapper-head h2:before,
			  				.site-footer .footer-widgets .widget-title:before,
			  				.hr_fancy:before, .sep:before,
							.sep.tleft:before, h3.widget-title:before,
							.wide-cta:before,.widget_magazine-post-boxed-widget h3.widget-title',
			'property' => 'border-bottom-color',
		),*/
		array(
			'element'  => '.ui-accordion .ui-accordion-header-active span.ui-icon.fa,.pullnone:before,.portfolioeffects:hover .portfolio_link_icons a:hover,
.portfolioeffects .content-details h3 a:hover,.site-footer .icon-horizontal .icon-title,
.site-footer .icon-vertical .icon-title,.site-footer .widget_list-widget ul li i,.columns.breadcrumb #breadcrumb a,
.ui-accordion h3:hover span.ui-icon.fa,.pullleft:before,.icon-horizontal a.link-title i,#secondary .btn-white:hover,
 #secondary .widget_button-widget .btn.white:hover,.callout-widget .call-btn a:hover,
.icon-horizontal .icon-title i,.widget_testimonial-widget ul.flex-direction-nav li a,.content-area .widget_list-widget ul li i, .content-area .widget_list-widget ol li i,
.icon-horizontal .fa-stack i,.related-posts ul#webulous-related-posts li a:hover,
.icon-vertical a.link-title i,.sidebar .dropcap,.site-footer .widget.widget_ourteam-widget .team-content h4,
.icon-vertical .icon-title i,.sidebar .icon-horizontal .icon-title,#secondary.sidebar .widget_testimonial-widget ul li .client,
.sidebar .icon-vertical .icon-title,.site-footer .widget_testimonial-widget ul li .client,
.icon-vertical .fa-stack i,.circle-icon-box .icon-wrapper p.fa-stack i,.circle-icon-box:hover .service h4,
.pullright:before,.ui-accordion h3:hover,.sidebar .widget_list-widget ul li i,.widget.widget_ourteam-widget:hover .team-content p,.site-footer.footer-bottom a,.site-footer a:hover,a:focus,a:active,.sidebar .widget_recent_comments li a,.sidebar .widget_rss li a,ol.webulous_page_navi li a:hover,.sidebar a:hover,ol.comment-list .reply a,ol.comment-list .comment-metadata a:hover,ol.comment-list .fn,ol.comment-list li.byuser .comment-metadata a,ol.comment-list li.byuser .comment-metadata a:hover,ol.webulous_page_navi li.bpn-current,
.site-header .site-title a:hover,.site-header #header-top a:hover,.site-info .copyright a,.widget_testimonial-widget ul.flex-direction-nav li a::before',
			'property' => 'color',
		),
		array(
			'element'  => '.ui-accordion .ui-accordion-header-active,.sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
.sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,.portfolioeffects .portfolio_overlay,
input[type="button"],.widget_social-networks-widget ul li a,.widget_recent-posts-gallery-widget .recent-post:hover .post-title,#filters ul.filter-options li a:hover,
#filters ul.filter-options li a.selected,.widget_testimonial-widget .flex-control-nav a.flex-active,
.icon-horizontal:hover .fa-stack,.sidebar .dropcap-circle,button.menu-toggle,
.sidebar .dropcap-box,.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,
.icon-vertical:hover .fa-stack,.widget_recent-posts-gallery-widget .recent-post .post-overlay,
.share-box ul li a,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a,
.tabs-container ul.ui-tabs-nav li a:hover,.ui-accordion .ui-accordion-header:hover,.ui-accordion .ui-accordion-header-active:hover,
input[type="reset"],.widget.widget_skill-widget .skill-container .skill .skill-percentage,
input[type="submit"],#secondary.sidebar .callout-widget,.flexslider .flex-direction-nav a,.flexslider .flex-caption a:hover,.widget .ei-slider-thumbs li.ei-slider-element,
ul.ei-slider-thumbs li.ei-slider-element,.hr_fancy:before,.hr_fancy2:before, .hr_fancy2:after,
.widget_button-widget .btn,a.btn-white:hover,.dropcap-circle,.toggle .toggle-title,
.dropcap-box,.dropcap-book,.sep:before,.circle-icon-box .more-button a,
.widget_button-widget .btn.white:hover,.cnt-form .wpcf7-form input[type="submit"],.entry-header .header-entry-meta span,
.entry-body .header-entry-meta span,.site-footer .callout-widget p.call-btn a:hover,.site-footer .footer-bottom ul.menu li a:hover,.site-footer .footer-bottom ul.menu li.current_page_item a,.site-footer .icon-horizontal .fa-stack,
.site-footer .icon-vertical .fa-stack,.sidebar .icon-horizontal .fa-stack,
.sidebar .icon-vertical .fa-stack,.flexslider .flex-control-nav a.flex-active,
.post-navigation .nav-links a:hover,
.paging-navigation .nav-links a:hover,.widget_calendar table caption,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a,
.comment-navigation .nav-links a:hover,.widget_calendar table td#today,.site-info .left-sidebar .current-menu-item page_item, .site-info .left-sidebar .current_page_item a,.site-info .left-sidebar .current-menu-item page_item::after, .site-info .left-sidebar .current_page_item a::after,
a.btn, .widget_button-widget .btn,.widget.widget_ourteam-widget .team-content::before',
			'property' => 'background-color',
		),
		array(
			'element'  => '.tabs ul li .tabulous_active, .tabs ul li a:hover',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
) );

Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-stronghold' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#1e1e1e',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => 'input,
select,
textarea,ol.comment-list a:hover,#respond .comment-form label,
.sidebar .circle-icon-box:hover .icon-wrapper p.fa-stack i:before,.sidebar a,#secondary .widget ul li:before, #secondary .widget ol li:before,
.site-footer .widget ul li:before,.callout-widget a,.ui-accordion h3,.widget_recent-work-widget .portfolio3col h4,.flexslider .flex-caption a,.columns.breadcrumb #breadcrumb #crumbs,
.site-footer .widget ol li:before,.alert-message,.circle-icon-box:hover .icon-wrapper p.fa-stack i,
.widget.widget_ourteam-widget .team-content p,.sidebar .widget_rss li a:hover,.search-form input.search-field,.widget_tag_cloud .tagcloud a:hover,.sidebar .widget_recent_comments li a:hover',
			'property' => 'color',
		),
		
		array(
			'element' => 'button:hover,.slicknav_menu,.cnt-form .wpcf7-form input[type="submit"]:hover,#secondary.sidebar .callout-widget p.call-btn a:hover,
			input[type="button"]:hover,.error-404.not-found .page-header,.not-found-inner a:hover,
			.circle-icon-box .more-button a:hover,.toggle .toggle-title .icn,.toggle .toggle-title:hover,.toggle .toggle-content,
			input[type="reset"]:hover,.widget.widget_skill-widget .skill-container .skill,
			input[type="submit"]:hover,.site-footer,.site-footer .search-form input,.site-footer .footer-top:after',
			'property' => 'background-color',
		),
		array(
			'element' => 'abbr, acronym',
			'property' => 'border-bottom-color',
		),
		array(
			'element' => 'button:hover,
input[type="button"]:hover,
input[type="reset"]:hover,
input[type="submit"]:hover,button:focus,
input[type="button"]:focus,
input[type="reset"]:focus,
input[type="submit"]:focus,
button:active,
input[type="button"]:active,
input[type="reset"]:active,
input[type="submit"]:active,.left-sidebar',  
			'property' => 'border-color',
		),
		/*array(
			'element' => 'table tr th:hover a,
			  				.site-header .social .recentcomments a:hover	
							.header-wrap .site-header .social .recentcomments a:hover,
							#primary .sticky a:hover,
							#primary .sticky span:hover,
							#primary .sticky time:hover,
							.left-sidebar .recentcomments a:hover,
							.left-sidebar .widget_rss a:hover,
							.wide-cta .call-btn a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),
        array(
			'element' => '.slicknav_menu,
				          .search-form input.search-submit:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		
		array(
			'element' => '.site-content .nav-next a span,
							.withtip.left:after,
							.home .flexslider .slides .flex-caption a:after,
			      			.home .flexslider .slides .flex-caption p a:after,
			      			.home .flexslider .flex-direction-nav .flex-nav-next a,
			      			#filters ul.filter-options li a:hover:before,
			        		#filters ul.filter-options li a.selected:before,
			        		.flexslider .slides .flex-caption a:after,
			      			.flexslider .slides .flex-caption p a:after,
			      			.flexslider .flex-direction-nav .flex-nav-next a,
			      			.widget_button-widget .btn.white:hover:after,
			      			.callout-widget .call-btn a:after,
			      			.wide-dark-grey .callout-widget p.call-btn a:hover:after,
			      			.widget_testimonial-widget .flex-direction-nav a.flex-next:hover',
			'property' => 'border-left-color',
		),
		
        array(
			'element' => '.withtip.right:after,.page-numbers:last-child,
			      			.site-content .nav-previous a span,
			      			.home .flexslider .flex-direction-nav .flex-nav-prev a,
			      			.flexslider .flex-direction-nav .flex-nav-prev a,
			      			a.btn-white:hover:before,
			    			.widget_button-widget .btn.white:hover:before,
			    			.callout-widget .call-btn a:before,
			    			.wide-dark-grey .callout-widget p.call-btn a:hover:before,
			    			.widget_testimonial-widget .flex-direction-nav a.flex-prev:hover',
			'property' => 'border-right-color',
		),
        array(
			'element' => '.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link:after',
			'property' => 'border-top-color',
		),
		array(
			'element' => '.site-footer .widget_social-networks-widget ul li a:after',
			'property' => 'border-top-color',
			'suffix' => '!important',
		),*/
		
	),
) );

//  slider panel //

Stronghold_Kirki::add_panel( 'slider_panel', array(   
	'title'       => __( 'Slider Settings', 'wbls-stronghold' ),  
	'description' => __( 'Flex slider related options', 'wbls-stronghold' ), 
	'priority'    => 11,    
) );

//  flexslider section  //

Stronghold_Kirki::add_section( 'flex_caption_section', array(
	'title'          => __( 'Flexcaption Settings','wbls-stronghold' ),
	'description'    => __( 'Flexcaption Related Options', 'wbls-stronghold'),
	'panel'          => 'slider_panel', // Not typically needed.
) );

Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexcaption_bg',  
	'label'    => __( 'Select Flexcaption Background Color', 'wbls-stronghold' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexcaption_align',
	'label'    => __( 'Select Flexcaption Alignment', 'wbls-stronghold' ),
	'section'  => 'flex_caption_section',
	'type'     => 'select',
	'default'  => 'center',
	'choices' => array(
		'left' => esc_attr__( 'Left', 'stronghold' ),
		'right' => esc_attr__( 'Right', 'stronghold' ),
		'center' => esc_attr__( 'Center', 'stronghold' ),
		'justify' => esc_attr__( 'Justify', 'stronghold' ),
	),
	'output'   => array(
		array(
			'element'  => '.home .flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption,.flexslider .slides .flex-caption h1, .flexslider .slides .flex-caption h2, .flexslider .slides .flex-caption h3, .flexslider .slides .flex-caption h4, .flexslider .slides .flex-caption h5, .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption p,.flexslider .slides .flex-caption',
			'property' => 'text-align',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
 Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexcaption_bg_position',
	'label'    => __( 'Select Flexcaption Background Horizontal Position', 'wbls-stronghold'),
	'tooltip' => __('Select how far from right, Default value Right = ( in % )','wbls-stronghold'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'right',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
 Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'wbls-stronghold' ),
	'tooltip' => __('Select how far from top, Default value top = 15 ( in % )','wbls-stronghold'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '15',
	'choices'     => array(
		'min'  => -50,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'top',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Stronghold_Kirki::add_field( 'stronghold', array( 
	'settings' => 'flexcaption_bg_width',
	'label'    => __( 'Select Flexcaption Background Width', 'wbls-stronghold' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Flexcaption Background Width ','wbls-stronghold'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexcaption_responsive_bg_width',
	'label'    => __( 'Select Responsive Flexcaption Background Width', 'wbls-stronghold' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Responsive Flexcaption Background Width, Default width value 100 ( This value will apply for max-width: 768px )','wbls-stronghold'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'media_query' => '@media (max-width: 768px)',
			'value_pattern' => 'calc($%)',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Stronghold_Kirki::add_field( 'stronghold', array(
	'settings' => 'flexcaption_color',
	'label'    => __( 'Select Flexcaption Font Color', 'wbls-stronghold' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '#ffffff',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption,.home .flexslider .slides .flex-caption p,
			.flexslider .slides .flex-caption p a,
			.flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption h1,.flexslider .slides .flex-caption h2,.flexslider .slides .flex-caption h3,.flexslider .slides .flex-caption h4,.flexslider .slides .flex-caption h5,.flexslider .slides .flex-caption h6',
			'property' => 'color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );

 if( class_exists( 'WooCommerce' ) ) {
	Stronghold_Kirki::add_section( 'woocommerce_section', array(
		'title'          => __( 'WooCommerce','wbls-stronghold' ),
		'description'    => __( 'Theme options related to woocommerce', 'stronghold'),
		'priority'       => 11, 

		'theme_supports' => '', // Rarely needed.
	) );
	Stronghold_Kirki::add_field( 'woocommerce', array(
		'settings' => 'woocommerce_sidebar',
		'label'    => __( 'Enable Woocommerce Sidebar', 'stronghold' ),
		'description' => __('Enable Sidebar for shop page','stronghold'),
		'section'  => 'woocommerce_section',
		'type'     => 'switch',
		'choices' => array(
			'on'  => esc_attr__( 'Enable', 'stronghold' ),
			'off' => esc_attr__( 'Disable', 'stronghold' ) 
		),

		'default'  => 'on',
	) );
}
// typography panel //

Stronghold_Kirki::add_panel( 'typography', array( 
	'title'       => __( 'Typography', 'wbsl-stronghold' ),
	'description' => __( 'Typography and Link Color Settings', 'wbsl-stronghold' ),
) );
   
    Stronghold_Kirki::add_section( 'typography_section', array(
		'title'          => __( 'General Settings','wbsl-stronghold' ),
		'description'    => __( 'General Settings', 'wbsl-stronghold'),
		'panel'          => 'typography', // Not typically needed.
	) );
	Stronghold_Kirki::add_field( 'stronghold', array(
		'settings' => 'custom_typography',
		'label'    => __( 'Enable Custom Typography', 'wbsl-stronghold'),
		'description' => __('Save the Settings, and Reload this page to Configure the typography section','wbsl-stronghold'),
		'section'  => 'typography_section',
		'type'     => 'switch',
		'choices' => array(
			'on'  => esc_attr__( 'Enable', 'wbsl-stronghold' ),
			'off' => esc_attr__( 'Disable', 'wbsl-stronghold' )
		),
		'tooltip' => __('Turn on to customize typography and turn off for default typography','wbsl-stronghold'),
		'default'  => 'off',
	) );

$typography_setting = get_theme_mod('custom_typography',false );
if( $typography_setting ) :

        $body_font = get_theme_mod('body_family','Lora');		        
	    $body_color = get_theme_mod( 'body_color','#1e1e1e' );   
		$body_size = get_theme_mod( 'body_size','16');
		$body_weight = get_theme_mod( 'body_weight','regular');
		$body_weight == 'bold' ? $body_weight = '400':  $body_weight = 'regular';
		

	Stronghold_Kirki::add_section( 'body_font', array(
		'title'          => __( 'Body Font','stronghold' ),
		'description'    => __( 'Specify the body font properties', 'wbsl-stronghold'),
		'panel'          => 'typography', // Not typically needed.
	) ); 


	Stronghold_Kirki::add_field( 'stronghold', array(
		'settings' => 'body',
		'label'    => __( 'Body Settings', 'wbsl-stronghold' ),
		'section'  => 'body_font', 
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $body_font,
			'variant'        => $body_weight,
			'font-size'      => $body_size.'px',
			'line-height'    => '1.5',
			'letter-spacing' => '0',
			'color'          => $body_color,
		),
		'output'      => array(
			array(
				'element' => 'body',
				//'suffix' => '!important',
			),
		),
	) );


	Stronghold_Kirki::add_section( 'heading_section', array(
		'title'          => __( 'Heading Font','stronghold' ),
		'description'    => __( 'Specify typography of H1, H2, H3, H4, H5, H6', 'wbsl-stronghold'),
		'panel'          => 'typography', // Not typically needed.
	) );
	

	$h1_font = get_theme_mod('h1_family','Exo');
	$h1_color = get_theme_mod( 'h1_color','#242424' );
	$h1_size = get_theme_mod( 'h1_size','30	');
	$h1_weight = get_theme_mod( 'h1_weight','700');
	$h1_weight == 'bold' ? $h1_weight = '700' : $h1_weight = 'regular';

	Stronghold_Kirki::add_field( 'stronghold', array(
		'settings' => 'h1',
		'label'    => __( 'H1 Settings', 'wbsl-stronghold' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h1_font,
			'variant'        => $h1_weight,
			'font-size'      => $h1_size.'px',
			'line-height'    => '1.8',
			'letter-spacing' => '0',
			'color'          => $h1_color,
		),
		'output'      => array(
			array(
				'element' => 'h1',
			),
		),
		
	) );

	$h2_font = get_theme_mod('h2_family','Exo');
	$h2_color = get_theme_mod( 'h2_color','#242424' );
	$h2_size = get_theme_mod( 'h2_size','36');
	$h2_weight = get_theme_mod( 'h2_weight','700');
	$h2_weight == 'bold' ? $h2_weight = '700' : $h2_weight = 'regular';

	Stronghold_Kirki::add_field( 'stronghold', array(
		'settings' => 'h2',
		'label'    => __( 'H2 Settings', 'wbsl-stronghold' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h2_font,
			'variant'        => $h2_weight,
			'font-size'      => $h2_size.'px',
			'line-height'    => '1.8',
			'letter-spacing' => '0',
			'color'          => $h2_color,
		),
		'output'      => array(
			array(
				'element' => 'h2',
			),
		),
		
	) );

	$h3_font = get_theme_mod('h3_family','Exo');
	$h3_color = get_theme_mod( 'h3_color','#242424' );
	$h3_size = get_theme_mod( 'h3_size','30');
	$h3_weight = get_theme_mod( 'h3_weight','700');
	$h3_weight == 'bold' ? $h3_weight = '700' : $h3_weight = 'regular';

	Stronghold_Kirki::add_field( 'stronghold', array(
		'settings' => 'h3',
		'label'    => __( 'H3 Settings', 'wbsl-stronghold'),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default' => array(
			'font-family'    => $h3_font,
			'variant'        => $h3_weight,
			'font-size'      => $h3_size.'px',
			'line-height'    => '1.8',
			'letter-spacing' => '0',
			'color'          => $h3_color,
		),
		'output'      => array(
			array(
				'element' => 'h3',
			),
		),
		
	) );

	$h4_font = get_theme_mod('h4_family','Exo');
	$h4_color = get_theme_mod( 'h4_color','#242424' );
	$h4_size = get_theme_mod( 'h4_size','24');
	$h4_weight = get_theme_mod( 'h4_weight','700');
	$h4_weight == 'bold' ? $h4_weight = '700' : $h4_weight = 'regular';


	Stronghold_Kirki::add_field( 'stronghold', array(
		'settings' => 'h4',
		'label'    => __( 'H4 Settings', 'wbsl-stronghold' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h4_font,
			'variant'        => $h4_weight,
			'font-size'      => $h4_size.'px',
			'line-height'    => '1.8',
			'letter-spacing' => '0',
			'color'          => $h4_color,
		),
		'output'      => array(
			array(
				'element' => 'h4',
			),
		),
	) );

    $h5_font = get_theme_mod('h5_family','Exo');
	$h5_color = get_theme_mod( 'h5_color','#242424' );
	$h5_size = get_theme_mod( 'h5_size','18');
	$h5_weight = get_theme_mod( 'h5_weight','700');
	$h5_weight == 'bold' ? $h5_weight = '700' : $h5_weight = 'regular';


	Stronghold_Kirki::add_field( 'stronghold', array(
		'settings' => 'h5',
		'label'    => __( 'H5 Settings', 'wbsl-stronghold' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h5_font,
			'variant'        => $h5_weight,
			'font-size'      => $h5_size.'px',
			'line-height'    => '1.8',
			'letter-spacing' => '0',
			'color'          => $h5_color,
		),
		'output'      => array(
			array(
				'element' => 'h5',
			),
		),
		
	) );

	$h6_font = get_theme_mod('h6_family','Exo');
	$h6_color = get_theme_mod( 'h6_color','#242424' );
	$h6_size = get_theme_mod( 'h6_size','16');
	$h6_weight = get_theme_mod( 'h6_weight','700');
	$h6_weight == 'bold' ? $h6_weight = '700' : $h6_weight = 'regular';


	Stronghold_Kirki::add_field( 'stronghold', array(
		'settings' => 'h6',
		'label'    => __( 'H6 Settings', 'wbsl-stronghold' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h6_font,
			'variant'        => $h6_weight,
			'font-size'      => $h6_size.'px',
			'line-height'    => '1.8',
			'letter-spacing' => '0',
			'color'          => $h6_color,
		),
		'output'      => array(
			array(
				'element' => 'h6',
			),
		),
	
	) );

	// navigation font 
	Stronghold_Kirki::add_section( 'navigation_section', array(
		'title'          => __( 'Navigation Font','stronghold' ),
		'description'    => __( 'Specify Navigation font properties', 'wbsl-stronghold'),
		'panel'          => 'typography', // Not typically needed.
	) );

	Stronghold_Kirki::add_field( 'stronghold', array(
		'settings' => 'navigation_font',
		'label'    => __( 'Navigation Font Settings', 'wbsl-stronghold' ),
		'section'  => 'navigation_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => 'Lora',
			'variant'        => '400',
			'font-size'      => '16px',
			'line-height'    => '1.8', 
			'letter-spacing' => '0',
			'color'          => '#ffffff',
		),
		'output'      => array(
			array(
				'element' => '.main-navigation a',
			),
		),
	) );
endif; 


}

