(function( $ ) {

	$(function() {

		docs = $('<a class="stronghold-docs doc"></a>')
			.attr('href','http://www.webulousthemes.com/stronghold-pro/') 
			.attr('target','_blank')
			.text('Documentation');

		support = $('<a class="stronghold-docs question"></a>')
			.attr('href','http://www.webulousthemes.com/support-ticket/')
			.attr('target','_blank')
			.text('Ask a Question');

		$('#customize-info .preview-notice').append(docs);
		$('#customize-info .preview-notice').append(support);

		$('.stronghold-docs').on('click',function(e){
			e.stopPropagation();
		});
		
		
	});

})( jQuery );
