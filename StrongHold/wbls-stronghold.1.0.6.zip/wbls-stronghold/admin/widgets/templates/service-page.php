<div class="services-wrapper clearfix">
        <div class="column"> 
	    	<?php if( has_post_thumbnail() ) : ?>
                <a href="<?php echo esc_url( get_permalink() ); ?>">                  <?php the_post_thumbnail('wbls-stronghold-recent_work_thumb'); ?></a>
	    	<?php endif; ?>
    	    <?php the_title( sprintf( '<h5><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h5>' ); ?>
	    	<?php the_content(); ?>
    	</div>
</div>

