<?php 
/*
	Template Name: Blog Full Width
 */
 	get_header();
get_template_part('breadcrumb'); ?>


	<?php do_action('stronghold_before_content'); ?>

	<div id="content" class="site-content">
		<div class="container">

		<div id="primary" class="content-area sixteen columns">

			<main id="main" class="site-main" role="main">

				<?php
					$query_string ="post_type=post&paged=$paged";
					query_posts($query_string);
					$num_of_posts = $wp_query->post_count;
						
					
 if ( have_posts() ) : 
 /* Start the Loop */ 
	 while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<div class="entry-content">        
				<?php	$featured_image = get_theme_mod('featured_image',true); 
			     if( $featured_image ) : ?>    
					<div class="thumb blog-thumb">
						<?php if( has_post_thumbnail() && ! post_password_required() ) :   
							  the_post_thumbnail('wbls-stronghold-blog-full-width'); 
							endif;
						?>
					</div>
				<?php endif; ?>

				<div class="entry-body">
					<header class="entry-header">
						<div class="entry-meta header-entry-meta">
							<a class="box-title" href="<?php the_permalink(); ?>" rel="bookmark">
							<?php wbls_stronghold_post_date(); ?>  </a>
						</div><!-- .entry-meta -->								
						<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1>
						<?php if ( get_theme_mod('enable_single_post_top_meta',true ) ): ?>
					    <div class="entry-title-meta">
							<?php if(function_exists('wbls_stronghold_entry_top_meta') ) {
							     wbls_stronghold_entry_top_meta();
							} ?>
						</div><!-- .entry-meta -->
				<?php endif; ?>
					</header>

					<?php echo '<div class="blog-content">' . get_the_content() . '</div>'; ?>
				<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
				<footer class="entry-footer">
				<?php if(function_exists('wbls_stronghold_entry_bottom_meta') ) {
				     wbls_stronghold_entry_bottom_meta();
				} ?>
				</footer><!-- .entry-footer -->
			<?php endif;?>	
				</div>

				<?php
					wp_link_pages( array(
						'before' => '<div class="page-links">' . __( 'Pages:', 'wbls-stronghold' ),
						'after'  => '</div>',
					) );
				?>
			</div><!-- .entry-content -->
			
		</article><!-- #post-## -->
     <?php endwhile; ?>

		<?php 
			if(  get_theme_mod ('numeric_pagination',true) && function_exists( 'wbls_stronghold_pagination' ) ) : 
					wbls_stronghold_pagination();
				else :
					wbls_stronghold_posts_nav();          
				endif; 
		?>

		<?php else : ?>

			<?php get_template_part( 'content', 'none' ); ?>

		<?php endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->

		
<?php get_footer(); ?>