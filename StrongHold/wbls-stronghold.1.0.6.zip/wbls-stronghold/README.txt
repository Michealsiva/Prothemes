=== Webulous Stronghold Pro ===
Contributors: webulous
Donate link: http://www.webulousthemes.com/
Tags: comments, spam
Requires at least: 4.0.0
Tested up to: 4.7.1
Stable tag: 1.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin converts free version of Stronghold theme into pro version.

== Description ==

This plugin converts free version of Stronghold theme into pro version.


== Installation ==

1. Upload `wbls-stronghold` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. This is a screen shot

== Changelog == 
= 1.0.6 =
* Merge Custom css option to WP option


= 1.0.5 =
* Fix Tracking code bug
* Fix single clock demo content bug
* Compatible with site origin widget bundle  

= 1.0.4 =
* Added More options
* Customizer Changed to kirki 

= 1.0.3 =
* Style Enhancement & Added More stylesheet

= 1.0.2 =
* Fix License activation issue

= 1.0.1 =
* Change Update file & Enable License Key Activation 

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.6 =
* Merge Custom css option to WP option