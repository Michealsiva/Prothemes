<?php
/**
 * flat functions and definitions
 *
 * @package PolishPro
 */
 
if ( ! function_exists( 'polish_pro_setup' ) ) :  
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function polish_pro_setup() {    

	/**
	 * Set the content width based on the theme's design and stylesheet.
	 */
	if ( ! isset( $content_width ) ) {
		$content_width = 780; /* pixels */
	}
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on flat, use a find and replace
	 * to change 'polish_pro' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'polish_pro', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );  

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	add_editor_style( 'css/editor-style.css' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );   
	add_image_size( 'polish_recent_work', 290 , 250, true );
	add_image_size( 'polish_team_member', 250 , 250, true );
	add_image_size( 'polish_testimonial', 200 , 200, true );
	add_image_size( 'polish_recent-post-img', 380, 200, true);
	add_image_size( 'polish-blog-full-width', 1200,350, true );
	add_image_size( 'polish-small-featured-image-width', 450,350, true );
	add_image_size( 'polish-blog-large-width', 800,350, true );
	add_image_size( 'polish-thumbnail-large', 400,200, true );
	add_image_size( 'polish-thumbnail-small', 130,90, true );
	add_image_size( 'polish-magazine_slider_thumbnail', 800,430, true );
	add_image_size( 'polish-highlighted-post', 550,300, true );   
	add_image_size( 'polish_service-img', 100, 100, true);


	add_image_size( 'polish-service-center-img', 380, 380, true );
	add_image_size( 'polish-service-img', 130,130, true );
	add_image_size( 'polish-recent-posts-img', 230,230, true );
	


	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'polish_pro' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 * See http://codex.wordpress.org/Post_Formats 
	 */
	add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'quote', 'link', 'gallery',  
	) );

	add_theme_support( 'custom-background' );
	

	add_theme_support( 'custom-logo' );

	/* License key - EDD update file */
	
	require_once get_template_directory() . '/pro/updater/theme-updater.php';	
	
}
endif; // polish_pro_setup
add_action( 'after_setup_theme', 'polish_pro_setup' );

/**
 * Register sidebars for this for this theme.
 */
require get_template_directory() . '/pro/class-theme-sidebars.php';
$theme_sidebars = Theme_Sidebars::getInstance();   

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/includes/template-tags.php';
/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/includes/extras.php';
/**
 * Implement the Custom Header feature.
 */
require  get_template_directory()  . '/includes/custom-header.php';
/**
 * Customizer additions.
 */
require get_template_directory() . '/includes/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/includes/jetpack.php';


/**
 * Load Filter and Hook functions
 */
require get_template_directory() . '/includes/hooks-filters.php';

/* Woocommerce support */

add_theme_support('woocommerce');
add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );


remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper');
add_action('woocommerce_before_main_content', 'polish_pro_output_content_wrapper');


function polish_pro_output_content_wrapper() {
	$woocommerce_sidebar = get_theme_mod('woocommerce_sidebar',true ) ;
	if( $woocommerce_sidebar ) {
        $woocommerce_sidebar_column = 'eleven';
    }else {
        $woocommerce_sidebar_column = 'sixteen';
        remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar');
    }
    $page_breadcrumb = get_theme_mod('breadcrumb'); 
    if( empty($page_breadcrumb) && function_exists('woocommerce_breadcrumb')) {
        echo '<div class="breadcrumb-wrap woocommerce-breadcrumb-class" style="margin-bottom: 30px;"><div class="container">';
		   woocommerce_breadcrumb();  
		echo '</div></div>';
    }
	echo '<div class="site-content container" id="content"><div id="primary" class="content-area '. $woocommerce_sidebar_column .' columns">';	
}

remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end' );
add_action( 'woocommerce_after_main_content', 'polish_pro_output_content_wrapper_end' );

function polish_pro_output_content_wrapper_end () {
	echo "</div>";
}

add_action( 'init', 'polish_pro_remove_wc_breadcrumbs' );  
function polish_pro_remove_wc_breadcrumbs() {
   	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}

include_once( get_template_directory() . '/admin/theme-options.php' ); 


/* Webulous Framework add */
 require get_template_directory() . '/framework/framework.php'; 			

/**
 * The core plugin class that is used to load dependencies, define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
if( !class_exists('Polish_Pro_Theme') ) {
   require get_template_directory() . '/pro/class-theme.php'; 		
}
/**
 * Begins execution of the theme.
 *
 * Since everything within the theme is registered via hooks,
 * then kicking off the theme from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_polish_pro() {

	$theme = new Polish_Pro_Theme( 'polish_pro', '1.0.0' );
	$theme->run(); 

}

run_polish_pro();


/* SVG Support */
function genex_svg_mime_support($mimes) {
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter('upload_mimes', 'genex_svg_mime_support');

/*
add_action( 'wp_head','polish_pro_custom_color_scheme' );
function polish_pro_custom_color_scheme() {
  if( get_theme_mod('enable_custom_color_scheme',false) ) {
    
    $custom_css_file = get_template_directory() . '/css/custom.css';

        $old_color_hex = get_theme_mod('previous_custom_color_scheme',"#00c94a");
        $oldcolor = array($old_color_hex,substr(str_replace(',',', ',Kirki_Color::get_rgb($old_color_hex,true)),4,-1));    
        
        $new_color_hex = get_theme_mod('custom_color_scheme',"#00c94a");
      $newcolor = array($new_color_hex,substr(str_replace(',',', ',Kirki_Color::get_rgb($new_color_hex,true)),4,-1));
       
     //chmod(get_template_directory() . '/css/custom.css', 0777);
    //read the entire string
    $str = file_get_contents($custom_css_file);
 
    //replace something in the file string - this is a VERY simple example
    $str = str_replace($oldcolor, $newcolor,$str);

    //write the entire string
    file_put_contents($custom_css_file, $str);
      set_theme_mod('previous_custom_color_scheme',$new_color_hex);

  }
}
*/