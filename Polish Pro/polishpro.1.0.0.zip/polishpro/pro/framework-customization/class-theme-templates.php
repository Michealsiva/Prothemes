<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Polish_Pro_Theme_templates' ) ) {  
	class Polish_Pro_Theme_templates {

        public function polish_pro_cta_template_file( $filename, $instance, $widget  ) {
           return get_stylesheet_directory() . '/pro/framework-customization/widgets/cta.php';  
        }
        public function polish_pro_our_team_template_file( $filename, $instance, $widget  ) {
           return get_stylesheet_directory() . '/pro/framework-customization/widgets/our-team.php';  
        }
        public function polish_pro_recent_post_template_file( $filename, $instance, $widget  ) {
           return get_stylesheet_directory() . '/pro/framework-customization/widgets/recent-post.php';  
        }
	}
}

         
