<?php
$output = '';
$output .= '<div class="callout-widget clearfix">';   
	$output .= '<div class="sixteen columns">';
		$output .= '<h3>' . esc_html( $title ) . '</h3>';
		$output .= do_shortcode( $content );
		$output .= '<p class="cta-btn">';
			if( $cta_url  || $anchor_text ) {
				$output .= '<a href="' . sow_esc_url($cta_url) . '">' . esc_html( $anchor_text ) . '</a>';
			}
		$output .= '</p>';
	$output .= '</div>';  
$output .= '</div>';   
echo apply_filters( 'cta_shortcode_html', $output );     
 