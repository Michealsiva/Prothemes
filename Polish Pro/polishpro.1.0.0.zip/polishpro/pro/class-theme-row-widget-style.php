<?php
/**
   * Created by PhpStorm.
   * User: venkat
   * Date: 26/11/15
   * Time: 11:10 AM
   */
    
if ( ! class_exists('Polish_Pro_So_Row_Widget_Style')) {

    class Polish_Pro_So_Row_Widget_Style {   

        /* Widget */ 

        public function polish_pro_panels_widget_style_fields($fields) {

        } 

        public function polish_pro_panels_panels_widget_style_attributes( $attributes, $args ) {
          
        }  

        public function polish_pro_widget_style_groups( $groups ) {
                   
        }

        /* Commin for widgets & Rows */

        public function polish_pro_css_object($css, $panels_data, $post_id) {       
           
        
        }

         /* Rows */ 

        public function polish_pro_panels_row_style_fields($fields) {
   
      
        }

        public function polish_pro_panels_panels_row_style_attributes( $attributes, $args ) {
        
        }

        public function polish_pro_row_style_groups( $groups ) {
            
        }

    }

}

