<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 *
 * @package Polish Pro
 * @since 1.0
 * @license GPL 2.0   
 */
    
/**    
 * Adds default page layouts
 *
 * Adds default page layouts to SiteOrigin Page Builder prebuilt layout section
 *
 * @param $layouts      
 */
if ( ! class_exists('Polish_Pro_Prebuilt_Layouts')) { 

    class Polish_Pro_Prebuilt_Layouts { 
        public function layouts($layouts) {     
           $layouts['default-home'] = array ( 
				'name' => __('Polish Pro Home', 'polish_pro'),
				'description' => __('Pre Built Layout for  home page', 'polish_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/home.json',

			);

			$layouts['about-us'] = array(
				'name' => __('About Us Page', 'polish_pro'),
				'description' => __( 'Pre Built layout for about us page', 'polish_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/about-us.json',
			);

			$layouts['contact-us'] = array(
				'name' => __('Contact Us Page', 'polish_pro'),
				'description' => __( 'Pre Built layout for contact us page', 'polish_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/contact-us.json',
			);

			$layouts['faq'] = array (
				'name' => __('FAQ Page', 'polish_pro'),
				'description' => __('Pre Built Layout for faq page', 'polish_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/faq.json',
			);
    		return $layouts; 
        }     

    }

}

