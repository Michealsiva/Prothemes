<?php

	$output = '';
	if(! empty( $instance['team-member'] ) ) {
		$output .= '<div class="member-container">'; 
		$output .= '<div class="teammember">';
		
		$output .= '<div class="five columns member-details">';
		$i=1;
			foreach ( $instance['team-member'] as $index => $item ) {
				//$member_image = wp_get_attachment_image_src($item['member_image'],'full');
				if($i ==1) {
					$output .= '<div id="teamhome-'.$i.'" class="staff-desc active">';
				}
				else {
					$output .= '<div id="teamhome-'.$i.'" class="staff-desc">';	
				}
				
					$output .= sprintf( '<div class="heading-block"><h3><strong>%1$s</strong></h3><p>%2$s</p></div>', $item['member_name'], $item['member_designation']);
					$output .= sprintf( '<div class="testimony"><div class="t-inner">%1$s</div></div>', $item['member_content'] );
					//if( ! empty( $instance['member_social_site'] ) ) {   
						$output .= '<div class="team-social">';
						$output .= '<ul>';
						foreach ( $item['member_social_site'] as $index => $site ) {
							$output .= '<li><a href="'. esc_url( $site['profile_url'] ) .'">';
							$output .= siteorigin_widget_get_icon($site['icon']);
							$output .= '</a></li>';
						}
						$output .= '</ul>';  
						$output .= '</div>';  
					//}
				$output .= '</div>';
				$i++;
			}
		$output .= '</div>'; 
			$output .='<div class="eleven columns member-image clearfix">';
				$output .= '<ul class="slides">';
				$i=1;
					foreach ( $instance['team-member'] as $index => $item ) {
						$member_image = wp_get_attachment_image_src($item['member_image'],'full');
						
						if( $member_image ) {
							$output .= '<li>';
							$output .= sprintf( '<div class="member-pic"><a href="#teamhome-'.$i.'"><img src="%1$s"></a></div>', $member_image[0] );
							$output .= '</li>';
						}

						$i++;
					}
				$output .= '</ul>';
			$output .= '</div>';
		$output .= '</div>';
		$output .= '</div>';
	}

	echo $output;