<?php
/*
Widget Name: Polish Pro: Team Member 2
Description: Creates Team Members
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class PolishPro_Team_Member_Widget extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'polishpro-team-member-widget',

			// The name of the widget for display purposes.
			__('Polish Pro Team Member Widget', 'framework'),

			array(
				'description' => __('Display Team Member', 'framework'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/best-sale-product',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

    function initialize_form() {
    	return array(
				'team-member' => array(
					'type' => 'repeater',
					'label' => __( 'PolishPro Team Member' , 'framework' ),
					'item_name'  => __( 'Member item', 'framework' ),
					'item_label' => array(
						'selector'     => "[id*='member_name']",
						'update_event' => 'change',
						'value_method' => 'val'
					),
					'fields' => array(
						'member_name'        => array(
							'type'  => 'text',
							'label' => __( 'Name of team member.', 'framework' )
						),
						'member_designation' => array(
							'type'  => 'text',
							'label' => __( 'Designation of team member.', 'framework' )
						),
						'member_image'       => array(
							'type'     => 'media',
							'label'    => __( 'Picture of team member.', 'framework' ),
							'choose'   => __( 'Choose image', 'framework' ),
							'update'   => __( 'Set image', 'framework' ),
							'library'  => 'image',
						),
						'member_more_url'    => array(
							'type'  => 'link',
							'label' => __( 'Linkable Image', 'framework' ),
						),
						'member_content'     => array(
							'type'  => 'tinymce',
							'label' => __( 'Content', 'framework' ),
							'rows'  => 5,
						),
						'member_social_site' => array(
							'type'      => 'repeater',
							'label'     => __( 'Add a social site', 'framework' ),
							'item_name' => __( 'Social Site', 'framework' ),
							'fields'    => array(
								'site_name'   => array(
									'type'  => 'text',
									'label' => __( 'Social Site name', 'framework' )
								),
								'icon'        => array(
									'type'  => 'icon',
									'label' => __( 'Choose site icon', 'framework' )
								),
								'profile_url' => array(
									'type'  => 'link',
									'label' => __( 'Enter your profile URL', 'framework' )
								),
							),
						),
					),
				)

		);
	}
	 
	function get_template_name($instance) {
		return 'default';
	}

	/*
	function get_template_variables( $instance, $args ) {
		return array(
			'client_testimonial' => ! empty( $instance['client_testimonial'] ) ? $instance['client_testimonial'] : '' ,
			'client_name' => ! empty( $instance['client_name'] ) ? $instance['client_name'] : '' ,
			'client_company' => ! empty( $instance['client_company'] ) ? $instance['client_company'] : '' ,
			'client_website' => ! empty( $instance['client_website'] ) ? $instance['client_website'] : '' ,
		);
	}
	*/

	function get_style_name($instance) {
		return '';
	}

} // class PolishPro_Team_Member_Widget

siteorigin_widget_register('polishpro-team-member-widget', __FILE__, 'PolishPro_Team_Member_Widget');