<?php

if ( ! class_exists( 'Polish_Pro_Widgets' ) ) {

	class Polish_Pro_Widgets {

	    /* Inclue All Widget folders */
	    public function Polish_Pro_get_widgets_folder( $folders ) {
	    	$sow_path = WP_PLUGIN_DIR . '/so-widgets-bundle/widgets/';
			$current_settings = get_option( 'siteorigin_panels_settings', array() );
			/* if( empty($current_settings['widget_bundle_widgets']) ) {
				if( $sow_path === $folders[0] ) {
				   unset($folders[0]);    
			    }   
			} */   
			 
			$folders[] = get_template_directory() . '/pro/widgets/';
			return $folders;
		} 

	    /* Site Origin Widget Bundle Webulous widgets Group & Tab */
		public function Polish_Pro_add_widgets_group($widgets) {
				$polish_pro_widgets = array(
				    'PolishPro_Team_Member_Widget',
				);
				foreach($polish_pro_widgets as $polish_pro_widget) {
					if( isset( $widgets[$polish_pro_widget] ) ) {
						$widgets[$polish_pro_widget]['groups'] = array('theme');
					}
				} 
				return $widgets;
		}   
    

		public function Polish_Pro_filter_active_widgets($active){
			$active_widgets = array(
				'polishpro-team-member-widget',
			);
			
			foreach ($active_widgets as $value ) {
			   $active[$value] = true;
			} 
		   
		    return $active;
		}   

	}
	
}


