<?php
/**
 * @package PolishPro
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		
		<?php
		$single_featured_image = get_theme_mod( 'single_featured_image',true );
		$single_featured_image_size = get_theme_mod ('single_featured_image_size',1);
		if (isset($single_featured_image_size) && $single_featured_image_size != 3  && $single_featured_image ) { ?>
		    <div class="post-thumb blog-thumb"><?php
			    if( has_post_thumbnail() && ! post_password_required() ) : 
			        if ( $single_featured_image_size == 1 ) : 
						the_post_thumbnail('polish-blog-large-width'); 
				    else: 
						the_post_thumbnail('polish-small-featured-image-width');		
					endif;
			    endif;?>
		    </div><?php
		} ?>

 		<div class="latest-content">
			<div class="entry-date"> 
				<span class="date-structure">
					<h2 class="dd"><?php echo get_the_time('j');?></h2>
					<span class="month"><?php echo get_the_time('M');?></span>
					<span class="year"><?php echo get_the_time('Y');?></span>
				</span>
			</div>
        	<header class="header-content">
        		<div class="title-meta">
		        	<h3 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h3>
						<?php if ( get_theme_mod('enable_single_post_top_meta', true ) ): ?>
							<div class="entry-meta">
								<?php if(function_exists('polish_pro_entry_top_meta') ) {
								    polish_pro_entry_top_meta(); 
								} ?> 
							</div>
				</div>
				<?php endif;
					do_action('polish_pro_entry_header_after'); 

		
				/* translators: %s: Name of current post */?>
				<div class="entry-content">   
					<?php the_content();
			
					wp_link_pages( array(
						'before' => '<div class="page-links">' . __( 'Pages:', 'polish_pro' ),
						'after'  => '</div>',
					) );
					?>
				</div>
			 
			</header>
			<br class="clear" />
		</div>
		    

   <?php do_action('polish_pro_entry_footer_before'); ?>

		<?php if ( get_theme_mod('enable_single_post_bottom_meta', false ) ): ?>
			<footer class="entry-footer">
				<?php if(function_exists('polish_pro_entry_bottom_meta') ) {
				     polish_pro_entry_bottom_meta();
				} ?>
			</footer><!-- .entry-footer -->
		<?php endif; ?>

    <?php do_action('polish_pro_entry_footer_after'); ?> 
    <?php if( get_theme_mod ('social_sharing_box',true)): ?>
		<div class="share-box">
			<h4><?php _e( 'Share This Post : ', 'polish_pro' ); ?></h4>
			<ul>
				<?php if( get_theme_mod('facebook_sb',true) ): ?>
				<li>
					<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php the_title(); ?>">
						<i class="fa fa-facebook"></i>
					</a>
				</li>
				<?php endif; ?>
				<?php if( get_theme_mod('twitter_sb',true)): ?>
				<li>
					<a href="http://twitter.com/intent/tweet?url=<?php the_permalink(); ?>">
						<i class="fa fa-twitter"></i>
					</a>
				</li>
				<?php endif; ?>
				<?php if( get_theme_mod('linkedin_sb',true)): ?>
				<li>
					<a href="http://linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>">
						<i class="fa fa-linkedin"></i>
					</a>
				</li>
				<?php endif; ?>

				<?php if(get_theme_mod('google-plus_sb',true)): ?>
				<li>
					<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>">
						<i class="fa fa-google-plus"></i>
					</a>
				</li>
				<?php endif; ?>
				<?php if( get_theme_mod ('email_sb',true)): ?>
				<li>
					<a href="mailto:?subject=<?php the_title(); ?>&amp;body=<?php the_permalink(); ?>">
						<i class="fa fa-envelope"></i>
					</a>
				</li>
				<?php endif; ?>
			</ul>
		</div>
	<?php endif; ?> 

<?php polish_pro_post_nav(); ?>
</article><!-- #post-## -->

	
