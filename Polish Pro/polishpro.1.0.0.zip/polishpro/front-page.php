<?php 
/**
 * The front page template file.
 *
 *
 * @package PolishPro 
 */
$page_sidebar_layout = get_post_meta( $post->ID, '_gx_pagesidebar_layout', true ); 
	if( 'posts' == get_option('show_on_front') ) {  
		get_template_part('home');
	}else{ 
        get_header();     

		do_action('polish_pro_content_before'); ?>

		<div id="content" class="site-content"> 
			<div class="container"><?php

			do_action('polish_pro_primary_before'); ?> 

				<div id="primary" class="content-area <?php polish_pro_primary_class(); ?> columns">

				   <main id="main" class="site-main" role="main"><?php
				      
						while ( have_posts() ) : the_post();
							the_content();    
						endwhile; 
				     ?>
			        </main><!-- #main -->

			    </div><!-- #primary --><?php

            do_action('polish_pro_primary_after');
			
			get_footer();  
	}
