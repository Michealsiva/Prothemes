(function($){
	// Sticky Header Options 

	$(window).scroll(function() {
		if (screen.width > 780) {
			if ($(this).scrollTop() > 150){  
		        $('.site-header').addClass("sticky-nav");
		        $('.home .site-content').css("top",($('.site-header').height() -2 ) );
		       	$('.breadcrumb').css("top",($('.site-header').height() -2 ) );
		       	$('.breadcrumb').css("margin-bottom",($('.site-header').height() -2 ) );
		        $('.site-footer').css("margin-top",($('.site-header').height() -2 ) );
		       
		    }
		    else{
		      	$('.site-header').removeClass("sticky-nav");
		      	$('.home .site-content').css("top",(0) );
		       	$('.breadcrumb').css("top",(0));
		       	$('.breadcrumb').css("margin-bottom",(0));
		        $('.site-footer').css("margin-top",($('.site-header').height() -2 ) );
		    }
	        	
	    }
	   }); 

})(jQuery); 