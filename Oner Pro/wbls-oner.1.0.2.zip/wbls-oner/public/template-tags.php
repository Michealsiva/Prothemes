<?php 


	add_image_size( 'wbls-oner-recent_posts_img', 600, 300, true );
    add_image_size( 'wbls-oner-recent_posts_slider_img', 1125, 430, true );
    add_image_size( 'wbls-oner-blog-full-width', 1200,350, true );
	add_image_size( 'wbls-oner-small-featured-image-width', 450,300, true );
	add_image_size( 'wbls-oner-blog-large-width', 800,300, true ); 
	add_image_size( 'wbls-oner-recent_page_img', 150, 150, true ); 
	add_image_size( 'portfolio4col', 290,200); 
	add_image_size( 'portfolio3col',350,230); 
	add_image_size( 'portfolio2col',600,400); 

// portfolio paging nav //

	if ( ! function_exists( 'wbls_fw_paging_nav' ) ) :
		/**
		 * Display navigation to next/previous set of posts when applicable.
	 	 */
		function wbls_fw_paging_nav() {
			// Don't print empty markup if there's only one page.
			if ( $GLOBALS['wp_query']->max_num_pages < 2 ) {
				return;
			}
			?>
			<nav class="navigation paging-navigation clearfix" role="navigation">
				<h1 class="screen-reader-text"><?php _e( 'Posts navigation', 'wbls-oner' ); ?></h1>  
				<div class="nav-links">

					<?php if ( get_next_posts_link() ) : ?>
						<div class="nav-previous"><?php next_posts_link( __( '<span class="meta-nav"><span>&larr;</span></span> Older posts', 'wbls-oner' ) ); ?></div>
			 		<?php endif; ?>

					<?php if ( get_previous_posts_link() ) : ?>
						<div class="nav-next"><?php previous_posts_link( __( 'Newer posts <span class="meta-nav"><span>&rarr;</span></span>', 'wbls-oner' ) ); ?></div>
					<?php endif; ?>

				</div><!-- .nav-links -->
			</nav><!-- .navigation -->
			<?php
		}
	endif;

	if ( ! function_exists( 'wbls_oner_posted_on' ) ) :   
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function wbls_oner_posted_on() {
	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';
	}

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

	$posted_on = sprintf(
		_x( '%s', 'post date', 'wbls-oner' ),
		'<i class="fa fa-clock-o"></i> <span><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a></span>'
	);

	$byline = sprintf(
		_x( '%s', 'post author', 'wbls-oner' ),
		'<i class="fa fa-user"></i> <span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	echo '<span class="posted-on">' . $posted_on . '</span><span class="byline"> ' . $byline . '</span>';
	edit_post_link( __( 'Edit', 'wbls-oner' ), ' <span class="edit-link"><i class="fa fa-pencil"></i>', '</span>' );

}
endif;

if ( ! function_exists( 'wbls_oner_entry_footer' ) ) :
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function wbls_oner_entry_footer() {   
	// Hide category and tag text for pages.
	if ( 'post' == get_post_type() ) {
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( __( ', ', 'wbls-oner' ) );
		if ( $categories_list && oner_categorized_blog() ) {
			printf( ' <span class="cat-links"><i class="fa fa-folder-open"></i>' . __( '%1$s ', 'wbls-oner' ) . '</span>', $categories_list );
		}

		/* translators: used between list items, there is a space after the comma */
		$tags_list = get_the_tag_list( '', __( ', ', 'wbls-oner' ) );
		if ( $tags_list ) {
			printf( '<span class="tags-links"><i class="fa fa-tags"></i> ' . __( '%1$s ', 'wbls-oner' ) . '</span>', $tags_list );
		}
	}

	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		echo '<span class="comments-link">';
		comments_popup_link( __( '<i class="fa fa-comments"></i>Leave a comment', 'wbls-oner' ), __( '<i class="fa fa-comments"></i> 1 Comment', 'wbls-oner' ), __( '<i class="fa fa-comments"></i> % Comments', 'wbls-oner' ) );
		echo '</span>';
	}
}
endif;




	if( ! function_exists( 'wbls_fw_pagination' )) {
		/**
		 * Generates Pagination without WP-PageNavi Plugin
		 */

		function wbls_fw_pagination($before = '', $after = '') {
			global $wpdb, $wp_query;
			$request = $wp_query->request;
			$posts_per_page = intval(get_query_var('posts_per_page'));
			$paged = intval(get_query_var('paged'));
			$numposts = $wp_query->found_posts;
			$max_page = $wp_query->max_num_pages;
			if ( $numposts <= $posts_per_page ) { return; }
			if(empty($paged) || $paged == 0) {
				$paged = 1;
			}
			$pages_to_show = 7;
			$pages_to_show_minus_1 = $pages_to_show-1;
			$half_page_start = floor($pages_to_show_minus_1/2);
			$half_page_end = ceil($pages_to_show_minus_1/2);
			$start_page = $paged - $half_page_start;
			if($start_page <= 0) {
				$start_page = 1;
			}
			$end_page = $paged + $half_page_end;
			if(($end_page - $start_page) != $pages_to_show_minus_1) {
				$end_page = $start_page + $pages_to_show_minus_1;
			}
			if($end_page > $max_page) {
				$start_page = $max_page - $pages_to_show_minus_1;
				$end_page = $max_page;
			}
			if($start_page <= 0) {
				$start_page = 1;
			}
			echo $before.'<nav class="page-navigation"><ol class="oner_page_navi pagination">'."";
			if ($start_page >= 2 && $pages_to_show < $max_page) {
				$first_page_text = __( "First", 'wbls-oner' );
				echo '<li class="bpn-first-page-link "><a href="'.get_pagenum_link().'" title="'.$first_page_text.'">'.$first_page_text.'</a></li>';
			}
			echo '<li class="bpn-prev-link">';
			previous_posts_link('&nbsp;');
			echo '</li>';
			for($i = $start_page; $i  <= $end_page; $i++) {
				if($i == $paged) {
					echo '<li class="bpn-current">'.$i.'</li>';
				} else {
					echo '<li><a href="'.get_pagenum_link($i).'">'.$i.'</a></li>';
				}
			}
			echo '<li class="bpn-next-link ">';
			next_posts_link('&nbsp;');
			echo '</li>';
			if ($end_page < $max_page) {
				$last_page_text = __( "Last", 'wbls-oner' );
				echo '<li class="bpn-last-page-link"><a href="'.get_pagenum_link($max_page).'" title="'.$last_page_text.'">'.$last_page_text.'</a></li>';
			}
			echo '</ol></nav>'.$after."";
	    }
	} /* wbls_pagination */

	
//  Readmore button html wrapper //

function wbls_oner_add_more_link_class_wrapper( $link, $text  ) {

	$html = '';

		$html .= '<p class="portfolio-readmore"><a class="more-link "' . $link . '</a></p>';

	return $html;
}
add_filter( 'the_content_more_link', 'wbls_oner_add_more_link_class_wrapper', 10, 2 );
 

 add_action( 'wbls_fw_portfolio_before_breadcrumbs', 'wbls_oner_portfolio_before_breadcrumbs' );

if( ! function_exists('wbls_oner_portfolio_before_breadcrumbs') ) {
	function wbls_oner_portfolio_before_breadcrumbs() {
		$output = '';
		$output .= '<div class="breadcrumb"><div class="container"><div class="breadcrumb-left eight columns"><h4>';
	    $output .=  get_the_title(); 
	    $output .= '</h4></div>';
	    $breadcrumb = get_theme_mod( 'breadcrumb',true ); 
	    if( $breadcrumb ) :	
			$output .='<div class="breadcrumb-right eight columns">'; 
		endif;	
		echo $output;    
	}
}


add_action( 'wbls_fw_portfolio_after_breadcrumbs', 'wbls_oner_portfolio_after_breadcrumbs' );

if( ! function_exists('wbls_oner_portfolio_after_breadcrumbs') ) {
	function wbls_oner_portfolio_after_breadcrumbs() {
		$output = '';
		$breadcrumb = get_theme_mod( 'breadcrumb',true ); 
	    if( $breadcrumb ) :	
	       $output .= '</div>';
	    endif;					
	    $output .= '</div></div>';
		echo $output;
		do_action('oner_before_content');	
         
	}
}


add_action( 'wbls_fw_portfolio_breadcrumbs', 'wbls_oner_portfolio_breadcrumbs' );

if( ! function_exists('wbls_oner_portfolio_breadcrumbs') ) {
	function wbls_oner_portfolio_breadcrumbs() {
		$breadcrumb = get_theme_mod( 'breadcrumb',true ); 
	    if( $breadcrumb ) :
          oner_breadcrumbs();
        endif;
	}
}


add_filter('siteorigin_panels_css_row_margin_bottom','wbls_oner_panels_css_row_margin_bottom');

function wbls_oner_panels_css_row_margin_bottom( $panels_margin_bottom ) {
	if ( $panels_margin_bottom == '30px' ) {
		 $panels_margin_bottom = '100px';
	}else {
		$panels_margin_bottom = $panels_margin_bottom;
	}
	return $panels_margin_bottom;
} 


// Related Posts Function (call using wbls_oner_related_posts(); ) /NecessarY/ May be write a shortcode?
function wbls_oner_related_posts() {

		echo '<ul id="webulous-related-posts">';
		global $post;
		$post_hierarchy = get_theme_mod('related_posts_hierarchy','1');
		$relatedposts_per_page  =  get_option('post_per_page') ;
		if($post_hierarchy == '1') {
			$related_post_type = wp_get_post_tags($post->ID);
			$tag_arr = '';
			if($related_post_type) {
				foreach($related_post_type as $tag) { 
					$tag_arr .= $tag->slug . ',';
			    }
		        $args = array(
		        	'tag' =>  esc_html( $tag_arr ),
		        	'numberposts' => intval( $relatedposts_per_page ), /* you can change this to show more */
		        	'post__not_in' => array($post->ID)
		     	);
		   }
		}else {
			$related_post_type = get_the_category($post->ID); 
			if ($related_post_type) {
				$category_ids = array();
				foreach($related_post_type as $category) {
				     $category_ids = $category->term_id; 
				}  
				$args = array(
					'category__in' => absint($category_ids),
					'post__not_in' => array($post->ID),
					'numberposts' => intval( $relatedposts_per_page ), 
		        );
		    }
		}
		if( $related_post_type ) {
	        $related_posts = get_posts($args);
	        if($related_posts) {
	        	foreach ($related_posts as $post) : setup_postdata($post); ?>
		           	<li class="related_post">
		           		<a class="entry-unrelated" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('recent-work'); ?></a>
		           		<a class="entry-unrelated" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
		           	</li>
		        <?php endforeach; }
		    else {
	            echo '<li class="no_related_post">' . __( 'No Related Posts Yet!', 'wbls-oner' ) . '</li>'; 
			 }
		}else{
			echo '<li class="no_related_post">' . __( 'No Related Posts Yet!', 'wbls-oner' ) . '</li>';
		}
		wp_reset_query();
		
		echo '</ul>';

}
 

function wbls_oner_get_author() {
	$byline = sprintf(
		_x( '%s', 'post author', 'wbls-oner' ),
		'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"> ' . esc_html( get_the_author() ) . '</a></span>'
	);	

	return $byline;
}


function wbls_oner_get_comments_meta() {
	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		$comments_meta = '<span class="comments-link"><i class="fa fa-comments"></i>';
		$comments_meta .= get_comments_popup_link( __( 'Leave a comment', 'wbls-oner' ), __( '1 Comment', 'oner' ), __( '% Comments', 'wbls-oner' ) );
		$comments_meta .=  '</span>';
		return $comments_meta;

	}	
}

/* Blog meta data options */

if ( ! function_exists( 'wbls_oner_entry_top_meta' ) ) : 
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function wbls_oner_entry_top_meta() {   
	// Post meta data 
	
	  $single_post_top_meta = get_theme_mod('single_post_top_meta', array(1,2,6) );

	if ( 'post' == get_post_type() ) {  
		foreach ($single_post_top_meta as $key => $value) {
		    if( $value == 1) { ?>
		  	    <span class="date-structure">				
					<span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-clock-o"></i><?php the_time('j M Y'); ?></a></span>	
				</span>
	<?php   }elseif( $value == 2) {
				printf(
					_x( '%s', 'post author', 'wbls-oner' ),
					'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"><i class="fa fa-user"></i> ' . esc_html( get_the_author() ) . '</a></span>'
				);	
			}elseif( $value == 3)  {
				if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
					echo ' <span class="comments-link"><i class="fa fa-comments"></i>';
					comments_popup_link( __( 'Leave a comment', 'wbls-oner' ), __( '1 Comment', 'wbls-oner' ), __( '% Comments', 'wbls-oner' ) );
					echo '</span>';
			    }
	        }elseif( $value == 4) {
				$categories_list = get_the_category_list( __( ', ', 'wbls-oner' ) );
				if ( $categories_list ) {
					printf( '<span class="cat-links"><i class="fa fa-folder-open"></i> ' . __( '%1$s ', 'wbls-oner' ) . '</span>', $categories_list );
				}	
		    }elseif( $value == 5)  {
	    		/* translators: used between list items, there is a space after the comma */
				$tags_list = get_the_tag_list( '', __( ', ', 'wbls-oner' ) );
				if ( $tags_list ) {
					printf( '<span class="tags-links"><i class="fa fa-tags"></i> ' . __( '%1$s ', 'wbls-oner' ) . '</span>', $tags_list );
				}			
		    }elseif( $value == 6) {
		        edit_post_link( __( 'Edit', 'wbls-oner' ), '<span class="edit-link"><i class="fa fa-pencil"></i> ', '</span>' );
		    }
	    }
	}
}

endif;
if ( ! function_exists( 'wbls_oner_entry_bottom_meta' ) ) : 
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function wbls_oner_entry_bottom_meta() {   
	// Post meta data 
	
	$single_post_bottom_meta = get_theme_mod('single_post_bottom_meta', array(3,4,5) );

	if ( 'post' == get_post_type() ) {  
		foreach ($single_post_bottom_meta as $key => $value) {
		    if( $value == 1) { ?>
		  	    <span class="date-structure">				
					<span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-clock-o"></i><?php the_time('j M Y'); ?></a></span>	
				</span>
	<?php   }elseif( $value == 2) {
				printf(
					_x( '%s', 'post author', 'wbls-oner' ),
					'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"><i class="fa fa-user"></i> ' . esc_html( get_the_author() ) . '</a></span>'
				);	
			}elseif( $value == 3)  {
				if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
					echo ' <span class="comments-link"><i class="fa fa-comments"></i>';
					comments_popup_link( __( 'Leave a comment', 'wbls-oner' ), __( '1 Comment', 'wbls-oner' ), __( '% Comments', 'wbls-oner' ) );
					echo '</span>';
			    }
	        }elseif( $value == 4) {
				$categories_list = get_the_category_list( __( ', ', 'wbls-oner' ) );
				if ( $categories_list ) {
					printf( '<span class="cat-links"><i class="fa fa-folder-open"></i> ' . __( '%1$s ', 'wbls-oner' ) . '</span>', $categories_list );
				}	
		    }elseif( $value == 5)  {
	    		/* translators: used between list items, there is a space after the comma */
				$tags_list = get_the_tag_list( '', __( ', ', 'wbls-oner' ) );
				if ( $tags_list ) {
					printf( '<span class="tags-links"><i class="fa fa-tags"></i> ' . __( '%1$s ', 'wbls-oner' ) . '</span>', $tags_list );
				}			
		    }elseif( $value == 6) {
		        edit_post_link( __( 'Edit', 'wbls-oner' ), '<span class="edit-link"><i class="fa fa-pencil"></i> ', '</span>' );
		    }
	    }
	}
}

endif;

/*  Site Layout Option  */
if ( ! function_exists( 'wbls_oner_layout_class' ) ) {
	function wbls_oner_layout_class() {
	     $sidebar_position = get_theme_mod( 'sidebar_position', 'right' ); 
		     if( 'fullwidth' == $sidebar_position ) {
		     	echo 'sixteen';
		     }elseif('two-sidebar' == $sidebar_position || 'two-sidebar-left' == $sidebar_position || 'two-sidebar-right' == $sidebar_position ) {
		     	echo 'eight';
		     }
		     else{
		     	echo 'eleven';
		     }
		     if ( 'no-sidebar' == $sidebar_position ) {
		     	echo ' no-sidebar';
		     }
	}
}


/* Two Sidebar Left action */

add_action('wbls_oner_two_sidebar_left','wbls_oner_double_sidebar_left'); 

    if ( ! function_exists( 'wbls_oner_double_sidebar_left' ) ) {
		 function wbls_oner_double_sidebar_left() {
		    $sidebar_position = get_theme_mod( 'sidebar_position', 'right' ); 
				if( 'two-sidebar' == $sidebar_position || 'two-sidebar-left' == $sidebar_position ) :
					 get_sidebar('left'); 
				endif; 
				if('two-sidebar-left' == $sidebar_position || 'left' == $sidebar_position ):
					get_sidebar(); 
				endif;
		 }
	}	    

/* Two Sidebar Right action */

 add_action('wbls_oner_two_sidebar_right','wbls_oner_double_sidebar_right'); 	

 if ( ! function_exists( 'wbls_oner_double_sidebar_right' ) ) {
    function wbls_oner_double_sidebar_right() {
  	    $sidebar_position = get_theme_mod( 'sidebar_position', 'right' ); 
		 if( 'two-sidebar' == $sidebar_position || 'two-sidebar-right' == $sidebar_position || 'right' == $sidebar_position) :
			 get_sidebar(); 
		endif; 	
		if('two-sidebar-right' == $sidebar_position ):
			get_sidebar('left'); 
		endif;   	
    }
}


/* dynamic sidebar for pro */

add_action('init','wbls_oner_dynamic_sidebar');
if( !function_exists('wbls_oner_dynamic_sidebar') ) { 
	function wbls_oner_dynamic_sidebar() {
		remove_action('oner_sidebar_right_widget','oner_sidebar_right_widget');
		add_action('oner_sidebar_right_widget','wbls_oner_dynamic_sidebar_right_widget');

		if( !function_exists('wbls_oner_dynamic_sidebar_right_widget') ) { 
			function wbls_oner_dynamic_sidebar_right_widget() {

				if( function_exists('generated_dynamic_sidebar') ) {
				    generated_dynamic_sidebar();
			    }elseif ( is_active_sidebar( 'sidebar-1' ) ) {
					 dynamic_sidebar('sidebar-1');
				}else { ?>
					<aside id="meta" class="widget">
						<h4 class="widget-title"><?php _e( 'Meta', 'oner' ); ?></h4>
						<ul>
							<?php wp_register(); ?>
							<li><?php wp_loginout(); ?></li>
							<?php wp_meta(); ?>
						</ul>
			        </aside><?php 
			    }  
			}
		}
    }
}
  
/* recent work widgets add options */

function wbls_oner_recent_work_widgets_add_option( $widget, $return, $instance ) {
  
    // widget id 
    if ( 'recent-work-widget' == $widget->id_base ) { 

        // Display the description option.    
		$portfolio_cat = isset( $instance['portfolio_cat'] ) ? $instance['portfolio_cat'] : '';
		$portfolio_skill = isset( $instance['portfolio_skill'] ) ? $instance['portfolio_skill'] : '';
		$portfolio_column = isset( $instance['portfolio_column'] ) ? $instance['portfolio_column'] : 4 ;

		?>      <p>   
				    <label for="<?php echo $widget->get_field_id('portfolio_cat') ?>"><?php _e(' Select Category ', 'wbls-oner') ?></label>
					<?php wp_dropdown_categories( array( 'name' => $widget->get_field_name( 'portfolio_cat' ), 'show_option_all' => 'All Category', 'selected' => $portfolio_cat ) ); ?>
				</p>  
				<p>
					<label for="<?php echo $widget->get_field_id('portfolio_skill') ?>"><?php _e(' Select Skill ', 'wbls-oner') ?></label>
					<?php wp_dropdown_categories( array( 'name' => $widget->get_field_name( 'portfolio_skill' ),  'show_option_all' => 'All Skills', 'taxonomy' => 'skills', 'selected' =>  $instance['portfolio_skill'] ) ); ?>
				</p> 
	            <p>
					<label for="<?php echo $widget->get_field_id('portfolio_column') ?>"><?php _e('Select Portfolio Column ', 'wbls-oner') ?></label>
					<select id="<?php echo $widget->get_field_id('portfolio_column') ?>" name="<?php echo $widget->get_field_name('portfolio_column') ?>">
						<option value="4" <?php selected($portfolio_column, "4") ?>>Four Column</option>
						<option value="3" <?php selected($portfolio_column, "3") ?>>Three Column</option>
						<option value="2" <?php selected($portfolio_column, "2") ?>>Two Column</option>
					</select>  
				</p>    
        <?php 
    } 
}             
add_filter('in_widget_form', 'wbls_oner_recent_work_widgets_add_option', 10, 3 );   

function wbls_oner_recent_work_widgets_save_option( $instance, $new_instance ) {
    $instance['portfolio_cat'] = ( ! empty( $new_instance['portfolio_cat'] ) ) ? strip_tags( $new_instance['portfolio_cat'] ) : '';
    $instance['portfolio_skill'] = ( ! empty( $new_instance['portfolio_skill'] ) ) ? strip_tags( $new_instance['portfolio_skill'] ) : '';
    $instance['portfolio_column'] = ( ! empty( $new_instance['portfolio_column'] ) ) ? strip_tags( $new_instance['portfolio_column'] ) : '';
 	
    return $instance;         
}  

add_filter( 'widget_update_callback', 'wbls_oner_recent_work_widgets_save_option', 10, 3 );

/* Remove Oner welcome page notification */

add_action( 'load-themes.php',  'wbls_oner_one_activation_admin_notice' ,11 ); 

function wbls_oner_one_activation_admin_notice() {  
	remove_action( 'admin_notices', 'oner_admin_notice' );
}