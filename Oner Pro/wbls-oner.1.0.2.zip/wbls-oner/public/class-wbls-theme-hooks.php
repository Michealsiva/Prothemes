<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 4:55 PM
	 */
if( ! class_exists( 'Wbls_Theme_Hooks' )) {
	class Wbls_Theme_Hooks {

		public function full_width_slider(){
			global $post;
			$slider_shortcode = get_post_meta( $post->ID, '_wbls_slider_shortcode', true );
			if( $slider_shortcode != '' ) {
				echo '<div class="page-slider">';
				echo do_shortcode( $slider_shortcode );
				echo '</div>';
			}
		}
		
		public function single_portfolio($single_template){
		    global $post;
			if( $post->post_type == 'portfolio') {
				$single_template = WBLS_THEME_DIR . 'public/views/single-portfolio.php';
				if( file_exists($single_template) && is_file($single_template) ) {
					 $single_template;
				} else {
					if( defined( 'WBLS_FW_DIR' ) ) {
						$single_template = WBLS_FW_DIR . 'public/views/single-portfolio.php';	
						if( is_file($single_template) && file_exists( $single_template ) ) {
                            $single_template;
						}
					}
					
				}
			}
			return $single_template;
		}
		
		public function single_post($single_template){    
		    global $post;
		    $post_fullwidth = get_post_meta( $post->ID, '_wbls_full_width_post', true );
			if( $post->post_type == 'post') {
				if ( $post_fullwidth ){
					$single_template = WBLS_THEME_DIR . 'public/views/single-post-fullwidth.php';
				    if( file_exists($single_template) && is_file($single_template) ) {
					    $single_template;
				    } 
				}
			}
			return $single_template;
		}

		public function portfolio_views($file){        
			global $post;
		    $file = WBLS_THEME_DIR . 'public/views/' . get_post_meta( $post->ID, '_wp_page_template', true );
			return $file;
		}

		public function customizer_options($free_options) {     
			$pro_options = array(
	            // typography start //
	            'typography' => array(   
	                'priority'       => 10,
	                'title'          => __('Typography', 'wbls-oner'),
	                'description'    => __('Typography and Link Color Settings', 'wbls-oner'),
	                'sections' => array(
	                    'typography_section' => array(
	                        'title' => __('General Settings', 'wbls-oner'),
	                        'fields' => array(
	                            'custom_typography' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Custom Typography', 'wbls-oner'),
	                                'description' => __('Turn on to customize typography and turn off for default typography.', 'wbls-oner'),
	                                'default' => 0,
	                            ),

	                        ),    
	                    ),

	                    'body_font' => array(
	                        'title' => __('Body Font','wbls-oner'),
	                        'description' => __('Specify the body font properties.','wbls-oner'),
	                        'fields' => array (
	                        	'body_custom_typography' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Body Custom Typography', 'wbls-oner'), 
	                                'default' => 0,
	                            ),
	                            'body' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-oner'),
	                            ),
	                            'body_color' => array(
	                                'type' => 'color',
	                                'label' => __('Body Color', 'wbls-oner'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#282827'
	                            ),
	                        ),
	                    ),
	                    'h1_property' => array(
	                        'title' => __('H1 Font Properties','wbls-oner'),
	                        'description' => __('Specify the h1 font properties.','wbls-oner'),
	                        'fields' => array (
	                        	'h1_custom_typography' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable H1 Custom Typography', 'wbls-oner'), 
	                                'default' => 0,
	                            ),
	                            'h1' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-oner'),
	                            ),
	                            'h1_color' => array(
	                                'type' => 'color',
	                                'label' => __('H1 Color', 'wbls-oner'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#282827'
	                            ),
	                        ),
	                    ),
	                    'h2_property' => array(
	                        'title' => __('H2 Font Properties','wbls-oner'),
	                        'description' => __('Specify the h2 font properties.','wbls-oner'),
	                        'fields' => array (
		                        	'h2_custom_typography' => array(
		                                'type' => 'checkbox',
		                                'label' => __('Enable H2 Custom Typography', 'wbls-oner'), 
		                                'default' => 0,
		                            ),
	                                'h2' => array(
	                                    'type' => 'typography',
	                                    'label' => __('', 'wbls-oner'),
	  
	                                ),
	                                'h2_color' => array(
	                                    'type' => 'color',
	                                    'label' => __('H2 Color', 'wbls-oner'),
	  
	                                    'sanitize_callback' => 'sanitize_hex_color',
	                                    'transport' => 'postMessage',
	                                    'default' => '#282827'
	                                )
	                        ),
	                    ),
	                    'h3_property' => array(
	                        'title' => __('H3 Font Properties','wbls-oner'),
	                        'description' => __('Specify the h3 font properties.','wbls-oner'),
	                        'fields' => array (
		                        	'h3_custom_typography' => array(
		                                'type' => 'checkbox',
		                                'label' => __('Enable H3 Custom Typography', 'wbls-oner'), 
		                                'default' => 0,
		                            ),
	                                'h3' => array(
	                                    'type' => 'typography',
	                                    'label' => __('', 'wbls-oner'),
	  
	                                ),
	                                'h3_color' => array(
	                                    'type' => 'color',
	                                    'label' => __('H3 Color', 'wbls-oner'),
	  
	                                    'sanitize_callback' => 'sanitize_hex_color',
	                                    'transport' => 'postMessage',
	                                    'default' => '#282827'     
	                                )
	                        ),
	                    ),
	                    'h4_property' => array(
	                        'title' => __('H4 Font Properties','wbls-oner'),
	                        'description' => __('Specify the h4 font properties.','wbls-oner'),
	                        'fields' => array (
	                        	'h4_custom_typography' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable H4 Custom Typography', 'wbls-oner'), 
	                                'default' => 0,
	                            ),
	                            'h4' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-oner'),
	                            ),
	                            'h4_color' => array(
	                                'type' => 'color',
	                                'label' => __('H4 Color', 'wbls-oner'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#282827'
	                            )
	                        ),
	                    ),
	                    'h5_property' => array(
	                        'title' => __('H5 Font Properties','wbls-oner'),
	                        'description' => __('Specify the h5 font properties.','wbls-oner'),
	                        'fields' => array (
	                        	'h5_custom_typography' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable H5 Custom Typography', 'wbls-oner'), 
	                                'default' => 0,
	                            ),
	                            'h5' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-oner'),
	                            ),
	                            'h5_color' => array(
	                                'type' => 'color',
	                                'label' => __('H5 Color', 'wbls-oner'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#282827'
	                            )
	                        ),
	                    ),
	                    'h6_property' => array(
	                        'title' => __('H6 Font Properties','wbls-oner'),
	                        'description' => __('Specify the h6 font properties.','wbls-oner'),
	                        'fields' => array (
	                        	'h6_custom_typography' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable H6 Custom Typography', 'wbls-oner'), 
	                                'default' => 0,
	                            ),
	                            'h6' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-oner'),
	                            ),
	                            'h6_color' => array(
	                                'type' => 'color',
	                                'label' => __('H6 Color', 'wbls-oner'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#282827'
	                            )
	                        ),
	                    ),
	                ),
	            ), // typography panel end //

				'pro_panel' => array(
	                'priority'       => 9,
	                'title'          => __('Pro Options', 'wbls-oner'),
	                'description'    => __('Pro Options', 'wbls-oner'),
	                'sections' => array(
	                    'multiple_color_section' => array(
	                        'title' => __('Color Scheme ', 'wbls-oner'),
	                        'description' => __('Select your color scheme','wbls-oner'),
	                        'fields' => array(
	                            'color_scheme' => array(        
	                                'type' => 'select',
	                                'label' => __('Select your color scheme.', 'wbls-oner'),
	                                'description' => __(' ', 'wbls-oner'),
	                                'choices' => array(
	                                    '1' => __('Default', 'wbls-oner'),       
	                                    '2' => __('Blue', 'wbls-oner'),
	                                    '3' => __('Orange', 'wbls-oner'),    
	                                    '4' => __('Pink', 'wbls-oner'),
	                                    '5' => __('Purple', 'wbls-oner'),
	                                    '6' => __('Red', 'wbls-oner'),
	                                    	                                 
	                                ),
	                                'default' => 1,  
                            	),                     
	                        ),
	                    ),
	
                       'social_network' => array(
                        'title' => __('Social Networks', 'wbls-oner'),
                        'description' => __(' Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-oner'),
                        'fields' => array(
                            'digg' => array(
                                'type' => 'text',
                                'label' => __('Digg', 'wbls-oner'), 
                                'description' => __('Your Digg link ', 'wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'dribbble' => array(
                                'type' => 'text',
                                'label' => __('Dribbble', 'wbls-oner'),
                                'description' => __('Your Dribbble link ', 'wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'facebook' => array(
                                'type' => 'text',
                                'label' => __('Facebook', 'wbls-oner'),
                                'description' => __('Your Facebook link', 'wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'twitter' => array(
                                'type' => 'text',
                                'label' => __('Twitter', 'wbls-oner'),
                                'description' => __('Your Twitter link', 'wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'google_plus' => array(
                                'type' => 'text',
                                'label' => __('Google +', 'wbls-oner'),
                                'description' => __('Your Google Plus', 'wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',

                            ),
                            'linkedin' => array(
                                'type' => 'text',
                                'label' => __('LinkedIn', 'wbls-oner'),
                                'description' => __('Your LinkedIn link', 'wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'instagram' => array(
                                'type' => 'text',
                                'label' => __('Instagram', 'wbls-oner'),
                                'description' => __('Your Instagram link ', 'wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'flickr' => array(
                                'type' => 'text',
                                'label' => __('Flickr', 'wbls-oner'),
                                'description' => __('Your Flickr link', 'wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'youtube' => array(
                                'type' => 'text',
                                'label' => __('YouTube', 'wbls-oner'),
                                'description' => __('Your YouTube link', 'wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'vimeo' => array(
                                'type' => 'text',
                                'label' => __('Vimeo', 'wbls-oner'),
                                'description' => __('Your Vimeo link', 'wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'pinterest' => array(
                                'type' => 'text',
                                'label' => __('Pinterest', 'wbls-oner'),
                                'description' => __('Your Pinterest link','wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'rss' => array(
                                'type' => 'text',
                                'label' => __('RSS', 'wbls-oner'),
                                'description' => __('Your RSS link','wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'skype' => array(
                                'type' => 'text',
                                'label' => __('Skype', 'wbls-oner'),
                                'description' => __('Your Skype link','wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'tumblr' => array(
                                'type' => 'text',
                                'label' => __('Tumblr', 'wbls-oner'),
                                'description' => __('Your Tumblr link','wbls-oner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                        ),
                    ),

						'flex_slider_section' => array(
	                        'title' => __('Flex Slider', 'wbls-oner'),
	                        'description' => __('Flex Slider Settings','wbls-oner'),
	                        'fields' => array(
	                            'animation' => array(
	                                'type' => 'select',
	                                'label' => __('Select slider animation effect', 'wbls-oner'),
	                                'description' => __('Select slider animation effect.', 'wbls-oner'),
	                                'choices' => array(
	                                    '1' => __('Fade', 'wbls-oner'),
	                                    '2' => __('Slide', 'wbls-oner'),
	                                ),
	                                'default' => 2,
	                            ),
	                            'slide_direction' => array(
	                                'type' => 'select',
	                                'label' => __('Select direction to slide ', 'wbls-oner'),
	                                'description' => __('Select direction to slide (if you are using the "Slide" animation)', 'wbls-oner'),
	                                'choices' => array(
	                                    '1' => __('Horizontal', 'wbls-oner'),
	                                    '2' => __('Vertical', 'wbls-oner'),
	                                ),
	                                'default' => 1,
	                            ),
	                            'flexslider_slideshow_speed' => array(
	                                'type' => 'range',
	                                'label' => __('Slideshow Speed', 'wbls-oner'),
	                                'description' => __('Set the delay between each slide animation (in milliseconds)', 'wbls-oner'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 1,
	                                ),
	                                'default' => 50
	                            ),
	                            'flexslider_animation_speed' => array(
	                                'type' => 'range',
	                                'label' => __('Animation Speed', 'wbls-oner'),
	                                'description' => __('Set the duration of each slide animation (in milliseconds)', 'wbls-oner'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 1,
	                                ),
	                                'default' => 50
	                            ),
	                            'flexslider_slideshow' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Animate the slideshows automatically', 'wbls-oner'),
	                                'description' => __('Enable Animate the slideshows automatically', 'wbls-oner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_smooth_height' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable to Adjust the height of the slideshow to the height of the current slide', 'wbls-oner'),
	                                'description' => __('Enable Adjust the height of the slideshow to the height of the current slide', 'wbls-oner'),
	                                'default' => 0,
	                            ),
	                            'flexslider_direction_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable  Display the "Previous/Next" Buttons', 'wbls-oner'),
	                                'description' => __('Enable  Display the "Previous/Next" Buttons', 'wbls-oner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_control_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Display the slideshow pagination', 'wbls-oner'),
	                                'description' => __('Enable Display the slideshow pagination', 'wbls-oner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_keyboard_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Keyboard Navigation', 'wbls-oner'),
	                                'description' => __('Enable keyboard navigation', 'wbls-oner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_mousewheel_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Mouse Wheel Navigation', 'wbls-oner'),
	                                'description' => __('Enable the mousewheel navigation', 'wbls-oner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_pauseplay' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Pause / Play event', 'wbls-oner'),
	                                'description' => __('Enable the "Pause/Play" event', 'wbls-oner'),
	                                'default' => 0,
	                            ),
	                            'flexslider_randomize' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Random Slides', 'wbls-oner'),
	                                'description' => __('Enable to Randomize the order of slides in slideshows', 'wbls-oner'),
	                                'default' => 0,
	                            ),
	                            'flexslider_animation_loop' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Loop Slideshow animations', 'wbls-oner'),
	                                'description' => __('Enable Loop the slideshow animations', 'wbls-oner'),
	                                'default' => 0,
	                            ),
	                            'flexslider_pause_on_action' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Pause On Action while navigation', 'wbls-oner'),
	                                'description' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation', 'wbls-oner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_pause_on_hover' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Pause On Action while hovering the slides', 'wbls-oner'),
	                                'description' => __('Enable to Pause the slideshow autoplay when hovering over a slide', 'wbls-oner'),
	                                'default' => 0,
	                            ),
	                            'flexslider_prev_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Previous" button', 'wbls-oner'),
	                                'description' => __(' The text to display on the "Previous" button.', 'wbls-oner'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Prev'
	                            ),
	                            'flexslider_next_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Next" button', 'wbls-oner'),
	                                'description' => __(' The text to display on the "Next" button.', 'wbls-oner'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Next'
	                            ),
	                            'flexslider_play_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Play" button', 'wbls-oner'),
	                                'description' => __(' The text to display on the "Play" button.', 'wbls-oner'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Play'
	                            ),
	                            'flexslider_pause_text' => array(
	                                'type' => 'text',
	                                'label' => __('The text to display on the "Pause" button', 'wbls-oner'),
	                                'description' => __(' The text to display on the "Pause" button.', 'wbls-oner'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Pause'
	                            ),

	                        ),
	                    ),
						'flex_carousel' => array(
	                        'title' => __('Flex Carousel Slider', 'wbls-oner'),
	                        'description' => __('Flex Carousel Settings','wbls-oner'),
	                        'fields' => array(
	                            'carousel_animation_loop' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Loop through carousel items?', 'wbls-oner'),
	                                'default' => 0,
	                            ),
	                            'carousel_item_width' => array(
	                                'type' => 'text',
	                                'label' => __('Carousel item width', 'wbls-oner'),
	                                'default' => 230,
	                                'sanitize_callback' => 'absint'
	                            ),
	                            'carousel_item_margin' => array(
	                                'type' => 'text',
	                                'label' => __('Carousel item margin', 'wbls-oner'),
	                                'default' => 5,
	                                'sanitize_callback' => 'absint'
	                            ),
	                            'carousel_pagination' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Carousel Pagination', 'wbls-oner'),
	                                'default' => 1,

	                            ),
	                        ),
                		),
						'light_box' => array(       
	                        'title' => __('Light Box', 'wbls-oner'),
	                        'description' => __('Light Box Settings ','wbls-oner'),
	                        'fields' => array(
	                            'lightbox_theme' => array(
	                                'type' => 'select',
	                                'label' => __('Lightbox Theme', 'wbls-oner'),
	                                'choices' => array(
	                                    '1' => __('pp_default', 'wbls-oner'),
	                                    '2' => __('light-rounded', 'wbls-oner'),
	                                    '3' => __('dark-rounded', 'wbls-oner'),
	                                    '4' => __('light-square', 'wbls-oner'),
	                                    '5' => __('dark-square', 'wbls-oner'),
	                                    '6' => __('facebook', 'wbls-oner'),
	                                ),
	                                'default' => '1',
	                            ),
	                            'lightbox_animation_speed' => array(
	                                'type' => 'select',
	                                'label' => __('Animation Speed', 'wbls-oner'),
	                                'choices' => array(
	                                    'fast' => __('Fast', 'wbls-oner'),
	                                    'slow' => __('Slow', 'wbls-oner'),
	                                    'normal' => __('Normal', 'wbls-oner'),
	                                ),
	                                'default' => 'fast',
	                            ),
	                            'lightbox_slideshow' => array( 
	                                'type' => 'range',
	                                'label' => __('Autoplay Gallery Speed', 'wbls-oner'),
	                                'description' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)', 'wbls-oner'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 10,
	                                ),
	                                'default' => 50,
	                            ),
	                            'lightbox_autoplay_slideshow' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Autoplay Gallery', 'wbls-oner'),
	                                'description' => __('Check to autoplay the lightbox gallery', 'wbls-oner'),
	                                'default' => 0,
	                            ),
	                            'lightbox_opacity' => array(
	                                'type' => 'range',
	                                'label' => __('Select Background Opacity', 'wbls-oner'),
	                                'description' => __('Enter 0.1 to 1.0', 'wbls-oner'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 1,
	                                    'step' => 0.1
	                                ),
	                                'default' => 0.5
	                            ),
	                           /* 'lightbox_show_title' => array( 
	                                'type' => 'checkbox',
	                                'label' => __('Check to show  visibility of the title', 'wbls-oner'),
	                                'description' => __('Select visibility of the title', 'wbls-oner'),
	                                'default' => 1,
	                            ),*/
	                            'lightbox_overlay_gallery' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Show Gallery Thumbnails', 'wbls-oner'),
	                                'description' => __('Check to show gallery thumbnails', 'wbls-oner'),
	                                'default' => 1,
	                            ),
	                          /*  'lightbox_social_tools' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Show social sharing icons', 'wbls-oner'),
	                                'description' => __('Check to show social sharing icons', 'wbls-oner'),
	                                'default' => 1,
	                            ),*/

	                        ),
                		),
						'analytics_section' => array(
	                        'title' => __('Tracking Code', 'wbls-oner'),
	                        'description' => __('Tracking Code','wbls-oner'),
	                        'fields' => array(
		                        'analytics' => array(
	                                'type' => 'textarea',
	                                'label' => __('Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-oner'),
	                                'description' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-oner'),
	                               // 'sanitize_callback' => 'sanitize_text_field',
	                            ),
	                            'analytics_place' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable to Load Tracking Code in Footer', 'wbls-oner'),
	                                'description' => __('Check to load analytics in footer. Uncheck to load in header.', 'wbls-oner'),
	                                'default' => 0,  
	                            ),                   
	                        ),
	                    ),
                       'custom_js_section' => array(
	                        'title' => __(' Custom Js', 'wbls-oner'),
	                        'description' => __('Custom Js','wbls-oner'),
	                        'fields' => array(
		                        'custom_js' => array(
	                                'type' => 'textarea',
	                                'label' => __('Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-oner'),
	                                'description' => __('','wbls-oner'),
	                                'sanitize_callback' => 'sanitize_text_field',  
                            	),                   
	                        ),
	                    ),

					),
				),


    		); // pro theme option end //

			$options = array_merge($free_options, $pro_options);
			return $options;

		}
	}
}