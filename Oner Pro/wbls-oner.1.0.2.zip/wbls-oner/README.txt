=== Webulous Oner Pro ===
Contributors: webulous
Donate link: https://www.webulousthemes.com/
Tags: comments, spam
Requires at least: 4.0.0
Tested up to: 4.7.5
Stable tag: 1.0.2
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

This plugin converts free version of Oner theme into pro version.

== Description ==

This plugin converts free version of Oner theme into pro version.


== Installation ==

1. Upload `wbls-oner` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog == 

= 1.0.2 =
* Demo Importer issue fixed.

= 1.0.1 =
* Sticky Issue Fixed.
* Prebuilt page issue Fixed.

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.2 =
* Demo Importer issue fixed.