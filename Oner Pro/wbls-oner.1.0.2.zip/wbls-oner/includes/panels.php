<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts
 *
 * @param $layouts    
 */

if (!function_exists('webulous_prebuilt_page_layouts') ) {   
function webulous_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-oner'),
    'description' => __('Pre Built Layout for  home page', 'wbls-oner'),
    'widgets' =>  array(
        0 => 
        array (
          'level' => '1',
          'type' => 'normal',
          'content' => 'Blog',
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_Heading_Widget',
            'raw' => false,
            'grid' => 0,
            'cell' => 0,
            'id' => 0,
            'widget_id' => 'e8380d65-2c5a-4ac0-b9b6-a78a0f45f86f',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        1 => 
        array (
          'title' => '',
          'count' => '2',
          'type' => 'normal',
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_Recent_Posts_Widget',
            'raw' => false,
            'grid' => 0,
            'cell' => 0,
            'id' => 1,
            'widget_id' => 'f6cb1944-4774-4411-acb8-7b1caee0b955',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        2 => 
        array (
          'panels_data' => 
          array (
            'widgets' => 
            array (
              0 => 
              array (
                'level' => '1',
                'type' => 'normal',
                'content' => 'Our Recent Projects',
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Heading_Widget',
                  'raw' => false,
                  'grid' => 0,
                  'cell' => 0,
                  'id' => 0,
                  'widget_id' => '1da85a45-0fbc-497a-bb7b-6434a783bfe5',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
              1 => 
              array (
                'title' => '',
                'count' => '12',
                'type' => 'isotope',
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '4',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Recent_Work_Widget',
                  'raw' => false,
                  'grid' => 0,
                  'cell' => 0,
                  'id' => 1,
                  'widget_id' => '3ecc7528-c552-4909-98cf-c95cc5c3cbff',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
            ),
            'grids' => 
            array (
              0 => 
              array (
                'cells' => 1,
                'style' => 
                array (
                ),
              ),
            ),
            'grid_cells' => 
            array (
              0 => 
              array (
                'grid' => 0,
                'weight' => 1,
              ),
            ),
          ),
          'builder_id' => '58fdc7341f35f',
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'SiteOrigin_Panels_Widgets_Layout',
            'raw' => false,
            'grid' => 1,
            'cell' => 0,
            'id' => 2,
            'widget_id' => '8d0c4edd-0f8b-46ff-ac63-47892a9e4a7d',
            'style' => 
            array (
              'class' => 'no-default-margin',
              'background_display' => 'tile',
            ),
          ),
        ),
        3 => 
        array (
          'panels_data' => 
          array (
            'widgets' => 
            array (
              0 => 
              array (
                'level' => '1',
                'type' => 'normal',
                'content' => 'Our Services',
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Heading_Widget',
                  'raw' => false,
                  'grid' => 0,
                  'cell' => 0,
                  'id' => 0,
                  'widget_id' => '823d9d33-4cec-4282-864f-5d7fcc015a63',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
              1 => 
              array (
                'title' => 'Responsive Layout',
                'text' => 'Oner is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
                'icon' => 'fa-mobile',
                'icon_background_color' => '',
                'icon_size' => '3x',
                'icon_placement' => 'top',
                'more' => '',
                'more_url' => '',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Icon_Widget',
                  'raw' => false,
                  'grid' => 1,
                  'cell' => 0,
                  'id' => 1,
                  'widget_id' => 'df5bf835-f781-4c12-84b9-f306127c2876',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
              2 => 
              array (
                'title' => 'Awesome Slider',
                'text' => 'Oner includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
                'icon' => 'fa-random',
                'icon_background_color' => '',
                'icon_size' => '3x',
                'icon_placement' => 'top',
                'more' => '',
                'more_url' => '',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Icon_Widget',
                  'raw' => false,
                  'grid' => 1,
                  'cell' => 1,
                  'id' => 2,
                  'widget_id' => 'a5be8e64-a8d4-435e-ab8c-47c2ce884522',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
              3 => 
              array (
                'title' => 'Font Awesome',
                'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
                'icon' => 'fa-flag',
                'icon_background_color' => '',
                'icon_size' => '3x',
                'icon_placement' => 'top',
                'more' => '',
                'more_url' => '',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Icon_Widget',
                  'raw' => false,
                  'grid' => 1,
                  'cell' => 2,
                  'id' => 3,
                  'widget_id' => '7d731e1f-2cf6-4c2c-ba1f-71560cfb9b39',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
            ),
            'grids' => 
            array (
              0 => 
              array (
                'cells' => 1,
                'style' => 
                array (
                ),
              ),
              1 => 
              array (
                'cells' => 3,
                'style' => 
                array (
                  'class' => 'no-default-margin',
                  'cell_class' => '',
                  'row_css' => '',
                  'bottom_margin' => '',
                  'gutter' => '',
                  'padding' => '',
                  'row_stretch' => '',
                  'background' => '',
                  'background_image_attachment' => '0',
                  'background_display' => 'tile',
                  'border_color' => '',
                ),
              ),
            ),
            'grid_cells' => 
            array (
              0 => 
              array (
                'grid' => 0,
                'weight' => 1,
              ),
              1 => 
              array (
                'grid' => 1,
                'weight' => 0.33333333333332998,
              ),
              2 => 
              array (
                'grid' => 1,
                'weight' => 0.33333333333332998,
              ),
              3 => 
              array (
                'grid' => 1,
                'weight' => 0.33333333333332998,
              ),
            ),
          ),
          'builder_id' => '58fdc7341f3f9',
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'SiteOrigin_Panels_Widgets_Layout',
            'raw' => false,
            'grid' => 2,
            'cell' => 0,
            'id' => 3,
            'widget_id' => '1feed75e-a1bd-4ac0-8e0c-044723002ab0',
            'style' => 
            array (
              'background_display' => 'tile',
              'animation_class' => 'fadeInUpBig-animation',
            ),
          ),
        ),
        4 => 
        array (
          'panels_data' => 
          array (
            'widgets' => 
            array (
              0 => 
              array (
                'level' => '1',
                'type' => 'normal',
                'content' => 'Our Team Creators',
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Heading_Widget',
                  'raw' => false,
                  'grid' => 0,
                  'cell' => 0,
                  'id' => 0,
                  'widget_id' => '63734133-3efe-4a96-9f7c-0f2479b306f9',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
              1 => 
              array (
                'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at.',
                'image_url' => 'http://dummy.genexthemes.com/oner/wp-content/uploads/2017/04/Color-Scheme-Three_12.png',
                'title' => 'Jessica Lee',
                'designation' => 'Manager',
                'linkedin' => 'http://www.Linkedin.com',
                'google' => 'http://www.google.com',
                'twitter' => 'http://www.Twitter.com',
                'facebook' => 'http://www.facebook.com',
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Ourteam_Widget',
                  'grid' => 1,
                  'cell' => 0,
                  'id' => 1,
                  'widget_id' => '66d13af6-bdfd-4f29-a217-6bc5cf00c2b4',
                  'style' => 
                  array (
                    'id' => '',
                    'class' => '',
                    'widget_css' => '',
                    'mobile_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
              2 => 
              array (
                'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. ',
                'image_url' => 'http://dummy.genexthemes.com/oner/wp-content/uploads/2017/04/Team-4.png',
                'title' => 'Louis Johnson',
                'designation' => 'Designer',
                'linkedin' => 'http://www.Linkedin.com',
                'google' => 'http://www.google.com',
                'twitter' => 'http://www.Twitter.com',
                'facebook' => 'http://www.facebook.com',
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Ourteam_Widget',
                  'grid' => 1,
                  'cell' => 1,
                  'id' => 2,
                  'widget_id' => 'f720b443-32c9-4186-ad0e-7326a4a2c1d2',
                  'style' => 
                  array (
                    'id' => '',
                    'class' => '',
                    'widget_css' => '',
                    'mobile_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
              3 => 
              array (
                'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at.',
                'image_url' => 'http://dummy.genexthemes.com/oner/wp-content/uploads/2017/04/Color-Scheme-Three_12.png',
                'title' => 'Merry Doe',
                'designation' => 'Developer',
                'linkedin' => 'http://www.Linkedin.com',
                'google' => 'http://www.google.com',
                'twitter' => 'http://www.Twitter.com',
                'facebook' => 'http://www.facebook.com',
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Ourteam_Widget',
                  'grid' => 1,
                  'cell' => 2,
                  'id' => 3,
                  'widget_id' => '376baf2d-ec5e-4bd1-88b5-ac4d8dc1674d',
                  'style' => 
                  array (
                    'id' => '',
                    'class' => '',
                    'widget_css' => '',
                    'mobile_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
              4 => 
              array (
                'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at.',
                'image_url' => 'http://dummy.genexthemes.com/oner/wp-content/uploads/2017/04/Team-4.png',
                'title' => 'Drake Brown',
                'designation' => 'Programmer',
                'linkedin' => 'http://www.Linkedin.com',
                'google' => 'http://www.google.com',
                'twitter' => 'http://www.Twitter.com',
                'facebook' => 'http://www.facebook.com',
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Ourteam_Widget',
                  'grid' => 1,
                  'cell' => 3,
                  'id' => 4,
                  'widget_id' => '4850bc35-5273-43ae-925a-640680a42b55',
                  'style' => 
                  array (
                    'id' => '',
                    'class' => '',
                    'widget_css' => '',
                    'mobile_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
            ),
            'grids' => 
            array (
              0 => 
              array (
                'cells' => 1,
                'style' => 
                array (
                  'id' => '',
                  'class' => '',
                  'cell_class' => '',
                  'row_css' => '',
                  'animation_class' => '',
                  'bottom_margin' => '',
                  'gutter' => '',
                  'padding' => '',
                  'mobile_padding' => '',
                  'row_stretch' => '',
                  'collapse_order' => '',
                  'background' => '',
                  'background_image_attachment' => '0',
                  'background_display' => 'tile',
                  'border_color' => '',
                ),
              ),
              1 => 
              array (
                'cells' => 4,
                'style' => 
                array (
                  'class' => '',
                  'cell_class' => '',
                  'row_css' => '',
                  'bottom_margin' => '',
                  'gutter' => '',
                  'padding' => '',
                  'row_stretch' => '',
                  'background' => '',
                  'background_image_attachment' => '0',
                  'background_display' => 'tile',
                  'border_color' => '',
                ),
              ),
            ),
            'grid_cells' => 
            array (
              0 => 
              array (
                'grid' => 0,
                'index' => 0,
                'weight' => 1,
                'style' => 
                array (
                ),
              ),
              1 => 
              array (
                'grid' => 1,
                'index' => 0,
                'weight' => 0.25,
                'style' => 
                array (
                ),
              ),
              2 => 
              array (
                'grid' => 1,
                'index' => 1,
                'weight' => 0.25,
                'style' => 
                array (
                ),
              ),
              3 => 
              array (
                'grid' => 1,
                'index' => 2,
                'weight' => 0.25,
                'style' => 
                array (
                ),
              ),
              4 => 
              array (
                'grid' => 1,
                'index' => 3,
                'weight' => 0.25,
                'style' => 
                array (
                ),
              ),
            ),
          ),
          'builder_id' => '5942806b8e420',
          'panels_info' => 
          array (
            'class' => 'SiteOrigin_Panels_Widgets_Layout',
            'grid' => 3,
            'cell' => 0,
            'id' => 4,
            'widget_id' => '0a13c37a-40ff-475f-8db7-a7733a3e48c1',
            'style' => 
            array (
              'background_image_attachment' => false,
              'background_display' => 'tile',
            ),
          ),
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
        ),
        5 => 
        array (
          'title' => 'Skills',
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_Skill_Widget',
            'raw' => false,
            'grid' => 4,
            'cell' => 0,
            'id' => 5,
            'widget_id' => 'e3b6b67c-c827-4dc5-9a0b-a4c9c0c1b216',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        6 => 
        array (
          'title' => 'Our Accordion',
          'text' => '[accordion_group][accordion title="Aliquam rutrum tortor quis ultrices ultricies."]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. Cras venenatis a nibh ut placerat. [/accordion][accordion title="Curabitur rutrum vehicula enim et pulvinar."] Sed nec massa lorem. Phasellus ut tincidunt velit, id scelerisque lorem. Nullam nisl tortor, mollis ut massa in, dapibus tincidunt libero. Pellentesque pretium posuere turpis eget dignissim. Curabitur sapien lorem, feugiat et velit et, vehicula aliquet urna. Vivamus pellentesque lorem at urna suscipit, at vulputate est ultricies. Aliquam ultrices nec massa sed adipiscing. Pellentesque feugiat sodales tellus. Ut tempus aliquam felis, quis consequat nunc hendrerit eget. Praesent sollicitudin nunc eu sollicitudin placerat. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="Pellentesque iaculis vulputate blandit."]Aliquam non lacus in lacus aliquet blandit. Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. Sed ut augue vitae augue vestibulum pulvinar. Fusce commodo ultricies volutpat. Vivamus quis nulla porta, faucibus metus eu, tempus dolor. Ut sed faucibus mi, ac volutpat lectus. Morbi a rhoncus erat. Mauris et metus posuere, imperdiet urna at, congue risus. Nunc at ante sed ipsum porttitor scelerisque semper non libero. Vivamus feugiat nisl sit amet mi tristique dictum. Donec id magna facilisis, euismod sem bibendum, interdum lorem. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][/accordion_group]',
          'filter' => false,
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'WP_Widget_Text',
            'raw' => false,
            'grid' => 4,
            'cell' => 1,
            'id' => 6,
            'widget_id' => 'b3416e35-e8be-4be2-b603-f43da0c2ef6c',
            'style' => 
            array (
              'class' => 'title-divider-left',
              'background_display' => 'tile',
            ),
          ),
        ),
        7 => 
        array (
          'panels_data' => 
          array (
            'widgets' => 
            array (
              0 => 
              array (
                'level' => '1',
                'type' => 'normal',
                'content' => 'Fun Facts',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Heading_Widget',
                  'grid' => 0,
                  'cell' => 0,
                  'id' => 0,
                  'widget_id' => '40e74ed2-9c0c-44ab-ba33-57efcc862b41',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
              ),
              1 => 
              array (
                'title' => '478',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Stats_Widget',
                  'raw' => false,
                  'grid' => 1,
                  'cell' => 0,
                  'id' => 1,
                  'widget_id' => '7e68d005-7a78-4de8-b14d-443179c1e5f5',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                  ),
                ),
              ),
              2 => 
              array (
                'title' => '479',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Stats_Widget',
                  'raw' => false,
                  'grid' => 1,
                  'cell' => 1,
                  'id' => 2,
                  'widget_id' => 'a34ec479-6fbb-4b2b-b7da-aff6de7f66f7',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                  ),
                ),
              ),
              3 => 
              array (
                'title' => '480',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Stats_Widget',
                  'raw' => false,
                  'grid' => 1,
                  'cell' => 2,
                  'id' => 3,
                  'widget_id' => '6fd0e4fe-d9bd-47f4-8f1f-5d96fe7d4f51',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                  ),
                ),
              ),
              4 => 
              array (
                'title' => '481',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Stats_Widget',
                  'raw' => false,
                  'grid' => 1,
                  'cell' => 3,
                  'id' => 4,
                  'widget_id' => '8a746e35-b8be-4f49-8509-6a867cab1555',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                  ),
                ),
              ),
            ),
            'grids' => 
            array (
              0 => 
              array (
                'cells' => 1,
                'style' => 
                array (
                ),
              ),
              1 => 
              array (
                'cells' => 4,
                'style' => 
                array (
                  'class' => '',
                  'cell_class' => '',
                  'row_css' => '',
                  'bottom_margin' => '',
                  'gutter' => '',
                  'padding' => '',
                  'row_stretch' => '',
                  'background' => '',
                  'background_image_attachment' => '0',
                  'background_display' => 'tile',
                  'border_color' => '',
                ),
              ),
            ),
            'grid_cells' => 
            array (
              0 => 
              array (
                'grid' => 0,
                'weight' => 1,
              ),
              1 => 
              array (
                'grid' => 1,
                'weight' => 0.25,
              ),
              2 => 
              array (
                'grid' => 1,
                'weight' => 0.25,
              ),
              3 => 
              array (
                'grid' => 1,
                'weight' => 0.25,
              ),
              4 => 
              array (
                'grid' => 1,
                'weight' => 0.25,
              ),
            ),
          ),
          'builder_id' => '58fd8abb8323e',
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'SiteOrigin_Panels_Widgets_Layout',
            'raw' => false,
            'grid' => 5,
            'cell' => 0,
            'id' => 7,
            'widget_id' => '970ad3ba-a248-424d-9cf7-db4b72560652',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        8 => 
        array (
          'level' => '1',
          'type' => 'normal',
          'content' => 'Our Testimonials',
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_Heading_Widget',
            'raw' => false,
            'grid' => 6,
            'cell' => 0,
            'id' => 8,
            'widget_id' => '5c14ebb7-05fb-401d-82b2-2c47b74fb81b',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        9 => 
        array (
          'title' => '',
          'count' => '5',
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_Testimonial_Widget',
            'raw' => false,
            'grid' => 6,
            'cell' => 0,
            'id' => 9,
            'widget_id' => 'eb5d6322-a17b-4fab-b76f-d9b9a57dbe3a',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        10 => 
        array (
          'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum',
          'title' => 'Welcome to Oner Theme',
          'url' => 'http://www.webulousthemes.com/oner',
          'anchor_text' => 'Download Now',
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_Cta_Widget',
            'raw' => false,
            'grid' => 7,
            'cell' => 0,
            'id' => 10,
            'widget_id' => 'f8fda553-892a-4780-80cb-c87d8637cedf',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
      ),
      'grids' => 
      array (
        0 => 
        array (
          'cells' => 1,
          'style' => 
          array (
            'id' => 'blog',
            'background_display' => 'tile',
            'bottom_margin' => '0px',
          ),
        ),
        1 => 
        array (
          'cells' => 1,
          'style' => 
          array (
            'id' => 'projects',
            'class' => 'panel-row-style-full-width-layout ',
            'background_display' => 'tile',
            'bottom_margin' => '0px',
          ),
        ),
        2 => 
        array (
          'cells' => 1,
          'style' => 
          array (
            'id' => 'services',
            'background_display' => 'tile',
            'bottom_margin' => '0px',
          ),
        ),
        3 => 
        array (
          'cells' => 1,
          'style' => 
          array (
            'id' => 'team',
            'class' => 'panel-row-style-full-width-layout full-width-grey-pattern',
            'background_display' => 'tile',
            'bottom_margin' => '0px',
          ),
        ),
        4 => 
        array (
          'cells' => 2,
          'style' => 
          array (
            'id' => 'skills',
            'background_display' => 'tile',
            'bottom_margin' => '0px',
          ),
        ),
        5 => 
        array (
          'cells' => 1,
          'style' => 
          array (
            'id' => 'facts',
            'class' => 'panel-row-style-full-width-layout ',
            'background_display' => 'tile',
            'bottom_margin' => '0px',
          ),
        ),
        6 => 
        array (
          'cells' => 1,
          'style' => 
          array (
            'id' => 'testimonials',
            'background_display' => 'cover',
            'bottom_margin' => '0px',
            'row_stretch' => 'full',
          ),
        ),
        7 => 
        array (
          'cells' => 1,
          'style' => 
          array (
            'id' => 'cta',
            'background_display' => 'tile',
          ),
        ),
      ),
      'grid_cells' => 
      array (
        0 => 
        array (
          'grid' => 0,
          'index' => 0,
          'weight' => 1,
          'style' => 
          array (
          ),
        ),
        1 => 
        array (
          'grid' => 1,
          'index' => 0,
          'weight' => 1,
          'style' => 
          array (
          ),
        ),
        2 => 
        array (
          'grid' => 2,
          'index' => 0,
          'weight' => 1,
          'style' => 
          array (
          ),
        ),
        3 => 
        array (
          'grid' => 3,
          'index' => 0,
          'weight' => 1,
          'style' => 
          array (
          ),
        ),
        4 => 
        array (
          'grid' => 4,
          'index' => 0,
          'weight' => 0.5,
          'style' => 
          array (
          ),
        ),
        5 => 
        array (
          'grid' => 4,
          'index' => 1,
          'weight' => 0.5,
          'style' => 
          array (
          ),
        ),
        6 => 
        array (
          'grid' => 5,
          'index' => 0,
          'weight' => 1,
          'style' => 
          array (
          ),
        ),
        7 => 
        array (
          'grid' => 6,
          'index' => 0,
          'weight' => 1,
          'style' => 
          array (
          ),
        ),
        8 => 
        array (
          'grid' => 7,
          'index' => 0,
          'weight' => 1,
          'style' => 
          array (
          ),
        ),
    
    ),

  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-oner'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-oner'),
    'widgets' => array(
          0 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'level' => '1',
                  'type' => 'normal',
                  'content' => 'About Us',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Heading_Widget',
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'widget_id' => '923afc08-8784-4ddd-b9a4-4166cf149430',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'mobile_padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                  'portfolio_cat' => '',
                  'portfolio_skill' => '',
                  'portfolio_column' => '',
                ),
                1 => 
                array (
                  'panels_data' => 
                  array (
                    'widgets' => 
                    array (
                      0 => 
                      array (
                        'type' => 'circle',
                        'title' => 'Responsive Layout',
                        'text' => 'Oner is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
                        'icon' => 'fa-mobile',
                        'icon_background_color' => '',
                        'icon_size' => '3x',
                        'more' => '',
                        'more_url' => '',
                        'panels_info' => 
                        array (
                          'class' => 'Wbls_CircleIcon_Widget',
                          'grid' => 0,
                          'cell' => 0,
                          'id' => 0,
                          'widget_id' => '1d2a784b-9088-423d-8f95-e301a1756ef4',
                          'style' => 
                          array (
                            'class' => '',
                            'widget_css' => '',
                            'animation_class' => '',
                            'padding' => '',
                            'mobile_padding' => '',
                            'background' => '',
                            'background_image_attachment' => '0',
                            'background_display' => 'tile',
                            'border_color' => '',
                            'font_color' => '',
                            'link_color' => '',
                          ),
                        ),
                        'box' => false,
                        'all_linkable' => false,
                        'portfolio_cat' => '',
                        'portfolio_skill' => '',
                        'portfolio_column' => '',
                      ),
                      1 => 
                      array (
                        'type' => 'circle',
                        'title' => ' Awesome Slider',
                        'text' => 'Oner includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
                        'icon' => 'fa-magic',
                        'icon_background_color' => '',
                        'icon_size' => '3x',
                        'more' => '',
                        'more_url' => '',
                        'panels_info' => 
                        array (
                          'class' => 'Wbls_CircleIcon_Widget',
                          'grid' => 0,
                          'cell' => 0,
                          'id' => 1,
                          'widget_id' => '3cc36ded-c1a6-4266-beea-10f41bc1c8d0',
                          'style' => 
                          array (
                            'class' => '',
                            'widget_css' => '',
                            'animation_class' => '',
                            'padding' => '',
                            'mobile_padding' => '',
                            'background' => '',
                            'background_image_attachment' => '0',
                            'background_display' => 'tile',
                            'border_color' => '',
                            'font_color' => '',
                            'link_color' => '',
                          ),
                        ),
                        'box' => false,
                        'all_linkable' => false,
                        'portfolio_cat' => '',
                        'portfolio_skill' => '',
                        'portfolio_column' => '',
                      ),
                    ),
                    'grids' => 
                    array (
                      0 => 
                      array (
                        'cells' => 1,
                        'style' => 
                        array (
                        ),
                      ),
                    ),
                    'grid_cells' => 
                    array (
                      0 => 
                      array (
                        'grid' => 0,
                        'weight' => 1,
                      ),
                    ),
                  ),
                  'builder_id' => '58f99f128a2cc',
                  'portfolio_cat' => '',
                  'portfolio_skill' => '',
                  'portfolio_column' => '',
                  'panels_info' => 
                  array (
                    'class' => 'SiteOrigin_Panels_Widgets_Layout',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 1,
                    'widget_id' => 'd7f31f7f-6505-418c-bfbe-e4e6fa22e4d3',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'mobile_padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'src' => 'http://modulus.webulous.in/wp-content/uploads/2016/01/About-Us.png',
                  'href' => 'http://modulus.webulous.in/wp-content/uploads/2016/01/About-Us.png',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Image_Widget',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 1,
                    'id' => 2,
                    'widget_id' => '41d6e293-88cd-4f76-bf86-182b55206643',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                  ),
                ),
                1 => 
                array (
                  'cells' => 2,
                  'style' => 
                  array (
                    'class' => '',
                    'cell_class' => '',
                    'row_css' => '',
                    'bottom_margin' => '',
                    'gutter' => '',
                    'padding' => '',
                    'row_stretch' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 1,
                ),
                1 => 
                array (
                  'grid' => 1,
                  'weight' => 0.5,
                ),
                2 => 
                array (
                  'grid' => 1,
                  'weight' => 0.5,
                ),
              ),
            ),
            'builder_id' => '58f9ac8ebb4c9',
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '9dd16044-36b1-491a-b0e0-96921235bba2',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          1 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'level' => '1',
                  'type' => 'normal',
                  'content' => 'Fun Facts',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Heading_Widget',
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'widget_id' => '8245eb35-fcd3-42d2-8e23-cbeb2ca93847',
                    'style' => 
                    array (
                      'class' => 'head-color-white',
                      'widget_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'mobile_padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                  'portfolio_cat' => '',
                  'portfolio_skill' => '',
                  'portfolio_column' => '',
                ),
                1 => 
                array (
                  'title' => '481',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Stats_Widget',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 1,
                    'widget_id' => 'aba64523-f465-4abe-aef3-7a326e6c8edc',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'title' => '480',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Stats_Widget',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 1,
                    'id' => 2,
                    'widget_id' => '73a05f03-21f8-4891-94a3-ba7d4a52076d',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                3 => 
                array (
                  'title' => '479',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Stats_Widget',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 2,
                    'id' => 3,
                    'widget_id' => '9d27a92c-8bac-4544-80c7-76f4534b152f',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                4 => 
                array (
                  'title' => '478',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Stats_Widget',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 3,
                    'id' => 4,
                    'widget_id' => 'f2ba4d56-a6cb-48dc-9cc6-3aef1f5a0c01',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                  ),
                ),
                1 => 
                array (
                  'cells' => 4,
                  'style' => 
                  array (
                    'class' => 'stat-white',
                    'cell_class' => '',
                    'row_css' => '',
                    'bottom_margin' => '',
                    'gutter' => '',
                    'padding' => '',
                    'row_stretch' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 1,
                ),
                1 => 
                array (
                  'grid' => 1,
                  'weight' => 0.25,
                ),
                2 => 
                array (
                  'grid' => 1,
                  'weight' => 0.25,
                ),
                3 => 
                array (
                  'grid' => 1,
                  'weight' => 0.25,
                ),
                4 => 
                array (
                  'grid' => 1,
                  'weight' => 0.25,
                ),
              ),
            ),
            'builder_id' => '58f9ad44a7cba',
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '25b58737-a370-4547-b31c-8e41cea50135',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          2 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'level' => '1',
                  'type' => 'normal',
                  'content' => 'Meet Our Creators',
                  'portfolio_cat' => '',
                  'portfolio_skill' => '',
                  'portfolio_column' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Heading_Widget',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'widget_id' => 'd11b8889-7ee7-4158-9f68-937e3cf57cb2',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'mobile_padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry.',
                  'image_url' => 'http://dummy.genexthemes.com/oner/wp-content/uploads/2017/04/Color-Scheme-Three_12.png',
                  'title' => 'Jessica Lee',
                  'designation' => 'Manager',
                  'linkedin' => 'www.google.com',
                  'google' => 'www.google.com',
                  'twitter' => 'www.google.com',
                  'facebook' => 'www.google.com',
                  'portfolio_cat' => '',
                  'portfolio_skill' => '',
                  'portfolio_column' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Ourteam_Widget',
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 1,
                    'widget_id' => '47efaf9a-35bb-44eb-8e3b-d25c27e8fead',
                    'style' => 
                    array (
                      'id' => '',
                      'class' => '',
                      'widget_css' => '',
                      'mobile_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'mobile_padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry.',
                  'image_url' => 'http://dummy.genexthemes.com/oner/wp-content/uploads/2017/04/Team-4.png',
                  'title' => 'Louis Johnson',
                  'designation' => 'Designer',
                  'linkedin' => 'www.google.com',
                  'google' => 'www.google.com',
                  'twitter' => 'www.google.com',
                  'facebook' => 'www.google.com',
                  'portfolio_cat' => '',
                  'portfolio_skill' => '',
                  'portfolio_column' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Ourteam_Widget',
                    'grid' => 1,
                    'cell' => 1,
                    'id' => 2,
                    'widget_id' => 'e2af28c9-c698-429b-ad79-e5c9aed5c175',
                    'style' => 
                    array (
                      'id' => '',
                      'class' => '',
                      'widget_css' => '',
                      'mobile_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'mobile_padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                ),
                3 => 
                array (
                  'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry.',
                  'image_url' => 'http://dummy.genexthemes.com/oner/wp-content/uploads/2017/04/Color-Scheme-Three_12.png',
                  'title' => 'Merry Doe',
                  'designation' => 'Developer',
                  'linkedin' => 'www.google.com',
                  'google' => 'www.google.com',
                  'twitter' => 'www.google.com',
                  'facebook' => 'www.google.com',
                  'portfolio_cat' => '',
                  'portfolio_skill' => '',
                  'portfolio_column' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Ourteam_Widget',
                    'grid' => 1,
                    'cell' => 2,
                    'id' => 3,
                    'widget_id' => 'b90a2ab8-2611-45d3-86e7-5fe504e86656',
                    'style' => 
                    array (
                      'id' => '',
                      'class' => '',
                      'widget_css' => '',
                      'mobile_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'mobile_padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                ),
                4 => 
                array (
                  'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry.',
                  'image_url' => 'http://dummy.genexthemes.com/oner/wp-content/uploads/2017/04/Team-4.png',
                  'title' => 'Drake Brown',
                  'designation' => 'Programmer',
                  'linkedin' => 'www.google.com',
                  'google' => 'www.google.com',
                  'twitter' => 'www.google.com',
                  'facebook' => 'www.google.com',
                  'portfolio_cat' => '',
                  'portfolio_skill' => '',
                  'portfolio_column' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Ourteam_Widget',
                    'grid' => 1,
                    'cell' => 3,
                    'id' => 4,
                    'widget_id' => '929adbcd-9736-475e-9b59-eea468b4fcb7',
                    'style' => 
                    array (
                      'id' => '',
                      'class' => '',
                      'widget_css' => '',
                      'mobile_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'mobile_padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                  ),
                ),
                1 => 
                array (
                  'cells' => 4,
                  'style' => 
                  array (
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'index' => 0,
                  'weight' => 1,
                  'style' => 
                  array (
                  ),
                ),
                1 => 
                array (
                  'grid' => 1,
                  'index' => 0,
                  'weight' => 0.25,
                  'style' => 
                  array (
                  ),
                ),
                2 => 
                array (
                  'grid' => 1,
                  'index' => 1,
                  'weight' => 0.25,
                  'style' => 
                  array (
                  ),
                ),
                3 => 
                array (
                  'grid' => 1,
                  'index' => 2,
                  'weight' => 0.25,
                  'style' => 
                  array (
                  ),
                ),
                4 => 
                array (
                  'grid' => 1,
                  'index' => 3,
                  'weight' => 0.25,
                  'style' => 
                  array (
                  ),
                ),
              ),
            ),
            'builder_id' => '59427a2b29b40',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'grid' => 2,
              'cell' => 0,
              'id' => 2,
              'widget_id' => 'afc79071-dc1a-4452-b46b-0a0aeed9ca5c',
              'style' => 
              array (
                'background_image_attachment' => false,
                'background_display' => 'tile',
              ),
            ),
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
          ),
          3 => 
          array (
            'level' => '1',
            'type' => 'normal',
            'content' => 'Our Testimonials',
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 3,
              'cell' => 0,
              'id' => 3,
              'widget_id' => '9d073748-e163-4fc3-88fe-ce72c2f576e3',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '',
            'count' => '5',
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Testimonial_Widget',
              'raw' => false,
              'grid' => 3,
              'cell' => 0,
              'id' => 4,
              'widget_id' => 'e90414f7-a3ad-44a8-b666-e4312dff330f',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          5 => 
          array (
            'slider' => 'home-clients',
            'type' => 'carousel',
            'panels_info' => 
            array (
              'class' => 'Wbls_FlexSlider_Widget',
              'raw' => false,
              'grid' => 4,
              'cell' => 0,
              'id' => 5,
              'widget_id' => 'd519ee2d-537a-4999-a2f3-9401b8accc67',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'panel-row-style-full-width-layout black-bg',
              'background_display' => 'tile',
            ),
          ),
          2 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          3 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'panel-row-style-full-width-layout',
              'background_display' => 'cover',
              'row_stretch' => 'full',
            ),
          ),
          4 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'index' => 0,
            'weight' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'grid' => 1,
            'index' => 0,
            'weight' => 1,
            'style' => 
            array (
            ),
          ),
          2 => 
          array (
            'grid' => 2,
            'index' => 0,
            'weight' => 1,
            'style' => 
            array (
            ),
          ),
          3 => 
          array (
            'grid' => 3,
            'index' => 0,
            'weight' => 1,
            'style' => 
            array (
            ),
          ),
          4 => 
          array (
            'grid' => 4,
            'index' => 0,
            'weight' => 1,
            'style' => 
            array (
            ),
          ),
    ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'wbls-oner'),
      'description' => __( 'Pre Built layout for features page', 'wbls-oner'),
      'widgets' => array(
          0 => 
          array (
            'level' => '3',
            'type' => 'normal',
            'content' => 'Our Features',
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'bf88bdea-d4cd-4491-bbef-a7036116d9e9',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Responsive Layout',
            'text' => 'Oner is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'baefd766-7cc9-4885-9d71-5a618fecaec0',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Awesome Slider',
            'text' => 'Oner includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
            'icon' => 'fa-random',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '48c22eb7-b88f-41bb-944b-1398a33c191a',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Font Awesome',
            'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
            'icon' => 'fa-flag',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => 'f94fcce9-28ce-474d-be2a-65dae12b5c72',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Typography',
            'text' => 'Oner loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
            'icon' => 'fa-font',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 2,
              'cell' => 0,
              'id' => 4,
              'widget_id' => 'faf71750-cdb1-41ec-86a4-2efecce84dc2',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          5 => 
          array (
            'title' => 'Retina Ready',
            'text' => 'Oner is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
            'icon' => 'fa-magic',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 2,
              'cell' => 1,
              'id' => 5,
              'widget_id' => 'b75fa8bb-9281-4090-baf8-e6cf41a3d844',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          6 => 
          array (
            'title' => 'Excellent Support',
            'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
            'icon' => 'fa-flag',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 2,
              'cell' => 2,
              'id' => 6,
              'widget_id' => 'ed47c8d6-fa48-4f6b-bc32-dfe6b02a25b2',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          7 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'title' => 'Welcome to Oner Theme',
            'url' => 'http://www.webulousthemes.com/oner',
            'anchor_text' => 'Purchase Now',
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Cta_Widget',
              'raw' => false,
              'grid' => 3,
              'cell' => 0,
              'id' => 7,
              'widget_id' => 'bda59ba6-9ae1-48fa-a6a1-8012c04f2784',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          8 => 
          array (
            'title' => 'Advanced Admin',
            'text' => 'Oner uses advanced Redux Framework for theme options panel, you can customize any part of your site quickly and easily!',
            'icon' => 'fa-thumb-tack',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 4,
              'cell' => 0,
              'id' => 8,
              'widget_id' => '35b00908-7467-48c8-afc0-da9b9cb44d36',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          9 => 
          array (
            'title' => 'Page Builder',
            'text' => 'Oner supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
            'icon' => 'fa-plus',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 4,
              'cell' => 1,
              'id' => 9,
              'widget_id' => 'a2ab0285-2259-437f-97ba-fc34de388557',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          10 => 
          array (
            'title' => 'Page Layout',
            'text' => 'Oner offers many different page layouts so you can quickly and easily create your pages with no hassle!',
            'icon' => 'fa-copy (alias)',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 4,
              'cell' => 2,
              'id' => 10,
              'widget_id' => '5f5dea45-26bc-49c4-a025-b059220febb6',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          11 => 
          array (
            'title' => 'Custom Widget',
            'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
            'icon' => 'fa-beer',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 5,
              'cell' => 0,
              'id' => 11,
              'widget_id' => 'ff53140f-e322-4131-a0c4-96438f3f0acd',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          12 => 
          array (
            'title' => 'Shortcode Builder',
            'text' => 'Oner includes lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
            'icon' => 'fa-check-square',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 5,
              'cell' => 1,
              'id' => 12,
              'widget_id' => 'cce50142-d001-49ab-9894-38951a9ce6cd',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          13 => 
          array (
            'title' => 'Demo Content',
            'text' => 'Oner includes demo content files. You can quickly setup the site like our demo and get started easily!',
            'icon' => 'fa-times',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 5,
              'cell' => 2,
              'id' => 13,
              'widget_id' => '11e432da-9d3b-455e-9a46-2c9cb140d77b',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          14 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'title' => 'Welcome to Oner Theme',
            'url' => 'http://www.webulousthemes.com/oner',
            'anchor_text' => 'Purchase Now',
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Cta_Widget',
              'raw' => false,
              'grid' => 6,
              'cell' => 0,
              'id' => 14,
              'widget_id' => '7678fe71-7b40-49de-b929-3f8882fae801',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          15 => 
          array (
            'title' => 'Customization',
            'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
            'icon' => 'fa-shopping-cart',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 7,
              'cell' => 0,
              'id' => 15,
              'widget_id' => '59eea14b-8f9b-4581-88ef-4536ec47d410',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          16 => 
          array (
            'title' => 'Testimonials',
            'text' => 'With our testimonial post type, shortcode and widget, Displaying testimonials is a breeze.',
            'icon' => 'fa-rocket',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 7,
              'cell' => 1,
              'id' => 16,
              'widget_id' => '53c71165-1c6a-4765-a80e-5c6ab524d89b',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          17 => 
          array (
            'title' => 'Social Media',
            'text' => 'Want your users to stay in touch? No problem, Oner has Social Media icons all throughout the theme!',
            'icon' => 'fa-copy (alias)',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'grid' => 7,
              'cell' => 2,
              'id' => 17,
              'widget_id' => '870a93d0-68b4-4eae-8b79-71f6500406e7',
              'style' => 
              array (
                'background_image_attachment' => false,
                'background_display' => 'tile',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
          ),
          18 => 
          array (
            'title' => 'Google Map',
            'text' => 'Oner includes Goole Map as shortcode and widget. So, you can use it anywhere in your site!',
            'icon' => 'fa-map-marker',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 8,
              'cell' => 0,
              'id' => 18,
              'widget_id' => 'f87397d2-f417-4335-a3e3-5fa042d36093',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          19 => 
          array (
            'title' => 'Multiple Portfolio',
            'text' => '7 portfolio layouts, 3 blog layouts and multiple other alternate layouts for interior pages!',
            'icon' => 'fa-list-alt',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'vertical',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 8,
              'cell' => 1,
              'id' => 19,
              'widget_id' => '00065214-828a-45c1-857c-da56f48dca77',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          20 => 
          array (
            'title' => 'Multiple Sidebar',
            'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
            'icon' => 'fa-columns',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'vertical',
            'more' => '',
            'more_url' => '',
            'box' => false,
            'all_linkable' => false,
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 8,
              'cell' => 2,
              'id' => 20,
              'widget_id' => 'c6e0e995-2fcb-464f-8142-265a8595bc52',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          21 => 
          array (
            'slider' => 'home-clients',
            'type' => 'carousel',
            'panels_info' => 
            array (
              'class' => 'Wbls_FlexSlider_Widget',
              'raw' => false,
              'grid' => 9,
              'cell' => 0,
              'id' => 21,
              'widget_id' => '046954aa-d7c1-468f-a13c-077014d2e544',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
          2 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
          3 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
          4 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
          5 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
          6 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
          7 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
          8 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
          9 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'panel-row-style-full-width-layout-carousel ',
              'background_display' => 'tile',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'index' => 0,
            'weight' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'grid' => 1,
            'index' => 0,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          2 => 
          array (
            'grid' => 1,
            'index' => 1,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          3 => 
          array (
            'grid' => 1,
            'index' => 2,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          4 => 
          array (
            'grid' => 2,
            'index' => 0,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          5 => 
          array (
            'grid' => 2,
            'index' => 1,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          6 => 
          array (
            'grid' => 2,
            'index' => 2,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          7 => 
          array (
            'grid' => 3,
            'index' => 0,
            'weight' => 1,
            'style' => 
            array (
            ),
          ),
          8 => 
          array (
            'grid' => 4,
            'index' => 0,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          9 => 
          array (
            'grid' => 4,
            'index' => 1,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          10 => 
          array (
            'grid' => 4,
            'index' => 2,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          11 => 
          array (
            'grid' => 5,
            'index' => 0,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          12 => 
          array (
            'grid' => 5,
            'index' => 1,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          13 => 
          array (
            'grid' => 5,
            'index' => 2,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          14 => 
          array (
            'grid' => 6,
            'index' => 0,
            'weight' => 1,
            'style' => 
            array (
            ),
          ),
          15 => 
          array (
            'grid' => 7,
            'index' => 0,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          16 => 
          array (
            'grid' => 7,
            'index' => 1,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          17 => 
          array (
            'grid' => 7,
            'index' => 2,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          18 => 
          array (
            'grid' => 8,
            'index' => 0,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          19 => 
          array (
            'grid' => 8,
            'index' => 1,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          20 => 
          array (
            'grid' => 8,
            'index' => 2,
            'weight' => 0.33333333333332998,
            'style' => 
            array (
            ),
          ),
          21 => 
          array (
            'grid' => 9,
            'index' => 0,
            'weight' => 1,
            'style' => 
            array (
            ),
          ),
    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-oner'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-oner'),
      'widgets' => array(
          0 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'level' => '1',
                  'type' => 'normal',
                  'content' => 'Contact Us',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Heading_Widget',
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'widget_id' => 'c95f625b-6440-429b-af14-f3d81a0e173a',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'mobile_padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                  'portfolio_cat' => '',
                  'portfolio_skill' => '',
                  'portfolio_column' => '',
                ),
                1 => 
                array (
                  'title' => '',
                  'text' => 'Po Box CT16122 Colins Street West, Australia / 1(2)345 6782 , / <a href="mailto:info@gmail.com"> info@gmail.com</a>',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 1,
                    'widget_id' => 'c6bf8285-70d6-4548-bd6a-5cb417f8c355',
                    'style' => 
                    array (
                      'class' => 'contact-info',
                      'widget_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'mobile_padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                  'filter' => false,
                  'portfolio_cat' => '',
                  'portfolio_skill' => '',
                  'portfolio_column' => '',
                ),
                2 => 
                array (
                  'title' => '',
                  'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d448190.25139036635!2d76.81055816501677!3d28.645153201805222!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd5b347eb62d%3A0x52c2b7494e204dce!2sNew+Delhi%2C+Delhi+110001!5e0!3m2!1sen!2sin!4v1452153536643" width="800" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 2,
                    'widget_id' => '3fb9a74a-bf0d-4420-a3d2-75cec1967689',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                3 => 
                array (
                  'title' => '',
                  'text' => '[contact-form-7 id="387" title="Contact form-t"]',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 1,
                    'id' => 3,
                    'widget_id' => '33d30cc8-4c5f-4b59-98e1-1650903c696a',
                    'style' => 
                    array (
                      'class' => 'contact-form',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                  ),
                ),
                1 => 
                array (
                  'cells' => 2,
                  'style' => 
                  array (
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 1,
                ),
                1 => 
                array (
                  'grid' => 1,
                  'weight' => 0.62835820895521999,
                ),
                2 => 
                array (
                  'grid' => 1,
                  'weight' => 0.37164179104478001,
                ),
              ),
            ),
            'builder_id' => '58f9adbbd195f',
            'portfolio_cat' => '',
            'portfolio_skill' => '',
            'portfolio_column' => '',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '1433242f-9d1e-4568-9156-ba3f8c5f6f68',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
          1 => 
          array (
            'slider' => 'home-clients',
            'type' => 'carousel',
            'panels_info' => 
            array (
              'class' => 'Wbls_FlexSlider_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '2284c765-0228-4c70-b623-b977bfcbc8f0',
              'style' => 
              array (
                'background_display' => 'tile',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'panel-row-style-full-width-layout-carousel',
              'background_display' => 'tile',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-oner'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-oner'),
    'widgets' =>  array(
        0 => 
        array (
          'panels_data' => 
          array (
            'widgets' => 
            array (
              0 => 
              array (
                'title' => 'Faq\'s',
                'text' => '',
                'panels_info' => 
                array (
                  'class' => 'WP_Widget_Text',
                  'grid' => 0,
                  'cell' => 0,
                  'id' => 0,
                  'widget_id' => '0cae776a-9219-4226-8a3e-edc016d17866',
                  'style' => 
                  array (
                    'class' => 'title-divider',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
                'filter' => false,
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
              ),
              1 => 
              array (
                'title' => '',
                'text' => '[accordion_group][accordion title=" Suspendisse massa odio"]Ut at lacinia erat. Aliquam lacus ex, tristique vitae quam nec, egestas scelerisque elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nunc tempor quam eu posuere porttitor. Etiam quis lectus est. Morbi ac gravida odio. Aliquam efficitur nisl orci, ac vestibulum ipsum blandit id. Aliquam lacinia eget sapien nec pulvinar. Praesent nibh erat, imperdiet non ornare euismod, rutrum ut mi. Quisque et risus in dolor porttitor iaculis.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu  Etiam semper tortor arcu, volutpat consequat est convallis eu. Nulla posuere neque quis mi laoreet volutpat.[/accordion][accordion title=" Praesent condimentum metus mauris"]In id lectus sed justo rhoncus luctus. Praesent imperdiet, massa et cursus sollicitudin, nibh tellus ullamcorper magna, eu fringilla est mi id magna. Etiam elit ex, pulvinar quis vehicula vitae, molestie eget ante. In hac habitasse platea dictumst. Duis turpis risus, ultricies sit amet libero pharetra, vestibulum imperdiet nisi. Integer sapien orci, placerat eu pretium a, faucibus eget massa. Nam gravida nisi eget felis consectetur, nec vestibulum urna malesuada.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu Integer nec faucibus sem, vitae molestie arcu. [/accordion][accordion title="Vivamus dignissim dolor fermentum."]Donec ornare scelerisque convallis. Integer at erat in dolor fringilla ornare ut vitae est. Vivamus vulputate bibendum ex ac pulvinar. Cras tincidunt lorem elementum, mollis felis ut, tristique ante. Cras mattis ante a metus dapibus, nec sollicitudin massa blandit. Sed eget augue eget leo elementum porta eu non augue. Aenean ac diam eget orci molestie eleifend id et ipsum. Quisque ac tellus ac ligula condimentum fermentum. Donec congue lorem nec pellentesque efficitur. Sed imperdiet molestie nibh efficitur feugiat. Mauris scelerisque et neque sed pellentesque. Vivamus finibus lectus ut erat bibendum bibendum. Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu[/accordion][accordion title="Mauris auctor vulputate urna"]Aenean laoreet, dolor sit amet faucibus finibus, sem sem interdum velit, et egestas libero enim sit amet libero. Maecenas nec nisi ut nibh luctus lacinia eu id magna. Duis sed arcu ipsum. Sed dictum a nisi vel pellentesque. Maecenas semper posuere rhoncus. Sed consectetur nibh felis, quis porttitor velit gravida eget. Donec lectus dolor, tincidunt finibus quam vitae, vulputate gravida ipsum. Integer blandit velit ante, eu placerat ligula mollis eget. Suspendisse elit metus, mollis at vehicula in, venenatis ut purus. Integer mollis scelerisque est, at congue nisi aliquam quis. Nulla vitae purus id nisl cursus tempor. Integer nibh risus, feugiat nec dui sed, dapibus tincidunt tortor. Pellentesque porta scelerisque lorem, sit amet porta dui. Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu [/accordion][accordion title="Praesent pulvinar pretium magna"] Sed dictum a nisi vel pellentesque. Maecenas semper posuere rhoncus. Sed consectetur nibh felis, quis porttitor velit gravida eget. Donec lectus dolor, tincidunt finibus quam vitae, vulputate gravida ipsum. Integer blandit velit ante, eu placerat ligula mollis eget. Suspendisse elit metus, mollis at vehicula in, venenatis ut purus. Integer mollis scelerisque est, at congue nisi aliquam quis. Nulla vitae purus id nisl cursus tempor. Integer nibh risus, feugiat nec dui sed, dapibus tincidunt tortor. Pellentesque porta scelerisque lorem, sit amet porta dui.Aenean laoreet, dolor sit amet faucibus finibus, sem sem interdum velit, et egestas libero enim sit amet libero. Maecenas nec nisi ut nibh luctus lacinia eu id magna. Duis sed arcu ipsum.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu  [/accordion][accordion title="Etiam eget lorem nisi Duis neque."] Maecenas nec nisi ut nibh luctus lacinia eu id magna. Duis sed arcu ipsum. Sed dictum a nisi vel pellentesque. Maecenas semper posuere rhoncus. Sed consectetur nibh felis, quis porttitor velit gravida eget. Donec lectus dolor, tincidunt finibus quam vitae, vulputate gravida ipsum. Integer blandit velit ante, eu placerat ligula mollis eget. Suspendisse elit metus, mollis at vehicula in, venenatis ut purus. Integer mollis scelerisque est, at congue nisi aliquam quis. Nulla vitae purus id nisl cursus tempor. Integer nibh risus, feugiat nec dui sed, dapibus tincidunt tortor. Pellentesque porta scelerisque lorem, sit amet porta dui.Aenean laoreet, dolor sit amet faucibus finibus, sem sem interdum velit, et egestas libero enim sit amet libero.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu  [/accordion][accordion title="Aliquam rutrum tortor quis ultrices ultricies."]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. Cras venenatis a nibh ut placerat. Vivamus a mauris non quam pretium lobortis non ac odio. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="Curabitur rutrum vehicula enim et pulvinar."] Sed nec massa lorem. Phasellus ut tincidunt velit, id scelerisque lorem. Nullam nisl tortor, mollis ut massa in, dapibus tincidunt libero. Pellentesque pretium posuere turpis eget dignissim. Curabitur sapien lorem, feugiat et velit et, vehicula aliquet urna. Vivamus pellentesque lorem at urna suscipit, at vulputate est ultricies. Aliquam ultrices nec massa sed adipiscing. Pellentesque feugiat sodales tellus. Ut tempus aliquam felis, quis consequat nunc hendrerit eget. Praesent sollicitudin nunc eu sollicitudin placerat. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="Pellentesque iaculis vulputate blandit."]Aliquam non lacus in lacus aliquet blandit. Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. Sed ut augue vitae augue vestibulum pulvinar. Fusce commodo ultricies volutpat. Vivamus quis nulla porta, faucibus metus eu, tempus dolor. Ut sed faucibus mi, ac volutpat lectus. Morbi a rhoncus erat. Mauris et metus posuere, imperdiet urna at, congue risus. Nunc at ante sed ipsum porttitor scelerisque semper non libero. Vivamus feugiat nisl sit amet mi tristique dictum. Donec id magna facilisis, euismod sem bibendum, interdum lorem. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title=" Vestibulum in mi mauris. Duis luctus dolor ante."]Fusce vehicula risus lorem, sed ultricies neque pellentesque at. Ut dapibus aliquam leo non cursus. Donec eros dui, fringilla vel lacinia id, tincidunt ac eros. Ut ultrices elit nec viverra adipiscing. Aliquam suscipit viverra luctus. Vivamus rhoncus molestie hendrerit. Aenean id lacinia odio. Nullam sit amet dui accumsan, ornare nisi at, ornare elit. Proin ut dolor risus. Cras quis pellentesque felis, at venenatis nibh. Quisque tincidunt id enim a aliquam. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][/accordion_group]',
                'panels_info' => 
                array (
                  'class' => 'WP_Widget_Text',
                  'grid' => 1,
                  'cell' => 0,
                  'id' => 1,
                  'widget_id' => '0cae776a-9219-4226-8a3e-edc016d17866',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
                'filter' => false,
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
              ),
            ),
            'grids' => 
            array (
              0 => 
              array (
                'cells' => 1,
                'style' => 
                array (
                  'class' => '',
                  'cell_class' => '',
                  'row_css' => '',
                  'bottom_margin' => '',
                  'gutter' => '',
                  'padding' => '',
                  'row_stretch' => '',
                  'background' => '',
                  'background_image_attachment' => '0',
                  'background_display' => 'tile',
                  'border_color' => '',
                ),
              ),
              1 => 
              array (
                'cells' => 1,
                'style' => 
                array (
                  'class' => '',
                  'cell_class' => '',
                  'row_css' => '',
                  'bottom_margin' => '',
                  'gutter' => '',
                  'padding' => '',
                  'row_stretch' => '',
                  'background' => '',
                  'background_image_attachment' => '0',
                  'background_display' => 'tile',
                  'border_color' => '',
                ),
              ),
            ),
            'grid_cells' => 
            array (
              0 => 
              array (
                'grid' => 0,
                'weight' => 1,
              ),
              1 => 
              array (
                'grid' => 1,
                'weight' => 1,
              ),
            ),
          ),
          'builder_id' => '58f988e05fe9a',
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'SiteOrigin_Panels_Widgets_Layout',
            'raw' => false,
            'grid' => 0,
            'cell' => 0,
            'id' => 0,
            'widget_id' => '5e30ee62-cc78-4689-ba6f-c39d52c7cf07',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        1 => 
        array (
          'slider' => 'home-clients',
          'type' => 'carousel',
          'panels_info' => 
          array (
            'class' => 'Wbls_FlexSlider_Widget',
            'raw' => false,
            'grid' => 1,
            'cell' => 0,
            'id' => 1,
            'widget_id' => 'e48f92df-ae9e-4c40-9d2f-c089066a4325',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
      ),
      'grids' => 
      array (
        0 => 
        array (
          'cells' => 1,
          'style' => 
          array (
            'background_display' => 'tile',
          ),
        ),
        1 => 
        array (
          'cells' => 1,
          'style' => 
          array (
            'class' => 'panel-row-style-full-width-layout-carousel',
            'background_display' => 'tile',
          ),
        ),
      ),
      'grid_cells' => 
      array (
        0 => 
        array (
          'grid' => 0,
          'weight' => 1,
        ),
        1 => 
        array (
          'grid' => 1,
          'weight' => 1,
        ),
      ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-oner'),
    'description' => __('Pre Built Layout for services page', 'wbls-oner'),
    'widgets' =>  array(
        0 => 
        array (
          'level' => '1',
          'type' => 'normal',
          'content' => 'Our Services',
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_Heading_Widget',
            'raw' => false,
            'grid' => 0,
            'cell' => 0,
            'id' => 0,
            'widget_id' => '186a411a-db46-4fd1-960c-272f7ea86328',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        1 => 
        array (
          'type' => 'circle',
          'title' => 'Responsive Layout',
          'text' => 'Oner is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
          'icon' => 'fa-mobile',
          'icon_background_color' => '',
          'icon_size' => '2x',
          'more' => '',
          'more_url' => '',
          'box' => false,
          'all_linkable' => false,
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_CircleIcon_Widget',
            'raw' => false,
            'grid' => 1,
            'cell' => 0,
            'id' => 1,
            'widget_id' => '1bc94a9c-32a6-4913-adfa-43589103dda2',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        2 => 
        array (
          'type' => 'circle',
          'title' => 'Awesome Slider',
          'text' => 'Oner includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site',
          'icon' => 'fa-random',
          'icon_background_color' => '',
          'icon_size' => '2x',
          'more' => '',
          'more_url' => '',
          'box' => false,
          'all_linkable' => false,
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_CircleIcon_Widget',
            'raw' => false,
            'grid' => 1,
            'cell' => 1,
            'id' => 2,
            'widget_id' => '90ae9cb4-127c-495e-9ee4-21fb4d2ff6fc',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        3 => 
        array (
          'type' => 'circle',
          'title' => 'Font Awesome',
          'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
          'icon' => 'fa-flag',
          'icon_background_color' => '',
          'icon_size' => '2x',
          'more' => '',
          'more_url' => '',
          'box' => false,
          'all_linkable' => false,
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_CircleIcon_Widget',
            'raw' => false,
            'grid' => 1,
            'cell' => 2,
            'id' => 3,
            'widget_id' => '6cf98925-7c71-4a75-98b0-1121a9b27f6b',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        4 => 
        array (
          'type' => 'circle',
          'title' => 'Custom Widget',
          'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
          'icon' => 'fa-beer',
          'icon_background_color' => '',
          'icon_size' => '2x',
          'more' => '',
          'more_url' => '',
          'box' => false,
          'all_linkable' => false,
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_CircleIcon_Widget',
            'raw' => false,
            'grid' => 2,
            'cell' => 0,
            'id' => 4,
            'widget_id' => '9cadd8a3-7d63-43ea-9f4e-eb97b2a0c92f',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        5 => 
        array (
          'type' => 'circle',
          'title' => 'Shortcode Builder',
          'text' => 'Oner inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
          'icon' => 'fa-check-square',
          'icon_background_color' => '',
          'icon_size' => '2x',
          'more' => '',
          'more_url' => '',
          'box' => false,
          'all_linkable' => false,
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_CircleIcon_Widget',
            'raw' => false,
            'grid' => 2,
            'cell' => 1,
            'id' => 5,
            'widget_id' => 'd34f7cdf-6c78-43c3-ab2e-f304a6d6e54b',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        6 => 
        array (
          'type' => 'circle',
          'title' => 'Demo Content',
          'text' => 'Oner includes demo content files. You can quickly setup the site like our demo and get started easily!',
          'icon' => 'fa-times',
          'icon_background_color' => '',
          'icon_size' => '2x',
          'more' => '',
          'more_url' => '',
          'box' => false,
          'all_linkable' => false,
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
          'panels_info' => 
          array (
            'class' => 'Wbls_CircleIcon_Widget',
            'raw' => false,
            'grid' => 2,
            'cell' => 2,
            'id' => 6,
            'widget_id' => 'eca0047f-7afa-4b9d-bfde-19493b97309d',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        7 => 
        array (
          'panels_data' => 
          array (
            'widgets' => 
            array (
              0 => 
              array (
                'level' => '1',
                'type' => 'normal',
                'content' => 'Testimonials',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Heading_Widget',
                  'grid' => 0,
                  'cell' => 0,
                  'id' => 0,
                  'widget_id' => '0517ee9d-2a6c-4851-97c3-522cb4aec481',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
              ),
              1 => 
              array (
                'title' => '',
                'count' => '5',
                'portfolio_cat' => '',
                'portfolio_skill' => '',
                'portfolio_column' => '',
                'panels_info' => 
                array (
                  'class' => 'Wbls_Testimonial_Widget',
                  'raw' => false,
                  'grid' => 0,
                  'cell' => 0,
                  'id' => 1,
                  'widget_id' => 'f22a75e3-0d8a-47e9-a9db-a8bf08a7a55b',
                  'style' => 
                  array (
                    'class' => '',
                    'widget_css' => '',
                    'animation_class' => '',
                    'padding' => '',
                    'mobile_padding' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                    'font_color' => '',
                    'link_color' => '',
                  ),
                ),
              ),
            ),
            'grids' => 
            array (
              0 => 
              array (
                'cells' => 1,
                'style' => 
                array (
                  'id' => '',
                  'class' => '',
                  'cell_class' => '',
                  'row_css' => '',
                  'animation_class' => '',
                  'bottom_margin' => '',
                  'gutter' => '',
                  'padding' => '',
                  'mobile_padding' => '',
                  'row_stretch' => '',
                  'collapse_order' => '',
                  'background' => '',
                  'background_image_attachment' => '0',
                  'background_display' => 'tile',
                  'border_color' => '',
                ),
              ),
            ),
            'grid_cells' => 
            array (
              0 => 
              array (
                'grid' => 0,
                'weight' => 1,
              ),
            ),
          ),
          'builder_id' => '58f9dc491259b',
          'panels_info' => 
          array (
            'class' => 'SiteOrigin_Panels_Widgets_Layout',
            'grid' => 3,
            'cell' => 0,
            'id' => 7,
            'widget_id' => '9abb01ed-f4ac-44bf-8a23-f6ac8e6bb284',
            'style' => 
            array (
              'background_image_attachment' => false,
              'background_display' => 'tile',
            ),
          ),
          'portfolio_cat' => '',
          'portfolio_skill' => '',
          'portfolio_column' => '',
        ),
        8 => 
        array (
          'title' => 'Skills',
          'panels_info' => 
          array (
            'class' => 'Wbls_Skill_Widget',
            'raw' => false,
            'grid' => 4,
            'cell' => 0,
            'id' => 8,
            'widget_id' => '97d29d38-511b-461b-8002-881b616a61ef',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
        9 => 
        array (
          'title' => 'Our Tabs',
          'text' => '[tabs_group type="normal"][tabs title="Graphics"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.[/tabs][tabs title="Web Design"] It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.[/tabs][tabs title="Word Press"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.[/tabs][/tabs_group]
    ',
          'filter' => false,
          'panels_info' => 
          array (
            'class' => 'WP_Widget_Text',
            'raw' => false,
            'grid' => 4,
            'cell' => 1,
            'id' => 9,
            'widget_id' => '4e4a2cfb-5b5f-42ae-97d4-52207a9d6a8e',
            'style' => 
            array (
              'class' => 'title-divider-left',
              'background_display' => 'tile',
            ),
          ),
        ),
        10 => 
        array (
          'slider' => 'home-clients',
          'type' => 'carousel',
          'panels_info' => 
          array (
            'class' => 'Wbls_FlexSlider_Widget',
            'raw' => false,
            'grid' => 5,
            'cell' => 0,
            'id' => 10,
            'widget_id' => 'e27b834c-ca4e-4d16-ab97-698a41c81bb0',
            'style' => 
            array (
              'background_display' => 'tile',
            ),
          ),
        ),
      ),
      'grids' => 
      array (
        0 => 
        array (
          'cells' => 1,
          'style' => 
          array (
          ),
        ),
        1 => 
        array (
          'cells' => 3,
          'style' => 
          array (
            'background_display' => 'tile',
          ),
        ),
        2 => 
        array (
          'cells' => 3,
          'style' => 
          array (
            'background_display' => 'tile',
          ),
        ),
        3 => 
        array (
          'cells' => 1,
          'style' => 
          array (
            'class' => 'panel-row-style-full-width-layout top-curve-divider',
            'background_display' => 'tile',
          ),
        ),
        4 => 
        array (
          'cells' => 2,
          'style' => 
          array (
            'background_display' => 'tile',
          ),
        ),
        5 => 
        array (
          'cells' => 1,
          'style' => 
          array (
            'class' => 'panel-row-style-full-width-layout-carousel',
            'background_display' => 'tile',
          ),
        ),
      ),
      'grid_cells' => 
      array (
        0 => 
        array (
          'grid' => 0,
          'weight' => 1,
        ),
        1 => 
        array (
          'grid' => 1,
          'weight' => 0.33333333333333331,
        ),
        2 => 
        array (
          'grid' => 1,
          'weight' => 0.33333333333333331,
        ),
        3 => 
        array (
          'grid' => 1,
          'weight' => 0.33333333333333331,
        ),
        4 => 
        array (
          'grid' => 2,
          'weight' => 0.33333333333333331,
        ),
        5 => 
        array (
          'grid' => 2,
          'weight' => 0.33333333333333331,
        ),
        6 => 
        array (
          'grid' => 2,
          'weight' => 0.33333333333333331,
        ),
        7 => 
        array (
          'grid' => 3,
          'weight' => 1,
        ),
        8 => 
        array (
          'grid' => 4,
          'weight' => 0.48897795591181997,
        ),
        9 => 
        array (
          'grid' => 4,
          'weight' => 0.51102204408817997,
        ),
        10 => 
        array (
          'grid' => 5,
          'weight' => 1,
        ),

   ),
    
  );

  return $layouts;
  }
}
add_filter('siteorigin_panels_prebuilt_layouts', 'webulous_prebuilt_page_layouts');



function wbls_modulus_panels_row_style_fields($fields) {  

    $modulus_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-oner'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-oner' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-oner' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-oner' ),
        'bounce-animation' => __('bounce-animation','wbls-oner' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-oner' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-oner' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-oner' ),
        'expandUp-animation' => __('expandUp-animation','wbls-oner' ),
        'fade-animation' => __('fade-animation','wbls-oner' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-oner' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-oner' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-oner' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-oner' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-oner' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-oner' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-oner' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-oner' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-oner' ),
        'flip-animation' => __('flip-animation','wbls-oner' ),
        'flipInX-animation' => __('flipInX-animation','wbls-oner' ),
        'flipInY-animation' => __('flipInY-animation','wbls-oner' ),
        'floating-animation' => __('floating-animation','wbls-oner' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-oner' ),
        'hatch-animation' => __('hatch-animation','wbls-oner' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-oner' ),
        'puffIn-animation' => __('puffIn-animation','wbls-oner' ),
        'pullDown-animation' => __('pullDown-animation','wbls-oner' ),
        'pullUp-animation' => __('pullUp-animation','wbls-oner' ),
        'pulse-animation' => __('pulse-animation','wbls-oner' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-oner' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-oner' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-oner' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-oner' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-oner' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-oner' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-oner' ),
        'scale-down-animation' => __('scale-down-animation','wbls-oner' ),
        'scale-up-animation' => __('scale-up-animation','wbls-oner' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-oner' ),
        'slide-left-animation' => __('slide-left-animation','wbls-oner' ),
        'slide-right-animation' => __('slide-right-animation','wbls-oner' ),
        'slide-top-animation' => __('slide-top-animation','wbls-oner' ),
        'slideDown-animation' => __('slideDown-animation','wbls-oner' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-oner' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-oner' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-oner' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-oner' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-oner' ),
        'slideRight-animation' => __('slideRight-animation','wbls-oner' ),
        'slideUp-animation' => __('slideUp-animation','wbls-oner' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-oner' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-oner' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-oner' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-oner' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-oner' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-oner' ),
        'swap-animation'  => __('swap-animation','wbls-oner' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-oner' ),
        'swing-animation'  => __('swing-animation','wbls-oner' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-oner' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-oner' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-oner' ), 
        'tossing-animation'  => __('tossing-animation','wbls-oner' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-oner' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-oner' ), 
        'wobble-animation' => __('wobble-animation','wbls-oner' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-oner' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'oner'),
            'type' => 'select',
            'options' => $modulus_animation_name,
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_modulus_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_modulus_panels_row_style_fields');

function wbls_modulus_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_modulus_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_modulus_panels_panels_row_style_attributes', 10, 2);

function wbls_modulus_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Animation', 'wbls-oner'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_modulus_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_modulus_row_style_groups' );