<?php
	$instance = wp_parse_args( $instance, array(
			'portfolio_cat' => '',
			'portfolio_skill' => '',
			'portfolio_column' => 4,
	) );
	
	$title = apply_filters( 'widget_title', $instance['title'] );
	echo $args['before_widget'];

	if ( ! empty( $title ) ) {
		echo $args['before_title'] . $title . $args['after_title'];
	}

	if ( $instance['type'] == "carousel" ) {
		if ( ! empty( $instance['count'] ) ) : ?><?php echo do_shortcode( '[recent_work count="' . $instance['count'] . '"]' ); ?><?php endif;
	} else {
		if ( ! empty( $instance['count'] ) ) : ?><?php echo do_shortcode('[recent_work_isotope count="' . $instance['count'] . '" portfolio_cat="'. $instance['portfolio_cat']. '" portfolio_skill="'. $instance['portfolio_skill'].'" portfolio_column="'. $instance['portfolio_column']. '"]'); ?><?php endif;
	}  