<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0 
 */

/**
 * Adds default page layouts 
 *
 * @param $layouts
 */
if (!function_exists('wbls_brawny_prebuilt_page_layouts') ) {   
function wbls_brawny_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-brawny'),
    'description' => __('Pre Built Layout for  home page', 'wbls-brawny'),
    'widgets' =>  array(
        0 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'f7248eb9-1f76-428f-9bad-1e21e2991809',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Our Services',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '013485e9-f4fd-4910-a192-f81b45ce4ced',
        'style' => 
        array (
          'class' => 'tcenter tcapital',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'type' => 'circle',
      'title' => 'Responsive Layout',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard',
      'icon' => 'fa-desktop',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://google.com/',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '6283d34f-80e1-459b-8d50-5e2d87ebd8db',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
    3 => 
    array (
      'type' => 'circle',
      'title' => 'Dedicated  Support',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard',
      'icon' => 'fa-lightbulb-o',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://google.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 3,
        'widget_id' => '7f9e3ec7-a627-4ee5-bb4f-9174764d1c79',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'type' => 'circle',
      'title' => 'Fully Customizable',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard',
      'icon' => 'fa-flask',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://google.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 4,
        'widget_id' => '015ba1f4-29cf-47c5-bd0a-eece9b7100a0',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 5,
        'widget_id' => 'f7248eb9-1f76-428f-9bad-1e21e2991809',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Our Team',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '77e282c9-0988-4da7-b671-4d4e2d8afb75',
        'style' => 
        array (
          'class' => 'tcenter tcapital',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'height' => '10',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 7,
        'widget_id' => 'e6059250-a3db-452a-aada-82cad804badf',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'content' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alternation in some form, by injected humour, or randomised.',
            'image_url' => 'http://brawny.webulous.in/wp-content/uploads/2016/06/one.png',
            'title' => 'John Doe',
            'designation' => 'CEO',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '3fd0a6fe-c650-4b79-8686-e90e7586b365',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alternation in some form, by injected humour, or randomised.',
            'image_url' => 'http://brawny.webulous.in/wp-content/uploads/2016/06/two.png',
            'title' => 'Jessica Lee',
            'designation' => 'Marketing Manager',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '2725c6df-c41a-4af8-ae45-b65b15915c3e',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alternation in some form, by injected humour, or randomised.',
            'image_url' => 'http://brawny.webulous.in/wp-content/uploads/2016/06/three.png',
            'title' => 'Christober',
            'designation' => 'Administrator',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '260e81d3-1a43-491e-ae98-26480c52f06e',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alternation in some form, by injected humour, or randomised.',
            'image_url' => 'http://brawny.webulous.in/wp-content/uploads/2016/06/Four.png',
            'title' => 'Kate Smith',
            'designation' => 'Accountant',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'widget_id' => '3154cb14-1f16-42fd-b259-84be75bad834',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '5774eab15beef',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'a75f317b-8b19-4da0-a589-20dc861fade5',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'height' => '80',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 9,
        'widget_id' => 'dad0bc48-8377-486d-b4e0-487d77bd3f11',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Our recent works',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. ',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 10,
        'widget_id' => 'd6507da2-9834-45ac-a73b-d8ed1b98e855',
        'style' => 
        array (
          'class' => 'txt-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => '',
      'count' => '12',
      'type' => 'isotope',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Work_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 11,
        'widget_id' => '47bcc749-21f0-46f1-87ba-6b0e2d979c4f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Fun Facts',
            'text' => 'Cras sed mauris augue. In at pellentesque sem. Vestibulum susciptin mi sodales tortor vehicula laoreet. Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'e0423828-e30a-4998-ab3a-083083dd928c',
              'style' => 
              array (
                'class' => 'tcenter tcapital',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'height' => '15',
            'panels_info' => 
            array (
              'class' => 'Wbls_Gap_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '7826d052-855a-45b5-bb0a-d65565061146',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => '<i class="fa fa-users"></i>[headline level="1" type="normal" align="tcenter"]7,381[/headline][headline level="4" type="normal" align="tcenter"]Customers[/headline]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 2,
              'widget_id' => 'fef1ec41-669a-48ef-90ee-305f083acd08',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '',
            'text' => '<i class="fa fa-check"></i>[headline level="1" type="normal" align="tcenter"]10,121[/headline][headline level="4" type="normal" align="tcenter"]Improvements[/headline]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 3,
              'widget_id' => 'd0e4db24-ab17-4a1f-a5e3-f690086433f6',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '',
            'text' => '<i class="fa fa-cloud-upload"></i>[headline level="1" type="normal" align="tcenter"]6,111[/headline][headline level="4" type="normal" align="tcenter"]Lines of Code[/headline]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 4,
              'widget_id' => '1764a867-9290-44ca-8828-f70145a4126c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => '',
            'text' => '<i class="fa fa-coffee"></i>[headline level="1" type="normal" align="tcenter"]870[/headline][headline level="4" type="normal" align="tcenter"]Coffee[/headline]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 5,
              'widget_id' => '7b7d2a03-7310-4a70-bb36-0fd18fec4759',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '5774e81422374',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 12,
        'widget_id' => '2002b438-7e8d-46c7-9e8e-c299cd9e338c',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'height' => '30',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 13,
        'widget_id' => 'a4b52dd7-bc10-4e19-a9dc-fca9ad24557e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'title' => '',
      'text' => '[headline level="3" type="normal" align="tcenter tcapital"]brawny is multipurpose wordpress theme[/headline][gap height="30"] Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s[gap height="50"][button link="http://webulous.in/" target="_self" color="btn-white" size="btn-normal"]List of Features[/button][button link="http://webulous.in/" target="_self" color="btn-white" size="btn-normal"]Buy Now[/button]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 14,
        'widget_id' => 'd6347b2f-821b-439a-b42a-6a59c7c5ff7c',
        'style' => 
        array (
          'class' => 'features tcapital white-button',
          'padding' => '80px',
          'background_display' => 'parallax-original',
        ),
      ),
    ),
    15 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'src' => 'http://brawny.webulous.in/wp-content/uploads/2016/06/lorem.png',
            'href' => 'http://brawny.webulous.in/wp-content/uploads/2016/06/lorem.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'c6813d86-ad32-481d-8fc5-38072254c6ca',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Lorem Ipsum is simply dummy',
            'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. <p>[gap height="10"]
[button link="http://webulous.in/" target="_self" color="btn-inverse" size="btn-normal"]Send[/button]</p>',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '735189ac-2115-4ecb-a019-46f77676c854',
              'style' => 
              array (
                'class' => 'align-justify black-button ',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'top_border' => '',
              'bottom_border' => '',
              'background_image' => '',
              'background' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.53872889771598997,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.46127110228401003,
          ),
        ),
      ),
      'builder_id' => '5774bde8a890b',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 15,
        'widget_id' => '28dd7afd-d8d7-4fb0-81f9-632d2f7e56bd',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'height' => '80',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 16,
        'widget_id' => 'd1a4353e-0e7d-4852-b423-541e53018099',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'title' => 'Testimonials & About Us',
      'text' => 'WHAT OUR HAPPY CLIENTS SAY ABOUT US',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 17,
        'widget_id' => '12033b2d-2c6b-4820-9f69-add8d7da7b5f',
        'style' => 
        array (
          'class' => 'content-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Testimonials',
            'count' => '5',
            'panels_info' => 
            array (
              'class' => 'Wbls_Testimonial_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'c2c46d3d-99d1-4040-adac-6b1f55796553',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '126fc752-5e41-4e76-94d7-863ea89a5742',
              'style' => 
              array (
                'class' => 'align-justify',
                'widget_css' => '',
                'padding' => '20px',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.48689282960677999,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.51310717039321996,
          ),
        ),
      ),
      'builder_id' => '5774c244ed91e',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 18,
        'widget_id' => 'b5e5b1de-66e0-474a-be4d-ddbcc23000b8',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'height' => '80',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 19,
        'widget_id' => 'd1ca29b8-a30f-43f8-bf5b-167b23190b0f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    20 => 
    array (
      'content' => 'Lorem ipsum Dummy Text Lorem ipsum Dummy Text Lorem ipsum Dummy Text',
      'title' => 'Brawny Pro',
      'url' => 'http://www.webulousthemes.com/',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 20,
        'widget_id' => '5a8bef2b-32bd-4b32-9d64-3f15f3dca535',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '10px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'class' => 'section-pattern',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'padding' => '20px',
        'row_stretch' => 'full',
        'background' => '#eeddee',
        'background_display' => 'tile',
        'background_image' => 'http://demo.webulous.in/brawny/wp-content/uploads/sites/10/2016/06/bg-repeat-pattern3.png',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'our-achive',
        'row_stretch' => 'full',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-bg ',
        'bottom_margin' => '100px',
        'row_stretch' => 'full',
        'background_display' => 'center',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'padding' => '50px',
        'row_stretch' => 'full',
        'background_display' => 'tile',
        'background_image' => 'http://demo.webulous.in/brawny/wp-content/uploads/sites/10/2016/06/bg-repeat-pattern3.png',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-bg ',
        'bottom_margin' => '0px',
        'row_stretch' => 'full',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    
    ),

  );
   $layouts['home-style2'] = array(
    'name' => __('Home Page2', 'wbls-brawny'),
    'description' => __( 'Pre Built layout for home page2', 'wbls-brawny'),
    'widgets' => array(
       0 => 
    array (
      'title' => 'Lightning fast',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard',
      'icon' => 'fa-bolt',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://google.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '4a8dd769-7510-42a2-89cc-67391deaf31c',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Built With Care',
      'text' => 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of',
      'icon' => 'fa-heart',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://google.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => 'a166a388-eb11-4b28-abdc-d8bdea48b24e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Mobile Ready',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown printer took a galley of type and',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://google.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 2,
        'widget_id' => 'bae71fac-30f7-4017-ba33-8864585f553f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => '',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. <p>[button link="http://webulous.in/" target="_self" color="btn-inverse" size="btn-normal"]Read More[/button]</p>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 3,
        'widget_id' => '95714e05-7eef-4529-8853-ca64f2151a75',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'height' => '30',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '570a3079-47ce-4001-bb44-bf05ad39830b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Our Achievements',
      'text' => 'Cras sed mauris augue. In at pellentesque sem. Vestibulum susciptin mi sodales tortor vehicula laoreet. Sed a purus vitae nisl sagittis consequat eget id velit.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '323241d5-d9e3-4d8a-bfba-82cc2bd81dab',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '<i class="fa fa-users"></i>[headline level="1" type="normal" align="tcenter"]7,381[/headline][headline level="4" type="normal" align="tcenter"]Customers[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '<i class="fa fa-check"></i>[headline level="1" type="normal" align="tcenter"]10,121[/headline][headline level="4" type="normal" align="tcenter"]Improvements[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => '<i class="fa fa-cloud-upload"></i>[headline level="1" type="normal" align="tcenter"]6,111[/headline][headline level="4" type="normal" align="tcenter"]Lines of Code[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '',
            'text' => '<i class="fa fa-coffee"></i>[headline level="1" type="normal" align="tcenter"]870[/headline][headline level="4" type="normal" align="tcenter"]Coffee[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '56bf1f9760e86',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '9037c8e6-0a22-4975-926b-0c503322c558',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'height' => '30',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '7aff00f8-db39-4a14-9bc6-f49d539239a7',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => '',
      'text' => '[headline level="3" type="normal" align="tcenter"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. In euismod erat nec pellentesque varius. Proin auctor varius tristique.[/headline][headline level="5" type="normal" align="tcenter"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. In euismod erat nec pellentesque varius. Proin auctor varius tristique.[/headline][gap height="20"][button link="http://webulous.in/" target="_self" color="btn-white" size="btn-normal"]List of Features[/button][button link="http://webulous.in/" target="_self" color="btn-white" size="btn-normal"]Buy Now[/button]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 8,
        'widget_id' => '5db09661-7a78-4410-bfac-847b95c5b950',
        'style' => 
        array (
          'class' => 'features',
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'We Are Brawny',
      'text' => '[gap height="10"]Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '74d16b6d-3221-42b2-bc8a-bbbf7d3cc06e',
        'style' => 
        array (
          'class' => 'txt-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'John Doe',
            'designation' => 'CEO',
            'image_url' => 'http://dummy.codinggeek.com/brawny/wp-content/uploads/2015/02/Our-Team1.png',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'content' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alternation in some form, by injected humour, or randomised.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Jessica Lee',
            'designation' => 'Designer',
            'image_url' => 'http://dummy.codinggeek.com/brawny/wp-content/uploads/2015/02/Our-Team1.png',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'content' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alternation in some form, by injected humour, or randomised.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Christober',
            'designation' => 'Developer',
            'image_url' => 'http://dummy.codinggeek.com/brawny/wp-content/uploads/2015/02/Our-Team1.png',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'content' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alternation in some form, by injected humour, or randomised.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Kate Smith',
            'designation' => 'Marketing Manager',
            'image_url' => 'http://dummy.codinggeek.com/brawny/wp-content/uploads/2015/02/Our-Team1.png',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'content' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alternation in some form, by injected humour, or randomised.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '56c2b52378869',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 10,
        'widget_id' => '22763bf8-990c-4b84-9499-3bcd3c121660',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Testimonials & About Us',
      'text' => 'WHAT OUR HAPPY CLIENTS SAY ABOUT US',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'widget_id' => 'f9071dd4-1eb1-4ada-a6ea-53616e6b6c13',
        'style' => 
        array (
          'class' => 'content-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Testimonials',
      'count' => '5',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'widget_id' => 'd218011b-00ad-48af-8149-f2a9905e17ec',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => '',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 13,
        'widget_id' => '5d707198-da60-46ae-b22a-bf17cb02a190',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'title' => 'Clients We Work With',
      'text' => 'We appreciate their hard work and efforts',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 14,
        'widget_id' => '55098afb-d329-4657-9b5c-d52c2f531691',
        'style' => 
        array (
          'class' => 'content-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'content' => 'Lorem ipsum Dummy Text Lorem ipsum Dummy Text Lorem ipsum Dummy Text',
      'title' => 'CALL TO ACTION',
      'url' => 'http://www.webulousthemes.com/',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 15,
        'widget_id' => '19bc5703-6489-4249-90e9-46a3bb50c764',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'slider' => 'carousel',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 10,
        'cell' => 0,
        'id' => 16,
        'widget_id' => '51ffade8-3baf-4291-9fce-50c3422329f0',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'height' => '30',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 17,
        'widget_id' => 'e70d7388-3408-4590-9ae8-f1e2f888f2b0',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'class' => 'section-pattern',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    1 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'section-bg',
        'bottom_margin' => '0px',
        'row_stretch' => 'full',
        'background_display' => 'center',
        'background_image' => 'http://dummy.codinggeek.com/brawny/wp-content/uploads/2015/02/bg1.png',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'our-achive',
        'background_image_attachment' => 963,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-bg',
        'row_stretch' => 'full',
        'background_display' => 'center',
        'background_image' => 'http://dummy.codinggeek.com/brawny/wp-content/uploads/2015/02/bg2.png',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    7 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    9 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    10 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    11 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.55395683453236999,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.44604316546763001,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    11 => 
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    12 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    13 => 
    array (
      'grid' => 9,
      'weight' => 1,
    ),
    14 => 
    array (
      'grid' => 10,
      'weight' => 1,
    ),
    15 => 
    array (
      'grid' => 11,
      'weight' => 1,
    ), 
    ),
  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-brawny'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-brawny'),
    'widgets' => array(
        0 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '36bbf245-3912-4d27-8c7e-d7154a2945df',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'We Are Brawny',
      'text' => 'Nihil hic munitissimus habendi senatus locus, nihil horum Salutantibus vitae libero, a pharetra augue. Tityre, tu patulae recubans sub tegmine fagi dolor. Quisque ut dolor gravida, placerat libero vel, euismod. Qui ipsorum lingua Celtae, nostra Galli appellantur. Curabitur blandit tempus ardua ridiculus sed magna.',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'aed99587-6402-4157-9ab0-034bd1a2322f',
        'style' => 
        array (
          'class' => 'content-center',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    2 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'content' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alternation in some form',
            'image_url' => 'http://brawny.webulous.in/wp-content/uploads/2016/06/one.png',
            'title' => 'John Doe',
            'designation' => 'CEO',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '1b0efb62-317b-466e-afd6-130f1ffe9d2a',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'There are many variations of passages of Lorem Ipsum available',
            'image_url' => 'http://brawny.webulous.in/wp-content/uploads/2016/06/two.png',
            'title' => 'Jessica Lee',
            'designation' => 'Marketing Manager',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '31ccbe01-d7a0-4b12-95cd-aecc8537e872',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alternation in some form There are many variations of passages of Lorem Ipsum available, but the majority have suffered alternation in some form',
            'image_url' => 'http://brawny.webulous.in/wp-content/uploads/2016/06/three.png',
            'title' => 'Christober',
            'designation' => 'Administator',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '4a22e5e4-9007-4347-8958-59921f0f0f34',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'the majority have suffered alternation in some form',
            'image_url' => 'http://brawny.webulous.in/wp-content/uploads/2016/06/Four.png',
            'title' => 'Kate Smith',
            'designation' => 'Accountant',
            'linkedin' => 'http://linkedin.in/',
            'google' => 'http://plus.google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'widget_id' => 'b18ad772-4c99-4994-882c-53cbab389c45',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '5774f98d1eeea',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'cb91a6ba-0852-48f1-9cd1-9869f9bcb5f6',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => '',
      'text' => '[divider style="solid"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '99bc28ac-94e8-40f6-8b37-e3cf40fa4bc7',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'About us',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content Here\', content here, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Skills',
            'panels_info' => 
            array (
              'class' => 'Wbls_Skill_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.38196600790794,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.61803399209206,
          ),
        ),
      ),
      'builder_id' => '54d4b8eb4ad6f',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '91fa0eca-fba7-406f-9af7-7ae546a32847',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '3405302a-60a5-4245-83d8-6a350f9f126c',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'title' => 'BRAWNY PRO',
      'url' => 'http://webulousthemes.com/',
      'anchor_text' => 'Buy Brawny Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 6,
        'widget_id' => 'c2c6b2f9-3089-4e97-add4-3be9b4a12e7f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-bg',
        'bottom_margin' => '0px',
        'row_stretch' => 'full',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'wbls-brawny'),
      'description' => __( 'Pre Built layout for features page', 'wbls-brawny'),
      'widgets' => array(
        0 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '9509ff6a-6f4f-4e67-aa32-bd8aa3397df2',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'type' => 'circle',
            'title' => 'Responsive Layout',
            'text' => 'Brawny is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
            'icon' => 'fa-desktop',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '34c55e77-80cc-48a9-9585-001e7a8ae2b4',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
          1 => 
          array (
            'type' => 'circle',
            'title' => 'Awasome Slider',
            'text' => 'Brawny includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
            'icon' => 'fa-phone',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '53db6d2b-8121-4fee-a2e7-3caae782deec',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
          2 => 
          array (
            'type' => 'circle',
            'title' => 'Advanced Admin',
            'text' => 'Brawny is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
            'icon' => 'fa-cog',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => 'a5ce77bb-853f-4369-add3-cc45e1aa6072',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
          3 => 
          array (
            'type' => 'circle',
            'title' => 'Page Builder',
            'text' => 'Brawny is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
            'icon' => 'fa-plus-square',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 3,
              'widget_id' => '848cc7d5-4448-498e-8e2b-bc85f33c75d3',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
          4 => 
          array (
            'type' => 'circle',
            'title' => 'Page Layout',
            'text' => 'Brawny offers many different page layouts so you can quickly and easily create your pages with no hassle!',
            'icon' => 'fa-copy (alias)',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 1,
              'cell' => 1,
              'id' => 4,
              'widget_id' => 'a2b20282-9d2d-4c60-b8a5-887d24d0eabd',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
          5 => 
          array (
            'type' => 'circle',
            'title' => 'Typography',
            'text' => 'Brawny loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
            'icon' => 'fa-font',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 1,
              'cell' => 2,
              'id' => 5,
              'widget_id' => '1929f524-c3ee-4664-8972-6a99c36bd423',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
          6 => 
          array (
            'type' => 'circle',
            'title' => 'Custom Widget',
            'text' => 'Brawny We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
            'icon' => 'fa-beer',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 2,
              'cell' => 0,
              'id' => 6,
              'widget_id' => '54fdd9bf-e677-4f33-ac62-2b4ccabd93b0',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
          7 => 
          array (
            'type' => 'circle',
            'title' => 'Demo Content',
            'text' => 'Brawny includes demo content files. You can quickly setup the site like our demo and get started easily!.',
            'icon' => 'fa-times',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 2,
              'cell' => 1,
              'id' => 7,
              'widget_id' => '4c712ee7-f371-43a1-ac0a-d648224d749b',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
          8 => 
          array (
            'type' => 'circle',
            'title' => 'Shortcode Builder',
            'text' => 'Brawny inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!.',
            'icon' => 'fa-check',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 2,
              'cell' => 2,
              'id' => 8,
              'widget_id' => 'ffcdcf61-2498-4a5d-9b28-1c129d4d8ada',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
          9 => 
          array (
            'type' => 'circle',
            'title' => 'Woo Commerce',
            'text' => 'Brawny has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!.',
            'icon' => 'fa-shopping-cart',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 3,
              'cell' => 0,
              'id' => 9,
              'widget_id' => '27baf622-54f2-4708-9b43-73826f934c44',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
          10 => 
          array (
            'type' => 'circle',
            'title' => 'Testimonials',
            'text' => 'With our testimonial post type, shortcode and widget, Displaying testimonials is a breeze..',
            'icon' => 'fa-rocket',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 3,
              'cell' => 1,
              'id' => 10,
              'widget_id' => '5fbfa347-f4a1-49b7-a2ca-05a8db0e93bd',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
          11 => 
          array (
            'type' => 'circle',
            'title' => 'Social Media',
            'text' => 'Want your users to stay in touch? No problem, Greenr has Social Media icons all throughout the theme!',
            'icon' => 'fa-twitter',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'grid' => 3,
              'cell' => 2,
              'id' => 11,
              'widget_id' => '437214b1-1641-4f3a-b601-60af0c17059c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'box' => false,
            'all_linkable' => false,
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
          2 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
          3 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          5 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          6 => 
          array (
            'grid' => 2,
            'weight' => 0.33333333333332998,
          ),
          7 => 
          array (
            'grid' => 2,
            'weight' => 0.33333333333332998,
          ),
          8 => 
          array (
            'grid' => 2,
            'weight' => 0.33333333333332998,
          ),
          9 => 
          array (
            'grid' => 3,
            'weight' => 0.33333333333332998,
          ),
          10 => 
          array (
            'grid' => 3,
            'weight' => 0.33333333333332998,
          ),
          11 => 
          array (
            'grid' => 3,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '577502f92e2c6',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '51cd4ee0-c42a-43a9-9116-ab561ef8614f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'title' => 'BRAWNY PRO',
      'url' => 'http://www.webulousthemes.com/',
      'anchor_text' => 'Buy Brawny Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'b1b32cf0-9e6a-44f8-ae36-1fd85ae7fe70',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-bg',
        'bottom_margin' => '0px',
        'row_stretch' => 'full',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-brawny'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-brawny'),
      'widgets' => array(
            0 => 
    array (
      'title' => '',
      'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m29!1m12!1m3!1d196281.64169563178!2d-104.85511145000002!3d39.76433895!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m14!1i0!3e6!4m5!1s0x876b8750bbb40c91%3A0xcf2970dac9d85d82!2sWEST+COLFAX!3m2!1d39.739399899999995!2d-105.0352855!4m5!1s0x876b80aa231f17cf%3A0x118ef4f8278a36d6!2sDenver%2C+CO%2C+USA!3m2!1d39.7384357!2d-104.9848593!5e0!3m2!1sen!2sin!4v1417267946514" width="1200" height="450" frameborder="0" style="border:0"></iframe>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '73bc5eba-e67d-4687-897d-d202977ca25f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '[icon icon="fa-map-marker" size="3x" align="text-left"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[icon icon="fa-envelope" size="3x" align="text-left"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => '[icon icon="fa-phone" size="3x" align="text-left"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '',
            'text' => '[icon icon="fa-clock-o" size="3x" align="text-left"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '54d9bc61b30bd',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'e6bbc896-452f-42a2-9bfb-3b355251313c',
        'style' => 
        array (
          'class' => 'content-center cnt-address',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => '',
      'text' => '[contact-form-7 id="304" title="Contact form 1"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '30756bd3-4816-499c-aa73-37fecc5fea92',
        'style' => 
        array (
          'class' => 'cnt-form',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'content' => '',
      'title' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'url' => 'http://webulousthemes.com/',
      'anchor_text' => 'Buy Brawny Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '8e7d7886-0003-418d-825f-ebb58f79f9b9',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-white contact-page',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-brawny'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-brawny'),
    'widgets' =>  array(
      0 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '618d1d3b-8c41-43f0-8b4c-072e9db4c8f7',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '[accordion_group][accordion title="Where can I find your offices?"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/accordion][accordion title="Aenean sodales tortor in rhoncus ultricies."]Morbi vestibulum, diam sed tempor cursus, sapien massa faucibus est, eget tincidunt nisl diam quis leo. Morbi condimentum erat id magna accumsan, in vestibulum enim fringilla.[/accordion][accordion title="Suspendisse ultrices ipsum convallis"]Nullam eros urna, rhoncus quis ultricies ut, dapibus nec nunc. Vivamus finibus nulla nec nibh placerat euismod. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/accordion][accordion title="Nam imperdiet maximus venenatis"]Sed ut velit nec augue tempor facilisis nec at odio. Nam non iaculis nunc. Donec eros ipsum, fermentum a ipsum auctor, varius sollicitudin elit. Cras convallis magna a est consectetur, non cursus risus viverra.[/accordion][accordion title="Quisque venenatis justo non laoree"]Curabitur vel diam dolor. Curabitur ac felis pulvinar, facilisis ante nec, molestie neque. Duis eleifend diam nec mattis laoreet. Aenean in mattis nunc. Quisque porta ligula eget ante tempor tempor.[/accordion][accordion title="Aenean condimentum elit eget viverra lobortis."]Vivamus accumsan dui eget leo faucibus, at vehicula nunc fermentum. Nam sit amet volutpat arcu. Mauris vitae lobortis metus. Nulla at tincidunt purus. Curabitur accumsan nibh eu pellentesque ullamcorper. Sed suscipit, ante sed dictum accumsan, diam massa lobortis mauris, sit amet commodo sem ex sed ante. Suspendisse potenti.[/accordion][/accordion_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '0a7af003-20ec-45e4-8d5a-e4f8f7f8cc26',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'e51468a2-f46a-45d1-af84-93f62e84ea17',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'BRAWNY PRO',
      'url' => 'http://www.webulousthemes.com/',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => 'bf50b9d1-6d54-4548-9d28-ab430234ab72',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-bg',
        'row_stretch' => 'full',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-brawny'),
    'description' => __('Pre Built Layout for services page', 'wbls-brawny'),
    'widgets' =>  array(
      0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Planing',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its-layout',
            'filter' => 'on',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[icon icon="fa-group" size="3x" align="text-left"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => '[icon icon="fa-picture-o" size="3x" align="text-left"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Designing',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its-layout',
            'filter' => 'on',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Developing',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its-layout',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 2,
              'cell' => 0,
              'id' => 4,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => '',
            'text' => '[icon icon="fa-pencil" size="3x" align="text-left"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 2,
              'cell' => 1,
              'id' => 5,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'title' => '',
            'text' => '[icon icon="fa-cog" size="3x" align="text-left"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 3,
              'cell' => 1,
              'id' => 6,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          7 => 
          array (
            'title' => 'Marketing',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its-layout',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 3,
              'cell' => 2,
              'id' => 7,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          2 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          3 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.42499999999999999,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.14999999999999999,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.42499999999999999,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.42499999999999999,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.14999999999999999,
          ),
          5 => 
          array (
            'grid' => 1,
            'weight' => 0.42499999999999999,
          ),
          6 => 
          array (
            'grid' => 2,
            'weight' => 0.42499999999999999,
          ),
          7 => 
          array (
            'grid' => 2,
            'weight' => 0.14999999999999999,
          ),
          8 => 
          array (
            'grid' => 2,
            'weight' => 0.42499999999999999,
          ),
          9 => 
          array (
            'grid' => 3,
            'weight' => 0.42499999999999999,
          ),
          10 => 
          array (
            'grid' => 3,
            'weight' => 0.14999999999999999,
          ),
          11 => 
          array (
            'grid' => 3,
            'weight' => 0.42499999999999999,
          ),
        ),
      ),
      'builder_id' => '54d9ecb68d69b',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '4b1f8cc0-d908-494b-868e-b5c054ca041b',
        'style' => 
        array (
          'class' => 'service-page',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'BRAWNY PRO',
      'url' => 'http://webulousthemes.com/',
      'anchor_text' => 'Buy Brawny Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'd75756db-da3c-4f44-8195-c47f78291f05',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-bg',
        'row_stretch' => 'full',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'wbls_brawny_prebuilt_page_layouts');



/**
 * Configure the SiteOrigin page builder settings.
 * 
 * @param $settings
 * @return mixed
 */
/*
function wbls_brawny_panels_settings($settings){
  $settings['home-page'] = true;
  $settings['margin-bottom'] = 35;
  $settings['home-page-default'] = 'default-home';
  $settings['responsive'] = 1; //siteorigin_setting( 'layout_responsive' );
  return $settings;
}
add_filter('siteorigin_panels_settings', 'wbls_brawny_panels_settings'); */

/**
 * Add row styles.
 *
 * @param $styles
 * @return mixed
 */
function wbls_brawny_panels_row_styles($styles) {
  $styles['full-width-layout'] = __('Full Width Layout', 'wbls-brawny');
  $styles['wide-white'] = __('Wide white', 'wbls-brawny');  
  $styles['wide-grey'] = __('Wide Grey', 'wbls-brawny');  
  //$styles['cta'] = __('Call To Action', 'wbls-brawny');
  $styles['section-pattern2'] = __('Section Pattern2', 'wbls-brawny');
  $styles['section-pattern'] = __('Section Pattern', 'wbls-brawny');
  return $styles;
}
add_filter('siteorigin_panels_row_styles', 'wbls_brawny_panels_row_styles');

function wbls_brawny_panels_row_style_fields($fields) {

  $fields['top_border'] = array(
    'name' => __('Top Border Color', 'wbls-brawny'),
    'type' => 'color',
  );

  $fields['bottom_border'] = array(
    'name' => __('Bottom Border Color', 'wbls-brawny'),
    'type' => 'color',
  );

  $fields['background'] = array(
    'name' => __('Background Color', 'wbls-brawny'),
    'type' => 'color',
  );

  $fields['background_image'] = array(
    'name' => __('Background Image', 'wbls-brawny'),
    'type' => 'url',
  );

  $fields['background_image_repeat'] = array(
    'name' => __('Repeat Background Image', 'wbls-brawny'),
    'type' => 'checkbox',
  );

  $fields['no_margin'] = array(
    'name' => __('No Bottom Margin', 'wbls-brawny'),
    'type' => 'checkbox',
  );

  return $fields;
}
add_filter('siteorigin_panels_row_style_fields', 'wbls_brawny_panels_row_style_fields');

function wbls_brawny_panels_panels_row_style_attributes($attr, $style) {
  $attr['style'] = '';

  if(!empty($style['top_border'])) $attr['style'] .= 'border-top: 1px solid '.$style['top_border'].'; ';
  if(!empty($style['bottom_border'])) $attr['style'] .= 'border-bottom: 1px solid '.$style['bottom_border'].'; ';
  if(!empty($style['background'])) $attr['style'] .= 'background-color: '.$style['background'].'; ';
  if(!empty($style['background_image'])) $attr['style'] .= 'background-image: url('.esc_url($style['background_image']).'); ';
  if(!empty($style['background_image_repeat'])) $attr['style'] .= 'background-repeat: repeat; ';

  if(empty($attr['style'])) unset($attr['style']);
  return $attr;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_brawny_panels_panels_row_style_attributes', 10, 2);

function wbls_brawny_panels_panels_row_attributes($attr, $row) {
  if(!empty($row['style']['no_margin'])) {
    if(empty($attr['style'])) $attr['style'] = '';
    $attr['style'] .= 'margin-bottom: 0px;';
  }

  return $attr;
}
add_filter('siteorigin_panels_row_attributes', 'wbls_brawny_panels_panels_row_attributes', 10, 2);



function wbls_brawny_animation_panels_row_style_fields($fields) {  

    $brawny_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-brawny'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-brawny' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-brawny' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-brawny' ),
        'bounce-animation' => __('bounce-animation','wbls-brawny' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-brawny' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-brawny' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-brawny' ),
        'expandUp-animation' => __('expandUp-animation','wbls-brawny' ),
        'fade-animation' => __('fade-animation','wbls-brawny' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-brawny' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-brawny' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-brawny' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-brawny' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-brawny' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-brawny' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-brawny' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-brawny' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-brawny' ),
        'flip-animation' => __('flip-animation','wbls-brawny' ),
        'flipInX-animation' => __('flipInX-animation','wbls-brawny' ),
        'flipInY-animation' => __('flipInY-animation','wbls-brawny' ),
        'floating-animation' => __('floating-animation','wbls-brawny' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-brawny' ),
        'hatch-animation' => __('hatch-animation','wbls-brawny' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-brawny' ),
        'puffIn-animation' => __('puffIn-animation','wbls-brawny' ),
        'pullDown-animation' => __('pullDown-animation','wbls-brawny' ),
        'pullUp-animation' => __('pullUp-animation','wbls-brawny' ),
        'pulse-animation' => __('pulse-animation','wbls-brawny' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-brawny' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-brawny' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-brawny' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-brawny' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-brawny' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-brawny' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-brawny' ),
        'scale-down-animation' => __('scale-down-animation','wbls-brawny' ),
        'scale-up-animation' => __('scale-up-animation','wbls-brawny' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-brawny' ),
        'slide-left-animation' => __('slide-left-animation','wbls-brawny' ),
        'slide-right-animation' => __('slide-right-animation','wbls-brawny' ),
        'slide-top-animation' => __('slide-top-animation','wbls-brawny' ),
        'slideDown-animation' => __('slideDown-animation','wbls-brawny' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-brawny' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-brawny' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-brawny' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-brawny' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-brawny' ),
        'slideRight-animation' => __('slideRight-animation','wbls-brawny' ),
        'slideUp-animation' => __('slideUp-animation','wbls-brawny' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-brawny' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-brawny' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-brawny' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-brawny' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-brawny' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-brawny' ),
        'swap-animation'  => __('swap-animation','wbls-brawny' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-brawny' ),
        'swing-animation'  => __('swing-animation','wbls-brawny' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-brawny' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-brawny' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-brawny' ), 
        'tossing-animation'  => __('tossing-animation','wbls-brawny' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-brawny' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-brawny' ), 
        'wobble-animation' => __('wobble-animation','wbls-brawny' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-brawny' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'brawny'),
            'type' => 'select',
            'options' => $brawny_animation_name,
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_brawny_animation_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_brawny_animation_panels_row_style_fields');

function wbls_brawny_animation_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_brawny_animation_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_brawny_animation_panels_panels_row_style_attributes', 10, 2);

function wbls_brawny_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Theme & Animation', 'wbls-brawny'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_brawny_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_brawny_row_style_groups' );