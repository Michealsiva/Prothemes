<?php 

// recent post -carousel and slider image crop //


	add_image_size( 'wbls-brawny_recent_posts_img',400,300,true );
	add_image_size( 'wbls-brawny-recent_work_thumb', 400, 400, true );
   // add_image_size( 'wbls-brawny-recent_work_isotope_thumb', 250, 260, true );   
	add_image_size( 'wbls-brawny-recent_post_thumb', 380, 350, true );  
	add_image_size( 'wbls-brawny-blog-full-width', 1200,350, true );
	add_image_size( 'wbls-brawny-small-featured-image-width', 450,350, true );
	add_image_size( 'wbls-brawny-blog-large-width', 800,350, true );  
	add_image_size( 'wbls-brawny_service-img', 100,100, true );  

	if( ! function_exists( 'wbls_brawny_breadcrumbs' )) {  
 
	function wbls_brawny_breadcrumbs() {
		/* === OPTIONS === */
		$text['home']     = __( '<i class="fa fa-home"></i>','wbls-brawny' ); // text for the 'Home' link
		$text['category'] = __( 'Archive by Category "%s"','wbls-brawny' ); // text for a category page
		$text['search']   = __( 'Search Results for "%s" Query','wbls-brawny' ); // text for a search results page
		$text['tag']      = __( 'Posts Tagged "%s"','wbls-brawny' ); // text for a tag page
		$text['author']   = __( 'Articles Posted by %s','wbls-brawny' ); // text for an author page
		$text['404']      = __( 'Error 404','wbls-brawny' ); // text for the 404 page

		$showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
		$showOnHome  = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show
		$breadcrumb_char = get_theme_mod( 'breadcrumb_char', 1 );
		if ( $breadcrumb_char ) {
		 switch ( $breadcrumb_char ) {
		 	case 2 :
		 		$delimiter = ' / ';
		 		break;
		 	case 3:
		 		$delimiter = ' > ';
		 		break;
		 	case 1:
		 	default:
		 		$delimiter = ' &raquo; ';
		 		break;
		 }
		}

		$before      = '<span class="current">'; // tag before the current crumb
		$after       = '</span>'; // tag after the current crumb
		/* === END OF OPTIONS === */

		global $post;
		$homeLink = home_url() . '/';
		$linkBefore = '<span typeof="v:Breadcrumb">';
		$linkAfter = '</span>';
		$linkAttr = ' rel="v:url" property="v:title"';
		$link = $linkBefore . '<a' . $linkAttr . ' href="%1$s">%2$s</a>' . $linkAfter;

		if (is_home() || is_front_page()) {

			if ($showOnHome == 1) echo '<div id="crumbs"><a href="' . $homeLink . '">' . $text['home'] . '</a></div>';

		} else {

			echo '<div id="crumbs" xmlns:v="http://rdf.data-vocabulary.org/#">' . sprintf($link, $homeLink, $text['home']) . $delimiter;

			if ( is_category() ) {
				$thisCat = get_category(get_query_var('cat'), false);
				if ($thisCat->parent != 0) {
					$cats = get_category_parents($thisCat->parent, TRUE, $delimiter);
					$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
					$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
					echo $cats;
				}
				echo $before . sprintf($text['category'], single_cat_title('', false)) . $after;

			} elseif ( is_search() ) {
				echo $before . sprintf($text['search'], get_search_query()) . $after;

			} elseif ( is_day() ) {
				echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;
				echo sprintf($link, get_month_link(get_the_time('Y'),get_the_time('m')), get_the_time('F')) . $delimiter;
				echo $before . get_the_time('d') . $after;

			} elseif ( is_month() ) {
				echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;
				echo $before . get_the_time('F') . $after;

			} elseif ( is_year() ) {
				echo $before . get_the_time('Y') . $after;

			} elseif ( is_single() && !is_attachment() ) {
				if ( get_post_type() != 'post' ) {
					$post_type = get_post_type_object(get_post_type());
					$slug = $post_type->rewrite;
					printf($link, $homeLink . '/' . $slug['slug'] . '/', $post_type->labels->singular_name);
					if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;
				} else {
					$cat = get_the_category(); $cat = $cat[0];
					$cats = get_category_parents($cat, TRUE, $delimiter);
					if ($showCurrent == 0) $cats = preg_replace("#^(.+)$delimiter$#", "$1", $cats);
					$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
					$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
					echo $cats;
					if ($showCurrent == 1) echo $before . get_the_title() . $after;
				}

			} elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
				$post_type = get_post_type_object(get_post_type());
				echo $before . $post_type->labels->singular_name . $after;

			} elseif ( is_attachment() ) {
				$parent = get_post($post->post_parent);
				$cat = get_the_category($parent->ID); $cat = $cat[0];
				$cats = get_category_parents($cat, TRUE, $delimiter);
				$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
				$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
				echo $cats;
				printf($link, get_permalink($parent), $parent->post_title);
				if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;

			} elseif ( is_page() && !$post->post_parent ) {
				if ($showCurrent == 1) echo $before . get_the_title() . $after;

			} elseif ( is_page() && $post->post_parent ) {
				$parent_id  = $post->post_parent;
				$breadcrumbs = array();
				while ($parent_id) {
					$page = get_page($parent_id);
					$breadcrumbs[] = sprintf($link, get_permalink($page->ID), get_the_title($page->ID));
					$parent_id  = $page->post_parent;
				}
				$breadcrumbs = array_reverse($breadcrumbs);
				for ($i = 0; $i < count($breadcrumbs); $i++) {
					echo $breadcrumbs[$i];
					if ($i != count($breadcrumbs)-1) echo $delimiter;
				}
				if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;

			} elseif ( is_tag() ) {
				echo $before . sprintf($text['tag'], single_tag_title('', false)) . $after;

			} elseif ( is_author() ) {
		 		global $author;
				$userdata = get_userdata($author);
				echo $before . sprintf($text['author'], $userdata->display_name) . $after;

			} elseif ( is_404() ) {
				echo $before . $text['404'] . $after;
			}

			if ( get_query_var('paged') ) {
				if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
				echo __('Page', 'abaris' ) . ' ' . get_query_var('paged');
				if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
			}

			echo '</div>';

		}
	} // end wbls_brawny_breadcrumbs()
}

if ( ! function_exists( 'wbls_brawny_posted_on' ) ) :   
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function wbls_brawny_posted_on() {
	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';
	}

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

	$posted_on = sprintf(
		_x( '%s', 'post date', 'wbls-brawny' ),
		'<i class="fa fa-clock-o"></i> <span><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a></span>'
	);

	$byline = sprintf(
		_x( '%s', 'post author', 'wbls-brawny' ),
		'<i class="fa fa-user"></i> <span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	echo '<span class="posted-on">' . $posted_on . '</span><span class="byline"> ' . $byline . '</span>';
	edit_post_link( __( 'Edit', 'wbls-brawny' ), ' <span class="edit-link"><i class="fa fa-pencil"></i>', '</span>' );

}
endif;
if( ! function_exists( 'wbls_brawny_pagination' )) {
	/**
	 * Generates Pagination without WP-PageNavi Plugin
	 */
	
	function wbls_brawny_pagination($before = '', $after = '') {
		global $wpdb, $wp_query;
		$request = $wp_query->request;
		$posts_per_page = intval(get_query_var('posts_per_page'));
		$paged = intval(get_query_var('paged'));
		$numposts = $wp_query->found_posts;
		$max_page = $wp_query->max_num_pages;
		if ( $numposts <= $posts_per_page ) { return; }
		if(empty($paged) || $paged == 0) {
			$paged = 1;
		}
		$pages_to_show = 7;
		$pages_to_show_minus_1 = $pages_to_show-1;
		$half_page_start = floor($pages_to_show_minus_1/2);
		$half_page_end = ceil($pages_to_show_minus_1/2);
		$start_page = $paged - $half_page_start;
		if($start_page <= 0) {
			$start_page = 1;
		}
		$end_page = $paged + $half_page_end;
		if(($end_page - $start_page) != $pages_to_show_minus_1) {
			$end_page = $start_page + $pages_to_show_minus_1;
		}
		if($end_page > $max_page) {
			$start_page = $max_page - $pages_to_show_minus_1;
			$end_page = $max_page;
		}
		if($start_page <= 0) {
			$start_page = 1;
		}
		echo $before.'<nav class="page-navigation"><ol class="webulous_page_navi clearfix">'."";
		if ($start_page >= 2 && $pages_to_show < $max_page) {
			$first_page_text = __( "First", 'wbls-brawny' );
			echo '<li class="bpn-first-page-link"><a href="'.get_pagenum_link().'" title="'.$first_page_text.'">'.$first_page_text.'</a></li>';
		}
		echo '<li class="bpn-prev-link">';
		previous_posts_link('&laquo;');
		echo '</li>';
		for($i = $start_page; $i  <= $end_page; $i++) {
			if($i == $paged) {
				echo '<li class="bpn-current">'.$i.'</li>';
			} else {
				echo '<li><a href="'.get_pagenum_link($i).'">'.$i.'</a></li>';
			}
		}
		echo '<li class="bpn-next-link">';
		next_posts_link('&raquo;');
		echo '</li>';
		if ($end_page < $max_page) {
			$last_page_text = __( "Last", 'wbls-brawny' );
			echo '<li class="bpn-last-page-link"><a href="'.get_pagenum_link($max_page).'" title="'.$last_page_text.'">'.$last_page_text.'</a></li>';
		}
		echo '</ol></nav>'.$after."";
	}
}

if ( ! function_exists( 'wbls_brawny_post_nav' ) ) :
/**
 * Display navigation to next/previous post when applicable.
 */
function wbls_brawny_post_nav() {
	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( get_post()->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous ) {
		return;
	}
	?>
	<nav class="navigation post-navigation clearfix" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Post navigation', 'wbls-brawny' ); ?></h1>
		<div class="nav-links">
			<?php
				previous_post_link( '<div class="nav-previous">%link</div>', _x( '<span class="meta-nav">&larr;</span>&nbsp;%title', 'Previous post link', 'wbls-brawny' ) );
				next_post_link(     '<div class="nav-next">%link</div>',     _x( '%title&nbsp;<span class="meta-nav">&rarr;</span>', 'Next post link',     'wbls-brawny' ) );
			?>
		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
endif;

// Related Posts Function (call using wbls_brawny_related_posts(); ) /NecessarY/ May be write a shortcode?
if ( ! function_exists( 'wbls_brawny_related_posts' ) ) {
	function wbls_brawny_related_posts() {
		echo '<ul id="webulous-related-posts">';
		global $post;
		$tags = wp_get_post_tags($post->ID);
		$tag_arr = '';
		if($tags) {
			foreach($tags as $tag) { $tag_arr .= $tag->slug . ','; }
	        $args = array(
	        	'tag' => $tag_arr,
	        	'numberposts' => 5, /* you can change this to show more */
	        	'post__not_in' => array($post->ID)
	     	);
	        $related_posts = get_posts($args);
	        if($related_posts) {
	        	foreach ($related_posts as $post) : setup_postdata($post); ?>
		           	<li class="related_post">
		           		<a class="entry-unrelated" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('recent-work'); ?></a>
		           		<a class="entry-unrelated" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
		           	</li>
		        <?php endforeach; }
		    else {
	            echo '<li class="no_related_post">' . __( 'No Related Posts Yet!', 'wbls-brawny' ) . '</li>'; 
			 }
		}else{
			echo '<li class="no_related_post">' . __( 'No Related Posts Yet!', 'wbls-brawny' ) . '</li>';
		}
		wp_reset_query();
		
		echo '</ul>';
	}
}


if ( ! function_exists( 'wbls_brawny_entry_footer' ) ) :
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function wbls_brawny_entry_footer() {   
	// Hide category and tag text for pages.
	if ( 'post' == get_post_type() ) {
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( __( ', ', 'wbls-brawny' ) );
		if ( $categories_list && brawny_categorized_blog() ) {
			printf( ' <span class="cat-links"><i class="fa fa-folder-open"></i>' . __( '%1$s ', 'wbls-brawny' ) . '</span>', $categories_list );
		}

		/* translators: used between list items, there is a space after the comma */
		$tags_list = get_the_tag_list( '', __( ', ', 'wbls-brawny' ) );
		if ( $tags_list ) {
			printf( '<span class="tags-links"><i class="fa fa-tags"></i> ' . __( '%1$s ', 'wbls-brawny' ) . '</span>', $tags_list );
		}
	}

	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		echo '<span class="comments-link">';
		comments_popup_link( __( '<i class="fa fa-comments"></i>Leave a comment', 'wbls-brawny' ), __( '<i class="fa fa-comments"></i> 1 Comment', 'wbls-brawny' ), __( '<i class="fa fa-comments"></i> % Comments', 'wbls-brawny' ) );
		echo '</span>';
	}
}
endif;

function add_more_link_class_wrapper( $link, $text  ) {

	$html = '';

		$html .= '<p><a class="btn btn-mini"' . $link . '</a></p>';

	return $html;
}
add_filter( 'the_content_more_link', 'add_more_link_class_wrapper', 10, 2 );



add_action( 'wbls_fw_portfolio_before_breadcrumbs', 'wbls_brawny_portfolio_before_breadcrumbs' );

if( ! function_exists('wbls_brawny_portfolio_before_breadcrumbs') ) {
	function wbls_brawny_portfolio_before_breadcrumbs() {
		$output = '';
		$output .= '<div class="container"><div class="sixteen columns breadcrumb">	<header class="entry-header"><h1 class="entry-title">';
	    $output .=  get_the_title();
	    $output .= '</h1></header>';
	    $breadcrumb = get_theme_mod( 'breadcrumb',true ); 
	    if( $breadcrumb ) :	
			$output .='<div id="breadcrumb" role="navigation">';
		endif;	
		echo $output;    
	}
}


add_action( 'wbls_fw_portfolio_after_breadcrumbs', 'wbls_brawny_portfolio_after_breadcrumbs' );

if( ! function_exists('wbls_brawny_portfolio_after_breadcrumbs') ) {
	function wbls_brawny_portfolio_after_breadcrumbs() {
		$output = '';
		$breadcrumb = get_theme_mod( 'breadcrumb',true ); 
	    if( $breadcrumb ) :	
	       $output .= '</div>';
	    endif;					
	    $output .= '</div></div>';
		echo $output;
		do_action('brawny_before_content');	
         
	}
}


add_action( 'wbls_fw_portfolio_breadcrumbs', 'wbls_brawny_portfolio_breadcrumbs' );

if( ! function_exists('wbls_brawny_portfolio_breadcrumbs') ) {
	function wbls_brawny_portfolio_breadcrumbs() {
		$breadcrumb = get_theme_mod( 'breadcrumb',true ); 
	    if( $breadcrumb ) :
          brawny_breadcrumbs();
        endif;
	}
}



if ( ! function_exists( 'wbls_fw_paging_nav' ) ) :
	/**
	 * Display navigation to next/previous post when applicable.
	 *
	 * @return void
	 */
	function wbls_fw_paging_nav() {
		// Don't print empty markup if there's nowhere to navigate.
		$previous = ( is_attachment() ) ? get_post( get_post()->post_parent ) : get_adjacent_post( false, '', true );
		$next     = get_adjacent_post( false, '', false );

		if ( ! $next && ! $previous ) {
			return;
		}
?>
	<nav class="navigation post-navigation" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Post navigation', 'wbls-brawny' ); ?></h1>
		<div class="nav-links">
			<?php
		previous_post_link( '<div class="nav-previous">%link</div>', _x( '<span class="meta-nav">&larr;</span> %title', 'Previous post link', 'wbls-brawny' ) );
		next_post_link(     '<div class="nav-next">%link</div>',     _x( '%title <span class="meta-nav">&rarr;</span>', 'Next post link',     'wbls-brawny' ) );
?>
		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
	}
endif;

add_filter('siteorigin_panels_css_row_margin_bottom','wbls_brawny_panels_css_row_margin_bottom');

function wbls_brawny_panels_css_row_margin_bottom( $panels_margin_bottom ) {
	if ( $panels_margin_bottom == '30px' ) {
		 $panels_margin_bottom = '35px';
	}else {
		$panels_margin_bottom = $panels_margin_bottom;
	}
	return $panels_margin_bottom;
} 


	// Related Posts Function (call using wbls_brawny_related_posts(); ) /NecessarY/ May be write a shortcode?
	function wbls_brawny_related_posts() {
		echo '<ul id="webulous-related-posts">';
		global $post;
		$tags = wp_get_post_tags($post->ID);
		$tag_arr = '';
		if($tags) {
			foreach($tags as $tag) { $tag_arr .= $tag->slug . ','; }
	        $args = array(
	        	'tag' => $tag_arr,
	        	'numberposts' => 5, /* you can change this to show more */
	        	'post__not_in' => array($post->ID)
	     	);
	        $related_posts = get_posts($args);
	        if($related_posts) {
	        	foreach ($related_posts as $post) : setup_postdata($post); ?>
		           	<li class="related_post">
		           		<a class="entry-unrelated" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('recent-work'); ?></a>
		           		<a class="entry-unrelated" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
		           	</li>
		        <?php endforeach; }
		    else {
	            echo '<li class="no_related_post">' . __( 'No Related Posts Yet!', 'wbls-brawny' ) . '</li>'; 
			 }
		}else{
			echo '<li class="no_related_post">' . __( 'No Related Posts Yet!', 'wbls-brawny' ) . '</li>';
		}
		wp_reset_query();
		
		echo '</ul>';
	}
if ( ! function_exists( 'wbls_brawny_entry_top_meta' ) ) : 
function wbls_brawny_entry_top_meta() {   
	// Post meta data 
	
	  $single_post_top_meta = get_theme_mod('single_post_top_meta', array(1,2,6) );

	if ( 'post' == get_post_type() ) {  
		foreach ($single_post_top_meta as $key => $value) {
		    if( $value == 1) { ?>
		  	    <span class="date-structure">				
					<span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-clock-o"></i><?php the_time('j M Y'); ?></a></span>	
				</span>
	<?php   }elseif( $value == 2) {
				printf(
					_x( '%s', 'post author', 'wbls-brawny' ),
					'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"><i class="fa fa-user"></i> ' . esc_html( get_the_author() ) . '</a></span>'
				);	
			}elseif( $value == 3)  {
				if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
					echo ' <span class="comments-link"><i class="fa fa-comments"></i>';
					comments_popup_link( __( 'Leave a comment', 'wbls-brawny' ), __( '1 Comment', 'wbls-brawny' ), __( '% Comments', 'wbls-brawny' ) );
					echo '</span>';
			    }
	        }elseif( $value == 4) {
				$categories_list = get_the_category_list( __( ', ', 'wbls-brawny' ) );
				if ( $categories_list ) {
					printf( '<span class="cat-links"><i class="fa fa-folder-open"></i> ' . __( '%1$s ', 'wbls-brawny' ) . '</span>', $categories_list );
				}	
		    }elseif( $value == 5)  {
	    		/* translators: used between list items, there is a space after the comma */
				$tags_list = get_the_tag_list( '', __( ', ', 'wbls-brawny' ) );
				if ( $tags_list ) {
					printf( '<span class="tags-links"><i class="fa fa-tags"></i> ' . __( '%1$s ', 'wbls-brawny' ) . '</span>', $tags_list );
				}			
		    }elseif( $value == 6) {
		        edit_post_link( __( 'Edit', 'wbls-brawny' ), '<span class="edit-link"><i class="fa fa-pencil"></i> ', '</span>' );
		    }
	    }
	}
}

endif;

if ( ! function_exists( 'wbls_brawny_entry_bottom_meta' ) ) : 
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function wbls_brawny_entry_bottom_meta() {   
	// Post meta data 
	
	$single_post_bottom_meta = get_theme_mod('single_post_bottom_meta', array(3,4,5) );

	if ( 'post' == get_post_type() ) {  
		foreach ($single_post_bottom_meta as $key => $value) {
		    if( $value == 1) { ?>
		  	    <span class="date-structure">				
					<span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-clock-o"></i><?php the_time('j M Y'); ?></a></span>	
				</span>
	<?php   }elseif( $value == 2) {
				printf(
					_x( '%s', 'post author', 'wbls-brawny' ),
					'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"><i class="fa fa-user"></i> ' . esc_html( get_the_author() ) . '</a></span>'
				);	
			}elseif( $value == 3)  {
				if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
					echo ' <span class="comments-link"><i class="fa fa-comments"></i>';
					comments_popup_link( __( 'Leave a comment', 'wbls-brawny' ), __( '1 Comment', 'wbls-brawny' ), __( '% Comments', 'wbls-brawny' ) );
					echo '</span>';
			    }
	        }elseif( $value == 4) {
				$categories_list = get_the_category_list( __( ', ', 'wbls-brawny' ) );
				if ( $categories_list ) {
					printf( '<span class="cat-links"><i class="fa fa-folder-open"></i> ' . __( '%1$s ', 'wbls-brawny' ) . '</span>', $categories_list );
				}	
		    }elseif( $value == 5)  {
	    		/* translators: used between list items, there is a space after the comma */
				$tags_list = get_the_tag_list( '', __( ', ', 'wbls-brawny' ) );
				if ( $tags_list ) {
					printf( '<span class="tags-links"><i class="fa fa-tags"></i> ' . __( '%1$s ', 'wbls-brawny' ) . '</span>', $tags_list );
				}			
		    }elseif( $value == 6) {
		        edit_post_link( __( 'Edit', 'wbls-brawny' ), '<span class="edit-link"><i class="fa fa-pencil"></i> ', '</span>' );
		    }
	    }
	}
}

endif;


/*  Site Layout Option  */
if ( ! function_exists( 'wbls_brawny_layout_class' ) ) {
	function wbls_brawny_layout_class() {
	     $sidebar_position = get_theme_mod( 'sidebar_position', 'right' ); 
		     if( 'fullwidth' == $sidebar_position ) {
		     	echo 'sixteen';
		     }elseif('two-sidebar' == $sidebar_position || 'two-sidebar-left' == $sidebar_position || 'two-sidebar-right' == $sidebar_position ) {
		     	echo 'eight';
		     }
		     else{
		     	echo 'eleven';
		     }
		     if ( 'no-sidebar' == $sidebar_position ) {
		     	echo ' no-sidebar';
		     }
	}
}

/* Two Sidebar Left action */

add_action('wbls_brawny_two_sidebar_left','wbls_brawny_double_sidebar_left'); 

    if ( ! function_exists( 'wbls_brawny_double_sidebar_left' ) ) {
		 function wbls_brawny_double_sidebar_left() {
		    $sidebar_position = get_theme_mod( 'sidebar_position', 'right' ); 
				if( 'two-sidebar' == $sidebar_position || 'two-sidebar-left' == $sidebar_position ) :
					 get_sidebar('left'); 
				endif; 
				if('two-sidebar-left' == $sidebar_position || 'left' == $sidebar_position ):
					get_sidebar(); 
				endif;
		 }
	}	    

/* Two Sidebar Right action */

 add_action('wbls_brawny_two_sidebar_right','wbls_brawny_double_sidebar_right'); 	

 if ( ! function_exists( 'wbls_brawny_double_sidebar_right' ) ) {
    function wbls_brawny_double_sidebar_right() {
  	    $sidebar_position = get_theme_mod( 'sidebar_position', 'right' ); 
		 if( 'two-sidebar' == $sidebar_position || 'two-sidebar-right' == $sidebar_position || 'right' == $sidebar_position) :
			 get_sidebar(); 
		endif; 	
		if('two-sidebar-right' == $sidebar_position ):
			get_sidebar('left'); 
		endif;   	
    }
}

/* dynamic sidebar for pro */

add_action('init','wbls_brawny_dynamic_sidebar');
if( !function_exists('wbls_brawny_dynamic_sidebar') ) { 
	function wbls_brawny_dynamic_sidebar() {
		remove_action('brawny_sidebar_right_widget','brawny_sidebar_right_widget');
		add_action('brawny_sidebar_right_widget','wbls_brawny_dynamic_sidebar_right_widget');

		if( !function_exists('wbls_brawny_dynamic_sidebar_right_widget') ) { 
			function wbls_brawny_dynamic_sidebar_right_widget() {

				if( function_exists('generated_dynamic_sidebar') ) {
				    generated_dynamic_sidebar();
			    }elseif ( is_active_sidebar( 'sidebar-1' ) ) {
					 dynamic_sidebar('sidebar-1');
				}else { ?>
					<aside id="meta" class="widget">
						<h4 class="widget-title"><?php _e( 'Meta', 'brawny' ); ?></h4>
						<ul>
							<?php wp_register(); ?>
							<li><?php wp_loginout(); ?></li>
							<?php wp_meta(); ?>
						</ul>
			        </aside><?php 
			    }  
			}
		}
    }
}

add_action( 'wp_head','wbls_brawny_style2_custom_css');
if( !function_exists('wbls_brawny_style2_custom_css') ) {
	function wbls_brawny_style2_custom_css() {
		$styel2_custom_css = get_theme_mod('color_scheme');
         if( $styel2_custom_css != '1') {  ?>  
			<style type="text/css">
			    .main-navigation .current_page_item a {
			    	color: #fff!important;
			    }
			</style><?php  
		} 
	}	
}

/* recent work widgets add options */

function wbls_brawny_recent_work_widgets_add_option( $widget, $return, $instance ) {
  
    // widget id 
    if ( 'recent-work-widget' == $widget->id_base ) { 

        // Display the description option.    
		$portfolio_cat = isset( $instance['portfolio_cat'] ) ? $instance['portfolio_cat'] : '';
		$portfolio_column = isset( $instance['portfolio_column'] ) ? $instance['portfolio_column'] : 4 ;

		?>      <p>   
				    <label for="<?php echo $widget->get_field_id('portfolio_cat') ?>"><?php _e(' Select Category ', 'wbls-brawny') ?></label>
					<?php wp_dropdown_categories( array( 'name' => $widget->get_field_name( 'portfolio_cat' ), 'show_option_all' => 'All Category', 'selected' => $portfolio_cat ) ); ?>
				</p>   
	            <p>
					<label for="<?php echo $widget->get_field_id('portfolio_column') ?>"><?php _e('Select Portfolio Column ', 'wbls-brawny') ?></label>
					<select id="<?php echo $widget->get_field_id('portfolio_column') ?>" name="<?php echo $widget->get_field_name('portfolio_column') ?>">
						<option value="4" <?php selected($portfolio_column, "4") ?>>Four Column</option>
						<option value="3" <?php selected($portfolio_column, "3") ?>>Three Column</option>
						<option value="2" <?php selected($portfolio_column, "2") ?>>Two Column</option>
					</select>  
				</p>    
        <?php
    } 
}             
//add_filter('in_widget_form', 'wbls_brawny_recent_work_widgets_add_option', 10, 3 );   

function wbls_brawny_recent_work_widgets_save_option( $instance, $new_instance ) {
    $instance['portfolio_cat'] = ( ! empty( $new_instance['portfolio_cat'] ) ) ? strip_tags( $new_instance['portfolio_cat'] ) : '';
    $instance['portfolio_column'] = ( ! empty( $new_instance['portfolio_column'] ) ) ? strip_tags( $new_instance['portfolio_column'] ) : '';
 	
    return $instance;         
}  

//add_filter( 'widget_update_callback', 'wbls_brawny_recent_work_widgets_save_option', 10, 3 );

/* Custom CSS Filed merge with the wp additional css
*  Remove get_theme_mod('custom_css')
*  add those css to wp css itself
*  Version4.7
*/
if( !function_exists('wbls_brawny_custom_css_migrate') ) {
    function wbls_brawny_custom_css_migrate(){
		if ( version_compare( $GLOBALS['wp_version'], '4.7', '>=' ) ) {

			if ( function_exists( 'wp_update_custom_css_post' ) ) {
			    // Migrate any existing theme CSS to the core option added in WordPress 4.7.
			    $css = get_theme_mod( 'custom_css' ); 
			    if ( $css ) {
			        $core_css = wp_get_custom_css(); // Preserve any CSS already added to the core option.
			        $return = wp_update_custom_css_post( $core_css . $css );     
			         //echo '<pre>',print_r($return),'</pre>';
			        if ( ! is_wp_error( $return ) ) {
			            // Remove the old theme_mod, so that the CSS is stored in only one place moving forward.
			            remove_theme_mod( 'custom_css' );
			        }
			    }
			}
		}
    }
}
add_action( 'after_setup_theme', 'wbls_brawny_custom_css_migrate' );