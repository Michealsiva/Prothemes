(function( $ ) {

	$(function() {

		docs = $('<a class="brawny-docs doc"></a>')
			.attr('href','http://www.webulousthemes.com/brawny-pro/') 
			.attr('target','_blank')
			.text('Documentation');

		support = $('<a class="brawny-docs question"></a>')
			.attr('href','http://www.webulousthemes.com/support-ticket/')
			.attr('target','_blank')
			.text('Ask a Question');

		$('#customize-info .preview-notice').append(docs);
		$('#customize-info .preview-notice').append(support);

		$('.brawny-docs').on('click',function(e){
			e.stopPropagation();
		});
		
		
	});

})( jQuery );
