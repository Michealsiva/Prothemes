<?php
/**
 * Pro customizer options     
 */

add_action('wbls-brawny_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() {     

// pro home page section 

		Brawny_Kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-brawny' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-brawny'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) );

		Brawny_Kirki::add_field( 'brawny', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-brawny' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch',
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
				'off' => esc_attr__( 'Disable', 'wbls-brawny' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-brawny'),
			'default'  => 'off',
		) );
		Brawny_Kirki::add_field( 'brawny', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-brawny' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-brawny'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-brawny'),
		) );

//  animation section 

Brawny_Kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-brawny' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-brawny'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-brawny' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Brawny_Kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-brawny' ),
	'description'    => __( 'Custom JS', 'wbls-brawny'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-brawny' ),
	'section'  => 'custom_js_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
) ); 

// Tracking section 

Brawny_Kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-brawny' ),
	'description'    => __( 'Tracking Code', 'wbls-brawny'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'analytics',
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-brawny' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-brawny' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'2' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-brawny'),
) );

// color scheme section 

Brawny_Kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-brawny' ),
	'description'    => __( 'Select your color scheme', 'wbls-brawny'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'color_scheme',
	'label'    => __( 'Select your color scheme', 'wbls-brawny' ),
	'section'  => 'multiple_color_section',
	'type'     => 'palette',
	'choices'     => array(
    '1' => array(
		'#41285b',
	),
	'2' => array(
		'#3138cf',
	),
	'3' => array(
		'#0ab05c',
	),
	'4' => array(
		'#cc3333',
	),
	'5' => array(
		'#8f6411',
	),
	'6' => array(
		'#ca4270',
	),
	'7' => array(
		'#7360cb',
	),
	'8' => array(
		'#7360cb',
	),
),
'default' => '1',
//'default'  => 'on',
) );

//Social Network URL Section
Brawny_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-brawny' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-brawny'),
	'panel'			 => 'social_panel',
) );


Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-brawny' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-brawny'),
) );

// flexslider section //

Brawny_Kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-brawny' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-brawny'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-brawny' ),
		'2' => esc_attr__( 'Slide', 'wbls-brawny' )
	),
	'default'  => '2',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-brawny' ),
		'2' => esc_attr__( 'Vertical', 'wbls-brawny' )
	),
	'default'  => '1',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => 'on',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => 'on',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => 'on',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => 'on',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => 'off',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => 'off',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => 'off',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'off' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-brawny' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Brawny_Kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-brawny' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-brawny'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-brawny' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'2' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => '2',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-brawny' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-brawny' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-brawny' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'2' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => '2',
) );

//  portfolio settings //

Brawny_Kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-brawny' ),
) );

$post_per_page = get_option('posts_per_page');
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-brawny' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-brawny' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-brawny' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-brawny' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-brawny'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-brawny' ),
		2 => __( 'Show Without "All"', 'wbls-brawny' ),
		3 => __( 'Hide', 'wbls-brawny' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Brawny_Kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-brawny' ),
	'description'    => __( 'Light Box Settings', 'wbls-brawny'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-brawny' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-brawny' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-brawny' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-brawny' ),
		'4' => esc_attr__( 'light-square', 'wbls-brawny' ),
		'5' => esc_attr__( 'dark-square', 'wbls-brawny' ),
		'6' => esc_attr__( 'facebook', 'wbls-brawny' ),
	),
	'default'  => '1',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-brawny' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-brawny' ),
		'slow' => esc_attr__( 'Slow', 'wbls-brawny' ),
		'normal' => esc_attr__( 'Normal', 'wbls-brawny' ),
	),
	'default'  => 'fast',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-brawny' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-brawny' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'2' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => '2',
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-brawny' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-brawny'),
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-brawny' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-brawny' ),
		'2' => esc_attr__( 'Disable', 'wbls-brawny' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-brawny' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#41285b',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'input[type="text"]:focus,
input[type="email"]:focus,.circle-icon-box .service:hover,
input[type="url"]:focus,.toggle .toggle-title .icn,.widget_image-box-widget .image-box img,
input[type="password"]:focus,.dropcap-box,
input[type="search"]:focus,.flex-control-paging li a.flex-active,
.flex-control-paging li a:hover,.circle-icon-box:hover,
textarea:focus,.site-content .wpcf7-form input[type="submit"],.cnt-form .wpcf7-form input[type="text"],
.cnt-form .wpcf7-form input[type="email"],
.cnt-form .wpcf7-form textarea',
			'property' => 'border-color',
		),
		array(
			'element'  => '.withtip.left:after',
			'property' => 'border-left-color',
		),
		array(
			'element'  => ' ul.filter-options li ,.withtip.right:after',
			'property' => 'border-right-color',
		),
		array(
			'element'  => '.withtip.top:after,.widget.widget_ourteam-widget .team-content h4 span::after,.site-footer .widget_calendar td.widget_ourteam-widget .team-content h4 span::after',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '.widget-area h3.widget-title:after,.widget_recent-work-widget .flex-direction-nav a.flex-prev,
  .widget_recent-work-widget .flex-direction-nav a.flex-next,.withtip.bottom:after',
			'property' => 'border-bottom-color',
		),
		array(
			'element'  => 'a,.main-navigation .current_page_item a,.icon-horizontal a.link-title i,    
.icon-horizontal .icon-title i,  
.icon-horizontal .fa-stack i,
.icon-vertical a.link-title i,.notfound-inner,.notfound-inner p a,
.icon-vertical .icon-title i,
.icon-vertical .fa-stack i,.icon-horizontal a.link-title:hover,
.icon-horizontal .icon-title:hover,
.icon-horizontal .fa-stack:hover,.cnt-address .fa:hover,.cnt-address h4,.cnt-address .textwidget:hover .fa,
.icon-vertical a.link-title:hover,h3.widget-title,.order-total .amount,
.cart-subtotal .amount,
.icon-vertical .icon-title:hover,.site-footer .footer-bottom ul.menu li a:hover,.site-footer .footer-bottom ul.menu li.current_page_item a,.site-footer .widget_social-networks-widget ul li a,
.icon-vertical .fa-stack:hover,h1.entry-title a:hover,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a,
.tabs-container ul.ui-tabs-nav li a:hover,.toggle .toggle-title .icn,
.ei-title h3,.ui-accordion .ui-accordion-header-active span.fa,.widget_recent-work-widget .recent_work_overlay .fa:hover,
.main-navigation .current-menu-item a,.content-details h3 a:hover,.widget_recent-posts-gallery-widget .flex-recent-posts h4,
.main-navigation ul.menu.nav-menu > li.current-menu-ancestor > a,.our-achive i ,.circle-icon-box:hover h4,.circle-icon-box:hover p.fa-stack i,.main-navigation ul.nav-menu li a:hover',
			'property' => 'color',
		),
		/*array(
			'element'  => 'th a,
							.site-header .social .recentcomments a,
							.header-wrap .site-header .social .recentcomments a,
							.left-sidebar .recentcomments a,
							.left-sidebar .widget_rss a,
							.ei-title h3,
							#secondary .btn-white:hover,
			  				#secondary .widget_button-widget .btn.white:hover',
			'property' => 'color',
			'suffix' => '!important',
		),*/
		array(
			'element'  => '.flex-container .flex-caption a,.btn,.widget_social-networks-widget ul li a:hover, .share-box ul li a:hover, #header-bottom .top-right ul li a:hover,
.widget_button-widget .btn,.callout-widget .callout-btn a,table td#today,.widget_recent-work-widget .flex-direction-nav a.flex-prev,.notfound-inner .search-form input[type="search"],
.widget_recent-work-widget .flex-direction-nav a.flex-next,.widget.widget_ourteam-widget .team-content .close:hover,.ui-accordion h3 span.fa,.site-footer .widget_calendar td.widget_ourteam-widget .team-content .close:hover,.widget_social-networks-widget ul li a:hover,.widget.widget_ourteam-widget ul.team-social li a,.site-footer .widget_calendar td.widget_ourteam-widget ul.team-social li a,
.share-box ul li a:hover,li.filter-options li a:hover,.portfolioeffects:hover .portfolio_overlay a:hover,.flex-control-paging li a.flex-active,
.flex-control-paging li a:hover,.page-slider .ei-slider-thumbs li a,.widget .ei-slider-thumbs li a,.site-footer .widget_calendar td .ei-slider-thumbs li a,
ul.ei-slider-thumbs li a,.notice,.hr_fancy2:before,.dropcap-circle,.service-page .textwidget .fa,
.dropcap-box,.sep:before,.pullleft,.withtip:before,.callout-widget:before,.cnt-address .fa,.og-grid .fa,
.pullright,.toggle .toggle-title,.toggle .toggle-title:hover,.slicknav_menu,.widget_button-widget a.btn.btn-white:hover, .widget_button-widget a.btn.white:hover, a.btn.btn-white:hover,
ul.filter-options li a.selected,.widget_recent-posts-gallery-widget .recent-post,.ui-accordion .ui-accordion .ui-accordion-header:hover,.ui-accordion h3:active,.ui-accordion .ui-accordion-header-active,.page-links a,.widget.widget_skill-widget .skill-container .skill .skill-percentage,.site-footer .widget_calendar td.widget_skill-widget .skill-container .skill .skill-percentage,ol.webulous_page_navi li a:hover,.main-navigation ul.sub-menu li.current_page_item > a,
.main-navigation ul.sub-menu li.current_page_ancestor > a,.post-navigation .nav-links a:hover,.post-navigation .nav-links a:focus,
.paging-navigation .nav-links a:hover,.site-footer .widget_testimonial-widget .flex-direction-nav a.flex-prev,
.site-footer .widget_testimonial-widget .flex-direction-nav a.flex-next,.ui-accordion h3,.widget_wbls-image-widget i,.comment-navigation .nav-next a:hover,
.comment-navigation .nav-previous a:hover,.site-footer a.more-button,.widget_image-box-widget a.more-button,.widget-area .widget_calendar caption,.tagcloud a:hover,.widget_search input.search-submit:hover,.site-header,
.paging-navigation .nav-links a:focus,#commentform .form-submit input,.site-content .wpcf7-form input[type="submit"]',
			'property' => 'background-color',
		),
		/*array(
			'element'  => '.main-navigation .sub-menu .current_page_item > a,   	
				            .main-navigation .sub-menu .current-menu-item > a,
							.main-navigation .sub-menu .current_page_ancestor > a,
							.site-content .comment-navigation a:hover,
							#primary .sticky,
							.entry-content blockquote:after,
							.site-main .search-form input.search-submit,
							.site-footer .scroll-to-top,
							.tabs ul li a.tabulous_active,
							.tabs ul li a:hover,
							.tabs.normal ul li a.tabulous_active,
							.tabs.normal ul li a:hover,
							.widget.widget_ourteam-widget ul.team-social li a:hover,.woocommerce #content input.button:hover,
							.woocommerce #respond input#submit:hover,.woocommerce a.button:hover,
							.woocommerce button.button:hover,
							.woocommerce input.button:hover,
							.woocommerce-page #content input.button:hover,.woocommerce-page a.button:hover,
							.woocommerce-page #respond input#submit:hover,
							.woocommerce-page button.button:hover,
							.woocommerce-page input.button:hover,.dropcap-book',
			'property' => 'background-color',
			'suffix' => '!important',
		),*/
	),
) );

Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-brawny' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#282828',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.icon-horizontal a.link-title,
.icon-horizontal .icon-title,.woocommerce ul.products li.product .price,
.icon-horizontal .fa-stack,.site-footer .widget.widget_ourteam-widget .team-content h4,.site-footer .widget_calendar td.widget_ourteam-widget .team-content h4,
.icon-vertical a.link-title,.site-footer a.more-button:hover,.site-footer .image-widget-overlay i,
.icon-vertical .icon-title,.site-footer .circle-icon-box p.more-button a,.site-footer .circle-icon-box p.more-button a:hover,
.icon-vertical .fa-stack,.widget_testimonial-widget .testimony p:nth-child(1)::before,.widget_testimonial-widget ul li p.client strong,blockquote:before,blockquote cite a,.columns.breadcrumb #breadcrumb a:hover,h1.entry-title a,.widget_social-networks-widget ul li a,
.share-box ul li a,ul.filter-options li a,#portfolio h4 a:hover,.widget_recent-work-widget .recent_work_overlay .fa,.widget_recent-work-widget .work:hover .recent_work_overlay .fa:hover,.widget.widget_ourteam-widget ul.team-social li a,.ui-accordion h3:hover,.site-footer .widget_calendar td.widget_ourteam-widget ul.team-social li a',
			'property' => 'color',
		),
		/*array(
			'element' => 'table tr th:hover a,
			  				.site-header .social .recentcomments a:hover	
							.header-wrap .site-header .social .recentcomments a:hover,
							#primary .sticky a:hover,
							#primary .sticky span:hover,
							#primary .sticky time:hover,
							.left-sidebar .recentcomments a:hover,
							.left-sidebar .widget_rss a:hover,
							.wide-cta .call-btn a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),*/
		array(
			'element' => '.site-content .wpcf7-form input[type="submit"]:hover,.navigation-wrap,.main-navigation ul ul,.comment-navigation .nav-next a,
.comment-navigation .nav-previous a,.woocommerce #content input.button,
.slicknav_menu .slicknav_btn,
.slicknav_menu .slicknav_btn:hover,
.woocommerce-page a.button,
.woocommerce-page button.button,
.woocommerce-page input.button ,.slicknav_menu li.current-menu-item a,
.slicknav_menu li a:hover,
.slicknav_menu .slicknav_row:hover,
.og-grid h4:hover,.single-portfolio .single-wrapper .one-third,.widget_image-box-widget a.more-button:hover,.widget_recent-work-widget .flex-direction-nav a.flex-prev:hover,
.widget_recent-work-widget .flex-direction-nav a.flex-next:hover,.flex-container .flex-direction-nav a:hover,.page-links a:hover,.widget.widget_ourteam-widget ul.team-social li a:hover,.site-footer .widget_calendar td.widget_ourteam-widget ul.team-social li a:hover',
			'property' => 'background-color',
		),
       /* array(
			'element' => '.slicknav_menu,
				          .search-form input.search-submit:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),*/
		array(
			'element' => '.sticky,.gallery-item img,.ui-accordion .ui-accordion-header-active span.fa,.dropcap-book,.widget_recent-work-widget .flex-direction-nav a.flex-prev:hover,
.widget_recent-work-widget .flex-direction-nav a.flex-next:hover,.flex-container .flex-direction-nav a:hover',  
			'property' => 'border-color',
		),
		/*array(
			'element' => '.site-content .nav-next a span,
							.withtip.left:after,
							.home .flexslider .slides .flex-caption a:after,
			      			.home .flexslider .slides .flex-caption p a:after,
			      			.home .flexslider .flex-direction-nav .flex-nav-next a,
			      			#filters ul.filter-options li a:hover:before,
			        		#filters ul.filter-options li a.selected:before,
			        		.flexslider .slides .flex-caption a:after,
			      			.flexslider .slides .flex-caption p a:after,
			      			.flexslider .flex-direction-nav .flex-nav-next a,
			      			.widget_button-widget .btn.white:hover:after,
			      			.callout-widget .call-btn a:after,
			      			.wide-dark-grey .callout-widget p.call-btn a:hover:after,
			      			.widget_testimonial-widget .flex-direction-nav a.flex-next:hover',
			'property' => 'border-left-color',
		),
		array(
			'element' => 'abbr,acronym,.withtip.bottom:after',
			'property' => 'border-bottom-color',
		),
        array(
			'element' => '.withtip.right:after,.page-numbers:last-child,
			      			.site-content .nav-previous a span,
			      			.home .flexslider .flex-direction-nav .flex-nav-prev a,
			      			.flexslider .flex-direction-nav .flex-nav-prev a,
			      			a.btn-white:hover:before,
			    			.widget_button-widget .btn.white:hover:before,
			    			.callout-widget .call-btn a:before,
			    			.wide-dark-grey .callout-widget p.call-btn a:hover:before,
			    			.widget_testimonial-widget .flex-direction-nav a.flex-prev:hover',
			'property' => 'border-right-color',
		),
        array(
			'element' => '.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link:after',
			'property' => 'border-top-color',
		),
		array(
			'element' => '.site-footer .widget_social-networks-widget ul li a:after',
			'property' => 'border-top-color',
			'suffix' => '!important',
		),*/
		
	),
) );

// typography panel //

Brawny_Kirki::add_panel( 'typography', array( 
	'title'       => __( 'Typography', 'brawny' ),
	'description' => __( 'Typography and Link Color Settings', 'brawny' ),
) );
   
    Brawny_Kirki::add_section( 'typography_section', array(
		'title'          => __( 'General Settings','brawny' ),
		'description'    => __( 'General Settings', 'brawny'),
		'panel'          => 'typography', // Not typically needed.
	) );
	Brawny_Kirki::add_field( 'brawny', array(
		'settings' => 'custom_typography',
		'label'    => __( 'Enable Custom Typography', 'brawny' ),
		'description' => __('Save the Settings, and Reload this page to Configure the typography section','brawny'),
		'section'  => 'typography_section',
		'type'     => 'switch',
		'choices' => array(
			'on'  => esc_attr__( 'Enable', 'brawny' ),
			'off' => esc_attr__( 'Disable', 'brawny' )
		),
		'tooltip' => __('Turn on to customize typography and turn off for default typography','brawny'),
		'default'  => 'off',
	) );

$typography_setting = get_theme_mod('custom_typography',false );
if( $typography_setting ) :

        $body_font = get_theme_mod('body_family','Open Sans');		        
	    $body_color = get_theme_mod( 'body_color','#282828' );

		$body_size = get_theme_mod( 'body_size','13');
		$body_weight = get_theme_mod( 'body_weight','normal');
		$body_weight == 'bold' ? $body_weight = '400':  $body_weight = 'normal';
		

	Brawny_Kirki::add_section( 'body_font', array(
		'title'          => __( 'Body Font','brawny' ),
		'description'    => __( 'Specify the body font properties', 'brawny'),
		'panel'          => 'typography', // Not typically needed.
	) ); 


	Brawny_Kirki::add_field( 'brawny', array(
		'settings' => 'body',
		'label'    => __( 'Body Settings', 'brawny' ),
		'section'  => 'body_font', 
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $body_font,
			'variant'        => $body_weight,
			'font-size'      => $body_size.'px',
			'line-height'    => '1.7',
			'letter-spacing' => '0',
			'color'          => $body_color,
		),
		'output'      => array(
			array(
				'element' => 'body',
				//'suffix' => '!important',
			),
		),
	) );


	Brawny_Kirki::add_section( 'heading_section', array(
		'title'          => __( 'Heading Font','brawny' ),
		'description'    => __( 'Specify typography of h1,h2,h3,h4,h5,h6', 'brawny'),
		'panel'          => 'typography', // Not typically needed.
	) );
	Brawny_Kirki::add_field( 'brawny', array(   
		'settings' => 'heading_level',
		'label'    => __( 'Select Heading level', 'brawny' ),
		'section'  => 'heading_section',
		'type'     => 'radio-buttonset',   
		'choices' => array(
			'h1'  => esc_attr__( 'H1', 'brawny' ), 
			'h2' => esc_attr__( 'H2', 'brawny' ),
			'h3'  => esc_attr__( 'H3', 'brawny' ), 
			'h4' => esc_attr__( 'H4', 'brawny' ),
			'h5'  => esc_attr__( 'H5', 'brawny' ), 
			'h6' => esc_attr__( 'H6', 'brawny' ),
		),
		'default'  => 'h1',
	) );

	$h1_font = get_theme_mod('h1_family','Oswald');
	$h1_color = get_theme_mod( 'h1_color','#282827' );
	$h1_size = get_theme_mod( 'h1_size','48');
	$h1_weight = get_theme_mod( 'h1_weight','bold');
	$h1_weight == 'bold' ? $h1_weight = '400' : $h1_weight = 'regular';

	Brawny_Kirki::add_field( 'brawny', array(
		'settings' => 'h1',
		'label'    => __( 'H1 Settings', 'brawny' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h1_font,
			'variant'        => $h1_weight,
			'font-size'      => $h1_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h1_color,
		),
		'output'      => array(
			array(
				'element' => 'h1',
			),
		),
		'active_callback' => array(
			array(
				'setting'  => 'heading_level',
				'operator' => '==',
				'value'    => 'h1',
			),
	    ),
	) );

	$h2_font = get_theme_mod('h2_family','Oswald');
	$h2_color = get_theme_mod( 'h2_color','#282827' );
	$h2_size = get_theme_mod( 'h2_size','36');
	$h2_weight = get_theme_mod( 'h2_weight','bold');
	$h2_weight == 'bold' ? $h2_weight = '400' : $h2_weight = 'regular';

	Brawny_Kirki::add_field( 'brawny', array(
		'settings' => 'h2',
		'label'    => __( 'H2 Settings', 'brawny' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h2_font,
			'variant'        => $h2_weight,
			'font-size'      => $h2_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h2_color,
		),
		'output'      => array(
			array(
				'element' => 'h2',
			),
		),
		'active_callback' => array(
			array(
				'setting'  => 'heading_level',
				'operator' => '==',
				'value'    => 'h2',
			),
	    ),
	) );

	$h3_font = get_theme_mod('h3_family','Oswald');
	$h3_color = get_theme_mod( 'h3_color','#282827' );
	$h3_size = get_theme_mod( 'h3_size','30');
	$h3_weight = get_theme_mod( 'h3_weight','bold');
	$h3_weight == 'bold' ? $h3_weight = '400' : $h3_weight = 'regular';

	Brawny_Kirki::add_field( 'brawny', array(
		'settings' => 'h3',
		'label'    => __( 'H3 Settings', 'brawny' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default' => array(
			'font-family'    => $h3_font,
			'variant'        => $h3_weight,
			'font-size'      => $h3_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h3_color,
		),
		'output'      => array(
			array(
				'element' => 'h3',
			),
		),
		'active_callback' => array(
			array(
				'setting'  => 'heading_level',
				'operator' => '==',
				'value'    => 'h3',
			),
	    ),
	) );

	$h4_font = get_theme_mod('h4_family','Oswald');
	$h4_color = get_theme_mod( 'h4_color','#282827' );
	$h4_size = get_theme_mod( 'h4_size','24');
	$h4_weight = get_theme_mod( 'h4_weight','bold');
	$h4_weight == 'bold' ? $h4_weight = '400' : $h4_weight = 'regular';


	Brawny_Kirki::add_field( 'brawny', array(
		'settings' => 'h4',
		'label'    => __( 'H4 Settings', 'brawny' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h4_font,
			'variant'        => $h4_weight,
			'font-size'      => $h4_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h4_color,
		),
		'output'      => array(
			array(
				'element' => 'h4',
			),
		),
		'active_callback' => array(
			array(
				'setting'  => 'heading_level',
				'operator' => '==',
				'value'    => 'h4',
			),
	    ),
	) );

    $h5_font = get_theme_mod('h5_family','Oswald');
	$h5_color = get_theme_mod( 'h5_color','#282827' );
	$h5_size = get_theme_mod( 'h5_size','18');
	$h5_weight = get_theme_mod( 'h5_weight','bold');
	$h5_weight == 'bold' ? $h5_weight = '400' : $h5_weight = 'regular';


	Brawny_Kirki::add_field( 'brawny', array(
		'settings' => 'h5',
		'label'    => __( 'H5 Settings', 'brawny' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h5_font,
			'variant'        => $h5_weight,
			'font-size'      => $h5_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h5_color,
		),
		'output'      => array(
			array(
				'element' => 'h5',
			),
		),
		'active_callback' => array(
			array(
				'setting'  => 'heading_level',
				'operator' => '==',
				'value'    => 'h5',
			),
	    ),
	) );

	$h6_font = get_theme_mod('h6_family','Oswald');
	$h6_color = get_theme_mod( 'h6_color','#282827' );
	$h6_size = get_theme_mod( 'h6_size','16');
	$h6_weight = get_theme_mod( 'h6_weight','bold');
	$h6_weight == 'bold' ? $h6_weight = '400' : $h6_weight = 'regular';


	Brawny_Kirki::add_field( 'brawny', array(
		'settings' => 'h6',
		'label'    => __( 'H6 Settings', 'brawny' ),
		'section'  => 'heading_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $h6_font,
			'variant'        => $h6_weight,
			'font-size'      => $h6_size.'px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => $h6_color,
		),
		'output'      => array(
			array(
				'element' => 'h6',
			),
		),
		'active_callback' => array(
			array(
				'setting'  => 'heading_level',
				'operator' => '==',
				'value'    => 'h6',
			),
	    ),
	) );

	// navigation font 
	Brawny_Kirki::add_section( 'navigation_section', array(
		'title'          => __( 'Navigation Font','brawny' ),
		'description'    => __( 'Specify Navigation font properties', 'brawny'),
		'panel'          => 'typography', // Not typically needed.
	) );

	Brawny_Kirki::add_field( 'brawny', array(
		'settings' => 'navigation_font',
		'label'    => __( 'Navigation Font Settings', 'brawny' ),
		'section'  => 'navigation_section',
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => 'Oswald',
			'variant'        => '400',
			'font-size'      => '15px',
			'line-height'    => '1.4',
			'letter-spacing' => '0',
			'color'          => '',
		),
		'output'      => array(
			array(
				'element' => '.main-navigation a',
			),
		),
	) );
endif; 

//  slider panel //

Brawny_Kirki::add_panel( 'slider_panel', array(   
	'title'       => __( 'Slider Settings', 'brawny' ),  
	'description' => __( 'Flex slider related options', 'brawny' ), 
	'priority'    => 11,    
) );

//  flexslider section  //

Brawny_Kirki::add_section( 'flex_caption_section', array(
	'title'          => __( 'Flexcaption Settings','brawny' ),
	'description'    => __( 'Flexcaption Related Options', 'brawny'),
	'panel'          => 'slider_panel', // Not typically needed.
) );

Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexcaption_bg',
	'label'    => __( 'Select Flexcaption Background Color', 'brawny' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '',
	'alpha' => true,   
	'output'   => array(
		array(
			'element'  => '.flexslider .flex-caption',
			'property' => 'background-color',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexcaption_align',
	'label'    => __( 'Select Flexcaption Alignment', 'brawny' ),
	'section'  => 'flex_caption_section',
	'type'     => 'select',
	'default'  => 'left',
	'choices' => array(
		'left' => esc_attr__( 'Left', 'brawny' ),
		'right' => esc_attr__( 'Right', 'brawny' ),
		'center' => esc_attr__( 'Center', 'brawny' ),
		'justify' => esc_attr__( 'Justify', 'brawny' ),
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .flex-caption',
			'property' => 'text-align',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );
 Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexcaption_bg_position',
	'label'    => __( 'Select Flexcaption Background Horizontal Position', 'brawny' ),
	'tooltip' => __('Select how far from left','brawny'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '0',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .flex-caption',
			'property' => 'left',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) ); 
 Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'brawny' ),
	'tooltip' => __('Select how far from top','brawny'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '10',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),	
	'output'   => array(
		array(
			'element'  => '.flexslider .flex-caption',
			'property' => 'top',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),

) ); 
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexcaption_bg_width',
	'label'    => __( 'Select Flexcaption Background Width', 'brawny' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Flexcaption Background Width','brawny'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .flex-caption',
			'property' => 'width',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) ); 
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexcaption_responsive_bg_width',
	'label'    => __( 'Select Responsive Flexcaption Background Width', 'brawny' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Responsive Flexcaption Background Width, Default width value 100 ( This value will apply for max-width: 768px )','brawny'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .flex-caption',
			'property' => 'width',
			'media_query' => '@media (max-width: 768px)',
			'value_pattern' => 'calc($%)',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );
Brawny_Kirki::add_field( 'brawny', array(
	'settings' => 'flexcaption_color',
	'label'    => __( 'Select Flexcaption Font Color', 'brawny' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '#ffffff',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption,.home .flexslider .slides .flex-caption p a,.home .flexslider .slides .flex-caption p,.flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption h1,.flexslider .slides .flex-caption h2,.flexslider .slides .flex-caption h3,.flexslider .slides .flex-caption h4,.flexslider .slides .flex-caption h5,.flexslider .slides .flex-caption h6',
			'property' => 'color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );
}

