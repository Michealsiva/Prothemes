<?php 


if( ! class_exists( 'Wbls_Theme_Custom_CSS_JS' ) ) {
	class Wbls_Theme_Custom_CSS_JS {

		/**
		 * Wbls_Theme_Custom_CSS_JS constructor.
		 */
		public function __construct() {
		}


		/**
		 * Custom Theme Options JS
		 */
		public function js() {

			$wbls_options_default = array(          

					'breadcrumb' => 1,
					'breadcrumb_char' => 1,   
					'numeric_pagination' => 1,   
					'sidebar_position' => 'right',
					'custom_js' => '',
					'custom_css' => '',
					'logo_title' =>  0,
					'logo' => '',
					'tagline' => 1,
					'apple_touch' => '',
					'header_search' => 1,
					'enable_primary_color' => 0,
					'primary_color' => '#3c5895',
					'digg' => '',
					'dribbble' => '',
					'facebook' => '',
					'twitter' => '',
					'google_plus' => '',
					'linkedin' => '',
					'instagram' => '',
					'flickr' => '',
					'youtube' => '',
					'vimeo' => '',
					'pinterest' => '',     
					'rss' => '',
					'skype' => '',
					'tumblr' => '',
					'footer_widgets' => 1,
					'copyright' => '',
					'page-builder' => 1,
					'flexslider' => '[flexslider name=home-slider]',
					'featured_image' => 1,
					'single_featured_image' => 1,
					'author_bio_box' => 0,
					'social_sharing_box' => 1,
					'related_posts' => 1,
					'comments' => 1,
					'facebook_sb' => 1,
					'twitter_sb' => 1,
					'linkedin_sb' => 1,
					'google-plus_sb' => 1,
					'email_sb' => 1,
					'animation' => 1,
					'slide_direction' => 1,
					'flexslider_slideshow_speed' => 50,
					'flexslider_animation_speed' => 50,
					'flexslider_slideshow' => 1,
					'flexslider_smooth_height' => 0,
					'flexslider_direction_nav' => 1,
					'flexslider_control_nav' => 1,
					'flexslider_keyboard_nav' => 1,
					'flexslider_mousewheel_nav' => 1,
					'flexslider_pauseplay' => 0,
					'flexslider_randomize' => 0,
					'flexslider_animation_loop' => 0,
					'flexslider_pause_on_action' => 1,
					'flexslider_pause_on_hover' => 0,
					'flexslider_prev_text' => 'Prev',
					'flexslider_next_text' => 'Next',
					'flexslider_play_text' => 'Play',
					'flexslider_pause_text' => 'Pause',
					'carousel_animation' => 2,
					'carousel_animation_loop' => 0,
					'carousel_item_width' => 270,  
					'carousel_item_margin' => 10,
					'carousel_pagination' => 0,
					'lightbox_theme' => '1',
					'lightbox_animation_speed' => 'fast',
					'lightbox_slideshow' => 50,
					'lightbox_autoplay_slideshow' => 0,
					'lightbox_opacity' => 0.5,
					'lightbox_overlay_gallery' => 1,
					'custom_typography' => 0,
					
			);
			$wbls_options = get_theme_mods();
			$wbls_options = wp_parse_args( $wbls_options, $wbls_options_default );

			//echo '<pre>', print_r($wbls_options), '</pre>';
			if( (int) $wbls_options['animation'] === 1 ) {
				$animation = 'fade';
			} else {
				$animation = 'slide';
			}


			if( (int) $wbls_options['slide_direction'] === 1 ) {
				$slide_direction = 'horizontal';
			} else {
				$slide_direction = 'vertical';
			}

			switch ($wbls_options['lightbox_theme']) {
				case '1':
					$lightbox_theme = 'pp_default';
					break;
				case '2':
					$lightbox_theme = 'light_rounded';
					break;
				case '3':
					$lightbox_theme = 'dark_rounded';
					break;
				case '4':
					$lightbox_theme = 'light_square';
					break;
				case '5':
					$lightbox_theme = 'dark_square';
					break;
				case '6':
					$lightbox_theme = 'facebook';
					break;
				default:
					$lightbox_theme = 'pp_default';
					break;
			}
			?>
			<script type="text/javascript">
				jQuery(document).ready(function($){
					$('.flexslider').flexslider({
						//controlsContainer: ".flex-container",
						animation: '<?php echo isset( $animation ) ? $animation : 'fade';?>',
						direction: '<?php echo isset( $slide_direction ) ? $slide_direction : 'horizontal'; ?>',
						slideshowSpeed: <?php echo !empty( $wbls_options['flexslider_slideshow_speed'] ) ? $wbls_options['flexslider_slideshow_speed']*100 : '7000'; ?>,
						animationSpeed: <?php echo !empty( $wbls_options['flexslider_animation_speed'] ) ? $wbls_options['flexslider_animation_speed'] *100: '600'; ?>,
						slideshow: <?php echo !empty( $wbls_options['flexslider_slideshow'] ) ? 'true' : 'false'; ?>,
						smoothHeight: <?php echo !empty( $wbls_options['flexslider_smooth_height'] ) ? 'true' : 'false'; ?>,
						directionNav: <?php echo !empty( $wbls_options['flexslider_direction_nav'] ) ? 'true' : 'false'; ?>,
						controlNav: <?php echo !empty( $wbls_options['flexslider_control_nav'] ) ? 'true' : 'false'; ?>,
						multipleKeyboard: <?php echo !empty( $wbls_options['flexslider_keyboard_nav'] ) ? 'true' : 'false'; ?>,
						mousewheel: <?php echo !empty( $wbls_options['flexslider_mousewheel_nav'] ) ? 'true' : 'false'; ?>,
						pauseplay: <?php echo !empty( $wbls_options['flexslider_pauseplay'] ) ? 'true' : 'false'; ?>,
						randomize: <?php echo !empty( $wbls_options['flexslider_randomize'] ) ? 'true' : 'false'; ?>,
						animationLoop: <?php echo !empty( $wbls_options['flexslider_animation_loop'] ) ? 'true' : 'false'; ?>,
						pauseOnAction: <?php echo !empty( $wbls_options['flexslider_pause_on_action'] ) ? 'true': 'false'; ?>,
						pauseOnHover: <?php echo !empty( $wbls_options['flexslider_pause_on_hover'] ) ? 'true' : 'false'; ?>,
						prevText: "<?php echo isset( $wbls_options['flexslider_prev_text'] ) ? $wbls_options['flexslider_prev_text'] : 'Previous'; ?>",
						nextText: "<?php echo isset( $wbls_options['flexslider_next_text'] ) ? $wbls_options['flexslider_next_text'] : 'Next'; ?>",
						playText: "<?php echo isset( $wbls_options['flexslider_play_text'] ) ? $wbls_options['flexslider_play_text'] : 'Play'; ?>",
						pauseText: "<?php echo isset( $wbls_options['flexslider_pause_text'] ) ? $wbls_options['flexslider_pause_text'] : 'Pause';?>",
					});
			

					
					$('.flexcarousel').flexslider({
						animation: 'slide',
						animationLoop: <?php echo !empty($wbls_options['carousel_animation_loop']) ? 'true':'false'; ?>,
						controlNav: <?php echo !empty($wbls_options['carousel_pagination'] ) ? 'true' : 'false'; ?>,
						itemWidth: <?php echo !empty($wbls_options['carousel_item_width']) ? $wbls_options['carousel_item_width'] : 230; ?>,
						itemMargin: <?php echo !empty($wbls_options['carousel_item_margin']) ? $wbls_options['carousel_item_margin'] : 10;?>,
					});


					$("a[rel^='prettyPhoto']").prettyPhoto({
						animation_speed: "<?php echo isset($wbls_options['lightbox_animation_speed']) ? strtolower($wbls_options['lightbox_animation_speed']) : 'fast'; ?>",
						slideshow: <?php echo isset( $wbls_options['lightbox_slideshow'] ) ? $wbls_options['lightbox_slideshow'] * 100 : '5000'; ?>,
						autoplay_slideshow: <?php echo !empty( $wbls_options['lightbox_autoplay_slideshow'] ) ? 'true' : 'false'; ?>,
						opacity: <?php echo isset( $wbls_options['lightbox_opacity'] ) ? $wbls_options['lightbox_opacity'] : '0.50'; ?>,
						theme: "<?php echo isset( $lightbox_theme ) ? $lightbox_theme : 'pp_default'; ?>",
						overlay_gallery: <?php echo !empty( $wbls_options['lightbox_overlay_gallery'] ) ? 'true' : 'false'; ?>,
					});

				});
			</script>
			<?php
		}



		public function wbls_user_customize_js() {
			$user_custom_js = get_theme_mod ('custom_js');
			?>	
			<script type="text/javascript">
				<?php echo $user_custom_js; ?>      
			</script>
			<?php
		}


		public function analytics_place_header() {
			$analytics_place = get_theme_mod('analytics_place');
			if( ! $analytics_place ) {
				echo get_theme_mod('analytics');
			}
		}

		public function analytics_place_footer() {
			$analytics_place = get_theme_mod('analytics_place');
			if(  $analytics_place ) {
				echo get_theme_mod('analytics');
			}
		}

	}
}
