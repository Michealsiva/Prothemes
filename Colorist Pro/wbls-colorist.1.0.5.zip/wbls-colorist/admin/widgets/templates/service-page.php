<div class="free-home">
    <div id="primary">
        <div class="services-wrapper clearfix">
            <div>
        	    	<?php if( has_post_thumbnail() ) : ?>
                        <a href="<?php echo esc_url( get_permalink() ); ?>">          <?php the_post_thumbnail('wbls-colorist_service-img'); ?></a>
        	    	<?php endif; ?>
            	    <?php the_title( sprintf( '<h2><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
        	    	<?php the_content( ); ?>
            </div>

        </div>
   </div>
</div>


