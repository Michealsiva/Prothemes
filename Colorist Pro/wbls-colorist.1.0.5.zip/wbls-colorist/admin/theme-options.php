<?php
/**
 * Pro customizer options     
 */

add_action('wbls-colorist_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() { 

Colorist_Kirki::add_panel( 'pro_panel', array(   
	'title'       => __( 'Pro Options', 'wbls-colorist' ),  
	'description' => __( 'Pro Options', 'wbls-colorist' ),         
   ) );     
 
// pro home paeg section 

		Colorist_Kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-colorist' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-colorist'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) ); 

		Colorist_Kirki::add_field( 'colorist', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-colorist' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch',
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
				'off' => esc_attr__( 'Disable', 'wbls-colorist' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-colorist'),
			'default'  => 'off',
		) );
		Colorist_Kirki::add_field( 'colorist', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-colorist' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-colorist'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-colorist'),
		) );

//  animation section 

Colorist_Kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-colorist' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-colorist'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-colorist' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Colorist_Kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-colorist' ),
	'description'    => __( 'Custom JS', 'wbls-colorist'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-colorist' ),
	'section'  => 'custom_js_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ),
) ); 


// Tracking section  

Colorist_Kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-colorist' ),
	'description'    => __( 'Tracking Code', 'wbls-colorist'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'analytics',
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-colorist' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ),
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-colorist' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'2' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-colorist'),
) );

// color scheme section 

Colorist_Kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-colorist' ),
	'description'    => __( 'Select your color scheme', 'wbls-colorist'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Colorist_Kirki::add_field( 'colorist', array(
			'settings' => 'color_scheme',
			'label'    => __( 'Select your color scheme', 'wbls-colorist' ),
			'section'  => 'multiple_color_section',
			'type'     => 'palette',
			'choices'     => array(
	            '1' => array(
					'#eb416b',
				),
				'2' => array(
					'#e18904',
				),
				'3' => array(
					'#1cbcb4',
				),
				'4' => array(
					'#7d3bc0 ',
				),
				'5' => array(
					'#629923',
				),
				'6' => array(
					'#ef584d',
				),
				'7' => array(
					'#2b73e1',
				),
				'8' => array(
					'#d85830',
				),
			),
'default' => '1',
//'default'  => 'on',
) );

//Social Network URL Section
Colorist_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-colorist' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-colorist'),
	'panel'			 => 'social_panel',
) );

Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-colorist' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-colorist'),
) );

// flexslider section //

Colorist_Kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-colorist' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-colorist'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-colorist' ),
		'2' => esc_attr__( 'Slide', 'wbls-colorist' )
	),
	'default'  => '2',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-colorist' ),
		'2' => esc_attr__( 'Vertical', 'wbls-colorist' )
	),
	'default'  => '1',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => 'on',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => 'on',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => 'on',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => 'on',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => 'off',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => 'off',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => 'off',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'off' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-colorist' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Colorist_Kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-colorist' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-colorist'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-colorist' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'2' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => '2',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-colorist' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-colorist' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-colorist' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'2' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => '2',
) );

//  portfolio settings //

Colorist_Kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-colorist' ),
) );

$post_per_page = get_option('posts_per_page');
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-colorist' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-colorist' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-colorist' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-colorist' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-colorist'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-colorist' ),
		2 => __( 'Show Without "All"', 'wbls-colorist' ),
		3 => __( 'Hide', 'wbls-colorist' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Colorist_Kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-colorist' ),
	'description'    => __( 'Light Box Settings', 'wbls-colorist'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-colorist' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-colorist' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-colorist' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-colorist' ),
		'4' => esc_attr__( 'light-square', 'wbls-colorist' ),
		'5' => esc_attr__( 'dark-square', 'wbls-colorist' ),
		'6' => esc_attr__( 'facebook', 'wbls-colorist' ),
	),
	'default'  => '1',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-colorist' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-colorist' ),
		'slow' => esc_attr__( 'Slow', 'wbls-colorist' ),
		'normal' => esc_attr__( 'Normal', 'wbls-colorist' ),
	),
	'default'  => 'fast',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-colorist' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-colorist' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'2' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => '2',
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-colorist' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-colorist'),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-colorist' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-colorist' ),
		'2' => esc_attr__( 'Disable', 'wbls-colorist' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-colorist' ),   
	'section'  => 'primary_color_field', 
	'type'     => 'color',
	'default'  => '#eb416b', 
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'button:focus,
							input[type="button"]:focus,     
							input[type="reset"]:focus,
							input[type="submit"]:focus,
							button:active,
							input[type="button"]:active,
							input[type="reset"]:active,
							input[type="submit"]:active,.tabs-container div,.widget_image-box-widget .image-box img,.ui-accordion .ui-accordion-content,.circle-icon-box .circle-icon-wrapper .fa-stack i:after,.toggle .toggle-content,.flex-direction-nav a:hover:before,.flex-direction-nav a:hover:after
							,.circle-icon-box .circle-icon-wrapper .fa-stack i ',
			'property' => 'border-color',
		),
		array(
			'element'  => '.faq-acc .ui-accordion-header-active:before,.tabs.normal ul.tab-title li .tabulous_active::after,.tabs.normal ul.tab-title li a:hover::after,.toggle-normal .toggle-title,.tabs-container div:before,.ui-accordion .ui-accordion-header-active',
			'property' => 'border-left-color',
		),
		array(
			'element'  => ' .faq-acc .ui-accordion-header-active:after,.toggle-normal .toggle-title,.tabs-container ul.tabs,.ui-accordion .ui-accordion-header-active',
			'property' => 'border-right-color',
		),
		array(
			'element'  => 'li.ui-tabs-active:before,.sep:after,.tabs-container.center div,.widget.widget_ourteam-widget .team-social li a:hover',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '.toggle-polygon .toggle-title,ul.filter-options li a',
			'property' => 'border-bottom-color',
		),
		array(
			'element'  => 'a, th a, button, .required, .site-header .branding .site-branding .site-title a, .site-title span, .page-template-blog-fullwidth .site-main .entry-body h1 a:hover, .page-template-blog-large .site-main .entry-body h1 a:hover, .blog .site-main .entry-body h1 a:hover, #recentcomments a, .comment-author cite.fn a:hover, .comment-author b, .comment-author a, .comment-metadata a:hover, .comment-metadata.reply a, .home .free-home #primary .post-wrapper .latest-post .latest-post-content h1 a:hover, .home .free-home #primary .post-wrapper .latest-post .latest-post-content h2 a:hover, .home .free-home #primary .post-wrapper .latest-post .latest-post-content h3 a:hover, .home .free-home #primary .post-wrapper .latest-post .latest-post-content h4 a:hover, .home .free-home #primary .post-wrapper .latest-post .latest-post-content h5 a:hover, .home .free-home #primary .post-wrapper .latest-post .latest-post-content h6 a:hover, .entry-content blockquote::before, .site-footer .dropcap, .widget_testimonial-widget .testimony .t-inner::before, .site-footer .widget_testimonial-widget p.client, .notice a:hover, .breadcrumb-wrap #breadcrumb a:hover i, .circle-icon-box .circle-icon-wrapper .fa-stack i, .circle-icon-box:hover a.link-title, .circle-icon-box:hover a.link-title h4, .circle-icon-box:hover h4, .icon-horizontal a.link-title i, .icon-horizontal .icon-title i, .icon-horizontal .fa-stack i, .icon-vertical a.link-title i, .icon-vertical .icon-title i, .icon-vertical .fa-stack i, .icon-horizontal:hover a.link-title, .icon-horizontal:hover .icon-title, .icon-horizontal:hover .fa-stack, .icon-vertical:hover a.link-title, .icon-vertical:hover .icon-title, .icon-vertical:hover .fa-stack, .pullright::before, .pullleft::before, .pullnone::before, .recent-post .rp-content h4:hover, .recent-post .rp-content a:hover h4, .recent-post .rp-content .entry-date, ul.filter-options li a:hover, .widget_stat-widget .stat-container .icon-wrapper i, .toggle-normal .toggle-title:hover, .widget_list-widget ul li .fa, .widget_list-widget ol li .fa, .widget_rss a, .widget-area ul a:hover, .recentcomments a, .site-footer .footer-widgets a:hover, .site-info a, .home .site-content #primary .post-wrapper .latest-post .latest-post-content h1 a:hover, .home .site-content #primary .post-wrapper .latest-post .latest-post-content h2 a:hover, .home .site-content #primary .post-wrapper .latest-post .latest-post-content h3 a:hover, .home .site-content #primary .post-wrapper .latest-post .latest-post-content h4 a:hover, .home .site-content #primary .post-wrapper .latest-post .latest-post-content h5 a:hover, .home .site-content #primary .post-wrapper .latest-post .latest-post-content h6 a:hover, #primary .entry-title a:hover, .widget-area .left-sidebar ul a:hover, #recentcomments a, .order-total .amount, .cart-subtotal .amount, .woocommerce #content table.cart a.remove, .woocommerce table.cart a.remove, .woocommerce-page #content table.cart a.remove, .woocommerce-page table.cart a.remove, .star-rating',							
			'property' => 'color',
		),
		array(
			'element'  => '.slicknav_nav li.current_page_item a,.slicknav_nav .slicknav_row:hover,.slicknav_nav a:hover,.slicknav_btn:hover,.current-menu-ancestor > a,.main-navigation ul ul a:hover,.main-navigation a:hover, .main-navigation .current_page_item a, .main-navigation .current-menu-item a, .main-navigation .current-menu-parent > a, .main-navigation .current_page_parent > a, input[type="button"], input[type="reset"], input[type="submit"], .main-navigation ul ul li, .sub-menu .current_page_item > a, .sub-menu .current-menu-item > a, .sub-menu .current_page_ancestor > a,.flex-direction-nav a:hover,.flexslider .flex-caption a,.site-content .navigation .nav-links a:hover, .site-content .more-link:hover, .page-links a:hover, ol.webulous_page_navi li a:hover, ol.webulous_page_navi li.bpn-current, .home .free-home #primary .post-wrapper .latest-post .latest-post-content p a:hover, #primary .sticky, .site-footer .circle-icon-box a.more-button:hover, a.more-button, .site-footer .flex-direction-nav a.flex-next:hover, .site-footer .flex-direction-nav a.flex-prev:hover, .ui-accordion h3, .ui-accordion h3 span .fa, .ui-accordion .ui-accordion-header-active, .notice, .btn, .widget_button-widget a.btn.btn-default, .callout-widget, .wide-cta, .circle-icon-box a.more-button:hover, .circle-icon-box:hover .circle-icon-wrapper .fa-stack i, .circle-icon-box:hover a.more-button, .dropcap-circle, .dropcap-box, .widget_flexslider-widget .flexcarousel .flex-direction-nav a:hover, .icon-horizontal:hover .more-button a, .icon-vertical:hover .more-button a, .widget_image-box-widget a.more-button, .sub-menu .current_page_item > a, .sub-menu .current-menu-item > a, .sub-menu .current_page_ancestor > a, .portfolioeffects .overlay_icon a:hover, .widget_recent-work-widget .portfolioeffects .overlay_icon a:hover, .widget_recent-work-widget .work .overlay_icon a:hover, .widget.widget_skill-widget .skill-container .skill .skill-percentage, .widget_social-networks-widget ul li a:hover, .share-box ul li a:hover, .widget_stat-widget .stat-container .icon-wrapper h5::after, .tabs-container ul.tabs li.ui-tabs-active a, .tabs-container ul.tabs li a:hover, .tabs-container.center ul.tabs li a, .toggle-normal .toggle-title::before, .withtip::before, .service-features .service:hover .fa-stack, #secondary .left-sidebar .callout-widget, .widget_calendar #today, .widget_tag_cloud a, .top-nav ul li:hover a, .order-total .amount, .cart-subtotal .amount, .home .flexslider .flex-control-paging li .flex-active, .home .site-content #primary .post-wrapper .latest-post .latest-post-content p a:hover,.woocommerce #content div.product .woocommerce-tabs ul.tabs li a:hover, .woocommerce div.product .woocommerce-tabs ul.tabs li a:hover, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li a:hover, .woocommerce-page div.product .woocommerce-tabs ul.tabs li a:hover, .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, .woocommerce #content nav.woocommerce-pagination ul li a:focus, .woocommerce #content nav.woocommerce-pagination ul li a:hover, .woocommerce #content nav.woocommerce-pagination ul li span.current, .woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce-page #content nav.woocommerce-pagination ul li a:focus, .woocommerce-page #content nav.woocommerce-pagination ul li a:hover, .woocommerce-page #content nav.woocommerce-pagination ul li span.current, .woocommerce-page nav.woocommerce-pagination ul li a:focus, .woocommerce-page nav.woocommerce-pagination ul li a:hover, .woocommerce-page nav.woocommerce-pagination ul li span.current',
			'property' => 'background-color',
		),
		array(
			'element'  => '.tabs.normal ul.tab-title li .tabulous_active,.site-footer .scroll-to-top, .site-footer .scroll-to-top:hover',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
) );

Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-colorist' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#1e1e1e',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => 'button,input,select,textarea,table tr th:hover a,.site-footer a.more-button:hover,
						.site-footer .widget_social-networks-widget ul li a:hover i,.left-sidebar .circle-icon-box:hover .icon-wrapper p.fa-stack i:before,.comment-list > li article .comment-meta .comment-author cite.fn a,.comment-list > li article .comment-meta .comment-author b:hover,.comment-list > li article .comment-meta .comment-author a:hover,
						.comment-list > li article .comment-meta .comment-metadata .reply a:hover,  .comment-respond input[type="email"]:focus,.comment-respond input[type="text"]:focus,
						.comment-respond input[type="url"]:focus,.comment-respond textarea:focus,#primary .sticky a:hover, #primary .sticky span:hover, #primary .sticky time:hover,.page-template-blog-fullwidth .site-main .entry-body h1 a,.page-template-blog-large .site-main .entry-body h1 a, .blog .site-main .entry-body h1 a,.recentcomments a:hover,.widget_rss a:hover,.widget_tag_cloud a:hover,.site-footer .footer-widgets .recentcomments a,.site-footer .footer-widgets .widget_archive select, .site-footer .footer-widgets .widget_categories select, .site-footer .footer-widgets .textwidget select,
						.site-footer .footer-widgets .widget_tag_cloud a:hover,.site-footer .footer-widgets .widget_rss ul a,.site-info a:hover',
			'property' => 'color',
		),
		array(
			'element' => 'button:hover,input[type="button"]:hover,input[type="reset"]:hover,input[type="submit"]:hover,ol.webulous_page_navi li a,
						.flexslider .flex-caption a:hover,.btn:hover,.widget_button-widget a.btn.btn-default:hover,#secondary .left-sidebar .callout-widget a:hover,.comment-respond input[type="email"],.comment-respond input[type="text"],
						.comment-respond input[type="url"],.comment-respond textarea,.widget_text .textwidget p.btn-more a,.top-features a.more-button:hover,#secondary select, .footer-widgets select ',
			'property' => 'background-color',
		),
		array(
			'element' => 'button:focus,input[type="button"]:focus,input[type="reset"]:focus,input[type="submit"]:focus,button:active,
						  input[type="button"]:active,input[type="reset"]:active,input[type="submit"]:active,
						 .page-numbers,.widget_testimonial-widget .testimony,.widget_image-box-widget a.more-button:hover',  
			'property' => 'border-color',
		),
		array(
			'element' => 'abbr, acronym',
			'property' => 'border-bottom-color',
		),
        array(
			'element' => '.page-numbers:last-child ',
			'property' => 'border-right-color',
		),
		
	),
) );

Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexcaption_bg',
	'label'    => __( 'Select Flexcaption Background Color', 'colorist' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => 'rgba(51, 51, 51, 0.5)',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexcaption_align',
	'label'    => __( 'Select Flexcaption Alignment', 'colorist' ),
	'section'  => 'flex_caption_section',
	'type'     => 'select',
	'default'  => 'left',
	'choices' => array(
		'left' => esc_attr__( 'Left', 'colorist' ),
		'right' => esc_attr__( 'Right', 'colorist' ),
		'center' => esc_attr__( 'Center', 'colorist' ),
		'justify' => esc_attr__( 'Justify', 'colorist' ),
	),
	'output'   => array(
		array(
			'element'  => '.home .flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption,.flexslider .slides .flex-caption h1, .flexslider .slides .flex-caption h2, .flexslider .slides .flex-caption h3, .flexslider .slides .flex-caption h4, .flexslider .slides .flex-caption h5, .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption p,.flexslider .slides .flex-caption',
			'property' => 'text-align',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
 Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexcaption_bg_position',
	'label'    => __( 'Select Flexcaption Background Horizontal Position', 'colorist' ),
	'tooltip' => __('Select how far from left, Default value left = 40 ( in % )','colorist'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '40',
	'choices'     => array(
		'min'  => 0,
		'max'  => 64,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'left',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
 Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'colorist' ),
	'tooltip' => __('Select how far from top, Default value top = 10 ( in % )','colorist'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '10',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'top',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexcaption_bg_width',
	'label'    => __( 'Select Flexcaption Background Width', 'colorist' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '55',
	'tooltip' => __('Select Flexcaption Background Width , Default width value 55','colorist'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Colorist_Kirki::add_field( 'colorist', array(
	'settings' => 'flexcaption_responsive_bg_width',
	'label'    => __( 'Select Responsive Flexcaption Background Width', 'colorist' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Responsive Flexcaption Background Width, Default width value 100 ( This value will apply for max-width: 768px )','colorist'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'media_query' => '@media (max-width: 768px)',
			'value_pattern' => 'calc($%)',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
// typography panel //

Colorist_Kirki::add_panel( 'typography', array( 
	'title'       => __( 'Typography', 'colorist' ),
	'description' => __( 'Typography and Link Color Settings', 'colorist' ),
) );
   
    Colorist_Kirki::add_section( 'typography_section', array(
		'title'          => __( 'General Settings','colorist' ),
		'description'    => __( 'General Settings', 'colorist'),
		'panel'          => 'typography', // Not typically needed.
	) );
	Colorist_Kirki::add_field( 'colorist', array(
		'settings' => 'custom_typography',
		'label'    => __( 'Enable Custom Typography', 'colorist' ),
		'description' => __('Save the Settings, and Reload this page to Configure the typography section','colorist'),
		'section'  => 'typography_section',
		'type'     => 'switch',
		'choices' => array(
			'on'  => esc_attr__( 'Enable', 'colorist' ),
			'off' => esc_attr__( 'Disable', 'colorist' )
		),
		'tooltip' => __('Turn on to customize typography and turn off for default typography','colorist'),
		'default'  => 'off',
	) );

$typography_setting = get_theme_mod('custom_typography',false );
if( $typography_setting ) :

        $body_font = get_theme_mod('body_family','Roboto');		        
	    $body_color = get_theme_mod( 'body_color','#1e1e1e' );   
		$body_size = get_theme_mod( 'body_size','16');
		$body_weight = get_theme_mod( 'body_weight','regular');
		$body_weight == 'bold' ? $body_weight = '400':  $body_weight = 'regular';
		

	Colorist_Kirki::add_section( 'body_font', array(
		'title'          => __( 'Body Font','colorist' ),
		'description'    => __( 'Specify the body font properties', 'colorist'),
		'panel'          => 'typography', // Not typically needed.
	) ); 


	Colorist_Kirki::add_field( 'colorist', array(
		'settings' => 'body',
		'label'    => __( 'Body Settings', 'colorist' ),
		'section'  => 'body_font', 
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $body_font,
			'variant'        => $body_weight,
			'font-size'      => $body_size.'px',
			'line-height'    => '1.8',
			'letter-spacing' => '0',
			'color'          => $body_color,
		),
		'output'      => array(
			array(
				'element' => 'body',
				//'suffix' => '!important',
			),
		),
	) );
	endif;
}

