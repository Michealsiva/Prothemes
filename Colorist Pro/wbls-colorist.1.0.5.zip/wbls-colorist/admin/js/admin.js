(function( $ ) {

	$(function() {

		docs = $('<a class="colorist-docs doc"></a>')
			.attr('href','http://www.webulousthemes.com/colorist-pro/') 
			.attr('target','_blank')
			.text('Documentation');

		support = $('<a class="colorist-docs question"></a>')
			.attr('href','http://www.webulousthemes.com/support-ticket/')
			.attr('target','_blank')
			.text('Ask a Question');

		$('#customize-info .preview-notice').append(docs);
		$('#customize-info .preview-notice').append(support);

		$('.colorist-docs').on('click',function(e){
			e.stopPropagation();
		});
		
		
	});

})( jQuery );
