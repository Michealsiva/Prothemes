<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts
 *
 * @param $layouts
 */
if (!function_exists('wbls_colorist_prebuilt_page_layouts') ) {   
function wbls_colorist_prebuilt_page_layouts($layouts){
 $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-colorist'),
    'description' => __('Pre Built Layout for  home page', 'wbls-colorist'),
    'widgets' =>  array(
     0 => 
    array (
      'type' => 'circle',
      'title' => 'Responsive Layout ',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://webulousthemes.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'd5219c29-8424-4df6-90a9-5e06860f059b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'type' => 'circle',
      'title' => 'Awesome Slider',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://webulousthemes.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => '64caed80-7bd6-4f1f-b3e7-959c2116fd12',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'type' => 'circle',
      'title' => 'Retina Ready',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://webulousthemes.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 2,
        'widget_id' => '93893dce-b615-491b-b895-0faed8cf5b74',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'style' => 'fancy',
      'panels_info' => 
      array (
        'class' => 'Wbls_Divider_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '19eab428-5743-4bc1-b5b0-48b005e4bece',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Top  Features',
            'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '18a77556-c892-466c-b5ab-bf366870d5a6',
              'style' => 
              array (
                'class' => 'top-features',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'list' => '*Aliquam dictum elit ac magna rhoncus, nec vestibulum sem suscipit.
*Pellentesque convallis tortor et massa rhoncus interdum.
*Morbi sit amet lacus porttitor, efficitur turpis eget, euismod ipsum.
*Pellentesque convallis tortor et massa rhoncus interdum.
',
            'icon' => 'fa-check',
            'color' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_List_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'cd6b260f-1df5-4764-a866-f94b92e1e68b',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'btntext' => 'READ MORE',
            'url' => 'http://colorist.codinggeek.com/features',
            'target' => '_blank',
            'size' => 'btn-normal',
            'color' => 'btn-default',
            'panels_info' => 
            array (
              'class' => 'Wbls_Button_Widget',
              'raw' => false,
              'grid' => 2,
              'cell' => 0,
              'id' => 2,
              'widget_id' => 'ddecf167-b71b-45f8-a609-33fcc7d11c5f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'animation_class' => '',
              'bottom_margin' => '50px',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'animation_class' => '',
              'bottom_margin' => '50px',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          2 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
          2 => 
          array (
            'grid' => 2,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '57ba8493aebe9',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => 'e86641a6-da50-4d94-b0e2-fa108ab97b13',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'src' => 'http://colorist.webulous.in/wp-content/uploads/2015/06/Our-Top-Features.png',
      'href' => 'http://colorist.webulous.in/wp-content/uploads/2015/06/Our-Top-Features.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 5,
        'widget_id' => '9eb7a50a-e485-49d2-bb8b-ca5430dd2206',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com/',
      'anchor_text' => 'Buy Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '213d4a57-36f7-48ca-aeb5-74f98d6e2c43',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Recent Work',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'top-features',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'count' => '12',
            'type' => 'isotope',
            'panels_info' => 
            array (
              'class' => 'Wbls_Recent_Work_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'tcenter',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '56bc5d364b5c4',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '5ee02794-3586-4885-be76-8e3ab27d531e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Our Team',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 8,
        'widget_id' => '0ea2b628-9e2e-45ee-bb76-a20b78a99f7c',
        'style' => 
        array (
          'class' => 'tcenter tcenter-color',
          'background_display' => 'cover',
        ),
      ),
    ),
    9 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-One.png',
            'title' => 'Feugiat Curces',
            'designation' => 'Senior Manager',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '2c2532f6-4ca6-4dcd-a384-594d49f6334d',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-Two.png',
            'title' => 'Aaleyah',
            'designation' => 'Senior Manager',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'ecf409af-7111-4fc8-9600-2b9921f978e7',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-Three.png',
            'title' => 'Christon Bale',
            'designation' => 'Designer',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '7dc5f010-5a37-453f-a0ac-a060b8a3037a',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-Four.png',
            'title' => 'Kate Smith',
            'designation' => 'Programmer',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'widget_id' => '7dc5f010-5a37-453f-a0ac-a060b8a3037a',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-Three.png',
            'title' => 'Feugiat Curces',
            'designation' => 'Senior Manager',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 4,
              'widget_id' => '038d36b1-79d6-4b9d-a869-1a66246d6ead',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-Four.png',
            'title' => 'Aaleyah',
            'designation' => 'Senior Manager',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 5,
              'widget_id' => 'efda1ad0-d97d-482f-9579-ccb8d4cee93c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-One.png',
            'title' => 'Christon Bale',
            'designation' => 'Designer',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 2,
              'id' => 6,
              'widget_id' => '95fa9487-48ea-4e33-a6b9-61069cd2cecc',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          7 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-Two.png',
            'title' => 'Kate Smith',
            'designation' => 'Programmer',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 7,
              'widget_id' => '95fa9487-48ea-4e33-a6b9-61069cd2cecc',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'animation_class' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'animation_class' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          5 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          6 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          7 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '57ba7e7e13af8',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '9e34de4c-9ff2-4cce-af7e-d7c595b72d3e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Photo Gallery',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 10,
        'widget_id' => '05b3eb72-7503-4db4-8292-16ba9b657b5f',
        'style' => 
        array (
          'class' => 'tcenter',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'slider' => 'photo-gallery',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'widget_id' => '0ce2d6c8-76d9-4f6e-b8ef-a3a86cf21e46',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Latest Posts',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'tcenter top-features',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'count' => '3',
            'type' => 'normal',
            'panels_info' => 
            array (
              'class' => 'Wbls_Recent_Posts_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '56820e2bf344e',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'widget_id' => '4224fde8-2a96-4271-a5c3-606cd6d2888b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'slider' => 'logo-carousel',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 13,
        'widget_id' => 'f25745ed-191f-487b-ba1d-f778a370304e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'class' => 'animation-row1',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '50px',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'animation-row2',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta animation-row3',
        'background_display' => 'cover',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'animation-row4',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-pattern',
        'background_display' => 'cover',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'animation-row6',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width animation-row7',
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'animation-row8',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.64663951120162999,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.35336048879837001,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    11 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    
    ),
  );

  $layouts['home-style2'] = array( 
    'name' => __('Home Page2', 'wbls-colorist'),
    'description' => __( 'Pre Built layout for home page2', 'wbls-colorist'),
    'widgets' => array(
        0 => 
    array (
      'height' => '60',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '72f5bff0-a4f5-4033-a42b-14acdfede413',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Our Services',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'b294d95c-d6b6-4356-b70a-c32f57fdd79b',
        'style' => 
        array (
          'class' => 'tcenter',
          'background_display' => 'cover',
        ),
      ),
    ),
    2 => 
    array (
      'type' => 'circle',
      'title' => 'Responsive Layout ',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://webulousthemes.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '2544c73f-ecd8-48e1-9c66-ffb013e46436',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'type' => 'circle',
      'title' => 'Awesome Slider',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://webulousthemes.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 3,
        'widget_id' => '5019d877-acce-4c7f-8337-953c5a149284',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'type' => 'circle',
      'title' => 'Retina Ready',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://webulousthemes.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 4,
        'widget_id' => '9d5f5e18-91d4-4906-8dff-3960fde3ab14',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'type' => 'circle',
      'title' => 'Page Builder',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => 'Read More ',
      'more_url' => 'http://webulousthemes.com/',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 3,
        'id' => 5,
        'widget_id' => '4ea83a54-f261-4e8d-ae27-6d90f4f51830',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '0721a2d3-14cf-49c7-b69a-0fad4f50b842',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Our Team',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 7,
        'widget_id' => 'b02b355b-78e3-464b-828a-b05b2705b21e',
        'style' => 
        array (
          'class' => 'tcenter',
          'padding' => '30px',
          'background_display' => 'cover',
        ),
      ),
    ),
    8 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-One.png',
            'title' => 'Feugiat Curces',
            'designation' => 'Senior Manager',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '637e0f0d-3fa1-4db2-aafd-0017e497f4fd',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-Two.png',
            'title' => 'Aaleyah',
            'designation' => 'Senior Manager',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '637e0f0d-3fa1-4db2-aafd-0017e497f4fd',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-Three.png',
            'title' => 'Christon Bale',
            'designation' => 'Designer',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '637e0f0d-3fa1-4db2-aafd-0017e497f4fd',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
            'image_url' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/Our-Team-Four.png',
            'title' => 'Kate Smith',
            'designation' => 'Senior Manager',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'widget_id' => '637e0f0d-3fa1-4db2-aafd-0017e497f4fd',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577792cd95c99',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 8,
        'widget_id' => '4e4a1f84-4d8f-4fad-99a2-5ab14510b6eb',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'height' => '80',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '51b806e7-9630-4485-8cad-56f72a94c702',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Top Features',
            'list' => '*Aliquam dictum elit ac magna rhoncus, nec vestibulum sem suscipit.
*Pellentesque convallis tortor et massa rhoncus interdum.
*Morbi sit amet lacus porttitor, efficitur turpis eget, euismod ipsum.
*Pellentesque convallis tortor et massa rhoncus interdum.[gap height="30"]
[button link="http://colorist.codinggeek.com/features" target="_blank" color="btn" size="btn-mini"]Read More[/button]

',
            'icon' => 'fa-check',
            'color' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_List_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'b39dd947-c5c7-4619-9411-ad44df97d8d8',
              'style' => 
              array (
                'class' => 'tcapital',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '577792cd95d14',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 10,
        'widget_id' => '7ba09339-ec80-475b-b6fc-47b40fc5e135',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'src' => 'http://colorist.webulous.in/wp-content/uploads/2015/06/Our-Top-Features.png',
      'href' => 'http://colorist.webulous.in/wp-content/uploads/2015/06/Our-Top-Features.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 11,
        'widget_id' => '7e008d73-4a05-481b-937d-6f34b9297d28',
        'style' => 
        array (
          'class' => 'image-outline',
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 12,
        'widget_id' => 'a694faa7-3aa3-4e60-8f44-fa2c61e63016',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Running Facts',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'bb438a4b-beb1-468f-ab06-ea7a5b186f81',
              'style' => 
              array (
                'class' => 'tcenter',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
          1 => 
          array (
            'title' => '869',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '6dc7a343-b5fe-44cd-bbb3-b3783f84d82e',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '868',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '1b3a980e-f575-48f4-bee2-f8ecd6443ddf',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '867',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '2c956f4d-1ad8-4ab6-925e-c1fb85c505fc',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '866',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => '16359f8c-6c7d-438b-9a1a-f58f45e984eb',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '50px',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577792cd95dd7',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 13,
        'widget_id' => 'bae74d7d-1ca8-4a59-a47a-fec3084d8281',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 14,
        'widget_id' => '3629232a-dafe-45f7-9ecf-6dbf94a6e58a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'title' => 'Accordion',
      'text' => '[accordion_group][accordion title="Responsive Design"]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. Cras venenatis a nibh ut placerat. Vivamus a mauris non quam pretium lobortis non ac odio. [/accordion][accordion title="Retina Ready"] Sed nec massa lorem. Phasellus ut tincidunt velit, id scelerisque lorem. Nullam nisl tortor, mollis ut massa in, dapibus tincidunt libero. Pellentesque pretium posuere turpis eget dignissim. Curabitur sapien lorem, feugiat et velit et, vehicula aliquet urna. Vivamus pellentesque lorem at urna suscipit, at vulputate est ultricies. Aliquam ultrices nec massa sed adipiscing. Pellentesque feugiat sodales tellus. Ut tempus aliquam felis, quis consequat nunc hendrerit eget. Praesent sollicitudin nunc eu sollicitudin placerat. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="Fully Customizable"]Aliquam non lacus in lacus aliquet blandit. Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. Sed ut augue vitae augue vestibulum pulvinar. Fusce commodo ultricies volutpat. Vivamus quis nulla porta, faucibus metus eu, tempus dolor. Ut sed faucibus mi, ac volutpat lectus. Morbi a rhoncus erat. Mauris et metus posuere, imperdiet urna at, congue risus. Nunc at ante sed ipsum porttitor scelerisque semper non libero. Vivamus feugiat nisl sit amet mi tristique dictum. Donec id magna facilisis, euismod sem bibendum, interdum lorem. [/accordion][accordion title="Awesome Slider"]Fusce vehicula risus lorem, sed ultricies neque pellentesque at. Ut dapibus aliquam leo non cursus. Donec eros dui, fringilla vel lacinia id, tincidunt ac eros. Ut ultrices elit nec viverra adipiscing. Aliquam suscipit viverra luctus. Vivamus rhoncus molestie hendrerit. Aenean id lacinia odio. Nullam sit amet dui accumsan, ornare nisi at, ornare elit. Proin ut dolor risus. Cras quis pellentesque felis, at venenatis nibh. Quisque tincidunt id enim a aliquam. [/accordion][/accordion_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 15,
        'widget_id' => 'c2e0d174-48e8-4b19-b0fb-c5ef1b7bd72d',
        'style' => 
        array (
          'class' => 'tcapital',
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => 'our Tabs',
      'text' => '[tabs_group type="normal"][tabs title="2011"]making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.Suspendisse dignissim, turpis ut tincidunt egestas, sem erat sollicitudin est, eget placerat metus erat in ante. Praesent consequat vitae mi quis tincidunt. [/tabs][tabs title="2012"]making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.Suspendisse dignissim, turpis ut tincidunt egestas, sem erat sollicitudin est, eget placerat metus erat in ante. Praesent consequat vitae mi quis tincidunt. [/tabs][tabs title="2013"]making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.Suspendisse dignissim, turpis ut tincidunt egestas, sem erat sollicitudin est, eget placerat metus erat in ante. Praesent consequat vitae mi quis tincidunt. [/tabs][/tabs_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 16,
        'widget_id' => '5fd361d1-e5af-4c48-a459-70fb99e1aec8',
        'style' => 
        array (
          'class' => 'tcapital',
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 17,
        'widget_id' => '4dadeac8-5c4a-4dba-b2b7-9cd49867ee58',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Recent Work',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '103000f1-0691-48c7-beb7-955d057f92ca',
              'style' => 
              array (
                'class' => 'top-features',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'count' => '12',
            'type' => 'isotope',
            'panels_info' => 
            array (
              'class' => 'Wbls_Recent_Work_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '838b0911-936a-44bc-a9bd-5d85d356d91a',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'id' => '',
              'class' => 'tcenter',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '50px',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '577794491b4a1',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 18,
        'widget_id' => '91005ee3-e73c-42bb-ba2b-6ee416900344',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 19,
        'widget_id' => '484b2cb0-36eb-4bc3-979e-1028fde88c36',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    20 => 
    array (
      'title' => 'Testimonials',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 20,
        'widget_id' => 'a536e2b6-8f87-4fa5-b10e-479d65062126',
        'style' => 
        array (
          'class' => 'tcenter',
          'background_display' => 'tile',
        ),
      ),
    ),
    21 => 
    array (
      'title' => 'Testimonials',
      'count' => '5',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 21,
        'widget_id' => '04ea9fd9-d067-474e-816e-6ab3a475ad09',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    22 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Latest Posts',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '3e424e48-8e25-446d-a3ac-71f69d80329a',
              'style' => 
              array (
                'class' => 'tcenter top-features',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'count' => '3',
            'type' => 'normal',
            'panels_info' => 
            array (
              'class' => 'Wbls_Recent_Posts_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '94a50338-a12a-48fa-9076-a70c4bfe041f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '5777b7e20c654',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 22,
        'widget_id' => '11331f34-9e6d-45df-a9c9-4d21816da7bc',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    23 => 
    array (
      'slider' => 'logo-carousel',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 23,
        'widget_id' => '8e528c74-29f0-4157-9c41-d5c83aaef729',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '50px',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'class' => 'animation-row1',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'row-divider fullwidth-patten',
        'row_stretch' => 'full',
        'background' => '#f0f2f3',
        'background_display' => 'cover',
      ),
    ),
    3 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'animation-row2',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'rect-bg',
        'row_stretch' => 'full',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'wide-cta animation-row3',
        'background_display' => 'cover',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'row_stretch' => 'full',
        'background' => '#f0f2f3',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'row-divider full-width animation-row7',
        'bottom_margin' => '29px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
    9 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'animation-row8',
        'bottom_margin' => '20px',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 0.50198609731876997,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 0.49801390268123003,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 5,
      'weight' => 0.52184707050644996,
    ),
    10 => 
    array (
      'grid' => 5,
      'weight' => 0.47815292949354998,
    ),
    11 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    12 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    13 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    14 => 
    array (
      'grid' => 9,
      'weight' => 1,
    ),
    ),
  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-colorist'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-colorist'),
    'widgets' => array(
        0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '<h2>Our Company  History</h2>',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Testimonials',
            'count' => '4',
            'panels_info' => 
            array (
              'class' => 'Wbls_Testimonial_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'tcenter title-divider',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '55addc984ac5a',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '3fea6eeb-21d8-45c9-a7b3-cfaa19528d5c',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '2',
            'type' => 'normal',
            'content' => 'Our Services',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '95d31419-7142-48f8-b090-d128ef8c35b8',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'type' => 'square',
            'title' => 'Leaf',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'icon' => 'fa-leaf',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read more',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '4a5ea148-8f03-4c67-98eb-528b611f43a7',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'type' => 'square',
            'title' => 'Tachometer',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'icon' => 'fa-tachometer',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read more',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '62cd35e8-682c-4674-aa49-c3d197290917',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'type' => 'square',
            'title' => 'Gift',
            'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'icon' => 'fa-gift',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read more',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => 'd9d20663-3cfa-48b9-88e1-7fe898117c8d',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'tcenter',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '5777bd1d3e417',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '34942c61-1eb3-47f5-a596-248503626388',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'height' => '10',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'edf5cfb6-2fe4-414c-93c2-e0e51491597f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '<h2>Why Choose Colorist</h2>',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '5b5cba46-46c2-467e-a936-5fe8eac88aab',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[tabs_group type="normal"][tabs title="GRAPHIC DESIGN"]<b>Vestibulum at lectus posuere, ultrices sapien sed, interdum lacus. Phasellus ullamcorper mollis nunc, nec consectetur tortor rutrum sit amet. Donec suscipit, ipsum id posuere venenatis. </b>
<p>Mauris sed sapien sed sem lacinia porttitor id sit amet est. Suspendisse molestie quis ante in iaculis. Nullam nunc mauris, egestas eu blandit eu, accumsan ut felis. Nam tortor ante, aliquet a risus sed, dictum scelerisque eros. Cras sapien enim, sollicitudin sit amet sapien.</p>
<ul><li> Aliquam dictum elit ac magna rhoncus, nec vestibulum sem suscipit.</li>
</ul>
<img src="http://colorist.webulous.in/wp-content/uploads/2015/06/about-us_03.jpg">[/tabs][tabs title="DEVELOPMENT"]<b>Vestibulum at lectus posuere, ultrices sapien sed, interdum lacus. Phasellus ullamcorper mollis nunc, nec consectetur tortor rutrum sit amet. Donec suscipit, ipsum id posuere venenatis, quam diam gravida lacus, semper vulputate mi magna ut tortor. </b>
<p>Mauris sed sapien sed sem lacinia porttitor id sit amet est. Suspendisse molestie quis ante in iaculis. Nullam nunc mauris, egestas eu blandit eu, accumsan ut felis. Nam tortor ante, aliquet a risus sed, dictum scelerisque eros.</p>
<ul><li> Aliquam dictum elit ac magna rhoncus, nec vestibulum sem suscipit.</li><li> Pellentesque convallis tortor et massa rhoncus interdum.</li></ul>
<img src="http://colorist.webulous.in/wp-content/uploads/2016/07/about-us_03.jpg">[/tabs][tabs title="SERVICES"]
<b>Vestibulum at lectus posuere, ultrices sapien sed, interdum lacus. Phasellus ullamcorper mollis nunc, nec consectetur tortor rutrum sit amet. Donec suscipit, ipsum id posuere venenatis, quam diam gravida lacus, semper vulputate mi magna ut tortor. </b>
<p>Mauris sed sapien sed sem lacinia porttitor id sit amet est. Suspendisse molestie quis ante in iaculis. Nullam nunc mauris, egestas eu blandit eu, accumsan ut felis. Nam tortor ante, aliquet a risus sed, dictum scelerisque eros. </p>
<ul><li> Aliquam dictum elit ac magna rhoncus, nec vestibulum sem suscipit.</li><li> Pellentesque convallis tortor et massa rhoncus interdum.</li><li> Morbi sit amet lacus porttitor, efficitur turpis eget, euismod ipsum.</li></ul>
<img src="http://colorist.webulous.in/wp-content/uploads/2016/07/about-us_03.jpg">
[/tabs][tabs title="HTML & CSS"]
<b>Vestibulum at lectus posuere, ultrices sapien sed, interdum lacus. Phasellus ullamcorper mollis nunc, nec consectetur tortor rutrum sit amet. Donec suscipit, ipsum id posuere venenatis, quam diam gravida lacus, semper vulputate mi magna ut tortor. </b>
<p>Mauris sed sapien sed sem lacinia porttitor id sit amet est. Suspendisse molestie quis ante in iaculis. Nullam nunc mauris, egestas eu blandit eu, accumsan ut felis. Nam tortor ante, aliquet a risus sed, dictum scelerisque eros. Cras sapien enim, sollicitudin sit amet sapien a, scelerisque maximus enim. Quisque semper velit ut fermentum vulputate. Nullam euismod vestibulum purus ac placerat. </p>
<img src="http://colorist.webulous.in/wp-content/uploads/2016/07/about-us_03.jpg">[/tabs][/tabs_group]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '26dbd92e-9aa5-4697-9108-75c6e9ff3207',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'tcenter',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '57ba816b4251a',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 2,
        'cell' => 0,
        'id' => 3,
        'widget_id' => 'c89c5dc6-cede-4738-b576-cd73be8194a2',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'height' => '30',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '75172fe1-fe45-46c1-88bb-db98237b8c68',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'height' => '40',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '91dde9ea-612a-4b11-92e1-8906a2563f0d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '2',
            'type' => 'normal',
            'content' => 'Colorist Statistics',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'c2684ba4-f982-4ea3-a724-629e386e6fe3',
              'style' => 
              array (
                'class' => 'tcenter',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '866',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '365e4f05-b83b-4c56-b339-b7a0942445ef',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '867',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '0b71f656-047e-4f06-8147-01d33fa8f945',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '868',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '1b41439b-52ac-4587-a6d6-cc095c243bed',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '869',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => 'da8ae6c8-e481-4eb1-9748-63ef1049f71f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'center',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '5777bdb7b2c86',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '2d968410-9002-4aa4-9f8c-94017dfd6954',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'height' => '40',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '498bbd4d-7f0c-422e-97ad-b17605d8d57d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Let\'s Get in Touch',
            'text' => 'Vivamus adipiscing eros ut mi imperdiet, quis elementum erat ornare. Donec adipiscing egestas laoreet. Maecenas condimentum, leo vitae interdum mattis, lorem tellus rhoncus purus, nec scelerisque diam ipsum in augue',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'get-touch',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[contact-form-7 id="424" title="contact form"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => 'simple-form1',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => '[contact-form-7 id="627" title="Untitled"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => 'simple-form1',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'tcenter',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '0px',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '5681243dbd396',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'fcf4251b-7b58-4ace-bad7-a8c746cd8b1b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'rect-bg',
        'padding' => '0px',
        'row_stretch' => 'full',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'row_stretch' => 'full',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    ),
  );

$layouts['features'] = array(
      'name' => __('Features Page', 'wbls-colorist'),
      'description' => __( 'Pre Built layout for features page', 'wbls-colorist'),
      'widgets' => array(
  0 => 
    array (
      'title' => '',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'class' => 'para-bold',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'type' => 'polygon',
      'title' => 'Responsive Design',
      'text' => 'Colorist is fully responsive and can adapt to any screen size. Resize your browser window to view it!',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'type' => 'polygon',
      'title' => 'Awesome Slider',
      'text' => 'Colorist includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'type' => 'polygon',
      'title' => 'Font Awesome',
      'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'type' => 'polygon',
      'title' => 'Typography    ',
      'text' => 'Colorist loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
      'icon' => 'fa-font',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'type' => 'polygon',
      'title' => 'Retina Ready    ',
      'text' => 'Colorist is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 5,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'type' => 'polygon',
      'title' => 'Excellent Support',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
      'icon' => 'fa-support',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 6,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'type' => 'polygon',
      'title' => 'Customization',
      'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!  ',
      'icon' => 'fa-cog',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'type' => 'polygon',
      'title' => 'Page Builder',
      'text' => 'Colorist supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 9,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'type' => 'polygon',
      'title' => 'Page Layout',
      'text' => 'Colorist offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 10,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'type' => 'polygon',
      'title' => 'Custom Widget',
      'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
      'icon' => 'fa-beer',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 11,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'type' => 'polygon',
      'title' => 'Shortcode Builder',
      'text' => 'Colorist includes lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
      'icon' => 'fa-check',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 12,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'type' => 'polygon',
      'title' => 'Demo Content',
      'text' => 'Colorist includes demo content files. You can quickly setup the site like our demo and get started easily!',
      'icon' => 'fa-close',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 2,
        'id' => 13,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 14,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'type' => 'polygon',
      'title' => 'Improvement',
      'text' => 'We love our theme customers. We are committed to improve and add new features to Colorist Pro!',
      'icon' => 'fa-signal',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 15,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'type' => 'polygon',
      'title' => 'Page Builder',
      'text' => 'Colorist supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 16,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'type' => 'polygon',
      'title' => 'Page Layout',
      'text' => 'Colorist offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 2,
        'id' => 17,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'type' => 'polygon',
      'title' => 'Google Map',
      'text' => 'Colorist includes Goole Map as shortcode and widget. So, you can use it anywhere in your site!',
      'icon' => 'fa-map-marker',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 18,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'type' => 'polygon',
      'title' => 'Multiple Portfolio',
      'text' => '7 portfolio layouts, 3 blog layouts and multiple other alternate layouts for interior pages!',
      'icon' => 'fa-list-alt',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 1,
        'id' => 19,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    20 => 
    array (
      'type' => 'polygon',
      'title' => 'Multiple Sidebar',
      'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
      'icon' => 'fa-columns',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 2,
        'id' => 20,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta animation-row3',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta animation-row3',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    9 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    10 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    11 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    12 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    13 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    14 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    15 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    16 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    17 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    18 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    19 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    20 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    ),
  ); 

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-colorist'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-colorist'),
      'widgets' => array(
        0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'title' => 'Get Social ',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Social_Networks_Widget',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'Contact',
                  'text' => '[icon icon="fa-map-marker" size=""] 1234  Amigapathi Parkway, 
Mountain View, CA 43005,US
',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => true,
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 1,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'title' => '',
                  'text' => '[icon icon="fa-phone" size=""] +321 123 4567
',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 2,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                3 => 
                array (
                  'title' => '',
                  'text' => '[icon icon="fa-envelope-o" size=""] colorist@example.com',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 3,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                  ),
                ),
                1 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                    'class' => 'cnt-address',
                    'cell_class' => '',
                    'row_css' => '',
                    'bottom_margin' => '',
                    'gutter' => '',
                    'padding' => '',
                    'row_stretch' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 1,
                ),
                1 => 
                array (
                  'grid' => 1,
                  'weight' => 1,
                ),
              ),
            ),
            'builder_id' => '55937a3194a90',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'title' => 'Get in Touch',
                  'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => true,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'style' => 
                    array (
                      'class' => 'headingcolor1',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => '',
                  'text' => '[contact-form-7 id="2593" title="contact us form"]',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 1,
                    'style' => 
                    array (
                      'class' => 'contactus-form1',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                  ),
                ),
                1 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                    'class' => '',
                    'cell_class' => '',
                    'row_css' => '',
                    'bottom_margin' => '',
                    'gutter' => '',
                    'padding' => '',
                    'row_stretch' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 1,
                ),
                1 => 
                array (
                  'grid' => 1,
                  'weight' => 1,
                ),
              ),
            ),
            'builder_id' => '55937b0c92ff1',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => true,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '55acf48040b23',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'class' => 'panel-row-style-full-width-layout',
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-colorist'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-colorist'),
    'widgets' =>  array(
          0 => 
    array (
      'title' => '',
      'text' => '[toggle title="How can install this new version?" open="0" type="polygon"]It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\'.[/toggle]

[toggle title="Curabitur imperdiet porttitor enim vel consequat" open="0" type="polygon"]Nullam sed varius orci, sed sodales libero. Vestibulum pulvinar lectus id placerat rutrum. Vestibulum pellentesque hendrerit erat a elementum. Vestibulum non gravida ligula. Donec mauris mi, pulvinar at scelerisque a, fermentum sit amet lorem. Nunc consequat lobortis odio, a rhoncus ex pellentesque nec.[/toggle]

[toggle title="Duis efficitur elementum ante" open="0" type="polygon"]Fusce efficitur tempus felis eu porta. Nullam in mollis urna. Pellentesque fermentum blandit lectus, suscipit porttitor lorem viverra quis. Suspendisse nec tempus diam. Suspendisse dignissim, mauris vitae tempus fringilla, magna neque efficitur lacus, rhoncus fringilla justo est eu tortor.[/toggle]

[toggle title="Ut iaculis quis ipsum vitae sodales" open="0" type="polygon"]Pellentesque eu suscipit nisi. Curabitur a laoreet lacus, in cursus tortor. Nunc imperdiet nulla eu risus varius, ac rutrum elit mattis. Ut ultrices at urna ac viverra. Fusce id diam mollis, ullamcorper nibh vitae, congue tellus.[/toggle]

[toggle title="Nullam sed accumsan augue" open="0" type="polygon"]Suspendisse posuere faucibus lacus vel ornare. Sed pellentesque erat ut sem sagittis, vel convallis mauris ultrices. Proin libero metus, facilisis sit amet nulla sed, pretium elementum tortor. Aliquam mattis felis a odio ornare, nec maximus orci aliquet. Nunc sit amet ultrices sem.[/toggle]

[toggle title="Praesent iaculis hendrerit viverra" open="0" type="polygon"]Nulla suscipit urna in nunc pellentesque, non suscipit purus scelerisque. Donec lobortis blandit nulla, at finibus libero interdum et. Aenean lobortis, ligula in aliquet porttitor, erat lorem hendrerit nulla, vel auctor ex leo sit amet massa. Ut consectetur, diam vitae rhoncus rhoncus, libero mi facilisis velit, ut aliquet ex magna ut tortor. Aliquam at euismod turpis, vitae pulvinar nunc[/toggle]



















',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '854813d6-dfde-4d2f-9909-f5de6f6f77a6',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-colorist'),
    'description' => __('Pre Built Layout for services page', 'wbls-colorist'),
    'widgets' =>  array(
  0 => 
    array (
      'title' => '',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '3e672d2c-5dba-4cc6-8ca3-c478d41fd9b8',
        'style' => 
        array (
          'class' => 'para-bold',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Para-bold',
      'text' => 'Colorist is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
      'icon' => 'fa-arrows-v',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'f7e60fda-1365-43d0-8599-8593bc459943',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Font Awesome',
      'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'widget_id' => '52db6660-f31f-4a6d-85c5-05af98f52191',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Typography',
      'text' => 'Colorist loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
      'icon' => 'fa-font',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'widget_id' => 'a79f9a62-c243-4676-bfeb-df033ea461ed',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Retina Ready',
      'text' => 'Colorist is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '90c9353a-dbcc-4e32-bac3-0d460ec3957c',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Customization',
      'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
      'icon' => 'fa-edit (alias)',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 5,
        'widget_id' => 'b5cf9ba6-a2e4-4e08-a9fa-777ed8dbc322',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Excellent Support',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
      'icon' => 'fa-thumb-tack',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 6,
        'widget_id' => '96accc3e-3c87-429e-992e-caadde256336',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'title' => 'Lorem Ipsum ?',
                  'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin interdum ipsum nisl, id vulputate erat euismod nec.',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'style' => 
                    array (
                      'class' => 'service_text',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'Awesome Design',
                  'text' => 'Suspendisse porttitor eros a sapien iaculis, sit amet dapibus metus viverra.',
                  'icon' => 'fa-pencil',
                  'icon_background_color' => '',
                  'icon_size' => '3x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => true,
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 1,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'title' => 'Animation Effects',
                  'text' => 'Nullam nunc mauris, egestas eu blandit eu, accumsan ut felis. Nam tortor ante.',
                  'icon' => 'fa-magic',
                  'icon_background_color' => '',
                  'icon_size' => '3x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 2,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                3 => 
                array (
                  'title' => 'Shortcode Builder',
                  'text' => 'Colorist inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
                  'icon' => 'fa-check',
                  'icon_background_color' => '',
                  'icon_size' => '3x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => false,
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 3,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                  ),
                ),
                1 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                    'class' => 'service-features',
                    'cell_class' => '',
                    'row_css' => '',
                    'bottom_margin' => '',
                    'gutter' => '',
                    'padding' => '',
                    'row_stretch' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 1,
                ),
                1 => 
                array (
                  'grid' => 1,
                  'weight' => 1,
                ),
              ),
            ),
            'builder_id' => '559382b9a5134',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '4c52cf1d-6517-4ee2-81a9-29031ca4ea93',
              'style' => 
              array (
                'class' => 'service-img-gap',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/men-3.png',
            'href' => 'http://colorist.webulous.in/wp-content/uploads/2016/07/men-3.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '90894976-f7f7-453b-947e-92ecf9c7a606',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '0px',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.62467532467532005,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.37532467532468,
          ),
        ),
      ),
      'builder_id' => '5779f7beb451e',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '6692e7ea-726c-4c9d-b1a1-516bfc5bd1b1',
        'style' => 
        array (
          'class' => 'service-img-gap',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-darkprimary',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'wbls_colorist_prebuilt_page_layouts');

function wbls_colorist_panels_row_style_fields($fields) {  

    $colorist_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-colorist'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-colorist' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-colorist' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-colorist' ),
        'bounce-animation' => __('bounce-animation','wbls-colorist' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-colorist' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-colorist' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-colorist' ),
        'expandUp-animation' => __('expandUp-animation','wbls-colorist' ),
        'fade-animation' => __('fade-animation','wbls-colorist' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-colorist' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-colorist' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-colorist' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-colorist' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-colorist' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-colorist' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-colorist' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-colorist' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-colorist' ),
        'flip-animation' => __('flip-animation','wbls-colorist' ),
        'flipInX-animation' => __('flipInX-animation','wbls-colorist' ),
        'flipInY-animation' => __('flipInY-animation','wbls-colorist' ),
        'floating-animation' => __('floating-animation','wbls-colorist' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-colorist' ),
        'hatch-animation' => __('hatch-animation','wbls-colorist' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-colorist' ),
        'puffIn-animation' => __('puffIn-animation','wbls-colorist' ),
        'pullDown-animation' => __('pullDown-animation','wbls-colorist' ),
        'pullUp-animation' => __('pullUp-animation','wbls-colorist' ),
        'pulse-animation' => __('pulse-animation','wbls-colorist' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-colorist' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-colorist' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-colorist' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-colorist' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-colorist' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-colorist' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-colorist' ),
        'scale-down-animation' => __('scale-down-animation','wbls-colorist' ),
        'scale-up-animation' => __('scale-up-animation','wbls-colorist' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-colorist' ),
        'slide-left-animation' => __('slide-left-animation','wbls-colorist' ),
        'slide-right-animation' => __('slide-right-animation','wbls-colorist' ),
        'slide-top-animation' => __('slide-top-animation','wbls-colorist' ),
        'slideDown-animation' => __('slideDown-animation','wbls-colorist' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-colorist' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-colorist' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-colorist' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-colorist' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-colorist' ),
        'slideRight-animation' => __('slideRight-animation','wbls-colorist' ),
        'slideUp-animation' => __('slideUp-animation','wbls-colorist' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-colorist' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-colorist' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-colorist' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-colorist' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-colorist' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-colorist' ),
        'swap-animation'  => __('swap-animation','wbls-colorist' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-colorist' ),
        'swing-animation'  => __('swing-animation','wbls-colorist' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-colorist' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-colorist' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-colorist' ), 
        'tossing-animation'  => __('tossing-animation','wbls-colorist' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-colorist' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-colorist' ), 
        'wobble-animation' => __('wobble-animation','wbls-colorist' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-colorist' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'colorist'),
            'type' => 'select',
            'options' => $colorist_animation_name,
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_colorist_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_colorist_panels_row_style_fields');

function wbls_colorist_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_colorist_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_colorist_panels_panels_row_style_attributes', 10, 2);

function wbls_colorist_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Animation', 'wbls-colorist'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_colorist_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_colorist_row_style_groups' );