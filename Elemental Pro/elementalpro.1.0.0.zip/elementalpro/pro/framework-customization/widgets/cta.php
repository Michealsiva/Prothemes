<?php
$output = '';
$output .= '<div class="callout-widget">';
	$output .= '<div class="call-content">';
		$output .= '<h2>' . esc_html( $title ) . '</h2>';
		$output .= '<p>';
			$output .= do_shortcode( $content );
		$output .= '</p>';
	

	$output .= '<p class="cta-right">';
		$output .= '<a href="' . sow_esc_url($cta_url) . '">' . esc_html( $anchor_text ) . '</a>';
		$output .= '</p>';
	$output .= '</div>';
$output .= '</div>';
echo apply_filters( 'cta_shortcode_html', $output );