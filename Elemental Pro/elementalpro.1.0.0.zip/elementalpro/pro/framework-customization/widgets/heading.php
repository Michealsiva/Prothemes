<div class="sow-headline-container"><?php
$divider = ! empty( $instance['divider'] ) ? 'sep '. $headline_align : '';  

	if( !empty( $headline ) ) {
		echo '<' . $headline_tag . ' class="sow-headline '.  $divider .' ">' . wp_kses_post( $headline ) . '</' . $headline_tag . '>';
	}

	if( !empty( $sub_headline ) ) {
		echo '<div class="genex-sub-head-align">';
		echo '<' . $sub_headline_tag . ' class="sow-sub-headline">' . wp_kses_post( $sub_headline ) . '</' . $sub_headline_tag . '>';
	    echo '</div>';
	} ?>
	
</div>