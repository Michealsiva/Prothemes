<?php

    $output = '';
		$output .= '<div class="recent-posts-wrapper">';

		switch( $type ) {
			case 'normal':
				$output .= '<div class="recent-posts">';
				break;
			case 'slider' :
				$output .= '<div class="recent-posts-slider clearfix">';
				break;
			case 'carousel' :
				$output .= '<div class="recent-posts-carousel">';
				break;
			default:
				$output .= '<div class="recent-posts">';
				break;
		}

		$output .= '<ul class="slides">';


			// WP_Query arguments
			$recent_post_args = array (
				'post_type'              => 'post',
				'category_name'          => $cat,
				'post_status'            => 'publish',
				'posts_per_page'         => $count,
				'ignore_sticky_posts'    => true,
				'order'                  => 'DESC',
			);

		// The Query
		$query = new WP_Query( apply_filters( 'recent_posts_args', $recent_post_args ) );

		// The Loop
		if ( $query->have_posts() ) {
	        if( $type == 'normal' ) {
				
			}
			while ( $query->have_posts() ) {
				$query->the_post();	
				if( $type == 'normal' ) {	
					$output .= '<li>';
						$output .= '<div class="recent-post">';
								$output .= '<div class="rp-thumb">'; 
										if ( has_post_thumbnail() ) {
											$output .= get_the_post_thumbnail($query->post->ID ,'genex_primal-highlighted-post');
										}
										else {  
											$output .= '<img src="' . get_template_directory_uri()  . '/images/no-image-blog-full-width.png" alt="" >';
										}
								$output .= '</div><!-- .rp-thumb -->';
								$output .= '<div class="rp-content">';
								$output .='<span class="entry-date"><a href="'. get_permalink() . '">' . get_the_time('j ').'<span>' . get_the_time('M').'</span></a></span>';
							    $output .= '<h4><a href="'. get_permalink() . '">' . get_the_title() . '</a></h4>';
							    $output .='<div class="entry-meta">'; 
									$output .= sprintf(_x( '%s', 'post author', 'elemental_pro' ),'<span class="author vcard"><i class="fa fa-user"></i><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"> ' . esc_html( get_the_author() ) . '</a></span>');
								    $output .= elemental_pro_get_comments_meta();
								$output .='</div><!-- entry-meta -->';
							    $output .= '<p>' . get_the_content() . '</p>';
							$output .= '</div><!-- .rp-content -->';
							
						$output .= '</div><!-- .latest-post -->';
					$output .= '</li>';
				}elseif( $type == 'carousel' ) {
				        $output .= '<li>';
						$output .= '<div class="recent-post">';
								$output .= '<div class="rp-thumb">'; 
										if ( has_post_thumbnail() ) {
											$output .= get_the_post_thumbnail($query->post->ID ,'genex_primal-highlighted-post');
										}
										else {  
											$output .= '<img src="' . get_template_directory_uri()  . '/images/no-image-blog-full-width.png" alt="" >';
										}
								$output .= '</div><!-- .rp-thumb -->';
								$output .= '<div class="rp-content">';
								$output .='<span class="entry-date"><a href="'. get_permalink() . '">' . get_the_time('j ').'<span>' . get_the_time('M').'</span></a></span>';
						
							    $output .= '<h4><a href="'. get_permalink() . '">' . get_the_title() . '</a></h4>';
							    $output .='<div class="entry-meta">';
									$output .='<span class="data-structure"><span class="dd"><i class="fa fa-calendar"></i>' . get_the_time('j M Y').'</span></span>';
								$output .='</div><!-- entry-meta -->';
							    $output .= '<p>' . get_the_content() . '</p>';
							$output .= '</div><!-- .rp-content -->';
							
						$output .= '</div><!-- .latest-post -->';
					$output .= '</li>';
			    }else {
			    	$output .= '<li>';
						$output .= '<div class="recent-post">';
						$output .= '<div class="rp-thumb">';	              
							if ( has_post_thumbnail() ) {
								$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $query->post->ID ), array(1200,400) );
								$output .= '<img src="' . $image_url[0] . '">';
							} else {
								$output .= '<img src="' . get_template_directory_uri()  . '/images/no-image-blog-full-width.png" alt="" >';     
							}
						$output .= '</div><!-- .rp-thumb -->';
						$output .= '<div class="rp-content flex-caption">';
						$output .='<span class="entry-date"><a href="'. get_permalink() . '">' . get_the_time('j ').'<span>' . get_the_time('M').'</span></a></span>';
						$output .= '<h4><a href="'.get_permalink().'">'. get_the_title() . '</a></h4>';
						$output .= get_the_content();
						$output .= '</div><!-- .rp-content -->';
						$output .= '</div>';
						$output .= '</li>';
			    }
			}
		}

		$query = null;

		// Restore original Post Data
		wp_reset_postdata();
		$output .= '</ul>';
		$output .= '</div></div>';
		echo $output; 
