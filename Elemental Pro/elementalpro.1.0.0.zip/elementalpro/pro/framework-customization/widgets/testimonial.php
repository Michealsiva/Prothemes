<?php

	$output = '';
	if(! empty( $instance['testimonial'] ) ) {
		$output .= '<div class="testimonial-container">';
		$output .= '<div id="ei-slider" class="testimonials ei-slider">';
		$output .= '<ul class="ei-slider-large">';
		foreach ( $instance['testimonial'] as $index => $item ) {
			
			$output .= '<li>';
			$output .='<div class="testimonial-content">';
			$output .= sprintf( '<div class="testimony">%1$s</div>', $item['client_testimonial'] );


			$output .= sprintf( '<p class="client"><strong>%1$s</strong>', $item['client_name'] );

			if( false === filter_var( $item['client_website'], FILTER_VALIDATE_URL ) ) {
				$output .= ! empty( $item['client_company'] ) ? ' ' . $item['client_company'] : '';
			} else {
				$output .= sprintf( '<a href="%1$s" target="_blank">%2$s</a>', $item['client_website'], $item['client_company'] );
			}
			$output .= '</p></div>';
			$client_image = wp_get_attachment_image_src($item['client_image'],'full');
			$output .= sprintf( '<div class="testimony-avatar">');
			if( $client_image ) {
				$output .= sprintf( '<img src="%1$s">', $client_image[0]);
			}
			$output .='</div>';
			$output .='</li>';
		}
		$output .= '</ul>';
		$output .='<ul class="ei-slider-thumbs">';
		$output .='<li class="ei-slider-element">'  . __ ('Current','genex_primal') .'</li>';
		$count = 1;
		foreach ( $instance['testimonial'] as $index => $item ) {
		//	if( has_post_thumbnail() ) {
				$output .= '<li><a href="#">Slide '. $count .'</a>';
				$client_image = wp_get_attachment_image_src($item['client_image']);
				if( $client_image ) {
					$output .= sprintf( '<img src="%1$s">', $client_image[0]);
				}
				$output .='</li>';
			$count++;
		//	}
		}
		$output .= '</ul>';
		$output .= '</div>';
		$output .= '</div>';
	}

            echo $output; 