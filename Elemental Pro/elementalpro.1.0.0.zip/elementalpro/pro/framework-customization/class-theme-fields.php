<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Elemental_Pro_Theme_fields' ) ) {  
	class Elemental_Pro_Theme_fields {
		
         /* Add Or Override the widegt fields */
        public function elemental_pro_extend_heading_form($form_options, $widget) {
		  $form_options['divider'] = array(
		  	'type' => 'checkbox',
	        'label' => __( 'Enable Heading Divider', 'elemental_pro' ),
	        'default' => true
		  );  
		  return $form_options;  

        }   

        public function elemental_pro_extend_teammember_form($form_options, $widget) {
		    // Lets add a new theme option
	        $form_options['ourteam_type'] = array(
                'type' => 'select',
				'label' => __('Select OurTeam Style Type', 'widget-form-fields-text-domain'),
				'options' => array(
					'normal' => __( 'Normal','genex' ),
					'style' => __( 'Style2','genex' ),
				)   
	        );

		    
		    return $form_options;

        } 

        public function elemental_pro_extend_tabs_form($form_options, $widget) {
		  // Lets add a new theme option
	        $form_options['tabs_type'] = array(
                'type' => 'checkbox',
				'label' => __('Select tabs Style2 Type', 'widget-form-fields-text-domain'),
				'options' => array(
					'style' => __( 'Style2','genex' ),
				)
                 
	        );
		    return $form_options;

        } 

     
	}
}

