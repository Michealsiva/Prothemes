<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Elemental_Pro_Theme_templates' ) ) {  
	class Elemental_Pro_Theme_templates {

        public function elemental_pro_call_to_action_template_file ( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/cta.php';  
        } 
 
        public function elemental_pro_teammember_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/teammember.php';  
        } 
        public function elemental_pro_stats_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/stats.php';  
        } 
        public function elemental_pro_skill_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/skill.php';  
        } 
        public function elemental_pro_testimonial_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/testimonial.php';  
        }
        public function elemental_pro_heading_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/heading.php';   
        }
        public function elemental_pro_iconbox_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/icon-box.php';   
        }
        public function elemental_pro_recentpost_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/recentpost.php';   
        }
        public function elemental_pro_tab_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/tabs.php';   
        }
        public function elemental_pro_price_table_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/price-table.php';   
        }
 
	}
}

         
