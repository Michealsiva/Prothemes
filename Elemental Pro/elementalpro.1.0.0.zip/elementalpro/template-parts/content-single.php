<?php
/**
 * @package ElementalPro
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

        <header class="entry-header">	
			<h1 class="entry-title"><?php the_title( '','' ); ?></h1>
			<?php if ( get_theme_mod('enable_single_post_top_meta',true ) ): ?>
				    <div class="entry-meta">
				    <?php if(function_exists('elemental_pro_entry_top_meta') ) {
				         elemental_pro_entry_top_meta();
				     } ?>
					</div><!-- .entry-meta -->
			<?php endif; ?>
	   </header><!-- .entry-header -->

	<div class="entry-content">
	 
		<?php
		$single_featured_image = get_theme_mod( 'single_featured_image',true );
		$single_featured_image_size = get_theme_mod ('single_featured_image_size',1);
		if (isset($single_featured_image_size) && $single_featured_image_size != 3  && $single_featured_image ) { ?>
		    <div class="post-thumb blog-thumb"><?php
			    if( has_post_thumbnail() && ! post_password_required() ) : 
			        if ( $single_featured_image_size == 1 ) : 
						the_post_thumbnail('elemental-blog-large-width'); 
				    else: 
						the_post_thumbnail('elemental-small-featured-image-width');		
					endif;
			    endif;?>
		    </div><?php
		} ?>

		<?php the_content(); 
		    wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'elemental_pro' ),
				'after'  => '</div>',
			) );
		?>
	
	</div><!-- .entry-content -->

<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
	<footer class="entry-meta">
	<?php if(function_exists('elemental_pro_entry_bottom_meta') ) {
		    elemental_pro_entry_bottom_meta();
		} ?>
	</footer><!-- .entry-footer -->
<?php endif;?>

</article><!-- #post-## -->

	<?php elemental_pro_post_nav(); ?>
