<?php
/**
 * Template Name: Blank Page
 */

global $webulous_options;
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php wp_title( '|', true, 'right' ); ?></title>

<?php if( isset( $webulous_options['ipad-icon-retina'] ) ) : ?>
	<!-- For third-generation iPad with high-resolution Retina display: -->
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo $webulous_options['ipad-icon-retina']['url']; ?>">
<?php endif; ?>

<?php if( isset( $webulous_options['iphone-icon-retina'] ) ) : ?>
	<!-- For iPhone with high-resolution Retina display: -->
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo $webulous_options['iphone-icon-retina']['url']; ?>"> 
<?php endif; ?>

<?php if( isset( $webulous_options['ipad-icon'] ) ) : ?>
	<!-- For first- and second-generation iPad: -->
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo $webulous_options['ipad-icon']['url']; ?>">
<?php endif; ?>

<?php if( isset( $webulous_options['iphone-icon'] ) ) : ?>
	<!-- For non-Retina iPhone, iPod Touch, and Android 2.1+ devices: -->
	<link rel="apple-touch-icon-precomposed" href="<?php echo $webulous_options['iphone-icon']['url']; ?>">
<?php endif; ?>

<?php if( isset( $webulous_options['favicon'] ) ) : ?>
	<link rel="icon" href="<?php echo $webulous_options['favicon']['url']; ?>">
<?php endif; ?>

	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php if( isset($webulous_options['analytics-place']) ) {
	if ( $webulous_options['analytics-place'] == 0 ){
		echo $webulous_options['google-analytics'];
	}
}
?>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>> 
	<div id="page" class="hfeed site">  

		<div id="content" class="site-content container">
			
			<div id="primary" class="content-area sixteen columns">
				
				<main id="main" class="site-main" role="main">
							
					<?php while ( have_posts() ) : the_post(); ?>

						<?php get_template_part( 'content', 'page' ); ?>

						<?php
							// If comments are open or we have at least one comment, load up the comment template
							if ( comments_open() || '0' != get_comments_number() ) :
								comments_template();
							endif;
						?>

					<?php endwhile; // end of the loop. ?>

				</main><!-- #main -->
			</div><!-- #primary -->

	    </div><!-- .row -->
	
    </div><!-- #page -->
	<?php if( isset($webulous_options['analytics-place']) && $webulous_options['analytics-place'] == 1 ){
		echo $webulous_options['google-analytics'];
	}
	?>
	<?php wp_footer(); ?>
</body>

</html>