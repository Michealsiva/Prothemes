<?php
/**
 * The template used for displaying page breadcrumb
 *
 * @package Webulous
 */
global $webulous_options;
?>
<?php if ( isset($webulous_options['breadcrumb']) && $webulous_options['breadcrumb'] && function_exists( 'webulous_breadcrumbs' ) ) : ?>	
    <div class="breadcrumb-wrap">
		<div class="container">
			<div class="sixteen columns">						
					<div id="breadcrumb" role="navigation">
						<?php webulous_breadcrumbs(); ?>
					</div>	
			</div>
		</div>
	</div>
<?php endif; ?>		