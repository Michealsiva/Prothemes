<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package Webulous
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<?php global $webulous_options;  
	
if( isset( $webulous_options['single_page_featured_image'] ) && $webulous_options['single_page_featured_image'] ) :
	$single_page_featured_image_size = $webulous_options['single_page_featured_image_size'] ;
    if ( $single_page_featured_image_size != 2 ) {
        if( has_post_thumbnail() && ! post_password_required() ) :   
		  the_post_thumbnail('blog-large');
	    endif;
	}
endif; 

if( isset( $webulous_options['page_titlebar_text'] ) && $webulous_options['page_titlebar_text'] ) : ?>
	<header class="entry-header">
		<h1 class="entry-title"><?php the_title(); ?></h1>
	</header><!-- .entry-header -->
<?php endif; ?>

	<div class="entry-content">
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'flatonpro' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->
	<?php edit_post_link( __( 'Edit', 'flatonpro' ), '<footer class="entry-meta"><span class="edit-link"><i class="el-icon-file-edit"></i> ', '</span></footer>' ); ?>
</article><!-- #post-## -->
