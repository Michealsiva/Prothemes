<?php
/**
 * @package Webulous
 */
global $webulous_options;
?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<div class="entry-content">
				<?php if( isset($webulous_options['featured-image'] ) && $webulous_options['featured-image'] ) : ?>
					<div class="thumb">
						<?php 
							if( has_post_thumbnail() && ! post_password_required() ) : 
								the_post_thumbnail('blog-large'); 
							else :
								echo '<img src="' . WEBULOUS_CHILD_URL . '/images/no-image-blog-large.png" />';
							endif;
						?>
					</div>
				<?php endif; ?>

				<div class="entry-body">
					<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1>
				<?php if ( $webulous_options['enable_single_post_top_meta'] ): ?>
					<footer class="entry-meta">
						<?php if(function_exists('webulous_entry_top_meta') ) {
						    webulous_entry_top_meta(); 
						} ?>  
				    </footer><!-- .entry-footer -->
				<?php endif;?> 
					<?php if( 'post' == get_post_type() ) : ?>
						<?php echo webulous_content_limit(50); ?>
					<?php else : ?>
						<?php the_content( ); ?>
					<?php endif; ?>
				</div>

				<?php
					wp_link_pages( array(
						'before' => '<div class="page-links">' . __( 'Pages:', 'flatonpro' ),
						'after'  => '</div>',
					) );
				?>
				<br class="clear" />
			</div><!-- .entry-content -->

			  <?php if ( $webulous_options['enable_single_post_bottom_meta'] ): ?>
					<footer class="entry-meta">
						<?php if(function_exists('webulous_entry_bottom_meta') ) {
						    webulous_entry_bottom_meta(); 
						} ?>  
				</footer><!-- .entry-footer -->
				<?php endif;?> 	
		</article><!-- #post-## -->