<?php
/**
 * @package Webulous
 */
global $webulous_options;
?>

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<div class="entry-content">
			<?php if( isset($webulous_options['featured-image'] ) && $webulous_options['featured-image'] ) : ?>
				<div class="thumb">
					<?php  
					if( has_post_thumbnail() && ! post_password_required() ) : 
						    if( $webulous_options['feature-image-size'] == '1' ) :
								the_post_thumbnail('blog-large'); 
							elseif( $webulous_options['feature-image-size'] == '2' ):
                                the_post_thumbnail('full'); 
                            elseif( $webulous_options['feature-image-size'] == '3' ):
                                the_post_thumbnail('large');
                            elseif( $webulous_options['feature-image-size'] == '4' ):
                                the_post_thumbnail('medium');
							endif;
					endif;
					?>     
				</div>
			<?php endif; ?>    
			<?php 
		    	if( has_post_format( 'gallery' ) ) { ?>			    	
			    	<div id="gallery-images">
				    	<ul class="slides"><?php
				    		$galleries = get_post_gallery_images( $post );
				    		 foreach ($galleries as $gallery) { ?>
						          <li><img src=<?php echo $gallery; ?>></li>
					    <?php } ?>
				    	</ul>
			    	</div><?php 
		    	}
			?>

			<div class="entry-body">
				<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1>
			<?php if ( $webulous_options['enable_single_post_top_meta'] ): ?>
				<footer class="entry-meta">
					<?php if(function_exists('webulous_entry_top_meta') ) {
					    webulous_entry_top_meta(); 
					} ?>  
			    </footer><!-- .entry-footer -->
			<?php endif;?> 
				<?php the_content( __( 'Read More', 'flatonpro' ) ); ?>  
			</div>

			<?php
				wp_link_pages( array(
					'before' => '<div class="page-links">' . __( 'Pages:', 'flatonpro' ),
					'after'  => '</div>',
				) );
			?>
			<br class="clear" />
		</div><!-- .entry-content -->
           <?php if ( $webulous_options['enable_single_post_bottom_meta'] ): ?>
				<footer class="entry-meta">
					<?php if(function_exists('webulous_entry_bottom_meta') ) {
					    webulous_entry_bottom_meta(); 
					} ?>  
			    </footer><!-- .entry-footer -->
			<?php endif;?>   		
	</article><!-- #post-## -->