jQuery(function($){
	if( $.fn.iconpicker ) {
	  $('.faip').iconpicker();
    }

     $('#page_template').change(function() {
        var template = ['portfolio-2col.php', 'portfolio-2col_sidebar.php', 'portfolio-2col_text.php','portfolio-3col.php','portfolio-3col_sidebar.php','portfolio-3col_text.php','portfolio-4col.php','portfolio-4col_text.php','portfolio.php','blog-fullwidth.php','blog-large.php','blog-small.php'];
    	var current_value = $(this).val();
    	if( $.inArray(current_value,template) != '-1' ) { 
           $('#category-options').show();
	   	}else{
	    	 $('#category-options').hide();
	    }
    }).change(); 


}); 