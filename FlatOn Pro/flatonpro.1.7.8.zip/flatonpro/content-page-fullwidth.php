<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package Webulous
 */
?>

		<?php the_content(); ?>
