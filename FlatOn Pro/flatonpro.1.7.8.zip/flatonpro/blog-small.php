<?php
/*
 * Template Name: Blog Small Image
 */
	global $webulous_options;
	get_header();
?>
	<?php get_template_part( 'breadcrumb' ); ?>
	
	<div id="content" class="site-content container">
	
	<?php do_action('webulous_two_sidebar_left'); ?>	

	<div id="primary" class="content-area eleven columns">
		<main id="main" class="site-main" role="main">
			
			<?php
			    $post_cat =  get_post_meta( $post->ID, 'portfolio_category');	
				if( $post_cat ) {
					foreach ($post_cat as $key => $value) {
			    	    $post_cats = "&cat=" . implode(", ", $value);
				    }
				}else{
					$post_cats = '';
				}
				$query_string ="post_type=post". $post_cats ."&paged=$paged";
				$query_string ="post_type=post&paged=$paged";
				query_posts($query_string);
				$num_of_posts = $wp_query->post_count;
			?>		
				
			<?php if ( have_posts() ) : ?>

				<?php /* Start the Loop */ ?>
				<?php while ( have_posts() ) : the_post(); ?>


				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

					<div class="entry-content">
						<div class="entry-body">
							<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1>
									<?php if ( $webulous_options['enable_single_post_top_meta'] ): ?>
											<footer class="entry-meta">
												<?php if(function_exists('webulous_entry_top_meta') ) {
												    webulous_entry_top_meta(); 
												} ?>  
										    </footer><!-- .entry-footer -->
										<?php endif;?> 
														<?php if( isset($webulous_options['featured-image'] ) && $webulous_options['featured-image'] ) : ?>
								<div class="thumb blog-thumb">
									<?php 
										if( has_post_thumbnail() && ! post_password_required() ) : 
											the_post_thumbnail(); 
										endif;
									?>
								</div>
							<?php endif; ?>
							<?php 
						    	if( has_post_format( 'gallery' ) ) { ?>			    	
							    	<div id="gallery-images">
								    	<ul class="slides"><?php
								    		$galleries = get_post_gallery_images( $post );
								    		 foreach ($galleries as $gallery) { ?>
										          <li><img src=<?php echo $gallery; ?>></li>
									    <?php } ?>
								    	</ul>
							    	</div><?php
						    	}
							?>
							<?php echo webulous_content_limit(); ?>
						</div>

						<?php
							wp_link_pages( array(
								'before' => '<div class="page-links">' . __( 'Pages:', 'flatonpro' ),
								'after'  => '</div>',
							) );
						?>
						<br class="clear" />
					</div><!-- .entry-content -->

					  <?php if ( $webulous_options['enable_single_post_bottom_meta'] ): ?>
					<footer class="entry-meta">
						<?php if(function_exists('webulous_entry_bottom_meta') ) {
						    webulous_entry_bottom_meta(); 
						} ?>  
				</footer><!-- .entry-footer -->
				<?php endif;?> 	
				</article><!-- #post-## -->
				<?php endwhile; ?>

				<?php 
					if( $webulous_options['pagenavi'] && function_exists( 'webulous_pagination' ) ) : 
						webulous_pagination();
					else :
						webulous_posts_nav();
					endif; 
				?>

			<?php else : ?>

				<?php get_template_part( 'content', 'none' ); ?>

			<?php endif; 
			wp_reset_query();?>

			</main><!-- #main -->
		</div><!-- #primary -->

	<?php do_action('webulous_two_sidebar_right'); ?>	

		<?php get_footer(); ?>