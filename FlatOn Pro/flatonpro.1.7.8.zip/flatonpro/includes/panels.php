<?php
/*  Integrates this theme with SiteOrigin Page Builder.

 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 *
 * @param $layouts
 */
if (!function_exists('webulous_prebuilt_page_layouts') ) {   
function webulous_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'flatonpro'),
    'description' => __('Pre Built Layout for  home page', 'flatonpro'),
    'widgets' =>  array(
    0 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Webulous_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'c0e9204c-09e5-4394-81ab-c2293c04ee54',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '<h1 class="tcenter widget-title">Services</h1>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '389d7fd0-aa52-45d9-b230-26eab3f5511a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => '',
      'text' => '[tabs_group type="center"][tabs title="Research"]
<div  class="fa fa-desktop"></div>
<h2>Research</h2>
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.[/tabs][tabs title="Usability"]<div  class="fa fa-heart"></div><h2>Usability</h2>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance.[/tabs][tabs title="Design"]<div  class="fa fa-meh-o"></div><h2>Design</h2>
It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).[/tabs][tabs title="Smart"]<div  class="fa fa-moon-o"></div><h2>Smart</h2>"But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. [/tabs][/tabs_group]',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '83586948-773f-4639-b37a-495a202a8094',
        'style' => 
        array (
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '<h1 class="widget-title tcenter">Meet The Team</h1>',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'a0112509-8ea7-4dd3-b081-5b3da82211dd',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'padding_bottom_gap' => '',
                'padding_top_gap' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
          1 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. Sed consequat, est in consectetur dapibus, turpis ligula vehicula sapien.',
            'image_url' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/Our-Team-One.png',
            'title' => 'Feugiat Curces',
            'designation' => 'Senior Manager',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Webulous_Ourteam_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'e00b1627-930d-46e3-9608-d7f5d1099ac1',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'padding_bottom_gap' => '',
                'padding_top_gap' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Sed lorem nibh, feugiat vel laoreet a, pharetra sit amet sem. Sed sagittis purus sit amet hendrerit gravida. Aliquam vitae velit justo. Cras convallis sollicitudin nunc.',
            'image_url' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/Our-Team-Two.png',
            'title' => 'Norman Ridus',
            'designation' => 'Art Director',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Webulous_Ourteam_Widget',
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '13694d9e-4311-495b-a8d9-2494368be450',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'padding_bottom_gap' => '',
                'padding_top_gap' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Donec sit amet placerat ipsum. Cras convallis sollicitudin nunc, quis convallis quam laoreet ac. Nam congue ex sit amet elit placerat, eget tincidunt velit hendrerit.',
            'image_url' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/Our-Team-Four.png',
            'title' => 'Kelly Clarkson',
            'designation' => 'Designer',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Webulous_Ourteam_Widget',
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '26676cf0-01ee-4281-9fe1-c4bf801677b8',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'padding_bottom_gap' => '',
                'padding_top_gap' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'content' => 'Aliquam vitae velit justo. Cras convallis sollicitudin nunc, quis convallis quam laoreet ac. Nam congue ex sit amet elit placerat, eget tincidunt velit hendrerit.',
            'image_url' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/Our-Team-Three.png',
            'title' => 'Teodor Borow',
            'designation' => 'Designer',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Webulous_Ourteam_Widget',
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => '24caf30b-8630-4c81-ba81-e7d1c43dfd34',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'padding_bottom_gap' => '',
                'padding_top_gap' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'animation_class' => '',
              'background_image' => '',
              'top_border' => '',
              'background' => '',
              'bottom_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'padding_top_gap' => '',
              'padding_bottom_gap' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '57d25e9b28a82',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '9d928fa5-aaf0-44e4-9100-8a86b62ad975',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Why Choose FlatOn',
      'text' => '<p>Aliquam malesuada tristique turpis vel vestibulum. Integer dolor eros, pretium ut ullamcorper ac, fringilla in leo. Sed sed nisi dictum, maximus eros ut, fringilla ipsum. Suspendisse fermentum nisl nibh, pulvinar efficitur sem semper sit amet. Donec venenatis erat felis, in eleifend urna congue ut. Ut quis luctus turpis, vel fermentum erat. Suspendisse dui felis, mattis ac egestas non, facilisis sed dolor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ultrices consectetur ligula, sit amet viverra felis finibus a. Mauris ut congue justo. Cras tincidunt, lacus a pulvinar scelerisque, velit libero consectetur risus, a egestas nisi urna eget turpis. Morbi sollicitudin dapibus dignissim. Donec sagittis libero orci, id auctor est lacinia ac. </p>
<p class="btn-more"><a href="#">Read More </a></p>',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '8758a877-2860-416e-b89d-ea82fab8a6dd',
        'style' => 
        array (
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Skills',
      'panels_info' => 
      array (
        'class' => 'Webulous_Skill_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 5,
        'widget_id' => '483848e2-daca-4f3b-9bb5-9f39516b131c',
        'style' => 
        array (
        ),
      ),
    ),
    6 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '<h3 class="widget-title tcenter">Top Features</h3>',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'c0a9dd69-3111-4dfe-bb39-a7f61ed0dc05',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'padding_bottom_gap' => '',
                'padding_top_gap' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/Features.png',
            'href' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/Features.png',
            'panels_info' => 
            array (
              'class' => 'Webulous_Image_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '47ac3def-3f30-4ae4-a555-8cf80f50c3dd',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'padding_bottom_gap' => '',
                'padding_top_gap' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Lorem Ipsum Dollor Sit Amet',
            'text' => 'Aliquam malesuada tristique turpis vel vestibulum. Integer dolor eros, pretium ut ullamcorper ac, fringilla in leo. Sed sed nisi dictum, maximus eros ut, fringilla ipsum. Suspendisse fermentum nisl nibh, pulvinar efficitur sem semper sit amet. Donec venenatis erat felis, in eleifend urna congue ut. Ut quis luctus turpis, vel fermentum erat. Suspendisse dui felis, mattis ac egestas non, facilisis sed dolor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ultrices consectetur ligula, sit amet viverra felis finibus a. Mauris ut congue justo. Cras tincidunt, lacus a pulvinar scelerisque, velit libero consectetur risus, a egestas nisi urna eget turpis.',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '5c5b71bb-5a18-476f-b436-30f0eee28834',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'padding_bottom_gap' => '',
                'padding_top_gap' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '57d263cc95aaf',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 6,
        'widget_id' => 'b91b2878-12a0-4ff7-a33b-d604588dc8ad',
        'style' => 
        array (
          'class' => 'section-pattern',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Suspendisse tempus',
      'text' => '[tabs_group type="normal"][tabs title="2012"]Pellentesque at vulputate nisi. Suspendisse eu consectetur justo, nec rhoncus erat. Nullam auctor nibh eget lectus pulvinar vulputate. Vivamus fermentum egestas lorem, eget accumsan neque lobortis sit amet. Nulla eu massa non mi rutrum semper at at libero. Etiam quis euismod massa, vitae volutpat felis. Aenean id nunc vel nibh fermentum lacinia finibus a magna. Donec pretium nunc eu velit iaculis, sodales cursus nunc laoreet.[/tabs][tabs title="2013"]Donec dapibus, metus eget dictum interdum, eros tellus maximus sapien, ac pretium magna lacus a justo. In dapibus consequat lacus ut congue. Quisque cursus enim sed condimentum faucibus. Vivamus gravida nibh ac justo tincidunt, vel posuere tellus tristique. Donec neque tellus, elementum ac ultrices vitae, tempor a tellus.[/tabs][tabs title="2014"]Ut in diam sapien. Duis ac felis quis ipsum sagittis luctus. Praesent est ex, mollis quis aliquam sit amet, egestas id velit. Praesent lobortis venenatis tincidunt. Fusce eget justo sapien. Phasellus sit amet rutrum nisi. Sed ullamcorper eu nunc sed auctor. Nam nisl tellus, cursus ac orci sed, molestie egestas orci.[/tabs][/tabs_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 7,
        'widget_id' => 'e7079e7e-b572-4387-9126-0d243d717380',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Words About Us',
      'text' => '[accordion_group][accordion title="Our Solutions"]Donec interdum sagittis quam id viverra. Cras interdum ligula efficitur enim scelerisque rhoncus. Quisque ullamcorper eget lacus consectetur dapibus. Mauris et hendrerit turpis. In auctor facilisis egestas. Vivamus et maximus nunc. Nunc blandit metus ac nulla varius, et porttitor orci egestas. [/accordion][accordion title="Our Missions"]Donec interdum sagittis quam id viverra. Cras interdum ligula efficitur enim scelerisque rhoncus. Quisque ullamcorper eget lacus consectetur dapibus. Mauris et hendrerit turpis. In auctor facilisis egestas. Vivamus et maximus nunc. Nunc blandit metus ac nulla varius, et porttitor orci egestas. [/accordion][accordion title="Our Visions"]Donec interdum sagittis quam id viverra. Cras interdum ligula efficitur enim scelerisque rhoncus. Quisque ullamcorper eget lacus consectetur dapibus. Mauris et hendrerit turpis. In auctor facilisis egestas. Vivamus et maximus nunc. Nunc blandit metus ac nulla varius, et porttitor orci egestas. [/accordion][/accordion_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 1,
        'id' => 8,
        'widget_id' => 'bc41e5e4-7c2a-4e5b-a9c4-500c7efd5bb5',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Recent Projects',
      'count' => '12',
      'type' => 'isotope',
      'panels_info' => 
      array (
        'class' => 'Webulous_Recent_Work_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '58a0f554-c092-4807-a489-0f9dfac26b06',
        'style' => 
        array (
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Testimonial Widget',
      'count' => '3',
      'panels_info' => 
      array (
        'class' => 'Webulous_Testimonial_Widget',
        'grid' => 8,
        'cell' => 0,
        'id' => 10,
        'widget_id' => '7c8dfeff-dc2f-4fef-abbd-b3ae7374539a',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Recent Work',
      'count' => '12',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Webulous_Recent_Work_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 11,
        'widget_id' => 'd1b2dff9-be30-45be-9788-bafe688ccc74',
        'style' => 
        array (
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '30px',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-divider',
        'bottom_margin' => '100px',
        'row_stretch' => 'full',
        'background' => '#f0f2f3',
        'background_display' => 'tile',
        'border_color' => '#e5e5e5',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    4 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-divider',
        'bottom_margin' => '100px',
        'row_stretch' => 'full',
        'background_display' => 'tile',
        'border_color' => '#f0f2f3',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    6 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-divider',
        'bottom_margin' => '0px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-layout',
        'bottom_margin' => '100px',
        'row_stretch' => 'full',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image' => 'http://demo.webulous.in/flaton/wp-content/uploads/sites/6/2015/01/Testi1.png',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    9 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 4,
      'weight' => 0.5,
    ),
    5 => 
    array (
      'grid' => 4,
      'weight' => 0.5,
    ),
    6 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 6,
      'weight' => 0.5,
    ),
    8 => 
    array (
      'grid' => 6,
      'weight' => 0.5,
    ),
    9 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    11 => 
    array (
      'grid' => 9,
      'weight' => 1,
    ),
     
    ),

  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'flatonpro'),
    'description' => __( 'Pre Built layout for about us page', 'flatonpro'),
    'widgets' => array(
           0 => 
    array (
      'height' => '30',
      'panels_info' => 
      array (
        'class' => 'Webulous_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'c1e9ee69-96be-4133-b173-79a07f88f3a5',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Our Skills',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed, lacinia in, mi. Cras vel lorem. Etiam pellentesque aliquet tellus. Phasellus pharetra nulla ac diam.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'd5c6c8b3-3faa-4f6f-b002-11a16dc8ea39',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Our Skills',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed, lacinia in, mi. Cras vel lorem. Etiam pellentesque aliquet tellus. Phasellus pharetra nulla ac diam.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'widget_id' => 'e40f294c-f631-4465-b189-5a1de23dd5c1',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Our Skills',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed, lacinia in, mi. Cras vel lorem. Etiam pellentesque aliquet tellus. Phasellus pharetra nulla ac diam.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'widget_id' => '1a4b12b1-1566-4357-87f7-99d0ca1252af',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'type' => 'square',
      'title' => '7766',
      'text' => 'Lorem Ipsum',
      'icon' => 'fa-desktop',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => 'bbcf605c-928d-483b-98d1-c4586f43a7aa',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => '4392',
      'text' => 'Lorem Ipsum',
      'icon' => 'fa-clock-o',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 5,
        'widget_id' => '2f08e4d1-d3f4-4241-b167-6e445264a0d9',
        'style' => 
        array (
        ),
      ),
    ),
    6 => 
    array (
      'title' => '1098',
      'text' => 'Lorem Ipsum',
      'icon' => 'fa-coffee',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 6,
        'widget_id' => '098ac425-2ae6-4a05-a6a7-0210a50e60d9',
        'style' => 
        array (
        ),
      ),
    ),
    7 => 
    array (
      'type' => 'square',
      'title' => '1200',
      'text' => 'Lorem Ipsum',
      'icon' => 'fa-lightbulb-o',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 3,
        'id' => 7,
        'widget_id' => '87b69cd6-05ba-4793-936c-b2be4627cc7f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'height' => '60',
      'panels_info' => 
      array (
        'class' => 'Webulous_Gap_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'c1e9ee69-96be-4133-b173-79a07f88f3a5',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Clients Say',
      'count' => '3',
      'panels_info' => 
      array (
        'class' => 'Webulous_Testimonial_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '7b0bc97a-4233-4f2c-952c-2d748a8e6239',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'height' => '60',
      'panels_info' => 
      array (
        'class' => 'Webulous_Gap_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 10,
        'widget_id' => 'c1e9ee69-96be-4133-b173-79a07f88f3a5',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. Sed consequat, est in consectetur dapibus, turpis ligula vehicula sapien, sit amet dapibus lorem risus rhoncus neque.',
      'image_url' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/four.png',
      'title' => 'Feugiat Curces',
      'designation' => 'Senior Manager',
      'linkedin' => 'https://in.linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'https://twitter.com/',
      'facebook' => 'www.facebook.com/‎',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'widget_id' => 'df15e43c-9d2a-4e21-8deb-6a695a7eced0',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'content' => 'Sed lorem nibh, feugiat vel laoreet a, pharetra sit amet sem. Sed sagittis purus sit amet hendrerit gravida. Aliquam vitae velit justo. Cras convallis sollicitudin nunc, quis convallis quam laoreet ac. Donec interdum sagittis quam id viverra. ',
      'image_url' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/Three-1.png',
      'title' => 'Aaleyah',
      'designation' => 'Art Director',
      'linkedin' => 'https://in.linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'https://twitter.com/',
      'facebook' => 'www.facebook.com/‎',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 1,
        'id' => 12,
        'widget_id' => 'd53a4f8e-5efd-42d6-b1f5-1f7f6e6620f0',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'content' => 'Donec sit amet placerat ipsum. Cras convallis sollicitudin nunc, quis convallis quam laoreet ac. Nam congue ex sit amet elit placerat, eget tincidunt velit hendrerit. Pellentesque ante orci, congue sit amet urna vel',
      'image_url' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/one.png',
      'title' => 'Christon Bale',
      'designation' => 'Designer',
      'linkedin' => 'https://in.linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'https://twitter.com/',
      'facebook' => 'www.facebook.com/‎',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 2,
        'id' => 13,
        'widget_id' => '198d3161-ab71-4f23-b4bc-de625444c491',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'content' => 'Aliquam vitae velit justo. Cras convallis sollicitudin nunc, quis convallis quam laoreet ac. Nam congue ex sit amet elit placerat, eget tincidunt velit hendrerit. Pellentesque ante orci, congue sit amet urna vel.',
      'image_url' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/Two.png',
      'title' => 'Kelly Clarkson',
      'designation' => 'Code Ninja',
      'linkedin' => 'https://in.linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'https://twitter.com/',
      'facebook' => 'www.facebook.com/‎',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 3,
        'id' => 14,
        'widget_id' => '1d52cf89-4f3e-442f-b562-028b6ddd04d7',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'height' => '40',
      'panels_info' => 
      array (
        'class' => 'Webulous_Gap_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 15,
        'widget_id' => 'c1e9ee69-96be-4133-b173-79a07f88f3a5',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'slider' => '9',
      'panels_info' => 
      array (
        'class' => 'Webulous_FlexSlider_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 16,
        'widget_id' => 'e22b07a1-6411-4f4e-ae3a-e10cc41a13d0',
        'style' => 
        array (
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '50px',
        'padding_bottom_gap' => '30px',
      ),
    ),
    2 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'row_stretch' => 'full',
        'background_image_attachment' => false,
        'background_display' => 'cover',
        'background_image' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/Faq-Background.png',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '40px',
        'padding_bottom_gap' => '30px',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'row_stretch' => 'full',
        'background_display' => 'tile',
        'background_image' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/bg-testimonial.png',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '30px',
        'padding_bottom_gap' => '30px',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    6 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    7 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    8 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    11 => 
    array (
      'grid' => 6,
      'weight' => 0.25,
    ),
    12 => 
    array (
      'grid' => 6,
      'weight' => 0.25,
    ),
    13 => 
    array (
      'grid' => 6,
      'weight' => 0.25,
    ),
    14 => 
    array (
      'grid' => 6,
      'weight' => 0.25,
    ),
    15 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    16 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ), 
    ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'flatonpro'),
      'description' => __( 'Pre Built layout for features page', 'flatonpro'),
      'widgets' => array(
         0 => 
    array (
      'height' => '80',
      'panels_info' => 
      array (
        'class' => 'Webulous_Gap_Widget',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '6dbd4b94-6eba-4cd4-ab6b-e07d7790a54a',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Responsive Layout',
      'text' => 'FlatOn is fully responsive and can adapt to any screen size. Resize your browser window to view it!',
      'icon' => 'fa-desktop',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.com',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '141b7f75-1a90-4361-a3c3-f972538a0db1',
        'style' => 
        array (
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Awesome Sliders',
      'text' => 'FlatOn includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
      'icon' => 'fa-random',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.com',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'widget_id' => 'fceef207-0dac-4e3d-ad22-61301793fef4',
        'style' => 
        array (
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Font Awesome',
      'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
      'icon' => 'fa-flag',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.com',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'widget_id' => '006a4134-bfd0-47cf-a8a0-b3314c8b6cfc',
        'style' => 
        array (
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Typography',
      'text' => 'FlatOn loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
      'icon' => 'fa-font',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.com',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 3,
        'id' => 4,
        'widget_id' => '8b997f0c-890f-4e23-8b18-f8a75e34fec2',
        'style' => 
        array (
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Retina Ready',
      'text' => 'FlatOn is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 5,
        'widget_id' => 'a687d7d9-5e10-4aad-a8bb-695e7fd43a62',
        'style' => 
        array (
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Excellent Support',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
      'icon' => 'fa-thumb-tack',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 6,
        'widget_id' => '48882e9c-743b-4f8f-99b7-a8b973023955',
        'style' => 
        array (
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Advanced Admin',
      'text' => 'FlatOn uses advanced Redux Framework for theme options panel, you can customize any part of your site quickly and easily!',
      'icon' => 'fa-cog',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 7,
        'widget_id' => 'f133e399-81d4-4bf0-8b8c-c0acdbcfdd19',
        'style' => 
        array (
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Page Builder',
      'text' => 'FlatOn supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
      'icon' => 'fa-plus',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 3,
        'id' => 8,
        'widget_id' => 'c02f2222-9888-400f-a0ba-f456dc4d25f3',
        'style' => 
        array (
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Page Layout',
      'text' => 'FlatOn offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy (alias)',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 9,
        'widget_id' => 'c1e16828-7241-4694-8720-be9239d37a69',
        'style' => 
        array (
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Custom Widget',
      'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
      'icon' => 'fa-beer',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 10,
        'widget_id' => '27da30ff-2788-43d3-9225-c677cfaca5a1',
        'style' => 
        array (
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Shortcode Builder',
      'text' => 'FlatOn inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
      'icon' => 'fa-check',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 11,
        'widget_id' => '1b0e857a-6349-4659-9276-697ae8566bbd',
        'style' => 
        array (
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Demo Content',
      'text' => 'FlatOn includes demo content files. You can quickly setup the site like our demo and get started easily!',
      'icon' => 'fa-times',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 3,
        'id' => 12,
        'widget_id' => '78bced85-4391-4c29-a82e-0b4b811fb59d',
        'style' => 
        array (
        ),
      ),
    ),
    13 => 
    array (
      'title' => 'Woo Commerce',
      'text' => 'FlatOn has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!',
      'icon' => 'fa-shopping-cart',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 13,
        'widget_id' => '89143fc7-f04e-4737-948e-38b9f1601ba9',
        'style' => 
        array (
        ),
      ),
    ),
    14 => 
    array (
      'title' => 'Testimonials',
      'text' => 'With our testimonial post type, shortcode and widget, Displaying testimonials is a breeze.',
      'icon' => 'fa-rocket',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 14,
        'widget_id' => '0a94785f-9da5-410b-b77a-042bbcca2115',
        'style' => 
        array (
        ),
      ),
    ),
    15 => 
    array (
      'title' => 'Social Media',
      'text' => 'Want your users to stay in touch? No problem, Flaton has Social Media icons all throughout the theme!',
      'icon' => 'fa-skype',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 15,
        'widget_id' => 'f361b770-5a6a-4678-9657-e0ffce4e877d',
        'style' => 
        array (
        ),
      ),
    ),
    16 => 
    array (
      'title' => 'Google Map',
      'text' => 'Flaton includes Goole Map as shortcode and widget. So, you can use it anywhere in your site!',
      'icon' => 'fa-map-marker',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 3,
        'id' => 16,
        'widget_id' => 'fec74910-ebaf-41ea-ac54-02b87235bbec',
        'style' => 
        array (
        ),
      ),
    ),
    17 => 
    array (
      'title' => 'Multiple Portfolio',
      'text' => '7 portfolio layouts, 3 blog layouts and multiple other alternate layouts for interior pages!',
      'icon' => 'fa-list-alt',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 17,
        'widget_id' => '3a51f84e-aef5-4498-854d-82353ef171d9',
        'style' => 
        array (
        ),
      ),
    ),
    18 => 
    array (
      'title' => 'Multiple Sidebar',
      'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
      'icon' => 'fa-columns',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 18,
        'widget_id' => '2b5aabef-8951-4a5a-ab0b-3db2573eb124',
        'style' => 
        array (
        ),
      ),
    ),
    19 => 
    array (
      'title' => 'Customization',
      'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
      'icon' => 'fa-edit (alias)',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 2,
        'id' => 19,
        'widget_id' => '0689d773-2e5b-49e8-96dc-d4b6547d9ac6',
        'style' => 
        array (
        ),
      ),
    ),
    20 => 
    array (
      'title' => 'Improvement',
      'text' => 'We love our theme and customers. We are committed to improve and add new features to FlatOn!',
      'icon' => 'fa-signal',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 3,
        'id' => 20,
        'widget_id' => '98aebd1f-85ad-4748-90d1-61245a3bdbf3',
        'style' => 
        array (
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    2 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    4 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    5 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.24901960784314001,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 0.25098039215686002,
    ),
    7 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    8 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    9 => 
    array (
      'grid' => 3,
      'weight' => 0.25,
    ),
    10 => 
    array (
      'grid' => 3,
      'weight' => 0.25,
    ),
    11 => 
    array (
      'grid' => 3,
      'weight' => 0.25,
    ),
    12 => 
    array (
      'grid' => 3,
      'weight' => 0.25,
    ),
    13 => 
    array (
      'grid' => 4,
      'weight' => 0.25,
    ),
    14 => 
    array (
      'grid' => 4,
      'weight' => 0.25,
    ),
    15 => 
    array (
      'grid' => 4,
      'weight' => 0.25,
    ),
    16 => 
    array (
      'grid' => 4,
      'weight' => 0.25,
    ),
    17 => 
    array (
      'grid' => 5,
      'weight' => 0.25,
    ),
    18 => 
    array (
      'grid' => 5,
      'weight' => 0.25,
    ),
    19 => 
    array (
      'grid' => 5,
      'weight' => 0.25,
    ),
    20 => 
    array (
      'grid' => 5,
      'weight' => 0.25,
    ),
      ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'flatonpro'),
      'description' => __( 'Pre Built layout for contact us page', 'flatonpro'),
      'widgets' => array(
         0 => 
    array (
      'title' => 'CONTACT US',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '0e68f389-a9cb-4eb8-80dc-6df5059a796f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Lets get in touch',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '0e68f389-a9cb-4eb8-80dc-6df5059a796f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => '',
      'text' => '[contact-form-7 id="4" title="Contact form 1"]',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'fbcffa16-8b8e-40a7-b59e-32241f05ae4a',
        'style' => 
        array (
        ),
      ),
    ),
    3 => 
    array (
      'title' => '',
      'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d6305.992774595653!2d-122.41157430890459!3d37.790124433800656!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858091edff45bd%3A0x70c4586b1202a605!2sUSA+Hostels+San+Francisco!5e0!3m2!1sen!2sin!4v1407318894507" width="1200" height="300" frameborder="0" style="border:0"></iframe>',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '7c540ec2-39b7-48e1-a121-35344001ced9',
        'style' => 
        array (
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
       ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'flatonpro'),
    'description' => __('Pre Built Layout for default faq page', 'flatonpro'),
    'widgets' =>  array(
      0 => 
    array (
      'type' => 'polygon',
      'title' => 'Shopping',
      'text' => '',
      'icon' => 'fa-shopping-cart',
      'icon_background_color' => '000000',
      'icon_size' => '5x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'b91e013d-a3af-4c30-97c1-f4199f2fe32a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'type' => 'polygon',
      'title' => 'Shipping',
      'text' => '',
      'icon' => 'fa-phone',
      'icon_background_color' => '000000',
      'icon_size' => '5x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => '716575df-22a0-46e5-adbf-ceeeafa987de',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'type' => 'polygon',
      'title' => 'Gift Wrapping ',
      'text' => '',
      'icon' => 'fa-gift',
      'icon_background_color' => '000000',
      'icon_size' => '5x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 2,
        'widget_id' => '0113e299-0ba5-47b5-8470-bd8320ff7e41',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'level' => '2',
      'type' => 'normal',
      'content' => 'Order',
      'panels_info' => 
      array (
        'class' => 'Webulous_Heading_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '8343d6f4-dc49-4c81-97fb-6b40201eae4c',
        'style' => 
        array (
        ),
      ),
    ),
    4 => 
    array (
      'title' => '',
      'text' => '[toggle title="Lorem ipsum dolor sit amet, consectetur adipiscing elit ?" open="0" type="polygon"]Vivamus eleifend elit sed nunc pretium placerat vitae ullamcorper dui. Quisque ac ante vel mi ullamcorper lacinia. Duis et elementum orci, at dignissim ipsum. Nulla suscipit semper ex vitae consequat. Interdum et malesuada fames ac ante ipsum primis in faucibus. Praesent nec tellus nec tellus rutrum sodales. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Fusce vel neque a purus accumsan lobortis. In et ultrices tellus. Curabitur molestie consectetur leo vulputate pulvinar. Quisque pellentesque ligula sapien, a mollis sem posuere ac. [/toggle]

[toggle title="Nullam eget elit rhoncus velit sollicitudin gravida ?" open="0" type="polygon"] Phasellus tempor, dui et lobortis posuere, ante velit consequat eros, quis laoreet dolor tortor nec sem. Nam ut lorem dictum, cursus nibh vitae, tristique sapien. Praesent quis sodales metus. Integer ultrices nibh sed nisl cursus scelerisque tempor sed neque. Duis nec imperdiet eros, quis lacinia magna.[/toggle]

[toggle title="Aenean et eros porta, aliquam nisi vitae, facilisis nulla ?" open="0" type="polygon"]Duis tempus nisi vehicula quam tincidunt, in iaculis est faucibus. Pellentesque varius arcu sit amet faucibus vehicula. Curabitur vel fermentum eros. Mauris viverra porta turpis non blandit. Ut nec sagittis metus. Morbi commodo tortor id malesuada hendrerit. Etiam pretium nec tortor nec lobortis. Nam consectetur aliquam ligula ut efficitur. Sed efficitur scelerisque tempor. [/toggle]

[toggle title="In dictum libero odio, ut consectetur urna condimentum vel ?" open="0" type="polygon"]Sed venenatis laoreet metus, in convallis ipsum auctor nec. Nullam sagittis iaculis gravida. Proin nec venenatis odio, dapibus bibendum nibh. In hac habitasse platea dictumst. Donec non vulputate diam. Etiam at ligula augue. Nunc cursus, risus vel facilisis dignissim, sapien lectus commodo enim, vitae imperdiet magna lorem sit amet odio[/toggle]

[toggle title="Pellentesque habitant morbi tristique senectus et netus ?" open="0" type="polygon"]Nam nec pharetra tortor. In hac habitasse platea dictumst. Sed ex diam, maximus vel nisi a, venenatis fermentum felis. Maecenas facilisis iaculis venenatis. Nullam at erat non turpis rutrum rhoncus ut sit amet lacus. Praesent ut ipsum sit amet turpis rhoncus scelerisque. Nulla vel posuere metus.[/toggle]
',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 4,
        'widget_id' => '5ac7f980-8de1-4a33-9abd-df776d586481',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'level' => '2',
      'type' => 'normal',
      'content' => 'Payment & Shipping',
      'panels_info' => 
      array (
        'class' => 'Webulous_Heading_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 5,
        'widget_id' => 'e3acebfa-437f-44be-99dc-286e6b0870dc',
        'style' => 
        array (
        ),
      ),
    ),
    6 => 
    array (
      'title' => '',
      'text' => '[toggle title="Lorem ipsum dolor sit amet, consectetur adipiscing elit ?" open="0" type="polygon"]Vivamus eleifend elit sed nunc pretium placerat vitae ullamcorper dui. Quisque ac ante vel mi ullamcorper lacinia. Duis et elementum orci, at dignissim ipsum. Nulla suscipit semper ex vitae consequat. Interdum et malesuada fames ac ante ipsum primis in faucibus. Praesent nec tellus nec tellus rutrum sodales. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Fusce vel neque a purus accumsan lobortis. In et ultrices tellus. Curabitur molestie consectetur leo vulputate pulvinar. Quisque pellentesque ligula sapien, a mollis sem posuere ac. [/toggle]

[toggle title="Nullam eget elit rhoncus velit sollicitudin gravida ?" open="0" type="polygon"] Phasellus tempor, dui et lobortis posuere, ante velit consequat eros, quis laoreet dolor tortor nec sem. Nam ut lorem dictum, cursus nibh vitae, tristique sapien. Praesent quis sodales metus. Integer ultrices nibh sed nisl cursus scelerisque tempor sed neque. Duis nec imperdiet eros, quis lacinia magna.[/toggle]

[toggle title="Aenean et eros porta, aliquam nisi vitae, facilisis nulla ?" open="0" type="polygon"]Duis tempus nisi vehicula quam tincidunt, in iaculis est faucibus. Pellentesque varius arcu sit amet faucibus vehicula. Curabitur vel fermentum eros. Mauris viverra porta turpis non blandit. Ut nec sagittis metus. Morbi commodo tortor id malesuada hendrerit. Etiam pretium nec tortor nec lobortis. Nam consectetur aliquam ligula ut efficitur. Sed efficitur scelerisque tempor. [/toggle]

[toggle title="In dictum libero odio, ut consectetur urna condimentum vel ?" open="0" type="polygon"]Sed venenatis laoreet metus, in convallis ipsum auctor nec. Nullam sagittis iaculis gravida. Proin nec venenatis odio, dapibus bibendum nibh. In hac habitasse platea dictumst. Donec non vulputate diam. Etiam at ligula augue. Nunc cursus, risus vel facilisis dignissim, sapien lectus commodo enim, vitae imperdiet magna lorem sit amet odio[/toggle]

[toggle title="Pellentesque habitant morbi tristique senectus et netus ?" open="0" type="polygon"]Nam nec pharetra tortor. In hac habitasse platea dictumst. Sed ex diam, maximus vel nisi a, venenatis fermentum felis. Maecenas facilisis iaculis venenatis. Nullam at erat non turpis rutrum rhoncus ut sit amet lacus. Praesent ut ipsum sit amet turpis rhoncus scelerisque. Nulla vel posuere metus.[/toggle]
',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 6,
        'widget_id' => '87c29f4d-aa62-4a4e-9a16-a34999d49591',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => '',
      'text' => '<h5 class="widget-title tcenter">Have any questions we didn\'t answer?       
[button link="http://www.webulousthemes.com" target="_self" color="btn-inverse" size="btn-Large"]Get in Touch[/button]</h5>
[gap height="10"]

',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'widget_id' => 'cc04269a-de59-4e6e-9e19-886f953d1733',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'row_stretch' => 'full',
        'background_image_attachment' => 2378,
        'background_display' => 'cover',
        'background_image' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/Faq-Background.png',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '50px',
        'padding_bottom_gap' => '50px',
      ),
    ),
    1 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '50px',
      ),
    ),
    2 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-layout',
        'padding' => '0px 219px 0px 219px',
        'row_stretch' => 'full',
        'background_display' => 'tile',
        'background_image' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/Uniq-Get-in-Touch.png',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '40px',
        'padding_bottom_gap' => '40px',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.15436241610738,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.84563758389262,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.15436241610738,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 0.84563758389262,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'flatonpro'),
    'description' => __('Pre Built Layout for services page', 'flatonpro'),
    'widgets' =>  array(
         0 => 
    array (
      'height' => '40',
      'panels_info' => 
      array (
        'class' => 'Webulous_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '39f280a2-aef9-4c76-9c82-b6f7b37c5fd4',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '<h3 class="widget-title tcenter">Our Working Process</h3>
It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '880bd07a-8717-471b-9a0a-32e71edeaa95',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'style' => 'default',
      'panels_info' => 
      array (
        'class' => 'Webulous_Divider_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '94ad4230-108e-4c04-8850-e67d4911cb78',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'type' => 'square',
      'title' => 'Diamond Perfect Design',
      'text' => 'Ut elit tellus, luctus nec ullamcorper mattis.',
      'icon' => 'fa-heart',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '950bd96e-f64e-4f1f-b801-e9ca8d318795',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'type' => 'square',
      'title' => 'Responsive Design',
      'text' => 'Ut elit tellus, luctus nec ullamcorper mattis.',
      'icon' => 'fa-desktop',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 4,
        'widget_id' => '0749a49b-0875-42d5-a5d1-80505ecb3fe2',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'type' => 'square',
      'title' => 'Online Shopping',
      'text' => 'Ut elit tellus, luctus nec ullamcorper mattis.',
      'icon' => 'fa-shopping-cart',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 5,
        'widget_id' => '95959bdf-7b8a-4739-b2a9-91cbbbb0b8e5',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Quality Products',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod mpor incididunt ut labore et dolore magna aliqua. Ut enim.
Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium que laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam oluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni olores eos qui ratione voluptatem sequi nesciunt.

[button link="http://www.google.co.in" target="_self" color="btn-danger" size="btn-large"]Browse Products[/button]



',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '73108bb3-022e-4e37-8209-9c6bd32a82af',
        'style' => 
        array (
        ),
      ),
    ),
    7 => 
    array (
      'src' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/1.png',
      'href' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/1.png',
      'panels_info' => 
      array (
        'class' => 'Webulous_Image_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 7,
        'widget_id' => '99928797-437e-493b-893a-b798a051f98a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'src' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/2.png',
      'href' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/2.png',
      'panels_info' => 
      array (
        'class' => 'Webulous_Image_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 8,
        'widget_id' => '4a4b2687-945c-4105-aef2-638d64544e60',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'src' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/3.png',
      'href' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/3.png',
      'panels_info' => 
      array (
        'class' => 'Webulous_Image_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 9,
        'widget_id' => 'a3a6303c-f202-4a96-8258-3333047659bc',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'src' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/4-1.png',
      'href' => 'http://flaton.webulous.in/wp-content/uploads/2016/09/4-1.png',
      'panels_info' => 
      array (
        'class' => 'Webulous_Image_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 10,
        'widget_id' => '71c69fe8-f0cc-44a7-8241-88a435e2c90f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Some fields of expertise',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.

It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 11,
        'widget_id' => '73108bb3-022e-4e37-8209-9c6bd32a82af',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Skills',
      'panels_info' => 
      array (
        'class' => 'Webulous_Skill_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 12,
        'widget_id' => '9d99ae16-cea5-4c16-a6cc-d669d4fd5edf',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '50px',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'bottom_margin' => '100px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    4 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'class' => 'section-divider',
        'bottom_margin' => '100px',
        'row_stretch' => 'full',
        'background' => '#f0f2f3',
        'background_image_attachment' => false,
        'background_display' => 'cover',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    5 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    6 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    7 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    9 => 
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    10 => 
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'webulous_prebuilt_page_layouts');
/**
 * Configure the SiteOrigin page builder settings.
 * 
 * @param $settings
 * @return mixed
 */
function webulous_panels_settings($settings){
	$settings['home-page'] = true;
	$settings['margin-bottom'] = 35;
	$settings['home-page-default'] = 'default-home';
	$settings['responsive'] = 1; //siteorigin_setting( 'layout_responsive' );
	return $settings;
}
add_filter('siteorigin_panels_settings', 'webulous_panels_settings');

/**
 * Add row styles.
 *
 * @param $styles
 * @return mixed
 */
function webulous_panels_row_styles($styles) {
	$styles['full-width-layout'] = __('Full Width Layout', 'flatonpro');
	$styles['wide-grey'] = __('Wide Grey', 'flatonpro');
	$styles['custom-width'] = __('Custom Width', 'flatonpro');
	$styles['section-divider'] = __('Section Divider', 'flatonpro');
	return $styles;
}
add_filter('siteorigin_panels_row_styles', 'webulous_panels_row_styles');

function webulous_panels_row_style_fields($fields) {

	$fields['top_border'] = array(
		'name' => __('Top Border Color', 'flatonpro'),
		'type' => 'color',
	);

	$fields['bottom_border'] = array(
		'name' => __('Bottom Border Color', 'flatonpro'),
		'type' => 'color',
	);

	$fields['background'] = array(
		'name' => __('Background Color', 'flatonpro'),
		'type' => 'color',
	);

	$fields['background_image'] = array(
		'name' => __('Background Image', 'flatonpro'),
		'type' => 'url',
	);

	$fields['background_image_repeat'] = array(
		'name' => __('Repeat Background Image', 'flatonpro'),
		'type' => 'checkbox',
	);

	$fields['no_margin'] = array(
		'name' => __('No Bottom Margin', 'flatonpro'),
		'type' => 'checkbox',
	);

	return $fields;
}
add_filter('siteorigin_panels_row_style_fields', 'webulous_panels_row_style_fields');

function webulous_panels_panels_row_style_attributes($attr, $style) {
	$attr['style'] = '';

	if(!empty($style['top_border'])) $attr['style'] .= 'border-top: 1px solid '.$style['top_border'].'; ';
	if(!empty($style['bottom_border'])) $attr['style'] .= 'border-bottom: 1px solid '.$style['bottom_border'].'; ';
	if(!empty($style['background'])) $attr['style'] .= 'background-color: '.$style['background'].'; ';
	if(!empty($style['background_image'])) $attr['style'] .= 'background-image: url('.esc_url($style['background_image']).'); ';
	if(!empty($style['background_image_repeat'])) $attr['style'] .= 'background-repeat: repeat; ';

	if(empty($attr['style'])) unset($attr['style']);
	return $attr;
}
add_filter('siteorigin_panels_row_style_attributes', 'webulous_panels_panels_row_style_attributes', 10, 2);

function webulous_panels_panels_row_attributes($attr, $row) {
	if(!empty($row['style']['no_margin'])) {
		if(empty($attr['style'])) $attr['style'] = '';
		$attr['style'] .= 'margin-bottom: 0px;';
	}

	return $attr;   
}
add_filter('siteorigin_panels_row_attributes', 'webulous_panels_panels_row_attributes', 10, 2);

/* Animation row panel */

function wbls_abaris_panels_row_style_fields($fields) {  

    $abaris_animation_name = array(
        '' => __(' --- Default --- ', 'flatonpro'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','flatonpro' ),
        'bigEntrance-animation' => __('bigEntrance-animation','flatonpro' ),
        'boingInUp-animation' => __('boingInUp-animation','flatonpro' ),
        'bounce-animation' => __('bounce-animation','flatonpro' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','flatonpro' ),
        'bounceInRight-animation' => __('bounceInRight-animation','flatonpro' ),
        'bounceInUp-animation' => __('bounceInUp-animation','flatonpro' ),
        'expandUp-animation' => __('expandUp-animation','flatonpro' ),
        'fade-animation' => __('fade-animation','flatonpro' ),
        'fadeIn-animation' => __('fadeIn-animation','flatonpro' ),
        'fadeInDown-animation' => __('fadeInDown-animation','flatonpro' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','flatonpro' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','flatonpro' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','flatonpro' ),
        'fadeInRight-animation' => __('fadeInRight-animation','flatonpro' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','flatonpro' ),
        'fadeInUp-animation' => __('fadeInUp-animation','flatonpro' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','flatonpro' ),
        'flip-animation' => __('flip-animation','flatonpro' ),
        'flipInX-animation' => __('flipInX-animation','flatonpro' ),
        'flipInY-animation' => __('flipInY-animation','flatonpro' ),
        'floating-animation' => __('floating-animation','flatonpro' ),
        'foolishIn-animation' => __('foolishIn-animation','flatonpro' ),
        'hatch-animation' => __('hatch-animation','flatonpro' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','flatonpro' ),
        'puffIn-animation' => __('puffIn-animation','flatonpro' ),
        'pullDown-animation' => __('pullDown-animation','flatonpro' ),
        'pullUp-animation' => __('pullUp-animation','flatonpro' ),
        'pulse-animation' => __('pulse-animation','flatonpro' ),
        'rollInLeft-animation' => __('rollInLeft-animation','flatonpro' ),
        'rollInRight-animation' => __('rollInRight-animation','flatonpro' ),
        'rotateIn-animation' => __('rotateIn-animation','flatonpro' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','flatonpro' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','flatonpro' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','flatonpro' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','flatonpro' ),
        'scale-down-animation' => __('scale-down-animation','flatonpro' ),
        'scale-up-animation' => __('scale-up-animation','flatonpro' ),
        'slide-bottom-animation' => __('slide-bottom-animation','flatonpro' ),
        'slide-left-animation' => __('slide-left-animation','flatonpro' ),
        'slide-right-animation' => __('slide-right-animation','flatonpro' ),
        'slide-top-animation' => __('slide-top-animation','flatonpro' ),
        'slideDown-animation' => __('slideDown-animation','flatonpro' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','flatonpro' ),
        'slideInDown-animation' => __('slideInDown-animation','flatonpro' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','flatonpro' ),
        'slideInRight-animation' => __('slideInRight-animation','flatonpro' ),
        'slideLeft-animation' => __('slideLeft-animation','flatonpro' ),
        'slideRight-animation' => __('slideRight-animation','flatonpro' ),
        'slideUp-animation' => __('slideUp-animation','flatonpro' ),
        'spaceInDown-animation' => __('spaceInDown-animation','flatonpro' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','flatonpro' ),
        'spaceInRight-animation' => __('spaceInRight-animation','flatonpro' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','flatonpro' ),
        'stretchLeft-animation' => __('stretchLeft-animation','flatonpro' ), 
        'stretchRight-animation'  => __('stretchRight-animation','flatonpro' ),
        'swap-animation'  => __('swap-animation','flatonpro' ),
        'swashIn-animation'  => __('swashIn-animation','flatonpro' ),
        'swing-animation'  => __('swing-animation','flatonpro' ),
        'tinDownIn-animation' => __('tinDownIn-animation','flatonpro' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','flatonpro' ),
        'tinUpIn-animation' => __('tinUpIn-animation','flatonpro' ), 
        'tossing-animation'  => __('tossing-animation','flatonpro' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','flatonpro' ),
        'twisterInUp-animation' => __('twisterInUp-animation','flatonpro' ), 
        'wobble-animation' => __('wobble-animation','flatonpro' ),
        'zoomIn-animation' => __('zoomIn-animation','flatonpro' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'abaris'),
            'type' => 'select',
            'options' => $abaris_animation_name,
            'priority' => 4,
    );

    /* Widgets & Row padding top & bottom field */

    $fields['padding_top_gap'] = array(
      'name' => __('Padding ( Top )', 'flatonpro'),
      'type' => 'measurement',
      'group' => 'layout',
      'description' => __('Padding Top Gap', 'flatonpro'),
    );
    $fields['padding_bottom_gap'] = array(
      'name' => __('Padding ( Bottom )', 'flatonpro'),
      'type' => 'measurement',
      'group' => 'layout',
      'description' => __('Padding Bottom Gap', 'flatonpro'),
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_abaris_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_abaris_panels_row_style_fields');

function wbls_abaris_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    
    /* Widgets & Row padding top & bottom field */ 
    if( empty($attributes['style']) ) $attributes['style'] = '';
    if(!empty($args['padding_top_gap'])) $attributes['style'] .= 'padding-top: '.esc_attr($args['padding_top_gap']).'; ';
    if(!empty($args['padding_bottom_gap'])) $attributes['style'] .= 'padding-bottom: '.esc_attr($args['padding_bottom_gap']).'; ';

    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_abaris_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_abaris_panels_panels_row_style_attributes', 10, 2);

function wbls_abaris_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Theme & Animation', 'flatonpro'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_abaris_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_abaris_row_style_groups' );