<?php
	// Makes theme translation ready
	load_theme_textdomain( 'flatonpro', WEBULOUS_LANGUAGES_DIR );
