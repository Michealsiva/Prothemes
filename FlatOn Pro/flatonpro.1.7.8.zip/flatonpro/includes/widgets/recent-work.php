<?php
/**
 * Recent Work Widget.
 *
 * @package Flaton Pro
 * @since 1.0
 * @license GPL 2.0
 */

class Webulous_Recent_Work_Widget extends WP_Widget {

	public function __construct() {
		// widget actual processes
		parent::__construct(
			'recent-work-widget', // Base ID    
			__('Recent Work', 'flatonpro'), // Name
			array( 'description' => __( 'Displays Recent Works', 'flatonpro' ), ) // Args
		);
	}

	public function widget( $args, $instance ) {
		$instance = wp_parse_args( $instance, array(
			'title' => __( 'Recent Work', 'flatonpro' ),
			'type' => __( 'Carousel', 'flatonpro' ),
			'count' => 12,
			'portfolio_cat' => '',
			'portfolio_skill' => '',
			'portfolio_column' => 4,
		) );
		$title = apply_filters( 'widget_title', $instance['title'] );
		echo $args['before_widget'];

		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		if(  $instance['type'] == "carousel" ) {
			if(!empty($instance['count'])) : ?><?php echo do_shortcode('[recent_work count="' . $instance['count'] . '" cat="'. $instance['portfolio_cat'].'"]'); ?><?php endif;
		} else {
			if(!empty($instance['count'])) : ?><?php echo do_shortcode('[recent_work_isotope count="' . $instance['count'] . '" cat="'. $instance['portfolio_cat']. '" portfolio_skill="'. $instance['portfolio_skill'] . '" column="'. $instance['portfolio_column']. '"]'); ?><?php endif;
		}

		echo $args['after_widget'];
	}

	/**
	 * Display the flexcount widget form.
	 *
	 * @param array $instance
	 * @return string|void
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( $instance, array(
			'title' => __( 'Recent Work', 'flatonpro' ),
			'type' => __( 'Carousel', 'flatonpro' ),
			'count' => 12,
			'portfolio_cat' => '',
			'portfolio_skill' => '',
			'portfolio_column' => 4,
		) );

	?>

		<p>
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e('Title', 'flatonpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('title') ?>" name="<?php echo $this->get_field_name('title') ?>" value="<?php echo esc_attr($instance['title']) ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('portfolio_cat') ?>"><?php _e(' Select Category ', 'flatonpro') ?></label>
			<?php wp_dropdown_categories( array( 'name' => $this->get_field_name( 'portfolio_cat' ), 'show_option_all' => 'All Category', 'selected' =>  $instance['portfolio_cat'] ) ); ?>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('portfolio_skill') ?>"><?php _e(' Select Skill ', 'flatonpro') ?></label>
			<?php wp_dropdown_categories( array( 'name' => $this->get_field_name( 'portfolio_skill' ),  'show_option_all' => 'All Skills', 'taxonomy' => 'skills', 'selected' =>  $instance['portfolio_skill'] ) ); ?>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('count') ?>"><?php _e('No. of Items to show', 'flatonpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('count') ?>" name="<?php echo $this->get_field_name('count') ?>" value="<?php echo esc_attr($instance['count']) ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('type') ?>"><?php _e('Type', 'flatonpro') ?></label>
			<select id="<?php echo $this->get_field_id('type') ?>" name="<?php echo $this->get_field_name('type') ?>">
				<option value="carousel" <?php selected($instance['type'], "carousel") ?>>Carousel</option>
				<option value="isotope" <?php selected($instance['type'], "isotope") ?>>Isotope</option>
			</select>
		</p>
		<?php //if( $instance['type'] == 'isotope' ) : ?>
			<p>
				<label for="<?php echo $this->get_field_id('portfolio_column') ?>"><?php _e('Select Portfolio Column ', 'flatonpro') ?></label>
				<select id="<?php echo $this->get_field_id('portfolio_column') ?>" name="<?php echo $this->get_field_name('portfolio_column') ?>">
					<option value="4" <?php selected($instance['portfolio_column'], "4") ?>>Four Column</option>
					<option value="3" <?php selected($instance['portfolio_column'], "3") ?>>Three Column</option>
					<option value="2" <?php selected($instance['portfolio_column'], "2") ?>>Two Column</option>
				</select>
			</p>
	    <?php //endif;?>


		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['portfolio_cat'] = ( ! empty( $new_instance['portfolio_cat'] ) ) ? strip_tags( $new_instance['portfolio_cat'] ) : '';
		$instance['portfolio_skill'] = ( ! empty( $new_instance['portfolio_skill'] ) ) ? strip_tags( $new_instance['portfolio_skill'] ) : ''; 
		$instance['count'] = ( ! empty( $new_instance['count'] ) ) ? strip_tags( $new_instance['count'] ) : '';
		$instance['type'] = ( ! empty( $new_instance['type'] ) ) ? strip_tags( $new_instance['type'] ) : '';
		$instance['portfolio_column'] = ( ! empty( $new_instance['portfolio_column'] ) ) ? strip_tags( $new_instance['portfolio_column'] ) : '';
		return $instance;
	}
}
