<?php

/**
 * Ourteam Group Widget
 */

class Webulous_Ourteam_Group_Widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'ourteam-group-widget', // Base ID
			__('Our Team Grop', 'flatonpro'), // Name
			array( 'description' => __( 'Display Group of Our Team members details', 'flatonpro' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];
		$widget_default = array();
		for ($i=1; $i < 5; $i++) { 
			$widget_default  = array_merge($widget_default ,array(
					    'content_'.$i => '',
						'image_url_'.$i  => '',
						'title_'.$i  => '',
						'designation_'.$i  => '', 
					)
			);
		}

		$widget_default = array_merge( $widget_default,array( 'title' => ''));

	    $instance = wp_parse_args( $instance, $widget_default );

		$output = '';
		$output .= '[ourteam_group ';
            $output .=  'title="' . $instance['title'];
            for ($i=1; $i < 5 ; $i++) { 
	            $output .= '" title_'.$i.'="' . $instance['title_'.$i];
				$output .= '" designation_'.$i.'="'. $instance['designation_'.$i];
				$output .= '" image_url_'.$i.'="' . $instance['image_url_'.$i];
				$output .= '" content_'.$i.'="'. $instance['content_'.$i];
            }

			$output .= '"]';
		$output .= '[/ourteam_group]';

   
		echo do_shortcode($output);
		echo $args['after_widget'];
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {

		$form_default  =array();
		for ($i=1; $i < 5; $i++) { 
		$form_default  = array_merge($form_default ,array(
				    'content_'.$i => '',
					'image_url_'.$i  => '',
					'title_'.$i  => '',
					'designation_'.$i  => '',
					)
				);
		}
       $form_default = array_merge( $form_default,array( 'title' => ''));
		//echo '<pre>', print_r($var2),'</pre>';

		$instance = wp_parse_args( $instance, $form_default );
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e('Title', 'flatonpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('title') ?>" name="<?php echo $this->get_field_name('title') ?>" value="<?php echo esc_attr($instance['title']) ?>" />
		</p>
		<?php for ($i=1; $i < 5; $i++) { ?>

		<h2><?php _e('Member '.$i); ?></h2>
		<p>
			<label for="<?php echo $this->get_field_id('title_'.$i) ?>"><?php _e('Name of Team Member', 'flatonpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('title_'.$i) ?>" name="<?php echo $this->get_field_name('title_'.$i) ?>" value="<?php echo esc_attr($instance['title_'.$i]) ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('designation_'.$i) ?>"><?php _e('Designation of Team Member', 'flatonpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('designation_'.$i) ?>" name="<?php echo $this->get_field_name('designation_'.$i) ?>" value="<?php echo esc_attr($instance['designation_'.$i]) ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('image_url_'.$i) ?>"><?php _e('Image URL of Team Member', 'flatonpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('image_url_'.$i) ?>" name="<?php echo $this->get_field_name('image_url_'.$i) ?>" value="<?php echo esc_attr($instance['image_url_'.$i]) ?>" />
		</p>
		<p>
		<label for="<?php echo $this->get_field_id( 'content_'.$i ); ?>"><?php _e( 'Content:' ); ?></label> 
		<textarea class="widefat" id="<?php echo $this->get_field_id( 'content_'.$i ); ?>" name="<?php echo $this->get_field_name( 'content_'.$i ); ?>"><?php echo esc_html( $instance['content_'.$i] ); ?></textarea>
		</p>

<?php } 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$allowed_tags = array(    
							'a' => array(
	        					'href' => array(),
    	    					'title' => array()
    					),
						    'em' => array(),
						    'strong' => array(),
						    'br' => array(),
						);
        $instance['title'] = $new_instance['title'];
		for ($i=1; $i < 5; $i++) { 
			$instance['content_'.$i] = ( ! empty( $new_instance['content_'.$i] ) ) ? wp_kses( $new_instance['content_'.$i], $allowed_tags ) : '';
			$instance['image_url_'.$i] = $new_instance['image_url_'.$i];
			$instance['title_'.$i] = $new_instance['title_'.$i];
			$instance['designation_'.$i] = $new_instance['designation_'.$i];	
		}

		return $instance;
	}

} // class Foo_Widget
