<?php

/**
 * Twitter Widget
 */

class Webulous_Twitter_Widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'twitter-widget', // Base ID
			__('Twitter', 'flatonpro'), // Name
			array( 'description' => __( 'Twitter Widget', 'flatonpro' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];

		$instance = wp_parse_args( $instance, array(
		    'title'	=> __( 'Recent Tweets', 'flatonpro' ),
			'twitter_id' => '',
			'twitter_widget_id' => '',
			'count'	=> 3,
			'width' => 400,
			'height' => 400,
		) ); 
		extract($instance); 
		extract($args);   

        if ( $title ) {
			echo $before_title . $title . $after_title;
		} ?>
		
		<a class="twitter-timeline" data-dnt="true" href="https://twitter.com/<?php echo $twitter_id; ?>" data-widget-id ="<?php echo $twitter_widget_id; ?>" data-tweet-limit = "<?php echo $count; ?>" data-width="<?php echo $width; ?>" data-height="<?php echo $height; ?>" width="<?php echo $width; ?>" height="<?php echo $height; ?>">Twitter Tweets</a>

		<script>
			!function(d,s,id) { 
				var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}
			} (document,"script","twitter-wjs");
		</script><?php      

	} 

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( $instance, array(
		    'title'	=> __( 'Recent Tweets', 'flatonpro' ),
			'twitter_id' => '',
			'twitter_widget_id' => '',
			'count'	=> 3,
			'width' => 400,
			'height' => 400,
		) );


		?> 

		<p>
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e('Title', 'flatonpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('title') ?>" name="<?php echo $this->get_field_name('title') ?>" value="<?php echo esc_attr($instance['title']) ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('twitter_id') ?>"><?php _e('Twitter Username', 'flatonpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('twitter_id') ?>" name="<?php echo $this->get_field_name('twitter_id') ?>" value="<?php echo esc_attr($instance['twitter_id']) ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('twitter_widget_id') ?>"><?php _e('Twitter Widget ID', 'flatonpro') ?></label> 
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('twitter_widget_id') ?>" name="<?php echo $this->get_field_name('twitter_widget_id') ?>" value="<?php echo esc_attr($instance['twitter_widget_id']) ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('count') ?>"><?php _e('Number of Tweet ', 'flatonpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('count') ?>" name="<?php echo $this->get_field_name('count') ?>" value="<?php echo esc_attr($instance['count']) ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('width') ?>"><?php _e('Width', 'flatonpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('width') ?>" name="<?php echo $this->get_field_name('width') ?>" value="<?php echo esc_attr($instance['width']) ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('height') ?>"><?php _e('Height', 'flatonpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('height') ?>" name="<?php echo $this->get_field_name('height') ?>" value="<?php echo esc_attr($instance['height']) ?>" />
		</p>

		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();

		$instance['title'] = $new_instance['title'];
		$instance['twitter_id'] = $new_instance['twitter_id'];
		$instance['twitter_widget_id'] = $new_instance['twitter_widget_id'];    
		$instance['count'] = $new_instance['count'];
		$instance['width'] = $new_instance['width'];
		$instance['height'] = $new_instance['height'];

		return $instance;
	}

} // class Foo_Widget

  