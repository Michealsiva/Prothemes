<?php
/**
 * Elastic Slider Widget.
 *
 * @package webulous
 * @since 1.5.7
 * @license GPL 2.0
 */

class Webulous_ElasticSlider_Widget extends WP_Widget {

	public function __construct() {
		// widget actual processes
		parent::__construct(
			'elasticslider-widget', // Base ID
			__('Elastic Slider', 'flatonpro'), // Name
			array( 'description' => __( 'Displays Elasticslider', 'flatonpro' ), ) // Args
		);
	}

	public function widget( $args, $instance ) {
		echo $args['before_widget'];

		$instance = wp_parse_args( $instance, array(
			'slider' => '',
		) );

		if(!empty($instance['slider'])) : ?><?php echo do_shortcode('[elasticslider id="' . $instance['slider'] . '"]'); ?><?php endif;

		echo $args['after_widget'];
	}

	/**
	 * Display the elasticslider widget form.
	 *
	 * @param array $instance
	 * @return string|void
	 */
	public function form( $instance ) {

		$instance = wp_parse_args( $instance, array(
			'slider' => '',
		) );
		?>

		<p>
			<label for="<?php echo $this->get_field_id('slider') ?>"><?php _e('Slider', 'flatonpro') ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('slider') ?>" name="<?php echo $this->get_field_name('slider') ?>" value="<?php echo esc_attr($instance['slider']) ?>">
				<?php
					$term_list = get_terms( 'elasticslider_group' ); ///wp_get_post_terms(0, 'elasticslider_group', array("fields" => "ids"));
					foreach($term_list as $term) : ?>
					<option value="<?php esc_attr_e($term->term_id); ?>" <?php selected($instance['slider'], $term->term_id) ?>><?php esc_html_e($term->name, 'flatonpro') ?></option>
				<?php endforeach; ?>
			</select>
		</p>

		<?php
	}

	public function update( $new_instance, $old_instance ) {
		return $new_instance;
	}
}
