<?php

return array(
	'web_application_icons' => __('Web Application Icons', 'flatonpro'),
	'form_control_icon' => __('Form Control Icons', 'flatonpro'),
	'currency_icons' => __('Currency Icons', 'flatonpro'),
	'text_editor_icons' => __('Text Editor Icons', 'flatonpro'),
	'directional_icons' => __('Directional Icons', 'flatonpro'),
	'video_player_icons' => __('Video Player Icons', 'flatonpro'),
	'brand_icons' => __('Brand Icons', 'flatonpro'),
	'medical_icons' => __('Medical Icons', 'flatonpro'),
	'hand_icons' => __( 'Hand Icons', 'flatonpro' ),
	'transportation_icons' => __( 'Transportation Icons', 'flatonpro' ),
	'gender_icons' => __( 'Gender Icons', 'flatonpro' ),
	'file_type_icons' => __( 'File Type Icons', 'flatonpro' ),
	'spinner_icons' => __( 'Spinner Icons', 'flatonpro' ),
	'payment_icons' => __( 'Payment Icons', 'flatonpro' ),
	'chart_icons' =>  __( 'Chart Icons', 'flatonpro' )
);

