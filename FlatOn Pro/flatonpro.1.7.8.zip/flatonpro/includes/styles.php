<?php

function webulous_custom_styles($custom) {
$custom = '';	
   global $webulous_options;   

   /* Heder background image */

   if( isset( $webulous_options['header_bg_status'] ) && $webulous_options['header_bg_status']  ) {  		

        $bg_size = isset($webulous_options['header-bg-size']) ? $webulous_options['header-bg-size'] : 'auto';
        $bg_repeat = isset($webulous_options['header-bg-repeat']) ? $webulous_options['header-bg-repeat'] : 'repeat'; 
        $bg_position = isset($webulous_options['header-bg-position']) ? $webulous_options['header-bg-position'] : 'left top';;
        $bg_attachment =  isset($webulous_options['header-bg-attachment']) ? $webulous_options['header-bg-attachment'] : 'scroll'; 
        $bg_color =  $webulous_options['header-bg-color'];
        $bg_height =  isset($webulous_options['header_bg_height']) ? $webulous_options['header_bg_height'] : '130'; 

        $custom .= ".header-wrap {  background-position: ". $bg_position. ";
				    background-repeat: ". $bg_repeat . ";  
				    background-size: ". $bg_size ." ;
				    min-height: ". $bg_height ."px; 
				    background-color: ". $bg_color .";
				    background-attachment : ". $bg_attachment .";
				    position: relative; }"."\n";
   }


   /* Portfolio templates navigation related css */
   if( isset( $webulous_options['portfolio_filter_type'] ) && $webulous_options['portfolio_filter_type'] == '2' ) {
      $custom .= "ul.filter-options li:first-child { display: none; }"."\n";
   }
   if( isset( $webulous_options['portfolio_filter_type'] ) && $webulous_options['portfolio_filter_type'] == '3' ) {
      $custom .= "#filters { display: none; }"."\n"; 
   }


  /* Extra options related CSS */

  /* Sticky header position */

  $sticky_header_position = isset($webulous_options['sticky_header_position']) ? $webulous_options['sticky_header_position'] : 'top';
     if( $sticky_header_position == 'bottom' ) : ?>
      <style type="text/css" media="screen"> 
             .nav-wrap.sticky-nav{
                  top: auto!important;
                  bottom:0; 
                  border-top: 1px solid #ffffff;
              }
              .nav-wrap.sticky-nav .sub-menu {
                top: auto;
            bottom:100%;
              }
      </style>
    <?php endif; 


	//Output all the styles
	wp_add_inline_style( 'webulous-style', $custom );    	
}


add_action( 'wp_enqueue_scripts', 'webulous_custom_styles' );
