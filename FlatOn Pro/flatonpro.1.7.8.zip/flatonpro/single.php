<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Webulous
 */

global $post;
$post_fullwidth = get_post_meta( $post->ID, 'full-width-post', true );
if ( $post_fullwidth && $post->post_type == 'post' ){
    get_template_part('single-post-fullwidth');
}else{
get_header(); ?>
	<?php get_template_part( 'breadcrumb' ); ?>

<?php do_action('webulous_single_blog_fullwidth_featured_image'); ?>
 
		
<div id="content" class="site-content container">

	<?php do_action('webulous_two_sidebar_left'); ?>	

	<div id="primary" class="content-area <?php webulous_primary_class(); ?> columns">
		<main id="main" class="site-main" role="main">
			
			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', 'single' ); ?>

				<?php webulous_post_nav(); ?>

				<?php if($webulous_options['show-social-sharing']): ?>
				<div class="share-box">
					<h4><?php echo __( 'Share this on ...', 'flatonpro' ); ?></h4>
					<ul>
						<?php if( $webulous_options['ss_box_facebook'] ): ?>
						<li>
							<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php the_title(); ?>">
								<i class="fa fa-facebook"></i>
							</a>
						</li>
						<?php endif; ?>
						<?php if($webulous_options['ss_box_twitter']): ?>
						<li>
						   <a href="http://twitter.com/intent/tweet?url=<?php the_permalink(); ?>">
								<i class="fa fa-twitter"></i>
							</a>     
						</li>
						<?php endif; ?>
						<?php if($webulous_options['ss_box_linkedin']): ?>
						<li>
							<a href="http://linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>">
								<i class="fa fa-linkedin"></i>
							</a>
						</li>
						<?php endif; ?>

						<?php if($webulous_options['ss_box_googleplus']): ?>
						<li>
							<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>">
								<i class="fa fa-google-plus"></i>
							</a>
						</li>
						<?php endif; ?>
						<?php if($webulous_options['ss_box_email']): ?>
						<li>
							<a href="mailto:?subject=<?php the_title(); ?>&amp;body=<?php the_permalink(); ?>">
								<i class="fa fa-envelope"></i>
							</a>
						</li>
						<?php endif; ?>
					</ul>
				</div>
				<?php endif; ?>

				<?php if($webulous_options['show-author-bio']): ?>
				<section class="author-bio clearfix">
					<div class="author-info">
						<div class="avatar">
							<?php echo get_avatar( get_the_author_meta( 'email' ), '72' ); ?>
						</div>
						<div class="description">
							<h4><?php echo __( 'About Author:', 'flatonpro' ); ?> <?php the_author_posts_link(); ?></h4>
							<?php the_author_meta('description');?>
						</div>
					</div>
				</section>  
				<?php endif; ?>

				<?php if( $webulous_options['show-related-posts'] && function_exists( 'webulous_related_posts' ) ) : ?>
						<section class="related-posts clearfix">
							<?php webulous_related_posts(); ?>
						</section>
				<?php endif;  ?>

				<?php
					if( $webulous_options['show-comments'] ) :
						// If comments are open or we have at least one comment, load up the comment template
						if ( comments_open() || '0' != get_comments_number() ) :
							comments_template();
						endif;
					endif;
				?>

			<?php endwhile; // end of the loop. ?>

			</main><!-- #main -->
		</div><!-- #primary -->

	<?php do_action('webulous_two_sidebar_right'); ?>	
	</div>
			
		<?php get_footer();
} 