<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package Webulous
 */
global $webulous_options;
?>
	<div id="secondary" class="widget-area offset-by-one left-sidebar <?php webulous_secondary_class();?> columns" role="complementary">
		<?php do_action( 'before_sidebar' ); ?>

		<?php if( is_active_sidebar( 'sidebar-left' ) &&  ( is_page_template('template-twosidebar.php') || is_page_template('template-twosidebarleft.php') || is_page_template('template-twosidebarright.php') || '4' == $webulous_options['layout'] || '5' == $webulous_options['layout'] || '6' == $webulous_options['layout'] )  ) {
				dynamic_sidebar( 'sidebar-left' ); 
		}else { ?>
            <aside id="search" class="widget widget_search">
			   <h4 class="widget-title"><?php _e( 'Search', 'flatonpro' ); ?></h4>
				<?php get_search_form(); ?>
			</aside>
<?php   } ?>
	
	</div><!-- #secondary -->