<?php 
/*
	Template Name: Blog Large Image
 */
 	get_header();

		do_action( 'wbls_fw_portfolio_before_breadcrumbs');
		do_action( 'wbls_fw_portfolio_breadcrumbs' );
		do_action( 'wbls_fw_portfolio_after_breadcrumbs' );
	?>

<div id="content" class="site-content container">

     <?php do_action('wbls_modulus_two_sidebar_left'); ?>

		<div id="primary" class="content-area <?php wbls_modulus_layout_class();?> columns">
			<main id="main" class="site-main" role="main">   
		   
				<?php
					$query_string ="post_type=post&paged=$paged";
					query_posts($query_string);
					$num_of_posts = $wp_query->post_count;
				?>		
					
				<?php if ( have_posts() ) : ?>

					<?php /* Start the Loop */ ?>
					<?php while ( have_posts() ) : the_post(); ?>
                     
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>> 

					
					<div class="entry-content">

 <?php	$featured_image = get_theme_mod( 'featured_image',true );
	    $featured_image_size = get_theme_mod ('featured_image_size','1');
		if( $featured_image ) : 
		        if ( $featured_image_size == '1' ) :?>		
						<div class="thumb blog-thumb">
						  <?php	if( $featured_image && has_post_thumbnail() ) : 
								    the_post_thumbnail('wbls-modulus-blog-large-width');

			                     endif;?>
			            </div> <?php
		        else: ?>
		 	            <div class="thumb blog-thumb">
		 	                 <?php if( has_post_thumbnail() && ! post_password_required() ) :   
					               the_post_thumbnail('wbls-modulus-small-featured-image-width');
								
								endif;?>
			             </div>  <?php				
	            endif; 
		endif; ?> 
		
					<div class="entry-body-wrapper">
									<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
						
								<header class="entry-header">
	<?php if ( get_theme_mod('enable_single_post_top_meta',true ) ): ?>
		    <div class="entry-meta">
		    <?php if(function_exists('modulus_entry_top_meta') ) {
		         modulus_entry_top_meta();
		     } ?>
			</div><!-- .entry-meta -->
	<?php endif; ?>
	</header><!-- .entry-header -->
							<?php echo the_content(); ?>   
			

						<?php
							wp_link_pages( array(
								'before' => '<div class="page-links">' . __( 'Pages:', 'wbls-modulus' ),
								'after'  => '</div>',
							) );
						?>
						<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
	<footer class="entry-footer">
	<?php if(function_exists('modulus_entry_bottom_meta') ) {
		    modulus_entry_bottom_meta();
		} ?>
	</footer><!-- .entry-footer -->
<?php endif;?>
					</div>
					</div><!-- .entry-content -->

					
				</article><!-- #post-## -->

					<?php endwhile; ?>
        <?php
			if ( get_theme_mod( 'numeric_pagination', true ) && function_exists( 'wbls_fw_pagination' ) ) :
				wbls_fw_pagination();
			else :
				if ( function_exists( 'wbls_fw_paging_nav' ) ) {
					wbls_fw_paging_nav();
				}
			endif;
		?>

				<?php else : ?>

					<?php get_template_part( 'content', 'none' ); ?>

				<?php endif; ?>

				</main><!-- #main -->
			</div><!-- #primary -->
			
	   <?php do_action('wbls_modulus_two_sidebar_right'); ?>

		<?php get_footer(); ?>