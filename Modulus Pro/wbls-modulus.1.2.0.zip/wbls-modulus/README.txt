=== Webulous Modulus Pro ===
Contributors: webulous
Donate link: http://www.webulousthemes.com/
Tags: comments, spam
Requires at least: 4.0.0
Tested up to: 4.7
Stable tag: 1.2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin converts free version of Modulus theme into pro version.

== Description ==

This plugin converts free version of Modulus theme into pro version.


== Installation ==

1. Upload `wbls-modulus` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. This is a screen shot

== Changelog == 

= 1.2.0 =
* Parent Link Navigation For Responsive.
* Fix Stats Count Warning Error.

= 1.1.9 =
* Merge Custom css option to WP option

= 1.1.8 =
* Mobile friendly Compatible with latest version

= 1.1.7 =
 * Fix Tracking Code bug
 * Fix demo content import bug

= 1.1.6 =
 * Fix tab style & overlay style issue
 * Compatible with mobile friendly

= 1.1.5 =
 * Fix header already sent issue

= 1.1.4 =
 * Added More options
 * Customizer Changed to kirki 

= 1.1.3 =
* Added custom header background image option

= 1.1.2 =
* Style Enhancement & Fix License issue

= 1.1.1 =
* Change Update file & Enable License Key Activation 

= 1.1.0 =
* Fix Home page responsive bug

= 1.0.9 =
* Added sticky header and layout option style

= 1.0.8 =
* Added layout option for blog page

= 1.0.7 =
* Custom Typography icon title issue fix.

= 1.0.6 =
* Merge

= 1.0.5 =
* Customizer typography css issue fix
* Circle icon  issue fix

= 1.0.4 =
* Signature change process_imports() method in Radium Importer
* Testimonial image issue fix

= 1.0.3 =
* Page builder margin bottom issue fix
* Button Widget style
* Woocommerce support
* Single Post Layout options
* Function Prefix and CSS style Changes

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.2.0 =
* Parent Link Navigation For Responsive.
* Fix Stats Count Warning Error.