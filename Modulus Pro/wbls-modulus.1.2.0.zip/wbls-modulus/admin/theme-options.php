<?php
/**
 * Pro customizer options     
 */

add_action('wbls-modulus_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() { 
  

// pro home paeg section 

		Modulus_Kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-modulus' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-modulus'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) );

		Modulus_Kirki::add_field( 'modulus', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-modulus' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch',
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
				'off' => esc_attr__( 'Disable', 'wbls-modulus' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-modulus'),
			'default'  => 'off',
		) );
		Modulus_Kirki::add_field( 'modulus', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-modulus' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-modulus'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-modulus'),
		) );

//  animation section 

Modulus_Kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-modulus' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-modulus'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-modulus' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Modulus_Kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-modulus' ),
	'description'    => __( 'Custom JS', 'wbls-modulus'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-modulus' ),
	'section'  => 'custom_js_section',
	'type'     => 'code',    
	'choices'     => array(
		'language' => 'javascript',
		'theme'    => 'monokai',
		'height'   => 250,
	), 
) ); 

// Tracking section   

Modulus_Kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-modulus' ),
	'description'    => __( 'Tracking Code', 'wbls-modulus'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'analytics', 
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-modulus' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
	'choices'     => array(
		'language' => 'javascript',  
		'theme'    => 'monokai',
		'height'   => 250,
	), 
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme.','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-modulus' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'2' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-modulus'),
) );

// color scheme section 

Modulus_Kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-modulus' ),
	'description'    => __( 'Select your color scheme', 'wbls-modulus'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Modulus_kirki::add_field( 'modulus', array(
			'settings' => 'color_scheme',
			'label'    => __( 'Select your color scheme', 'wbls-modulus' ),
			'section'  => 'multiple_color_section',
			'type'     => 'palette',
			'choices'     => array(
	            '1' => array(
					'#1fb2e2 ', 
				),
				'2' => array(
					'#4c89db',
				),
				'3' => array(
					'#7ead16',
				),
				'4' => array(
					'#db4678',
				),
				'5' => array(
					'#855bce',
				),
				'6' => array(
					'#e44647',   
				),
				'7' => array(
					'#ec8e06',
				),
			),
			'default' => '1',
			//'default'  => 'on',
		) );

//Social Network URL Section
modulus_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-modulus' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-modulus'),
	'panel'			 => 'social_panel',
) );

modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-modulus'),
) );
modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-modulus' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-modulus'),
) );

// flexslider section //

Modulus_Kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-modulus' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-modulus'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-modulus' ),
		'2' => esc_attr__( 'Slide', 'wbls-modulus' )
	),
	'default'  => '2',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-modulus' ),
		'2' => esc_attr__( 'Vertical', 'wbls-modulus' )
	),
	'default'  => '1',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => 'on',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => 'on',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => 'on',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => 'on',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => 'off',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => 'off',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => 'off',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'off' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-modulus' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Modulus_Kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-modulus' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-modulus'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-modulus' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'2' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => '2',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-modulus' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-modulus' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-modulus' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'2' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => '2',
) );

//  portfolio settings //

Modulus_Kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-modulus' ),
) );

$post_per_page = get_option('posts_per_page');
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-modulus' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-modulus' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-modulus' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-modulus' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-modulus'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-modulus' ),
		2 => __( 'Show Without "All"', 'wbls-modulus' ),
		3 => __( 'Hide', 'wbls-modulus' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Modulus_Kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-modulus' ),
	'description'    => __( 'Light Box Settings', 'wbls-modulus'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-modulus' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-modulus' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-modulus' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-modulus' ),
		'4' => esc_attr__( 'light-square', 'wbls-modulus' ),
		'5' => esc_attr__( 'dark-square', 'wbls-modulus' ),
		'6' => esc_attr__( 'facebook', 'wbls-modulus' ),
	),
	'default'  => '1',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-modulus' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-modulus' ),
		'slow' => esc_attr__( 'Slow', 'wbls-modulus' ),
		'normal' => esc_attr__( 'Normal', 'wbls-modulus' ),
	),
	'default'  => 'fast',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-modulus' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-modulus' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'2' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => '2',
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-modulus' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-modulus'),
) );
Modulus_Kirki::add_field( 'modulus', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-modulus' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-modulus' ),
		'2' => esc_attr__( 'Disable', 'wbls-modulus' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Modulus_kirki::add_field( 'modulus', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-modulus' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#1fb2e2',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => '.left-sidebar .dropcap-box,.title-divider-left .widget-title::before,.title-divider .left::before,.icon-polygon .circle-icon-wrapper h3.fa-stack,.icon-horizontal:hover .service,
							.icon-vertical:hover .service,.icon-top:hover .service,.icon-right:hover .service,.icon-left:hover .service,.widget_image-box-widget .image-box img,.widget_tag_cloud a,
							.icon-polygon .circle-icon-wrapper h3.fa-stack:before,
							.icon-polygon .circle-icon-wrapper h3.fa-stack:after,.btn:before,.toggle .toggle-content,.circle-icon-box .circle-icon-wrapper .fa-stack i,
							.widget_button-widget a.btn.btn-default:before,.btn:before,.notice a,.flexslider .flex-caption a,.page-template-portfolio-2col .entry-title:before, .page-template-portfolio-2col_text .entry-title:before,
							.page-template-portfolio-2col_sidebar .entry-title:before,.page-template-portfolio-3col .entry-title:before, .page-template-portfolio-3col_text .entry-title:before, .page-template-portfolio-3col_sidebar .entry-title:before,
							.page-template-portfolio-4col .entry-title:before,.page-template-portfolio-4col_text .entry-title:before, .page-template-portfolio .entry-title:before,.widget_recent-work-widget .widget-title:before,.ui-accordion .ui-accordion-content,.widget.widget_skill-widget .widget-title:before , .title-divider .widget-title:before ,.free-home .services-wrapper .service:hover .service-content,
							.free-home .title-divider:before,.free-home .services-wrapper .service:hover ',
			'property' => 'border-color',
		),
		array(
			'element'  => '.withtip.left:after,.icon-polygon .circle-icon-wrapper h3.fa-stack',
			'property' => 'border-left-color',
		),
		array(
			'element'  => ' .withtip.right:after,.icon-polygon .circle-icon-wrapper h3.fa-stack ',
			'property' => 'border-right-color',
		),
		array(
			'element'  => '.sep:after,.withtip.top:after',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '.withtip.bottom:after,.widget-area h4.widget-title  ',
			'property' => 'border-bottom-color',
		),
		array(
			'element'  => '.hentry.post h2 a:hover,.site-info .widget_nav_menu a:hover,.title-divider-left .widget-title::before,.title-divider .left::before,.site-info p a,.site-footer .footer-widgets a:hover,.site-footer .footer-widgets #calendar_wrap a,#secondary .btn-white:hover,.widget-area ul li a:hover,#secondary #recentcomments a,.widget-area .widget_rss a,.widget-area .widget_rss a,
							#secondary .widget_button-widget .btn.white:hover,.left-sidebar .widget_social-networks-widget ul li a:hover i,.left-sidebar .widget_recent-posts-widget .flex-recent-posts li a,#secondary .left-sidebar .widget.widget_ourteam-widget .team-content h4,.left-sidebar .widget_list-widget ul li i,.left-sidebar .icon-horizontal .icon-title,
							.left-sidebar .icon-vertical .icon-title,.left-sidebar .dropcap,.site-footer .widget_testimonial-widget ul li .client,.site-footer .widget.widget_ourteam-widget:hover .team-content h4,.site-footer .widget_list-widget ul li i,.site-footer .icon-horizontal .icon-title,
							.site-footer .icon-vertical .icon-title,.site-footer .footer-bottom ul.menu li a:hover,.widget_recent-posts-widget .recent-post .entry-author a:hover,.widget_list-widget ul li .fa, .widget_list-widget ol li .fa,.circle-icon-box:hover h4,.circle-icon-box:hover a.link-title,.circle-icon-box:hover a.link-title h4 ,.notice a:hover,.alert-message a:hover,.breadcrumb a,.flexslider .flex-caption h1:before, .flexslider .flex-caption h2:before, .flexslider .flex-caption h3:before, .flexslider .flex-caption h4:before, .flexslider .flex-caption h5:before, .flexslider .flex-caption h6:before,.recent-work-container .recent_work_overlay a:hover i,.page-template-portfolio-2col .entry-title:before, .page-template-portfolio-2col_text .entry-title:before, .page-template-portfolio-2col_sidebar .entry-title:before, .page-template-portfolio-3col .entry-title:before, .page-template-portfolio-3col_text .entry-title:before, .page-template-portfolio-3col_sidebar .entry-title:before, .page-template-portfolio-4col .entry-title:before, .page-template-portfolio-4col_text .entry-title:before, .page-template-portfolio .entry-title:before,ul#portfolio li h3 a:hover,.portfolioeffects .overlay_icon a:hover i,.portfolioeffects .content-details h3 a:hover,.widget_recent-work-widget .portfolioeffects .content-details h3 a:hover, .widget_recent-work-widget .work .content-details h3 a:hover,.widget_recent-work-widget .widget-title:before,.widget.widget_skill-widget .widget-title:before ,.widget.widget_ourteam-widget .team-social ul:after,.tabs.normal ul li .tabulous_active:after, .tabs ul li .tabulous_active:after,.contact-info .textwidget a:hover,.order-total .amount,.title-divider .widget-title:before,
							.cart-subtotal .amount,.woocommerce .woocommerce-breadcrumb a:hover, .woocommerce-page .woocommerce-breadcrumb a:hover,.free-home .post-wrapper .btn-readmore,.free-home .post-wrapper .entry-meta span:hover i, .free-home .post-wrapper .entry-meta span:hover a ,.free-home .post-wrapper .entry-meta span:hover,.free-home .post-wrapper h3 a:hover,.free-home .title-divider:before,.free-home .services-wrapper .service:hover h4',
			'property' => 'color',
		),
		array(
			'element'  => '.widget.widget_ourteam-widget .our-team:hover .team-content,.portfolioeffects:hover .overlay_icon',
			'property' => 'background-color',
			'opacity' => '0.5',
		),
		array(
			'element'  => '.main-navigation .sub-menu .current_page_item > a,.main-navigation .sub-menu .current-menu-item > a, .main-navigation .sub-menu .current_page_ancestor > a, .main-navigation .children .current_page_item > a, .main-navigation .children .current-menu-item > a, .main-navigation .children .current_page_ancestor > a,.left-sidebar .dropcap-circle,.widget_tag_cloud a,.main-navigation button.menu-toggle:hover,
							.left-sidebar .icon-horizontal .fa-stack,.site-footer .footer-widgets .widget_calendar table caption,
							.left-sidebar .icon-vertical .fa-stack, .left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
							.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,
							.left-sidebar .dropcap-box,#secondary .left-sidebar .callout-widget,.dropcap-circle,.widget_stat-widget .stat-container .icon-wrapper i,.dropcap-book,.pullright,.widget_recent-posts-widget .recent-post .entry-date a,
							.pullleft,.site-footer .widget_social-networks-widget ul li a .fa,
							.site-footer .share-box ul li a .fa,.circle-icon-box:hover a.more-button,.icon-left .fa-stack i,.icon-top .fa-stack i,.icon-right .fa-stack i,.icon-horizontal .fa-stack i,.widget_recent-posts-widget .recent-post .readmore a,.icon-vertical .fa-stack i,.widget_image-box-widget a.more-button,.title-divider-left .widget-title::after,
							.pullnone,.icon-polygon a.more-button,.callout-widget a:hover,.share-box ul li a:hover,
							.withtip:before,.circle-icon-box .circle-icon-wrapper .fa-stack i,.widget .ei-slider-thumbs li.ei-slider-element,
							ul.ei-slider-thumbs li.ei-slider-element,.site-footer .icon-horizontal .fa-stack,
							.site-footer .icon-vertical .fa-stack,.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
							.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,
							.dropcap-box ,.toggle .toggle-title ,.circle-icon-box a.more-button:hover,
							.widget_button-widget a.btn.btn-default ,.notice,.widget_flexslider-widget .flexcarousel .flex-direction-nav a:hover,.flex-direction-nav a:hover,.page-template-portfolio-2col .entry-title:after, .page-template-portfolio-2col_text .entry-title:after, .page-template-portfolio-2col_sidebar .entry-title:after, .page-template-portfolio-3col .entry-title:after, .page-template-portfolio-3col_text .entry-title:after, .page-template-portfolio-3col_sidebar .entry-title:after, .page-template-portfolio-4col .entry-title:after, .page-template-portfolio-4col_text .entry-title:after, .page-template-portfolio .entry-title:after,.portfolio-excerpt .more-link,ul.filter-options li a:hover,
							ul.filter-options li .selected,.widget_recent-work-widget .widget-title:after,.ui-accordion h3 span,.ui-accordion h3,.widget.widget_skill-widget .skill-container .skill .skill-percentage,.widget.widget_skill-widget .widget-title:after,.widget.widget_ourteam-widget .our-team:hover .team-social ul li a,.widget.widget_ourteam-widget .team-social ul,
							.tabs.normal ul li .tabulous_active a,.title-divider .left::after,.tabs ul li .tabulous_active a,
							.tabs.normal ul li a:hover, .tabs ul li a:hover,.contact-form,.title-divider .widget-title:after,.free-home .title-divider:after,.free-home .services-wrapper .service .demo-thumb,
							.woocommerce #content nav.woocommerce-pagination ul li a:focus,.woocommerce a.remove,.woocommerce #content table.cart a.remove, .woocommerce table.cart a.remove,.woocommerce-page #content table.cart a.remove, .woocommerce-page table.cart a.remove,.woocommerce #content div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li a:hover, .woocommerce-page div.product .woocommerce-tabs ul.tabs li a:hover, .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active,.woocommerce #content nav.woocommerce-pagination ul li a:hover, .woocommerce #content nav.woocommerce-pagination ul li span.current, .woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce-page #content nav.woocommerce-pagination ul li a:focus, .woocommerce-page #content nav.woocommerce-pagination ul li a:hover, .woocommerce-page #content nav.woocommerce-pagination ul li span.current, .woocommerce-page nav.woocommerce-pagination ul li a:focus, .woocommerce-page nav.woocommerce-pagination ul li a:hover, .woocommerce-page nav.woocommerce-pagination ul li span.current,
							.btn, .widget_button-widget a.btn.btn-default,.site-footer .scroll-to-top,.site-footer .scroll-to-top:hover',
			'property' => 'background-color',
		),
        array(
			'element'  => '.site-footer .widget_social-networks-widget ul li a .fa:hover,.left-sidebar .widget.widget_skill-widget .skill-container .skill-percentage,
							.site-footer .share-box ul li a .fa:hover,.tabs.normal ul li .tabulous_active, .tabs ul li .tabulous_active,.site-footer .widget.widget_skill-widget .skill-container .skill-percentage,.woocommerce #content input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce-page #content input.button:hover, .woocommerce-page #respond input#submit:hover, .woocommerce-page a.button:hover, 
							.woocommerce-page button.button:hover, .woocommerce-page input.button:hover',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
) );

/*Modulus_kirki::add_field( 'modulus', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-modulus' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#222222',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.site-content .navigation a,
							.site-content .more-link,
							.site-content .comment-navigation a,
							.webulous_page_navi li.bpn-current,
							.header-wrap .social ul li a,
							.comment-list > li article .comment-meta .comment-author b:hover,
							.comment-list > li article .comment-meta .comment-author a:hover,
							.comment-list > li article .comment-meta .comment-author cite:hover,
							.comment-list > li article .reply:hover i,
							#primary .sticky .entry-meta a,
					  		#primary .sticky .entry-footer a,
					  		.latest-post-content a.btn-readmore,
					  		.related-posts ul#webulous-related-posts li:hover a,
					  		.site-footer .footer-widgets .widget_archive select,
						    .site-footer .footer-widgets .widget_categories select,
						    .site-footer .footer-widgets .textwidget select,
						    .widget.widget_ourteam-widget .team-content h4 span,
						    .widget_recent-posts-widget .recent-post .readmore a,
						    .alert-message a,
						    .icon-right .icon-title,
							.icon-left .icon-title,
							.icon-right a.link-title,
							.icon-right .icon-title,
							.icon-right .fa-stack,
							.icon-left a.link-title,
							.icon-left .icon-title,
							.icon-left .fa-stack,
							.widget_testimonial-widget ul li .client,
							.single-portfolio .one-third dd a:hover,
							.modulus-process.white-bg,
			  				.modulus-process.white-bg h3.widget-title,
			  				.modulus-process.white-bg .textwidget h4,
			  				.not-found-inner a:hover,
			  				.cnt-address .widget_text p:nth-of-type(1),
							.cnt-address .textwidget p:nth-of-type(1),
							#secondary.sidebar .widget_testimonial-widget h3',
			'property' => 'color',
		),
		array(
			'element' => 'table tr th:hover a,
			  				.site-header .social .recentcomments a:hover	
							.header-wrap .site-header .social .recentcomments a:hover,
							#primary .sticky a:hover,
							#primary .sticky span:hover,
							#primary .sticky time:hover,
							.left-sidebar .recentcomments a:hover,
							.left-sidebar .widget_rss a:hover,
							.wide-cta .call-btn a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),
		array(
			'element' => 'button:hover,
							input[type="button"]:hover,
							input[type="reset"]:hover,
							input[type="submit"]:hover,
							.footer-widgets .textwidget .wpcf7-form input.wpcf7-submit:hover,
							#nav-wrap,
							.main-navigation ul ul li,
							.site-content .more-link:hover,
							.webulous_page_navi li a,
							.webulous_page_navi li.bpn-next-link a,
			  				.webulous_page_navi li.bpn-prev-link a,
			  				.home .flexslider .slides .flex-caption a:hover,
			      			.home .flexslider .slides .flex-caption p a:hover,
			      			.home .flexslider .flex-control-paging li a,
			      			.share-box ul li a,
			      			.site-footer .widget_social-networks-widget ul li a:hover,
			      			#secondary select,
							.footer-widgets select,
							.widget.widget_ourteam-widget ul.team-social li a,
							.widget.widget_ourteam-widget:hover .team-social ul li a:hover,
							.widget.widget_skill-widget .skill-container .skill .skill-percentage,
							.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link,
							.widget_recent-work-widget .portfolio4col .overlay_icon a,
							#filters ul.filter-options li a:hover,
						    #filters ul.filter-options li a.selected,
						    .recent-work-container .recent_work_overlay a.icon-zoom,
						    .portfolioeffects .portfolio_link_icons a,
						    .flexslider .slides .flex-caption a:hover,
			      			.flexslider .slides .flex-caption p a:hover,
			      			.flexslider .flex-control-paging li a,
			      			.widget_recent-work-widget ul.flex-direction-nav a:hover,
			      			.widget_recent-posts-widget .recent-posts-carousel ul.flex-direction-nav a:hover,
			      			.recent-posts-slider .flex-direction-nav a:hover,
			      			.widget_recent-posts-widget .recent-posts-carousel .flex-control-nav li a,
			      			.recent-posts-slider .flex-control-paging li a,
			      			.flex-control-nav li a,
			      			.wide-default .widget_flexslider-widget .flexcarousel .flex-direction-nav a:hover,
			      			.page-slider ul.ei-slider-thumbs li a,
			      			a.btn-white:hover,
			  				.widget_button-widget .btn.white:hover,
			  				.toggle .toggle-title:hover,
			  				.circle-icon-box:hover .circle-icon-wrapper,
			  				.callout-widget .call-btn a,
			  				.wide-dark-grey .callout-widget p.call-btn a:hover,
			  				.widget_wbls-image-widget .image-widget-overlay:hover i:hover,
			  				.error-404.not-found .page-header,
			  				.cnt-form .wpcf7-form input[type="submit"]:hover,
			  				.site-footer .widget_social-networks-widget ul li a,
			  				#secondary.sidebar .callout-widget p.call-btn a:hover',
			'property' => 'background-color',
		),
        array(
			'element' => '.slicknav_menu,
				          .search-form input.search-submit:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element' => '.page-numbers,
				         .modulus-process.white-bg .textwidget img',  
			'property' => 'border-color',
		),
		array(
			'element' => '.site-content .nav-next a span,
							.withtip.left:after,
							.home .flexslider .slides .flex-caption a:after,
			      			.home .flexslider .slides .flex-caption p a:after,
			      			.home .flexslider .flex-direction-nav .flex-nav-next a,
			      			#filters ul.filter-options li a:hover:before,
			        		#filters ul.filter-options li a.selected:before,
			        		.flexslider .slides .flex-caption a:after,
			      			.flexslider .slides .flex-caption p a:after,
			      			.flexslider .flex-direction-nav .flex-nav-next a,
			      			.widget_button-widget .btn.white:hover:after,
			      			.callout-widget .call-btn a:after,
			      			.wide-dark-grey .callout-widget p.call-btn a:hover:after,
			      			.widget_testimonial-widget .flex-direction-nav a.flex-next:hover',
			'property' => 'border-left-color',
		),
		array(
			'element' => 'abbr,acronym,.withtip.bottom:after',
			'property' => 'border-bottom-color',
		),
        array(
			'element' => '.withtip.right:after,.page-numbers:last-child,
			      			.site-content .nav-previous a span,
			      			.home .flexslider .flex-direction-nav .flex-nav-prev a,
			      			.flexslider .flex-direction-nav .flex-nav-prev a,
			      			a.btn-white:hover:before,
			    			.widget_button-widget .btn.white:hover:before,
			    			.callout-widget .call-btn a:before,
			    			.wide-dark-grey .callout-widget p.call-btn a:hover:before,
			    			.widget_testimonial-widget .flex-direction-nav a.flex-prev:hover',
			'property' => 'border-right-color',
		),
        array(
			'element' => '.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link:after',
			'property' => 'border-top-color',
		),
		array(
			'element' => '.site-footer .widget_social-networks-widget ul li a:after',
			'property' => 'border-top-color',
			'suffix' => '!important',
		),
		
	),
) );*/
}


