(function( $ ) {
	$(function() {
	docs = $('<a class="modulus-docs doc"></a>')
			.attr('href','http://www.webulousthemes.com/modulus-pro/')
			.attr('target','_blank')
			.text('Documentation');     

	support = $('<a class="modulus-docs question"></a>')
			.attr('href','http://www.webulousthemes.com/support-ticket/')
			.attr('target','_blank')
			.text('Ask a Question');

			$('#customize-info .preview-notice').append(docs);
			$('#customize-info .preview-notice').append(support);

			$('.modulus-docs').on('click',function(e){
				e.stopPropagation();
			});
	});

})( jQuery );
