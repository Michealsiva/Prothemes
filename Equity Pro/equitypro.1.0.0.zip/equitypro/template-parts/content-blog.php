<?php
/**
 * Template part for displaying posts.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package EquityPro 
 */
?>      
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>> 
    <div class="entry-content"><?php 
		$featured_image = get_theme_mod( 'featured_image',true );
	    if( $featured_image ) : ?>
			<div class="thumb"><?php
				if( function_exists( 'equity_pro_featured_image' ) ) :
					equity_pro_featured_image();
		        endif; ?>
		    </div><?php   
		endif;
    	if( has_post_format( 'gallery' ) ) { ?>			    	
	    	<div id="gallery-images">
		    	<ul class="slides"><?php
		    		$galleries = get_post_gallery_images( $post );
		    		 foreach ($galleries as $gallery) { ?>
				          <li><img src=<?php echo $gallery; ?>></li>
			    <?php } ?>
		    	</ul>
	    	</div><?php 
    	}
	 
	    do_action('equity_pro_entry_header_before'); ?>
        <div class="entry-body">
	        <h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1>
				<?php if ( get_theme_mod('enable_single_post_top_meta', true ) ): ?>
					<footer class="entry-meta">
						<?php if(function_exists('equity_pro_entry_top_meta') ) {
						    equity_pro_entry_top_meta(); 
						} ?> 
					</footer><!-- .entry-footer -->
				<?php endif;
				do_action('equity_pro_entry_header_after'); 

		
				/* translators: %s: Name of current post */
				the_content();
			
				wp_link_pages( array(
					'before' => '<div class="page-links">' . __( 'Pages:', 'equity_pro' ),
					'after'  => '</div>',
				) );
			?>
			 <?php do_action('equity_pro_entry_footer_before'); ?>

					<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
						<footer class="entry-meta">
							<?php if(function_exists('equity_pro_entry_bottom_meta') ) {
							     equity_pro_entry_bottom_meta();
							} ?>
							<div class="post_info">   
							    <div class="post_share">
							        <a href="#"><i class="fa fa-share-alt"></i><?php _e('Share','equity_pro'); ?></a>
							        <div class="share_wrap">
							            <ul>
							                <li><a target="_blank" href="https://twitter.com/intent/tweet?text=<?php the_title(); ?>&amp;url=<?php the_permalink(); ?>"><span class="fa fa-twitter"></span></a></li>
							                <li><a target="_blank" href="https://www.facebook.com/share.php?u=<?php the_permalink(); ?>&amp;t=<?php the_title(); ?>"><span class="fa fa-facebook"></span></a></li>
							                <li><a target="_blank" href="http://linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>"><span class="fa fa-linkedin"></span></a></li>
							            </ul>
							        </div>
							    </div>
							    <div class="likes_block post_likes_add post_likes_add_<?php the_ID(); ?>" data-postid="<?php the_ID(); ?>" data-modify="like_post">
							        <span class="fa fa-heart icon"></span>
							        <span class="like_count"><?php echo get_simple_likes_button( get_the_ID() ); ?></span>
							    </div>							   
							</div>
						</footer><!-- .entry-footer -->
					<?php endif; ?>

			    <?php do_action('equity_pro_entry_footer_after'); ?>  
		    <br class="clear" />
		</div>
	</div><!-- .entry-content -->

   

</article><!-- #post-## -->