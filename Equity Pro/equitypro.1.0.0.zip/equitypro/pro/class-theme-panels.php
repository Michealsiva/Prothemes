<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 *
 * @package Equity Pro
 * @since 1.0
 * @license GPL 2.0   
 */
    
/**    
 * Adds default page layouts
 *
 * Adds default page layouts to SiteOrigin Page Builder prebuilt layout section
 *
 * @param $layouts      
 */
if ( ! class_exists('Equity_Pro_Prebuilt_Layouts')) { 

    class Equity_Pro_Prebuilt_Layouts { 
        public function layouts($layouts) {     
            $layouts['default-home'] = array (
				'name' => __('Equity Pro Home', 'equity_pro'),
				'description' => __('Pre Built Layout for  home page', 'equity_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/home.json',

			);

			$layouts['about-us'] = array(
				'name' => __('About Us Page', 'equity_pro'),
				'description' => __( 'Pre Built layout for about us page', 'equity_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/about-us.json',
			);

			$layouts['contact-us'] = array(
				'name' => __('Contact Us Page', 'equity_pro'),
				'description' => __( 'Pre Built layout for contact us page', 'equity_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/contact-us.json',
			);

			$layouts['faq'] = array (
				'name' => __('FAQ Page', 'equity_pro'),
				'description' => __('Pre Built Layout for faq page', 'equity_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/faq.json',
			);

			$layouts['attorney'] = array (
				'name' => __('Attorney Page', 'equity_pro'),
				'description' => __('Pre Built Layout for Individual Attorney page', 'equity_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/attorneypage.json',
			);

			$layouts['practice-area'] = array (
				'name' => __('Practice Area', 'equity_pro'),
				'description' => __('Pre Built Layout for Individual Practice Area page', 'equity_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/practice-area.json',
			);

			return $layouts;      
        }     

    }

}

