<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Equity_Pro_Theme_fields' ) ) {  
	class Equity_Pro_Theme_fields {
		
        /* Add Or Override the widegt fields */
        public function equity_pro_extend_heading_form($form_options, $widget) {
	          $form_options['divider'] = array(
			  	'type' => 'checkbox',
		        'label' => __( 'Enable Heading Divider', 'equity_pro' ),
		        'default' => true  
			  );  
			  $form_options['divider_color'] = array(
			  	'type' => 'color',
		        'label' => __( 'Choose Heading Divider Color', 'equity_pro' ),
			  ); 
			  
			  return $form_options; 

        }  

     
	}
}

