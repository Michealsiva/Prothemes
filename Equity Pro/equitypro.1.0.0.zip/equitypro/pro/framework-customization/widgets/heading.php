<div class="sow-headline-container"><?php  
$divider = ! empty( $instance['divider'] ) ? 'title-divider '. $headline_align : '';  
$divider_color = ! empty( $instance['divider_color'] ) ? 'style="border-color:' . $instance['divider_color']. '"' : '';

	if( !empty( $headline ) ) {
		echo '<' . $headline_tag . ' class="sow-headline '.  $divider .' "'. $divider_color .'><span class="td-1"><span class="td-2">' . wp_kses_post( $headline ) . '</span></span></' . $headline_tag . '>';
	}

	if( !empty( $sub_headline ) ) {
		echo '<div class="genex-sub-head-align">';
		echo '<' . $sub_headline_tag . ' class="sow-sub-headline">' . wp_kses_post( $sub_headline ) . '</' . $sub_headline_tag . '>';
	    echo '</div>';
	} ?>
	
</div>      

