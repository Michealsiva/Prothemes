<?php
$divider = ! empty( $instance['divider'] ) ? 'icon ': '';  

if( !empty( $divider ) ) {

	echo '<div class="divider">';
		echo '<div class="left hr_' . esc_attr( $type ) .'"> </div>';
			echo siteorigin_widget_get_icon( $icon, $icon_styles ); 
		echo '<div class="right hr_' . esc_attr( $type ) .'"> </div>';
	echo '</div>';
	

}
elseif($type == 'fancy' || $type == 'fancy_with_color' ) {
    echo '<div class="title-divider center hr_'. esc_attr ($type) .' "><span class="td-1"><span class="td-2"></span></span></div>';
}
else {
	echo '<div class="hr_'. esc_attr ($type) .' "></div>';
}