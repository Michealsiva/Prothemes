<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Equity_Pro_Theme_templates' ) ) {  
	class Equity_Pro_Theme_templates {

        public function equity_pro_heading_template_file( $filename, $instance, $widget  ) {
           return get_stylesheet_directory() . '/pro/framework-customization/widgets/heading.php';  
        }

        public function equity_pro_divider_template_file( $filename, $instance, $widget  ) {
           return get_stylesheet_directory() . '/pro/framework-customization/widgets/divider.php';  
        }

        public function equity_pro_team_member_template_file( $filename, $instance, $widget  ) {
           return get_stylesheet_directory() . '/pro/framework-customization/widgets/team-member.php';  
        }
 
	}
}

         
