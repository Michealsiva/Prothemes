<?php  
/**
 * Created by PhpStorm.
 * User: venkat
 * Date: 2/5/16
 * Time: 4:32 PM        
 */   
        
include_once( get_template_directory() . '/admin/kirki/kirki.php' );   
include_once( get_template_directory() . '/admin/kirki-helpers/class-theme-kirki.php' ); 
     

Equity_Kirki::add_config( 'equity_pro', array(     
    'capability'    => 'edit_theme_options',                  
    'option_type'   => 'theme_mod',          
) );               
     
// Flat option start //   

//  site identity section // 

Equity_Kirki::add_section( 'title_tagline', array(
    'title'          => __( 'Site Identity','equity_pro' ),
    'description'    => __( 'Site Header Options', 'equity_pro'),       
    'priority'       => 8,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'logo_title',
    'label'    => __( 'Enable Logo as Title', 'equity_pro' ),
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'priority' => 5,
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'off',   
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'tagline',
    'label'    => __( 'Show site Tagline', 'equity_pro' ), 
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'on',
) );  

// home panel //

Equity_Kirki::add_panel( 'home_options', array(     
    'title'       => __( 'Home', 'equity_pro' ),
    'description' => __( 'Home Page Related Options', 'equity_pro' ),     
) );  


// home page type section

Equity_Kirki::add_section( 'home_type_section', array(
    'title'          => __( 'PRO Home - General Settings','equity_pro' ),
    'description'    => __( 'Home Page options', 'equity_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'enable_home_default_content',
    'label'    => __( 'Enable Home Page Default Content', 'equity_pro' ),
    'section'  => 'home_type_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Use pagebuilder to built pro home page (or) Use prebuilt layout','equity_pro'),
) );  


// Slider section 

Equity_Kirki::add_section( 'slider_section', array(
    'title'          => __( 'Slider Section','equity_pro' ),
    'description'    => __( 'Home Page Slider Related Options', 'equity_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );
Equity_Kirki::add_field( 'equity_pro', array(  
    'settings' => 'slider_field',  
    'label'    => __( 'Enable Slider Post ( Section )', 'equity_pro' ),
    'section'  => 'slider_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Slider Post in home page','equity_pro'),
) );
 
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'slider_cat',
    'label'    => __( 'Slider Posts category', 'equity_pro' ),
    'section'  => 'slider_section',
    'type'     => 'select',
    'choices' => Kirki_Helper::get_terms( 'category' ),
    'active_callback' => array(
        array(
            'setting'  => 'slider_field', 
            'operator' => '==',
            'value'    => true, 
        ),
    ),
    'tooltip' => __('Create post ( Goto Dashboard => Post => Add New ) and Post Featured Image ( Preferred size is 1200 x 450 pixels ) as taken as slider image and Post Content as taken as Flexcaption.','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'slider_count',
    'label'    => __( 'No. of Sliders', 'equity_pro' ),
    'section'  => 'slider_section',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 999,
        'step' => 1,
    ),
    'default'  => 2,
    'active_callback' => array(
        array(
            'setting'  => 'slider_field',
            'operator' => '==',
            'value'    => true,
        ),                                                                                                                                                                                                                                                                                                                                                                          
    ),
    'tooltip' => __('Enter number of slides you want to display under your selected Category','equity_pro'),
) );

// service section 

Equity_Kirki::add_section( 'service_section', array(
    'title'          => __( 'Service Section','equity_pro' ),
    'description'    => __( 'Home Page - Service Related Options', 'equity_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Equity_Kirki::add_field( 'equity_pro', array(  
    'settings' => 'service_field',  
    'label'    => __( 'Enable Service Section', 'equity_pro' ),
    'section'  => 'service_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Service section in home page','equity_pro'),
) );

for ( $i = 1 ; $i <= 3 ; $i++ ) {
    //Create the settings Once, and Loop through it.
    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'service_section_icon_'.$i,
        'label'    => sprintf(__( 'Service Section Icons #%1$s', 'equity_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'text',
        'description' => sprintf(__( '%1$s (fa fa-apple) ', 'equity_pro' ), '<a href="http://fontawesome.io/icons/">Type FontAwesome icons</a>' ),          
        'active_callback' => array(
            array(
                'setting'  => 'service_field',
                'operator' => '==',
                'value'    => true,
            ),                                                                                                                                                                                                                                                                                                                                                                          
        ),
    ) );

    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'service_'.$i,
        'label'    => sprintf(__( 'Service Section #%1$s', 'equity_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'dropdown-pages', 
        'active_callback' => array(
            array(
                'setting'  => 'service_field',
                'operator' => '==',
                'value'    => true,
            ),                                                                                                                                                                                                                                                                                                                                                                          
        ),        
    ) );
}

/* banner form */
Equity_Kirki::add_section( 'banner_form_section', array(  
    'title'          => __( 'Request a Call Back Form','equity_pro' ),
    'description'    => __( 'Sliding Form', 'equity_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Equity_Kirki::add_field( 'equity_pro', array(   
    'settings' => 'enable_banner_form_section',  
    'label'    => __( 'Enable Request a Call Back Form', 'equity_pro' ),
    'section'  => 'banner_form_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ),
    ),
    'default'  => 'off',
) );

Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'banner_form',
        'label'    => __( 'Request a Call Back Form', 'equity_pro' ),
        'section'  => 'banner_form_section',
        'type'     => 'text', 
        'description' => __( 'Copy and paste the shortcode of the form from the contact form 7.', 'equity_pro' ),           
        'active_callback' => array(
            array(
                'setting'  => 'enable_banner_form_section',
                'operator' => '==',
                'value'    => true,
            ),                                                                                                                                                                                                                                                                                                                                                                          
        ),
        'sanitize_callback' => 'wp_kses_post',
) );


// latest blog section 

Equity_Kirki::add_section( 'latest_blog_section', array(
    'title'          => __( 'Latest Blog Section','equity_pro' ),
    'description'    => __( 'Home Page - Latest Blog Options', 'equity_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'enable_recent_post_service',
    'label'    => __( 'Enable Recent Post Section', 'equity_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),

    'default'  => 'on',
    'tooltip' => __('Enable recent post section in home page','equity_pro'),
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'recent_posts_count',
    'label'    => __( 'No. of Recent Posts', 'equity_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'number',
    'choices' => array(
        'min' => 2,
        'max' => 99,
        'step' => 2,
    ),
    'default'  => 6,
    'active_callback' => array(
        array(
            'setting'  => 'enable_recent_post_service',
            'operator' => '==',
            'value'    => true,
        ),

    ),
) );


// general panel      

Equity_Kirki::add_panel( 'general_panel', array(   
    'title'       => __( 'General Settings', 'equity_pro' ),  
    'description' => __( 'general settings', 'equity_pro' ),         
) );
//  Page title bar section // 

Equity_Kirki::add_section( 'header-pagetitle-bar', array(   
    'title'          => __( 'Page Title Bar & Breadcrumb','equity_pro' ),
    'description'    => __( 'Page Title bar related options', 'equity_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) ); 
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'global_page_title_bar',
    'label'    => __( 'Check the box if you want to use a global page title bar settings. This option overrides the page options', 'equity_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'checkbox',
    'default' => '0',
) );   

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'page_titlebar',  
    'label'    => __( 'Page Title Bar', 'equity_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( 'Show Bar and Content', 'equity_pro' ),
        2 => __('Hide','equity_pro'),
    ),
    'default' => 1,
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'page_titlebar_text',  
    'label'    => __( 'Page Title Bar Text', 'equity_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        0 => __( 'Show', 'equity_pro' ),
        1 => __( 'Hide', 'equity_pro' ), 
    ),
    'default' => 0,
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'breadcrumb',  
    'label'    => __( 'Hide Breadcrumb', 'equity_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'checkbox',
    'default'  => 0,
) ); 

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'breadcrumb_char',
    'label'    => __( 'Breadcrumb Character', 'equity_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( ' >> ', 'equity_pro' ),
        2 => __( ' / ', 'equity_pro' ),
        3 => __( ' > ', 'equity_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'breadcrumb',
            'operator' => '==',
            'value'    => 0,
        ),
    ),
    //'sanitize_callback' => 'allow_htmlentities'
) );

//  pagination section // 

Equity_Kirki::add_section( 'general-pagination', array(   
    'title'          => __( 'Pagination','equity_pro' ),
    'description'    => __( 'Pagination related options', 'equity_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'numeric_pagination',
    'label'    => __( 'Numeric Pagination', 'equity_pro' ),   
    'section'  => 'general-pagination',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Numbered', 'equity_pro' ),
        'off' => esc_attr__( 'Next/Previous', 'equity_pro' )
    ),
    'default'  => 'on',
) );

// skin color panel 

Equity_Kirki::add_panel( 'skin_color_panel', array(   
    'title'       => __( 'Skin Color', 'equity_pro' ),  
    'description' => __( 'Color Settings', 'equity_pro' ),         
) );
// color scheme section 

Equity_Kirki::add_section( 'multiple_color_section', array(
    'title'          => __( 'Color Scheme','equity_pro' ),
    'description'    => __( 'Select your color scheme', 'equity_pro'),
    'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 9,
) );  

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'color_scheme',
    'label'    => __( 'Select your color scheme', 'equity_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'palette',
    'choices'     => array( 
        '1' => array(
            '#cc8800',
        ),
        '2' => array(
            '#1e8ad2',
        ),
        '3' => array(
            '#009688',
        ),
        '4' => array(
            '#ff5722',
        ),
        '5' => array(
            '#f05020',
        ),
    ),
    'default' => '1',
//'default'  => 'on',
) );
// skin color panel 

Equity_Kirki::add_panel( 'skin_color_panel', array(   
    'title'       => __( 'Skin Color', 'equity_pro' ),  
    'description' => __( 'Color Settings', 'equity_pro' ),         
) );

// Change Color Options

Equity_Kirki::add_section( 'primary_color_field', array(
    'title'          => __( 'Change Color Options','equity_pro' ),
    'description'    => __( 'This will reflect in links, buttons,Navigation and many others. Choose a color to match your site.', 'equity_pro'),
    'panel'          => 'skin_color_panel', // Not typically needed.
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'enable_primary_color',
    'label'    => __( 'Enable Custom Primary color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'off',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'primary_color',
    'label'    => __( 'Primary color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => '#cc8800',
    'alpha'  => true,
    'active_callback' => array(
        array (
            'setting'  => 'enable_primary_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array( 
        array(
            'element'  => 'input[type="text"]:focus,.title-divider,
input[type="email"]:focus,
input[type="url"]:focus,
input[type="password"]:focus,
input[type="search"]:focus,
textarea:focus,.title-divider.hr_fancy,button:hover,
input[type="button"]:hover,
input[type="reset"]:hover,
input[type="submit"]:hover,.ui-accordion h3 span',
            'property' => 'border-color',
        ),
        array(
            'element'  => 'button,
input[type="button"],.woocommerce #content nav.woocommerce-pagination ul li a:focus,
.woocommerce #content nav.woocommerce-pagination ul li a:hover,
.woocommerce #content nav.woocommerce-pagination ul li span.current,
.woocommerce nav.woocommerce-pagination ul li a:focus,
.woocommerce nav.woocommerce-pagination ul li a:hover,
.woocommerce nav.woocommerce-pagination ul li span.current,
.woocommerce-page #content nav.woocommerce-pagination ul li a:focus,
.woocommerce-page #content nav.woocommerce-pagination ul li a:hover,
.woocommerce-page #content nav.woocommerce-pagination ul li span.current,
.woocommerce-page nav.woocommerce-pagination ul li a:focus,
.woocommerce-page nav.woocommerce-pagination ul li a:hover,
.woocommerce-page nav.woocommerce-pagination ul li span.current,
input[type="reset"],.widget_calendar table caption,.widget_tag_cloud a ,    .so-widget-flexslider-widget .flexcarousel .flex-direction-nav a:hover, .so-widget-recent-posts-widget .flexcarousel .flex-direction-nav a:hover,.ui-accordion .ui-accordion-header-active,
#secondary .left-sidebar .callout-widget,.dropcap-circle,
.dropcap-box,.left-sidebar .dropcap-circle,
.left-sidebar .dropcap-box,.widget .ei-slider-thumbs li.ei-slider-element,
ul.ei-slider-thumbs li.ei-slider-element,.flexslider .flex-direction-nav a:hover, .flexslider:hover .flex-direction-nav a.flex-prev:hover ,.flexslider:hover .flex-direction-nav a.flex-next:hover ,
.flexslider .flex-caption a, .flexslider .flex-caption p a,ol.flex-control-paging li a.flex-active, ol.flex-control-paging li a:hover ,
.flex-direction-nav a:hover,
.icon-box a.more-button:hover,.gx-pricing-table:hover .btn-normal,.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next, .so-widget-skills-widget .skill-container .skill .skill-percentage,.share-box ul li a:hover ,
input[type="submit"],.menu-toggle ul li a:hover,
.main-navigation.toggled ul.menu.nav-menu ul li a:hover,
.slicknav_menu ul li a:hover,.slicknav_btn:hover,a.more-link,.share-box ul li a:hover,.comment-meta .edit-link a:hover,
.hentry.sticky,  .hentry.sticky .entry-footer span,.page-links,#banner-form .banner-form-title,
.tabs.normal ul li a:hover, .tabs ul li a:hover , .team-member h4,
.withtip:before,#primary .widget_nav_menu ul .current_page_item,.nav-links .nav-previous:hover a,
.more-link .nav-previous:hover a, .comment-navigation .nav-previous:hover a ,.top-nav .widget_search .search-form .search-submit-wrapper:before,#banner-form .pull_feedback,
.woocommerce #content div.product .woocommerce-tabs ul.tabs li a:hover,
.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,
.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li a:hover,
.woocommerce-page div.product .woocommerce-tabs ul.tabs li a:hover,.top-nav .widget_search .search-form .search-submit-wrapper .search-submit,ul.filter-options li a:hover, ul.filter-options li .selected,
.woocommerce #content div.product .woocommerce-tabs ul.tabs li.active,
.woocommerce div.product .woocommerce-tabs ul.tabs li.active,.site-footer .widget_social-networks-widget ul li a .fa,
.site-footer .share-box ul li a .fa,.widget_stats-widget .stat-container .icon-wrapper .sow-icon-fontawesome,.scroll-to-top,.main-navigation button.menu-toggle:hover ,
.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active,
.woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, .widget_search .search-form input[type="submit"] ,.portfolio-excerpt .more-link ,.breadcrumb,.callout-widget a:hover,.dropcap-book',
            'property' => 'background-color',
        ),
        array(
            'element'  => '.woocommerce #content input.button:hover,.site-footer .widget.widget_skill-widget .skill-container .skill-percentage, .left-sidebar .widget.widget_skill-widget .skill-container .skill-percentage,
.woocommerce #respond input#submit:hover,
.woocommerce a.button:hover,
.woocommerce button.button:hover,
.woocommerce input.button:hover,
.woocommerce-page #content input.button:hover,
.woocommerce-page #respond input#submit:hover,
.woocommerce-page a.button:hover,
.woocommerce-page button.button:hover,.tabs.normal ul li .tabulous_active, .tabs ul li .tabulous_active,
.woocommerce-page input.button:hover,.site-footer .widget_social-networks-widget ul li a .fa:hover,
.site-footer .share-box ul li a .fa:hover,.top-nav .widget_search .search-form .search-submit-wrapper .search-submit',
            'property' => 'background-color',
            'suffix' => '!important',
        ),
        array(
            'element'  => '.main-navigation .sub-menu a:hover, .main-navigation .sub-menu .current-menu-item > a, .main-navigation .sub-menu .current-menu-parent > a,.main-navigation li.menu-item-has-children > a:hover:after ,
.main-navigation a:hover,
.main-navigation .current_page_item > a,
.main-navigation .current-menu-item > a,
.main-navigation .current-menu-parent > a,
.main-navigation .current_page_ancestor > a,.nav-links .nav-previous:hover a .meta-nav,
.more-link .nav-previous:hover a .meta-nav, .comment-navigation .nav-previous:hover a .meta-nav,.nav-links .nav-next:hover a .meta-nav,
.more-link .nav-next:hover a .meta-nav, .comment-navigation .nav-next:hover a .meta-nav ,
.main-navigation .current_page_parent > a ,.top-nav a:hover,.comment-author .fn a ,ol.comment-list article .fn:hover ,.comment-metadata a ,.hentry.post h1 a:hover, .entry-meta .date-structure .dd,.entry-meta span i ,    .entry-meta span a ,.entry-footer span i ,.entry-footer span a ,.post .latest-content .entry-title a:hover ,
.post .latest-content a.more-link,.post a.more-link ,.post_info .post_share > a i,.post_info .post_share .share_wrap ul li a:hover , .post_info .likes_block .fa , .services-wrapper .service-section .service-image .fa,.services-wrapper .service-section .service-content .service-title a:hover,.post-wrapper .latest-posts .latest-post-details h4 a:hover,
.post-wrapper .latest-posts .latest-post-details .btn-readmore ,.services-wrapper a.more-link, .post-wrapper a.more-link,.order-total .amount,
.cart-subtotal .amount,.dropcap,.left-sidebar .dropcap,
.woocommerce #content table.cart a.remove,  .pullright:before,
.pullleft:before,
.pullnone:before ,    .widget_recent-posts-widget .recent-posts .latest-post-details .btn-readmore, .widget_recent-posts-widget .recent-posts-carousel .latest-post-details .btn-readmore,.widget_recent-posts-widget .recent-posts-slider .flex-caption a:hover,.site-footer .widget_recent-posts-widget .latest-post-details h3 a:before,
.widget_recent-posts-widget .recent-posts .latest-post-details h3 a:hover, .widget_recent-posts-widget .recent-posts-carousel .latest-post-details h3 a:hover,
.woocommerce table.cart a.remove,.icon-box .icon-wrapper span, .left-sidebar .widget_recent-posts-widget .flex-recent-posts li a,
.woocommerce-page #content table.cart a.remove,      .widget_recent-work-widget .portfolioeffects .content-details h3 a:hover, .widget_recent-work-widget .work .content-details h3 a:hover,      .portfolioeffects .content-details h3 a:hover, .work .content-details h3 a:hover,.left-sidebar .widget_social-networks-widget ul li a:hover i ,.site-footer .widget.widget_ourteam-widget:hover .team-content h4 ,  #secondary .left-sidebar .widget.widget_ourteam-widget .team-content h4,.footer-widgets a:hover ,
.site-info .left-sidebar .textwidget ul li a:hover,.site-info p a,.site-info .widget_nav_menu a:hover,
.woocommerce-page table.cart a.remove,
.woocommerce .woocommerce-breadcrumb a:hover,
.woocommerce-page .woocommerce-breadcrumb a:hover,.widget-area ul li a:hover,#secondary #recentcomments a:hover,.widget_calendar table th a, .widget_calendar table td a ,
.widget-area .widget_rss span, .widget-area .widget_rss a:hover,ul#portfolio li h3 a:hover,.ui-accordion h3 span',  
            'property' => 'color',
        ),
        array(
            'element'  => '.main-navigation a:hover:after,
.main-navigation .current_page_item > a:after,.branding .site-branding .site-title a:hover ,
.main-navigation .current-menu-item > a:after,
.main-navigation .current-menu-parent > a:after,
.main-navigation .current_page_ancestor > a:after,
.main-navigation .current_page_parent > a:after , .post-navigation a',
            'property' => 'color',
            'suffix' => '!important',
        ),
        array(
            'element' => 'abbr, acronym',
            'property' => 'border-bottom-color',
        ),
        
    ),
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'enable_secondary_color',
    'label'    => __( 'Enable Custom Secondary color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'off',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'secondary_color',
    'label'    => __( 'Secondary Color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => '#1a1d25',
    'alpha'  => true,
    'active_callback' => array(
        array(
            'setting'  => 'enable_secondary_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array(
        array(
            'element' => 'h1, h2, h3, h4, h5, h6,table,table thead tr th,.main-navigation ul ul a,.post-navigation .meta-previuous-post, .post-navigation .meta-next-post,
.nav-links .meta-nav,.entry-meta .date-structure:hover .dd,.entry-meta span a:hover,.entry-meta span:hover i,
.more-link .meta-nav, .comment-navigation .meta-nav,.share-box .widget-title ,.share-box ul li a,.comment-content p,.comment-author,.comment-author .fn a:hover ,ol.comment-list article .fn ,ol.comment-list li.byuser .comment-metadata a:hover , .comment-metadata a:hover,
.hentry.sticky .entry-meta .date-structure:hover .dd,.hentry.sticky h3.entry-title a:hover , .hentry.sticky a:hover,
.entry-footer span a:hover,.page-links a,.post .latest-content .entry-title a, .post .latest-content .entry-content,.post .latest-content .entry-content p,.post .latest-content a.more-link:hover,.post a.more-link:hover,.post_info .post_share .share_wrap ul li a,.post_info .likes_block .fa:hover,.services-wrapper .service-section .service-content,.services-wrapper .service-section .service-content .service-title a,
.post-wrapper .latest-posts .latest-post-details h4 a,.post-wrapper .latest-posts .latest-post-details .entry-meta .data-structure span:hover,
.post-wrapper .latest-posts .latest-post-details .latest-post-content,.post-wrapper .latest-posts .latest-post-details .btn-readmore:hover,
.services-wrapper a.more-link:hover, .post-wrapper a.more-link:hover,
.woocommerce ul.products li.product .price,
.woocommerce-page ul.products li.product .price,
.woocommerce #content div.product p.price,
.woocommerce #content div.product span.price,
.woocommerce div.product p.price,
.woocommerce div.product span.price,.portfolioeffects .overlay_icon a:hover i,ul#portfolio li h3 a,.breadcrumb a,.ui-accordion .ui-accordion-content,.callout-widget a ,
.flexslider .flex-caption,.gx-pricing-table .gx-table-rate,.gx-pricing-table .gx-table-content li .fa,.gx-pricing-table .price-btn .btn-normal,
.pullright,
.pullleft,
.pullnone,.widget_recent-posts-widget .recent-posts .latest-post-details .btn-readmore:hover, .widget_recent-posts-widget .recent-posts-carousel .latest-post-details .btn-readmore:hover,.widget_recent-posts-widget .recent-posts-slider .flex-caption h4 p.btn-slider a ,
.so-widget-skills-widget .skill-container .skill span,.skill-circle .chart-per,.skill-circle .label,.share-box .widget-title,.share-box ul li a,.tabs.normal .tabs_container, .tabs .tabs_container,.team-social ul li a:hover,.so-widget-testimonial-widget ul li p.client a ,
.footer-widgets a,.site-footer,.site-footer .footer-widgets,.site-footer .footer-widgets h3.widget-title,
.woocommerce-page #content div.product p.price,
.woocommerce-page #content div.product span.price,
.woocommerce-page div.product p.price,
.woocommerce-page div.product span.price,.woocommerce .woocommerce-breadcrumb,.woocommerce-breadcrumb-class,
.widget_calendar table th a:hover, .widget_calendar table td a:hover,.widget_calendar table th,
.widget_calendar table tbody tr th, .widget_calendar table tbody tr td,.widget-area .widget_rss a,.widget-area .widget_rss .widget-title .rsswidget,.widget_search .search-form input[type="search"]
',
            'property' => 'color',
        ),
        array(
            'element' => '.post-navigation a:hover , .hentry.sticky .entry-meta a:hover,.entry-meta .cat-links a:hover,
.widget_search .search-form input[type="search"]:focus',
            'property' => 'color',
            'suffix' => '!important',
        ),
        array(
            'element' => '.woocommerce #content input.button,
.woocommerce #respond input#submit,
.woocommerce a.button,
.woocommerce button.button,
.woocommerce input.button,
.woocommerce-page #content input.button,
.woocommerce-page #respond input#submit,
.woocommerce-page a.button,
.woocommerce-page button.button,button:hover,
input[type="button"]:hover,
input[type="reset"]:hover,
input[type="submit"]:hover ,.header-image ,.nav-wrap,a.more-link:hover ,.share-box ul li a,.woocommerce #content table.cart a.remove:hover,
.woocommerce table.cart a.remove:hover,
.woocommerce-page #content table.cart a.remove:hover,
.woocommerce-page table.cart a.remove:hover,.woocommerce #content nav.woocommerce-pagination ul li a,
.woocommerce #content nav.woocommerce-pagination ul li span,
.woocommerce nav.woocommerce-pagination ul li a,
.woocommerce nav.woocommerce-pagination ul li span,
.woocommerce-page #content nav.woocommerce-pagination ul li a,
.woocommerce-page #content nav.woocommerce-pagination ul li span,
.woocommerce-page nav.woocommerce-pagination ul li a,
.woocommerce-page nav.woocommerce-pagination ul li span,.woocommerce #content nav.woocommerce-pagination ul li,
.woocommerce #content nav.woocommerce-pagination ul, #secondary .left-sidebar .callout-widget a:hover ,.flexslider:hover .flex-direction-nav a.flex-prev ,.flexslider:hover .flex-direction-nav a.flex-next,
.flexslider .flex-caption a:hover, .flexslider .flex-caption p a:hover,ol.flex-control-paging li a,.icon-box a.more-button,.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev:hover,
.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next:hover,.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev:hover,
.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next:hover ,.team-social ul li a:hover ,.site-footer .footer-widgets .widget_tag_cloud a:hover,
.woocommerce-page input.button,.woocommerce #content div.product .woocommerce-tabs ul.tabs li,
.woocommerce div.product .woocommerce-tabs ul.tabs li,
.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li,
.woocommerce-page div.product .woocommerce-tabs ul.tabs li ,.widget_tag_cloud a:hover,.portfolio-excerpt .more-link:hover,
.so-widget-flexslider-widget .flexcarousel .flex-direction-nav a, .so-widget-recent-posts-widget .flexcarousel .flex-direction-nav a,.flexslider .flex-direction-nav a ,
.flex-direction-nav a,  .widget_recent-posts-widget .recent-posts-carousel ol.flex-control-paging li a.flex-active, .widget_recent-posts-widget .recent-posts-carousel ol.flex-control-paging li a:hover, ul.filter-options li a,
.site-footer .footer-widgets select,.site-info ,.main-navigation button.menu-toggle',
            'property' => 'background-color',
        ),
        array(
            'element' => '.left-sidebar .widget.widget_skill-widget .skill-container .skill',
            'property' => 'background-color',
            'suffix' => '!important',
        ),
        array(
            'element' => 'button:hover,.site-footer .dropcap-box,
input[type="button"]:hover,
input[type="reset"]:hover,
input[type="submit"]:hover,button:focus,
input[type="button"]:focus,
input[type="reset"]:focus,
input[type="submit"]:focus,
button:active,
input[type="button"]:active,
input[type="reset"]:active,
input[type="submit"]:active',
            'property' => 'border-color',   
        ),
        
    ),
) );

/* navogation font and hover color */

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'enable_nav_font_color',
    'label'    => __( 'Enable Navigation Font color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'off',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'nav_font_color',
    'label'    => __( 'Navigation Font color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => '#ffffff',
    'alpha'  => true,
    'active_callback' => array(
        array (
            'setting'  => 'enable_nav_font_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array(
        array(
            'element' => '.main-navigation a',
            'property' => 'color',
        ),
    ),
    
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'enable_nav_hover_color',
    'label'    => __( 'Enable Navigation Hover color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'off',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'nav_hover_color',
    'label'    => __( 'Navigation Hover color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => '#cc8800',
    'alpha'  => true,
    'active_callback' => array(
        array (
            'setting'  => 'enable_nav_hover_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array(
        array(
            'element' => '.main-navigation li.menu-item-has-children > a:hover::after,.main-navigation a:hover, .main-navigation .current_page_item > a, .main-navigation .current-menu-item > a, .main-navigation .current-menu-parent > a, .main-navigation .current_page_ancestor > a, .main-navigation .current_page_parent > a, .main-navigation a:hover::after, .main-navigation .current_page_item > a::after, .main-navigation .current-menu-item > a::after, .main-navigation .current-menu-parent > a::after, .main-navigation .current_page_ancestor > a::after, .main-navigation .current_page_parent > a::after',
                                                                                       
            'property' => 'color',
            'suffix' => '!important',
        ),
    ),
    
) );

/* dropdown font and bg color */
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'enable_nav_dd_bg_color',
    'label'    => __( 'Enable Sub-Navigation Dropdown background color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'off',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'nav_dd_bg_color',
    'label'    => __( 'Sub-Navigation Dropdown background color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => '#ffffff',
    'alpha'  => true,
    'active_callback' => array(
        array (
            'setting'  => 'enable_nav_dd_bg_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array(
        array(
            'element' => '.main-navigation ul ul::before,.main-navigation ul ul li',
            'property' => 'background-color',
        ),
    ),
    
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'enable_dd_font_color',
    'label'    => __( 'Enable Dropdown Font color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'off',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'dd_font_color',
    'label'    => __( 'Dropdown Font color', 'equity_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => '#1a1d25',
    'alpha'  => true,
    'active_callback' => array(
        array (
            'setting'  => 'enable_dd_font_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array(
        array(
            'element' => '.main-navigation ul ul a',
            'property' => 'color',
        ),
    ),
    
) );


// typography panel //  

Equity_Kirki::add_panel( 'typography', array( 
    'title'       => __( 'Typography', 'equity_pro' ),
    'description' => __( 'Typography and Link Color Settings', 'equity_pro' ),
) );
   
    Equity_Kirki::add_section( 'typography_section', array(
        'title'          => __( 'General Settings','equity_pro' ),
        'description'    => __( 'General Settings', 'equity_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );
        

    Equity_Kirki::add_section( 'body_font', array(
        'title'          => __( 'Body Font','equity_pro' ),
        'description'    => __( 'Specify the body font properties', 'equity_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) ); 

    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'body_typography',
        'label'    => __( 'Enable Custom body Settings', 'equity_pro' ),
        'section'  => 'body_font',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'equity_pro' ),
            'off' => esc_attr__( 'Disable', 'equity_pro' )
        ),
        'tooltip' => __('Turn on to body typography and turn off for default typography','equity_pro'),
        'default'  => 'off',
    ) );


    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'body',
        'label'    => __( 'Body Settings', 'equity_pro' ),
        'section'  => 'body_font', 
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Open Sans', 
            'variant'        => 'regular',
            'font-size'      => '16px',  
            'line-height'    => '1.5',
            'letter-spacing' => '0',
            'color'          => '#1a1d25', 
        ),
        'output'      => array(
            array(
                'element' => 'body',
                //'suffix' => '!important',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'body_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );


    Equity_Kirki::add_section( 'heading_section', array(
        'title'          => __( 'Heading Font','equity_pro' ),
        'description'    => __( 'Specify typography of H1, H2, H3, H4, H5, H6', 'equity_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'heading_one_typography',
        'label'    => __( 'Enable Custom H1 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'equity_pro' ),
            'off' => esc_attr__( 'Disable', 'equity_pro' )
        ),
        'tooltip' => __('Turn on to H1 typography and turn off for default typography','equity_pro'),
        'default'  => 'off',
    ) );


    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'h1',  
        'label'    => __( 'H1 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Hind',
            'variant'        => '700',
            'font-size'      => '48px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#1a1d25',
        ),
        'output'      => array(
            array(
                'element' => 'h1',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_one_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );
    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'heading_two_typography',
        'label'    => __( 'Enable Custom H2 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'equity_pro' ),
            'off' => esc_attr__( 'Disable', 'equity_pro' )
        ),
        'tooltip' => __('Turn on to H2 typography and turn off for default typography','equity_pro'),
        'default'  => 'off',
    ) );


    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'h2',
        'label'    => __( 'H2 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Hind',
            'variant'        => '700',
            'font-size'      => '36px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#1a1d25',
        ),
        'output'      => array(
            array(
                'element' => 'h2',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_two_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'heading_three_typography',
        'label'    => __( 'Enable Custom H3 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'equity_pro' ),
            'off' => esc_attr__( 'Disable', 'equity_pro' )
        ),
        'tooltip' => __('Turn on to H3 typography and turn off for default typography','equity_pro'),
        'default'  => 'off',
    ) );


    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'h3',
        'label'    => __( 'H3 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default' => array(
            'font-family'    => 'Hind',
            'variant'        => '700',
            'font-size'      => '30px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#1a1d25',
        ),
        'output'      => array(
            array(
                'element' => 'h3',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_three_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'heading_four_typography',
        'label'    => __( 'Enable Custom H4 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'equity_pro' ),
            'off' => esc_attr__( 'Disable', 'equity_pro' )
        ),
        'tooltip' => __('Turn on to H4 typography and turn off for default typography','equity_pro'),
        'default'  => 'off',
    ) );


    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'h4',
        'label'    => __( 'H4 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Hind',
            'variant'        => '700',
            'font-size'      => '24px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#1a1d25',
        ),
        'output'      => array(
            array(
                'element' => 'h4',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_four_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'heading_five_typography',
        'label'    => __( 'Enable Custom H5 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'equity_pro' ),
            'off' => esc_attr__( 'Disable', 'equity_pro' )
        ),
        'tooltip' => __('Turn on to H5 typography and turn off for default typography','equity_pro'),
        'default'  => 'off',
    ) );



    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'h5',
        'label'    => __( 'H5 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Hind',
            'variant'        => '700',
            'font-size'      => '18px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#1a1d25',
        ),
        'output'      => array(
            array(
                'element' => 'h5',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_five_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );

    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'heading_six_typography',
        'label'    => __( 'Enable Custom H6 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'equity_pro' ),
            'off' => esc_attr__( 'Disable', 'equity_pro' )
        ),
        'tooltip' => __('Turn on to H6 typography and turn off for default typography','equity_pro'),
        'default'  => 'off',
    ) );



    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'h6',
        'label'    => __( 'H6 Settings', 'equity_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Hind', 
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#1a1d25',
        ),
        'output'      => array(
            array(
                'element' => 'h6',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_six_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    // navigation font 
    Equity_Kirki::add_section( 'navigation_section', array(
        'title'          => __( 'Navigation Font','equity_pro' ),
        'description'    => __( 'Specify Navigation font properties', 'equity_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'navigation_font_status',
        'label'    => __( 'Enable Navigation Font Settings', 'equity_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'equity_pro' ),
            'off' => esc_attr__( 'Disable', 'equity_pro' )
        ),
        'tooltip' => __('Turn on to Navigation Font typography and turn off for default typography','equity_pro'),
        'default'  => 'off',
    ) );

    Equity_Kirki::add_field( 'equity_pro', array(
        'settings' => 'navigation_font',
        'label'    => __( 'Navigation Font Settings', 'equity_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Open Sans',
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8', 
            'letter-spacing' => '0',
            'color'          => '#ffffff',
        ),
        'output'      => array(
            array(
                'element' => '.main-navigation a',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'navigation_font_status',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );



// header panel //  

Equity_Kirki::add_panel( 'header_panel', array(     
    'title'       => __( 'Header', 'equity_pro' ),
    'description' => __( 'Header Related Options', 'equity_pro' ), 
) );  

/* STICKY HEADER section */     
  
Equity_Kirki::add_section( 'stricky_header', array(
    'title'          => __( 'Sticky Menu','equity_pro' ),
    'description'    => __( 'sticky header', 'equity_pro'),
    'panel'          => 'header_panel', // Not typically needed.
) );
Equity_Kirki::add_field( 'equity_pro', array(    
    'settings' => 'sticky_header',
    'label'    => __( 'Enable Sticky Header', 'equity_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'on',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'sticky_header_position',
    'label'    => __( 'Enable Sticky Header Position', 'equity_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'top'  => esc_attr__( 'Top', 'equity_pro' ),
        'bottom' => esc_attr__( 'Bottom', 'equity_pro' )
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'sticky_header',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'top',
) );
/*
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'header_top_margin',
    'label'    => __( 'Header Top Margin', 'equity_pro' ),
    'description' => __('Select the top margin of header in pixels','equity_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'header_bottom_margin',
    'label'    => __( 'Header Bottom Margin', 'equity_pro' ),
    'description' => __('Select the bottom margin of header in pixels','equity_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );*/

Equity_Kirki::add_section( 'header_image', array(
    'title'          => __( 'Header Background Image','equity_pro' ),
    'description'    => __( 'Custom Header Image options', 'equity_pro'),
    'panel'          => 'header_panel', // Not typically needed.  
) );

Equity_Kirki::add_field( 'equity_pro', array(   
    'settings' => 'header_bg_size',
    'label'    => __( 'Header Background Size', 'equity_pro' ),
    'section'  => 'header_image',
    'type'     => 'radio-buttonset', 
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'equity_pro' ),
        'contain' => esc_attr__( 'Contain', 'equity_pro' ),
        'auto'  => esc_attr__( 'Auto', 'equity_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'equity_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Header Background Image Size','equity_pro'),
) );

/*Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'header_height',
    'label'    => __( 'Header Background Image Height', 'equity_pro' ),
    'section'  => 'header_image',
    'type'     => 'number',
    'choices' => array(
        'min' => 100,
        'max' => 600,
        'step' => 1,
    ),
    'default'  => '213',
) ); */
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'header_bg_repeat',
    'label'    => __( 'Header Background Repeat', 'equity_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'equity_pro'),
        'repeat' => esc_attr__('Repeat', 'equity_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','equity_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'repeat',  
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'header_bg_position', 
    'label'    => __( 'Header Background Position', 'equity_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'equity_pro'),
        'center center' => esc_attr__('Center Center', 'equity_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'equity_pro'),
        'left top' => esc_attr__('Left Top', 'equity_pro'),
        'left center' => esc_attr__('Left Center', 'equity_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'equity_pro'),
        'right top' => esc_attr__('Right Top', 'equity_pro'),
        'right center' => esc_attr__('Right Center', 'equity_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'center center',  
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'header_bg_attachment',
    'label'    => __( 'Header Background Attachment', 'equity_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'equity_pro'),
        'fixed' => esc_attr__('Fixed', 'equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'scroll',  
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'header_overlay',
    'label'    => __( 'Enable Header( Background ) Overlay', 'equity_pro' ),
    'section'  => 'header_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'off',
) );
  
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'header_overlay_color',
    'label'    => __( 'Header Overlay ( Background )color', 'equity_pro' ),
    'section'  => 'header_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'output'   => array(
        array(
            'element'  => '.overlay-header',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

/*
/* e-option start */
/*
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'custon_favicon',
    'label'    => __( 'Custom Favicon', 'equity_pro' ),
    'section'  => 'header',
    'type'     => 'upload',
    'default'  => '',
) ); */
/* e-option start */ 
/* Blog page section */


/* Blog panel */

Equity_Kirki::add_panel( 'blog_panel', array(     
    'title'       => __( 'Blog', 'equity_pro' ),
    'description' => __( 'Blog Related Options', 'equity_pro' ),     
) ); 
Equity_Kirki::add_section( 'blog', array(
    'title'          => __( 'Blog Page','equity_pro' ),
    'description'    => __( 'Blog Related Options', 'equity_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
  
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'blog_layout',
    'label'    => __( 'Select Blog Page Layout you prefer', 'equity_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1  => esc_attr__( 'Default ( One Column )', 'equity_pro' ),
        2 => esc_attr__( 'Two Columns ', 'equity_pro' ),
        3 => esc_attr__( 'Three Columns ( Without Sidebar ) ', 'equity_pro' ),
        4 => esc_attr__( 'Two Columns With Masonry', 'equity_pro' ),
        5 => esc_attr__( 'Three Columns With Masonry ( Without Sidebar ) ', 'equity_pro' ),
        6 => esc_attr__( 'Blog FullWidth', 'equity_pro' ),
    ),
    'default'  => 1,
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'featured_image',
    'label'    => __( 'Enable Featured Image', 'equity_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for blog page','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'more_text',
    'label'    => __( 'More Text', 'equity_pro' ),
    'section'  => 'blog',
    'type'     => 'text',
    'description' => __('Text to display in case of text too long','equity_pro'),
    'default' => __('Read More','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'featured_image_size',
    'label'    => __( 'Choose the Featured Image Size for Blog Page', 'equity_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1 => esc_attr__( 'Large Featured Image', 'equity_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'equity_pro' ),
        3 => esc_attr__( 'Original Size', 'equity_pro' ),
        4 => esc_attr__( 'Medium', 'equity_pro' ),
        5 => esc_attr__( 'Large', 'equity_pro' ), 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Set large and medium image size: Goto Dashboard => Settings => Media', 'equity_pro') ,
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'enable_single_post_top_meta',
    'label'    => __( 'Enable to display top post meta data', 'equity_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'single_post_top_meta',
    'label'    => __( 'Activate and Arrange the Order of Top Post Meta elements', 'equity_pro' ),
    'section'  => 'blog',
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'equity_pro' ),
        2 => esc_attr__( 'author', 'equity_pro' ),
        3 => esc_attr__( 'comment', 'equity_pro' ),
        4 => esc_attr__( 'category', 'equity_pro' ),
        5 => esc_attr__( 'tags', 'equity_pro' ),
        6 => esc_attr__( 'edit', 'equity_pro' ),
    ),
    'default'  => array(1, 2, 3,6),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_top_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','equity_pro'),

) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'enable_single_post_bottom_meta',
    'label'    => __( 'Enable to display bottom post meta data', 'equity_pro' ),
    'section'  => 'blog', 
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','equity_pro'),
    'default'  => 'on',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'single_post_bottom_meta',
    'label'    => __( 'Activate and arrange the Order of Bottom Post Meta elements', 'equity_pro' ),
    'section'  => 'blog',    
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'equity_pro' ),
        2 => esc_attr__( 'author', 'equity_pro' ),
        3 => esc_attr__( 'comment', 'equity_pro' ),
        4 => esc_attr__( 'category', 'equity_pro' ),
        5 => esc_attr__( 'tags', 'equity_pro' ),
        6 => esc_attr__( 'edit', 'equity_pro' ),
    ),
    'default'  => array(4,5),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_bottom_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','equity_pro'),
) );


/* Single Blog page section */

Equity_Kirki::add_section( 'single_blog', array(
    'title'          => __( 'Single Blog Page','equity_pro' ),
    'description'    => __( 'Single Blog Page Related Options', 'equity_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'single_featured_image',
    'label'    => __( 'Enable Single Post Featured Image', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for Single Post Page','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'single_featured_image_size',
    'label'    => __( 'Choose the featured image display type for Single Post Page', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Large Featured Image', 'equity_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'equity_pro' ),
        3 => esc_attr__( 'FullWidth Featured Image', 'equity_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'author_bio_box',
    'label'    => __( 'Enable Author Bio Box below single post', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'off',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'related_posts',
    'label'    => __( 'Show Related Posts', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Show the Related Post for Single Blog Page','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'related_posts_hierarchy',
    'label'    => __( 'Related Posts Must Be Shown As:', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Related Posts By Tags', 'equity_pro' ),
        2 => esc_attr__( 'Related Posts By Categories', 'equity_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'related_posts',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Select the Hierarchy','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'comments',
    'label'    => __( ' Show Comments', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Show the Comments for Single Blog Page','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'social_sharing_box',
    'label'    => __( 'Show social sharing options box below single post', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
) );

//social sharing box section

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'facebook_sb',
    'label'    => __( 'Enable facebook sharing option below single post', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'twitter_sb',
    'label'    => __( 'Enable twitter sharing option below single post', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'linkedin_sb',
    'label'    => __( 'Enable linkedin sharing option below single post', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'google-plus_sb',
    'label'    => __( 'Enable googleplus sharing option below single post', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'email_sb',
    'label'    => __( 'Enable email sharing option below single post', 'equity_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
/* FOOTER SECTION 
footer panel */

Equity_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'equity_pro' ),
    'description' => __( 'Footer Related Options', 'equity_pro' ),     
) );  

Equity_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','equity_pro' ),
    'description'    => __( 'Footer related options', 'equity_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'equity_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','equity_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'equity_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'equity_pro' ),
        2  => esc_attr__( '2', 'equity_pro' ),
        3  => esc_attr__( '3', 'equity_pro' ),
        4  => esc_attr__( '4', 'equity_pro' ),
    ),
    'default'  => 4,
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'equity_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'equity_pro' ),
    'description' => __('Select the top margin of footer in pixels','equity_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Equity_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','equity_pro' ),
    'description'    => __( 'Custom Footer Image options', 'equity_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'equity_pro' ),
        'contain' => esc_attr__( 'Contain', 'equity_pro' ),
        'auto'  => esc_attr__( 'Auto', 'equity_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'equity_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'equity_pro'),
        'repeat' => esc_attr__('Repeat', 'equity_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','equity_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',   
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'equity_pro'),
        'center center' => esc_attr__('Center Center', 'equity_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'equity_pro'),
        'left top' => esc_attr__('Left Top', 'equity_pro'),
        'left center' => esc_attr__('Left Center', 'equity_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'equity_pro'),
        'right top' => esc_attr__('Right Top', 'equity_pro'),
        'right center' => esc_attr__('Right Center', 'equity_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'equity_pro'),
        'fixed' => esc_attr__('Fixed', 'equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'off',
) );
  
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer_image',
            'property' => 'background-color',
        ),
    ),
) );


// single page section //

Equity_Kirki::add_section( 'single_page', array(
    'title'          => __( 'Single Page','equity_pro' ),
    'description'    => __( 'Single Page Related Options', 'equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'single_page_featured_image',
    'label'    => __( 'Enable Single Page Featured Image', 'equity_pro' ),
    'section'  => 'single_page',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'single_page_featured_image_size',
    'label'    => __( 'Single Page Featured Image Size', 'equity_pro' ),
    'section'  => 'single_page',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( 'Normal', 'equity_pro' ),
        2 => esc_attr__( 'FullWidth', 'equity_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_page_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

// Layout section //

Equity_Kirki::add_section( 'layout', array( 
    'title'          => __( 'Layout','equity_pro' ),
    'description'    => __( 'Layout Related Options', 'equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'site-style',
    'label'    => __( 'Site Style', 'equity_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'wide' =>  esc_attr__('Wide', 'equity_pro'),
        'boxed' =>  esc_attr__('Boxed', 'equity_pro'),
        'fluid' =>  esc_attr__('Fluid', 'equity_pro'),  
        //'static' =>  esc_attr__('Static ( Non Responsive )', 'equity_pro'),
    ),
    'default'  => 'wide',
    'tooltip' => __('Choose the default site layout.','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'global_sidebar_layout',
    'label'    => __( 'Check the box if you want to use a global sidebar on all pages. This option overrides the page options', 'equity_pro' ),
    'section'  => 'layout',
    'type'     => 'checkbox',
    'default' => '0',
) );


Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'sidebar_position',
    'label'    => __( 'Main Layout', 'equity_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-image',   
    'description' => __('Select main content and sidebar arrangement.','equity_pro'),
    'choices' => array(
        'left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cl.png',
        'right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cr.png',
        'two-sidebar' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cm.png',  
        'two-sidebar-left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cl.png',
        'two-sidebar-right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cr.png',
        'fullwidth' =>  get_template_directory_uri() . '/admin/kirki/assets/images/1c.png',
        'no-sidebar' =>  get_template_directory_uri() . '/images/no-sidebar.png',
    ),
    'default'  => 'right', 
    'tooltip' => __('global sidebar on all pages. This option overrides the page layout sidebar options','equity_pro'),
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'body_top_margin',
    'label'    => __( 'Body Top Margin', 'equity_pro' ),
    'description' => __('Select the top margin of body element in pixels','equity_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-top',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'body_bottom_margin',
    'label'    => __( 'Body Bottom Margin', 'equity_pro' ),
    'description' => __('Select the bottom margin of body element in pixels','equity_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-bottom',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );

/* LAYOUT SECTION  */
/*
Equity_Kirki::add_section( 'layout', array(
    'title'          => __( 'Layout','equity_pro' ),   
    'description'    => __( 'Layout settings that affects overall site', 'equity_pro'),
    'panel'          => 'equity_pro_options', // Not typically needed.
) );



Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'primary_sidebar_width',
    'label'    => __( 'Primary Sidebar Width', 'equity_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'equity_pro' ),
        '2' => __( 'Two Column', 'equity_pro' ),
        '3' => __( 'Three Column', 'equity_pro' ),
        '4' => __( 'Four Column', 'equity_pro' ),
        '5' => __( 'Five Column ', 'equity_pro' ),
    ),
    'default'  => '5',  
    'tooltip' => __('Select the width of the Primary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'secondary_sidebar_width',
    'label'    => __( 'Secondary Sidebar Width', 'equity_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'equity_pro' ),
        '2' => __( 'Two Column', 'equity_pro' ),
        '3' => __( 'Three Column', 'equity_pro' ),
        '4' => __( 'Four Column', 'equity_pro' ),
        '5' => __( 'Five Column ', 'equity_pro' ),
    ),            
    'default'  => '5',  
    'tooltip' => __('Select the width of the Secondary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','equity_pro'),
) ); 

*/

/* FOOTER SECTION 
footer panel */

Equity_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'equity_pro' ),
    'description' => __( 'Footer Related Options', 'equity_pro' ),     
) );  

Equity_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','equity_pro' ),
    'description'    => __( 'Footer related options', 'equity_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'equity_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','equity_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'equity_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'equity_pro' ),
        2  => esc_attr__( '2', 'equity_pro' ),
        3  => esc_attr__( '3', 'equity_pro' ),
        4  => esc_attr__( '4', 'equity_pro' ),
    ),
    'default'  => 4,
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'equity_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'equity_pro' ),
    'description' => __('Select the top margin of footer in pixels','equity_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Equity_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','equity_pro' ),
    'description'    => __( 'Custom Footer Image options', 'equity_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'equity_pro' ),
        'contain' => esc_attr__( 'Contain', 'equity_pro' ),
        'auto'  => esc_attr__( 'Auto', 'equity_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'equity_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'equity_pro'),
        'repeat' => esc_attr__('Repeat', 'equity_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','equity_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'equity_pro'),
        'center center' => esc_attr__('Center Center', 'equity_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'equity_pro'),
        'left top' => esc_attr__('Left Top', 'equity_pro'),
        'left center' => esc_attr__('Left Center', 'equity_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'equity_pro'),
        'right top' => esc_attr__('Right Top', 'equity_pro'),
        'right center' => esc_attr__('Right Center', 'equity_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'equity_pro'),
        'fixed' => esc_attr__('Fixed', 'equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => 'off',
) );
  
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'equity_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.overlay-footer',
            'property' => 'background-color',
        ),
    ),
) );


 if( class_exists( 'WooCommerce' ) ) {
    Equity_Kirki::add_section( 'woocommerce_section', array(
        'title'          => __( 'WooCommerce','equity_pro' ),
        'description'    => __( 'Theme options related to woocommerce', 'equity_pro'),
        'priority'       => 11, 
        'theme_supports' => '', // Rarely needed.
    ) );
    Equity_Kirki::add_field( 'woocommerce', array(
        'settings' => 'woocommerce_sidebar',
        'label'    => __( 'Enable Woocommerce Sidebar', 'equity_pro' ),
        'description' => __('Enable Sidebar for shop page','equity_pro'),
        'section'  => 'woocommerce_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'equity_pro' ),
            'off' => esc_attr__( 'Disable', 'equity_pro' ) 
        ),

        'default'  => 'on',
    ) );
}
    
// background color ( rename )

Equity_Kirki::add_section( 'colors', array(
    'title'          => __( 'Background Color','equity_pro' ),
    'description'    => __( 'This will affect overall site background color', 'equity_pro'),
    //'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 11,
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'general_background_color',
    'label'    => __( 'General Background Color', 'equity_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-color',
        ),
    ),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'content_background_color',
    'label'    => __( 'Content Background Color', 'equity_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'description' => __('when you are select boxed layout content background color will reflect the grid area','equity_pro'), 
    'alpha' => true, 
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'general_background_image',
    'label'    => __( 'General Background Image', 'equity_pro' ),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-image',
        ),
    ),
) );

// background image ( general & boxed layout ) //


Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'general_background_repeat',
    'label'    => __( 'General Background Repeat', 'equity_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'equity_pro'),
        'repeat' => esc_attr__('Repeat', 'equity_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','equity_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'general_background_size',
    'label'    => __( 'General Background Size', 'equity_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'equity_pro' ),
        'contain' => esc_attr__( 'Contain', 'equity_pro' ),
        'auto'  => esc_attr__( 'Auto', 'equity_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'equity_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'general_background_attachment',
    'label'    => __( 'General Background Attachment', 'equity_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'equity_pro'),
        'fixed' => esc_attr__('Fixed', 'equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'general_background_position',
    'label'    => __( 'General Background Position', 'equity_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'equity_pro'),
        'center center' => esc_attr__('Center Center', 'equity_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'equity_pro'),
        'left top' => esc_attr__('Left Top', 'equity_pro'),
        'left center' => esc_attr__('Left Center', 'equity_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'equity_pro'),
        'right top' => esc_attr__('Right Top', 'equity_pro'),
        'right center' => esc_attr__('Right Center', 'equity_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );


/* CONTENT BACKGROUND ( boxed background image )*/

Equity_Kirki::add_field( 'equity_pro', array(  
    'settings' => 'content_background_image',
    'label'    => __( 'Content Background Image', 'equity_pro' ),
    'description' => __('when you are select boxed layout content background image will reflect the grid area','equity_pro'),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-image',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'content_background_repeat',
    'label'    => __( 'Content Background Repeat', 'equity_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'equity_pro'),
        'repeat' => esc_attr__('Repeat', 'equity_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','equity_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'content_background_size',
    'label'    => __( 'Content Background Size', 'equity_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'equity_pro' ),
        'contain' => esc_attr__( 'Contain', 'equity_pro' ),
        'auto'  => esc_attr__( 'Auto', 'equity_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'equity_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'content_background_attachment',
    'label'    => __( 'Content Background Attachment', 'equity_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'equity_pro'),
        'fixed' => esc_attr__('Fixed', 'equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'content_background_position',
    'label'    => __( 'Content Background Position', 'equity_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'equity_pro'),
        'center center' => esc_attr__('Center Center', 'equity_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'equity_pro'),
        'left top' => esc_attr__('Left Top', 'equity_pro'),
        'left center' => esc_attr__('Left Center', 'equity_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'equity_pro'),
        'right top' => esc_attr__('Right Top', 'equity_pro'),
        'right center' => esc_attr__('Right Center', 'equity_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'equity_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );

/* pro theme options */

//  animation section 

Equity_Kirki::add_section( 'animation_section', array(
    'title'          => __( 'Animation','equity_pro' ),
    'description'    => __( 'Animation that affects overall site', 'equity_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );    

Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'animation_effect',
    'label'    => __( 'Enable Animation Effect', 'equity_pro' ),   
    'section'  => 'animation_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'equity_pro' ),
        'off' => esc_attr__( 'Disable', 'equity_pro' ) 
    ),
    'default'  => 'on',
) );

// custom JS section

Equity_Kirki::add_section( 'custom_js_section', array(
    'title'          => __( 'Custom JS','equity_pro' ),
    'description'    => __( 'Custom JS', 'equity_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
 Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'custom_js',
    'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'equity_pro' ),
    'section'  => 'custom_js_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
) ); 


// Tracking section 

Equity_Kirki::add_section( 'analytics_section', array(
    'title'          => __( 'Tracking Code','equity_pro' ),
    'description'    => __( 'Tracking Code', 'equity_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'analytics',
    'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'equity_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
    'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'analytics_place',
    'label'    => __( 'Enable to Load Tracking Code in Footer', 'equity_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'equity_pro' ),
        '2' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => '2',
    'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','equity_pro'),
) );


//  lightbox section //

Equity_Kirki::add_section( 'light_box', array(
    'title'          => __( 'Light Box','equity_pro' ),
    'description'    => __( 'Light Box Settings', 'equity_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'lightbox_theme',
    'label'    => __( 'Lightbox Theme', 'equity_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => esc_attr__( 'pp_default', 'equity_pro' ),
        '2' => esc_attr__( 'light-rounded', 'equity_pro' ),
        '3' => esc_attr__( 'dark-rounded', 'equity_pro' ),
        '4' => esc_attr__( 'light-square', 'equity_pro' ),
        '5' => esc_attr__( 'dark-square', 'equity_pro' ),
        '6' => esc_attr__( 'facebook', 'equity_pro' ),
    ),
    'default'  => '1',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'lightbox_animation_speed',
    'label'    => __( 'Animation Speed', 'equity_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'fast' => esc_attr__( 'Fast', 'equity_pro' ),
        'slow' => esc_attr__( 'Slow', 'equity_pro' ),
        'normal' => esc_attr__( 'Normal', 'equity_pro' ),
    ),
    'default'  => 'fast',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'lightbox_slideshow',
    'label'    => __( 'Autoplay Gallery Speed', 'equity_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 100,
        'step' => 10,
    ),
    'default'  => 50,
    'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'lightbox_autoplay_slideshow',
    'label'    => __( 'Enable Autoplay Gallery', 'equity_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'equity_pro' ),
        '2' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => '2',
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'lightbox_opacity',
    'label'    => __( 'Select Background Opacity', 'equity_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 1,
        'step' => 0.1,
    ),
    'default'  => 0.5,
    'tooltip' => __('Enter 0.1 to 1.0','equity_pro'),
) );
Equity_Kirki::add_field( 'equity_pro', array(
    'settings' => 'lightbox_overlay_gallery',
    'label'    => __( 'Show Gallery Thumbnails', 'equity_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array( 
        '1'  => esc_attr__( 'Enable', 'equity_pro' ),
        '2' => esc_attr__( 'Disable', 'equity_pro' )
    ),
    'default'  => '1',
) );


 

         
do_action('equity_pro_child_customizer_options');
