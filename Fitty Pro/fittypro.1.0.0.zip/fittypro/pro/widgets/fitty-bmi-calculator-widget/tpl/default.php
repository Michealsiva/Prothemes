<div class="gym-bmi-wrapper clearfix">	
	<!--Calculate table -->   
	    <div id="gym-calculate_bodymass">
            <p class="gym-calculate-subtitle"><?php echo $sub_title; ?></p>
		    <h1><?php echo $title; ?></h1>

			<div class="gym-bmi-left eight columns alpha">

			    <p><label for="height"><?php echo $height; ?><span>(cm)</span></label>
			    <input type="text" name="height" id="height" /></p>
                <p><label for="weight"><?php echo $weight; ?><span>(kg)</span></label>
                <input type="text" name="weight" id="weight" /></p>

                <input id="submit" onclick="gym_bodymass_calculate()" type="button" value="<?php echo $calculate; ?>" />
			    <input id="reset" onclick="resetform()" type="button" value="<?php echo $reset; ?>" />

			</div>
			<div id="bm_result" class="eight columns"><div class="bm_result-wrapper"><p><span><?php echo $yourbm; ?></span><strong id="bm_value">0.0</strong></p><p><strong id="bm_status"><?php echo $normal; ?></strong></p></div></div>
			


		</div>

		<!--BMI Calculate Javascript code-->
		<script type="text/javascript">

			function gym_bodymass_calculate() {

				var weight = document.getElementById('weight').value;
				var height = document.getElementById('height').value/100;
				var bm = weight/(height*height);
				var msg = '';

				if(bm < 18.5) {
					 msg = '<?php echo $underweight; ?>'; }
				else if(bm > 18.5 && bm < 25) {
					 msg = '<?php echo $normal; ?>'; }
				else if(bm > 25 && bm < 30) {
					 msg = '<?php echo $overweight; ?>'; }
				else if(bm > 30) {
					 msg = '<?php echo $obese; ?>'; }

				if(weight > 0 && height > 0 && weight != null && height != null) {
					bm_result.innerHTML = '<div class="bm_result-wrapper"><p><span><?php echo $yourbm; ?></span><strong id="bm_value">' + bm.toFixed(2) + '</strong></p><p><strong id="bm_status">' + msg + '</strong></p></div>'; } 
				else {
					alert('<?php echo $error; ?>');
			    }
	        }

			<!--Reset button Javacript code-->
			function resetform() {
				document.getElementById('weight').value='';
				document.getElementById('height').value='';
				document.getElementById('bm_value').innerHTML='0.0';
				document.getElementById('bm_status').innerHTML= '<?php echo $normal; ?>';
	        }

	    </script>
</div>