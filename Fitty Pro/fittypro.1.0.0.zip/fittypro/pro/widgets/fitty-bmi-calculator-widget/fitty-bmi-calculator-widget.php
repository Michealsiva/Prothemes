<?php
/*
Widget Name: BMI Calculator
Description: A BMI( Body Mass Index) calculater widget
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class Fitty_BMI_Calculator_Widget extends SiteOrigin_Widget {

	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'fitty-bmi-calculator-widget',

			// The name of the widget for display purposes.
			__('BMI Calculator', 'fitty_pro'),

			array(
				'description' => __('A BMI( Body Mass Index) calculator', 'fitty_pro'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/bmi',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

	function initialize_form() {
		return array(
			'sub_title' => array(
				'type' => 'text', 
				'label' => __( 'Sub Title', 'fitty_pro' ),
				'default' => __('CHECK YOUR BODY MASS','fitty_pro'),
			),
			'title' => array(
				'type' => 'text', 
				'label' => __( 'Title', 'fitty_pro' ),
				'default' => __('BMI Calculator','fitty_pro'),
			),
			'yourbm' => array(
				'type' => 'text', 
				'label' => __( 'Your BMI', 'fitty_pro' ),
				'default' => __('Your BMI is','fitty_pro'),
			),
			'underweight' => array(
				'type' => 'text', 
				'label' => __( 'Underweight', 'fitty_pro' ),
				'default' => __('Underweight','fitty_pro'),
			),
			'normal' => array(
				'type' => 'text', 
				'label' => __( 'Normal', 'fitty_pro' ),
				'default' => __('Normal','fitty_pro'),
			),
			'overweight' => array(
				'type' => 'text', 
				'label' => __( 'Overweight', 'fitty_pro' ),
				'default' => __('Overweight','fitty_pro'),
			),
			'obese' => array(
				'type' => 'text', 
				'label' => __( 'Obese', 'fitty_pro' ),
				'default' => __('Obese','fitty_pro'),
			),
			'weight' => array(
				'type' => 'text', 
				'label' => __( 'Your Body Weight', 'fitty_pro' ),
				'default' => __('Your Body Weight','fitty_pro'),
			),
			'height' => array(
				'type' => 'text', 
				'label' => __( 'Your Body Height', 'fitty_pro' ),
				'default' => __('Your Body Height','fitty_pro'),
			),
			'error' => array(
				'type' => 'text', 
				'label' => __( 'Text: Error!', 'fitty_pro' ),
				'default' => __('Please enter valid information!','fitty_pro'),
			),
			'calculate' => array(
				'type' => 'text', 
				'label' => __( 'Calculate your body mass', 'fitty_pro' ),
				'default' => __('Calculate','fitty_pro'),
			),
			'reset' => array(
				'type' => 'text', 
				'label' => __( 'Reset', 'fitty_pro' ),
				'default' => __('Reset','fitty_pro'),
			),
		);
	}

	/**
	 * Get the template variables for the headline
	 *
	 * @param $instance
	 * @param $args
	 *
	 * @return array
	 */
	function get_template_variables( $instance, $args ) {
		return array(
			'sub_title' => $instance['sub_title'],
			'title' => $instance['title'],
			'yourbm' => $instance['yourbm'],
			'underweight' => $instance['underweight'],
			'normal' => $instance['normal'],
			'overweight' => $instance['overweight'],
			'obese' => $instance['obese'],
			'weight' => $instance['weight'],
			'height' => $instance['height'],
			'error' => $instance['error'],
			'calculate' => $instance['calculate'],
			'reset' => $instance['reset'],
		);
	}

	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class Gympress_Pro_Accordion_Widget

siteorigin_widget_register('fitty-bmi-calculator-widget', __FILE__, 'Fitty_BMI_Calculator_Widget');