<?php

if ( ! class_exists( 'Fitty_Pro_Widgets' ) ) {

	class Fitty_Pro_Widgets {

	    /* Inclue All Widget folders */
	    public function Fitty_Pro_get_widgets_folder( $folders ) {
	    	$sow_path = WP_PLUGIN_DIR . '/so-widgets-bundle/widgets/';
			$current_settings = get_option( 'siteorigin_panels_settings', array() );
			/* if( empty($current_settings['widget_bundle_widgets']) ) {
				if( $sow_path === $folders[0] ) {
				   unset($folders[0]);    
			    }   
			} */   
			 
			$folders[] = get_template_directory() . '/pro/widgets/';
			return $folders;
		} 

	    /* Site Origin Widget Bundle Webulous widgets Group & Tab */
		public function Fitty_Pro_add_widgets_group($widgets) {
				$fitty_pro_widgets = array(
				    'Fitty_BMI_Calculator_Widget',
				    'Fitty_ServiceBox_Widget',
				    'Fitty_Latest_Product',
				);
				foreach($fitty_pro_widgets as $fitty_pro_widget) {
					if( isset( $widgets[$fitty_pro_widget] ) ) {
						$widgets[$fitty_pro_widget]['groups'] = array('theme');
					}
				} 
				return $widgets;
		}   
    

		public function Fitty_Pro_filter_active_widgets($active){
			$active_widgets = array(
				'fitty-bmi-calculator-widget',
				'fitty-servicebox-widget',
				'fitty-latest-product-widget',
			);
			
			foreach ($active_widgets as $value ) {
			   $active[$value] = true;
			} 
		   
		    return $active;
		}   

	}
	
}


