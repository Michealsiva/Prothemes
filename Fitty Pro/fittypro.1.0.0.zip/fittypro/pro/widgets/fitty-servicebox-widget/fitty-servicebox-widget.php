<?php
/*
Widget Name: Service Box
Description: Creates featured-product content section
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class Fitty_ServiceBox_Widget extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'fitty-servicebox-widget',

			// The name of the widget for display purposes.
			__('Service Box', 'fitty_pro'),

			array(
				'description' => __('Creates Service Box section', 'fitty_pro'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/featured-product',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

	function initialize_form() {
		return array(
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Title.', 'fitty_pro' )
			),
			'sub_title' => array(
				'type'  => 'text',
				'label' => __( 'Sub Title.', 'fitty_pro' )
			),
			'image' => array( 
				'type' => 'media',
				'label' => __( 'Icon image', 'fitty_pro' ),
				'library' => 'image'
			),
			'img_align' => array(
				'type' => 'select',
				'label' => __('Image alignment', 'fitty_pro'),
				'default' => 'left',
				'options' => array(
					'left' => __('Left', 'fitty_pro'),
					'right' => __('Right', 'fitty_pro'),
					'center' => __('Center', 'fitty_pro'),
				),
			),
			'text_align' => array(
				'type' => 'select',
				'label' => __('Text alignment', 'fitty_pro'),
				'default' => 'right',
				'options' => array(
					'left' => __('Left', 'fitty_pro'),
					'right' => __('Right', 'fitty_pro'),
					'center' => __('Center', 'fitty_pro'),
				),
			),
			'text_position' => array(
				'type' => 'select',
				'label' => __('Text position', 'fitty_pro'),
				'default' => 'bottom',
				'options' => array(
					'bottom' => __( 'Bottom', 'fitty_pro' ),
					'top' => __( 'Top', 'fitty_pro' ),
					'center'=>__( 'Center','fitty_pro'),
				),
			),
			'alt' => array(
				'type' => 'text',
				'label' => __('Button Text', 'fitty_pro'),
			),

			'url' => array(
				'type' => 'link',
				'label' => __('Destination URL', 'fitty_pro'),
			),
			'new_window' => array(
				'type' => 'checkbox',
				'default' => false,
				'label' => __('Open in new window', 'fitty_pro'),
			),
		);
	}
	function get_template_variables( $instance, $args ) {  
		return array(
			'title'           => ! empty( $instance['title'] ) ? $instance['title'] : '',
			'sub_title'    => ! empty( $instance['sub_title'] ) ? $instance['sub_title'] : '',
			'image'          => ! empty( $instance['image'] ) ? $instance['image'] : '',
			'text_position' => $instance['text_position'],
			'img_align'=> $instance['img_align'],
			'text_align'=> $instance['text_align'],
			'alt' => $instance['alt'],
			'url' => $instance['url'],
			'new_window' => $instance['new_window'],
		);
	}
	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class Fitty_ServiceBox_Widget

siteorigin_widget_register('fitty-servicebox-widget', __FILE__, 'Fitty_ServiceBox_Widget');