<?php
/*
Widget Name: Latest Product
Description: Creates latest woocommerce product content section
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class Fitty_Latest_Product extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'fitty-latest-product-widget',

			// The name of the widget for display purposes.
			__('Latest Product', 'fitty_pro'),

			array(
				'description' => __('Display Woocommerce Latest Products', 'fitty_pro'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/latest-product',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

	function initialize_form() {
		return array(
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Title', 'fitty_pro' )
			),
			
			'select_product_type' => array(
				'type' => 'select',
				'label' => __('Select Product Type', 'fitty_pro'),
				'default' => 'all_product',
				'options' => array(
					'all_product' => __('All Product', 'fitty_pro'),
					'latest_product' => __('Latest Products', 'fitty_pro'),
				),
			),
			'latest_product_type' => array(
				'type' => 'select',
				'label' => __('Latest Product Type', 'fitty_pro'),
				'default' => 'normal',
				'options' => array(
					'normal' => __( 'Normal', 'fitty_pro' ),
					'carousel' => __( 'Carousel', 'fitty_pro' ),
				),
			),
			'latest_product_count' => array(
				'type' => 'number',
				'label' => __('Number of Latest Products to be Display', 'fitty_pro'),
			),

			'order_by' => array(
				'type' => 'select',
				'label' => __('Order By', 'fitty_pro'),
				'default' => 'date',
				'options' => array(
					'date' => __( 'Date', 'fitty_pro' ),
					'price' => __( 'Price', 'fitty_pro' ),
					'sales' => __( 'Sales', 'fitty_pro' ),
					'random' => __( 'Random', 'fitty_pro' ),
				),
			),
			'order' => array(
				'type' => 'select',
				'label' => __('Order', 'fitty_pro'),
				'default' => 'desc',
				'options' => array(
					'asc' => __( 'ASC', 'fitty_pro' ),
					'desc' => __( 'DESC', 'fitty_pro' ),
				),
			),
		);
	}
	function get_template_variables( $instance, $args ) {  
		return array(
			'title'           => ! empty( $instance['title'] ) ? $instance['title'] : '',
			'select_product_type'    => ! empty( $instance['select_product_type'] ) ? $instance['select_product_type'] : '',
			'latest_product_type'          => ! empty( $instance['latest_product_type'] ) ? $instance['latest_product_type'] : '',
			'latest_product_count' => $instance['latest_product_count'],
			'order_by'=> $instance['order_by'],
			'order' => $instance['order'],
		);
	}
	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class Fitty_Latest_Product

siteorigin_widget_register('fitty-latest-product-widget', __FILE__, 'Fitty_Latest_Product');