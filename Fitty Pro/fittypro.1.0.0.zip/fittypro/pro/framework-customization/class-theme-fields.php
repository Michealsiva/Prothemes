<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Fitty_Pro_Theme_fields' ) ) {  
	class Fitty_Pro_Theme_fields {
	
      	
        /* Add Or Override the widegt fields */
        public function fitty_pro_extend_heading_form($form_options, $widget) {
	          $form_options['divider'] = array(
			  	'type' => 'checkbox',
		        'label' => __( 'Enable Heading Divider', 'fitty_pro' ),
		        'default' => true  
			  );  
			  $form_options['divider_color'] = array(
			  	'type' => 'color',
		        'label' => __( 'Choose Heading Divider Color', 'fitty_pro' ),
			  ); 
			  
			  return $form_options; 

        }  

        /* Add Or Override the testimonial widget fields */
        public function fitty_pro_extend_testimonial_form($form_options, $widget) {
	        
		    $form_options['testimonial']['fields']['client_after_image'] = array(
				'type' => 'media',
				'label' => __( 'Client After image', 'fitty_pro' ),
				'choose' => __( 'Choose image', 'fitty_pro' ),  
				'update' => __( 'Set image', 'fitty_pro' ),
				'library' => 'image',
			);
			$form_options['testimonial']['fields']['client_image'] = array(
				'type' => 'media',
				'label' => __( 'Client Before image', 'fitty_pro' ),
				'choose' => __( 'Choose image', 'fitty_pro' ),  
				'update' => __( 'Set image', 'fitty_pro' ),
				'library' => 'image',
			); 
			  
			return $form_options;   

        } 


     
	}
}

