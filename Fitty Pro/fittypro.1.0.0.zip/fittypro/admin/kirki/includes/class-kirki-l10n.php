<?php
/**
 * Internationalization helper.
 *
 * @package     Kirki
 * @category    Core
 * @author      Aristeides Stathopoulos
 * @copyright   Copyright (c) 2016, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/https://opensource.org/licenses/MIT
 * @since       1.0
 */

if ( ! class_exists( 'Kirki_l10n' ) ) {

	/**
	 * Handles translations
	 */
	class Kirki_l10n {

		/**
		 * The plugin textdomain
		 *
		 * @access protected
		 * @var string
		 */
		protected $textdomain = 'fitty_pro';

		/**
		 * The class constructor.
		 * Adds actions & filters to handle the rest of the methods.
		 *
		 * @access public
		 */
		public function __construct() {

			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		}

		/**
		 * Load the plugin textdomain
		 *
		 * @access public
		 */
		public function load_textdomain() {

			if ( null !== $this->get_path() ) {
				load_textdomain( $this->textdomain, $this->get_path() );
			}
			load_plugin_textdomain( $this->textdomain, false, Kirki::$path . '/languages' );

		}

		/**
		 * Gets the path to a translation file.
		 *
		 * @access protected
		 * @return string Absolute path to the translation file.
		 */
		protected function get_path() {
			$path_found = false;
			$found_path = null;
			foreach ( $this->get_paths() as $path ) {
				if ( $path_found ) {
					continue;
				}
				$path = wp_normalize_path( $path );
				if ( file_exists( $path ) ) {
					$path_found = true;
					$found_path = $path;
				}
			}

			return $found_path;

		}

		/**
		 * Returns an array of paths where translation files may be located.
		 *
		 * @access protected
		 * @return array
		 */
		protected function get_paths() {

			return array(
				WP_LANG_DIR . '/' . $this->textdomain . '-' . get_locale() . '.mo',
				Kirki::$path . '/languages/' . $this->textdomain . '-' . get_locale() . '.mo',
			);

		}

		/**
		 * Shortcut method to get the translation strings
		 *
		 * @static
		 * @access public
		 * @param string $config_id The config ID. See Kirki_Config.
		 * @return array
		 */
		public static function get_strings( $config_id = 'global' ) {

			$translation_strings = array(
				'background-color'      => esc_attr__( 'Background Color', 'fitty_pro' ),
				'background-image'      => esc_attr__( 'Background Image', 'fitty_pro' ),
				'no-repeat'             => esc_attr__( 'No Repeat', 'fitty_pro' ),
				'repeat-all'            => esc_attr__( 'Repeat All', 'fitty_pro' ),
				'repeat-x'              => esc_attr__( 'Repeat Horizontally', 'fitty_pro' ),
				'repeat-y'              => esc_attr__( 'Repeat Vertically', 'fitty_pro' ),
				'inherit'               => esc_attr__( 'Inherit', 'fitty_pro' ),
				'background-repeat'     => esc_attr__( 'Background Repeat', 'fitty_pro' ),
				'cover'                 => esc_attr__( 'Cover', 'fitty_pro' ),
				'contain'               => esc_attr__( 'Contain', 'fitty_pro' ),
				'background-size'       => esc_attr__( 'Background Size', 'fitty_pro' ),
				'fixed'                 => esc_attr__( 'Fixed', 'fitty_pro' ),
				'scroll'                => esc_attr__( 'Scroll', 'fitty_pro' ),
				'background-attachment' => esc_attr__( 'Background Attachment', 'fitty_pro' ),
				'left-top'              => esc_attr__( 'Left Top', 'fitty_pro' ),
				'left-center'           => esc_attr__( 'Left Center', 'fitty_pro' ),
				'left-bottom'           => esc_attr__( 'Left Bottom', 'fitty_pro' ),
				'right-top'             => esc_attr__( 'Right Top', 'fitty_pro' ),
				'right-center'          => esc_attr__( 'Right Center', 'fitty_pro' ),
				'right-bottom'          => esc_attr__( 'Right Bottom', 'fitty_pro' ),
				'center-top'            => esc_attr__( 'Center Top', 'fitty_pro' ),
				'center-center'         => esc_attr__( 'Center Center', 'fitty_pro' ),
				'center-bottom'         => esc_attr__( 'Center Bottom', 'fitty_pro' ),
				'background-position'   => esc_attr__( 'Background Position', 'fitty_pro' ),
				'background-opacity'    => esc_attr__( 'Background Opacity', 'fitty_pro' ),
				'on'                    => esc_attr__( 'ON', 'fitty_pro' ),
				'off'                   => esc_attr__( 'OFF', 'fitty_pro' ),
				'all'                   => esc_attr__( 'All', 'fitty_pro' ),
				'cyrillic'              => esc_attr__( 'Cyrillic', 'fitty_pro' ),
				'cyrillic-ext'          => esc_attr__( 'Cyrillic Extended', 'fitty_pro' ),
				'devanagari'            => esc_attr__( 'Devanagari', 'fitty_pro' ),
				'greek'                 => esc_attr__( 'Greek', 'fitty_pro' ),
				'greek-ext'             => esc_attr__( 'Greek Extended', 'fitty_pro' ),
				'khmer'                 => esc_attr__( 'Khmer', 'fitty_pro' ),
				'latin'                 => esc_attr__( 'Latin', 'fitty_pro' ),
				'latin-ext'             => esc_attr__( 'Latin Extended', 'fitty_pro' ),
				'vietnamese'            => esc_attr__( 'Vietnamese', 'fitty_pro' ),
				'hebrew'                => esc_attr__( 'Hebrew', 'fitty_pro' ),
				'arabic'                => esc_attr__( 'Arabic', 'fitty_pro' ),
				'bengali'               => esc_attr__( 'Bengali', 'fitty_pro' ),
				'gujarati'              => esc_attr__( 'Gujarati', 'fitty_pro' ),
				'tamil'                 => esc_attr__( 'Tamil', 'fitty_pro' ),
				'telugu'                => esc_attr__( 'Telugu', 'fitty_pro' ),
				'thai'                  => esc_attr__( 'Thai', 'fitty_pro' ),
				'serif'                 => _x( 'Serif', 'font style', 'fitty_pro' ),
				'sans-serif'            => _x( 'Sans Serif', 'font style', 'fitty_pro' ),
				'monospace'             => _x( 'Monospace', 'font style', 'fitty_pro' ),
				'font-family'           => esc_attr__( 'Font Family', 'fitty_pro' ),
				'font-size'             => esc_attr__( 'Font Size', 'fitty_pro' ),
				'font-weight'           => esc_attr__( 'Font Weight', 'fitty_pro' ),
				'line-height'           => esc_attr__( 'Line Height', 'fitty_pro' ),
				'font-style'            => esc_attr__( 'Font Style', 'fitty_pro' ),
				'letter-spacing'        => esc_attr__( 'Letter Spacing', 'fitty_pro' ),
				'top'                   => esc_attr__( 'Top', 'fitty_pro' ),
				'bottom'                => esc_attr__( 'Bottom', 'fitty_pro' ),
				'left'                  => esc_attr__( 'Left', 'fitty_pro' ),
				'right'                 => esc_attr__( 'Right', 'fitty_pro' ),
				'center'                => esc_attr__( 'Center', 'fitty_pro' ),
				'justify'               => esc_attr__( 'Justify', 'fitty_pro' ),
				'color'                 => esc_attr__( 'Color', 'fitty_pro' ),
				'add-image'             => esc_attr__( 'Add Image', 'fitty_pro' ),
				'change-image'          => esc_attr__( 'Change Image', 'fitty_pro' ),
				'no-image-selected'     => esc_attr__( 'No Image Selected', 'fitty_pro' ),
				'add-file'              => esc_attr__( 'Add File', 'fitty_pro' ),
				'change-file'           => esc_attr__( 'Change File', 'fitty_pro' ),
				'no-file-selected'      => esc_attr__( 'No File Selected', 'fitty_pro' ),
				'remove'                => esc_attr__( 'Remove', 'fitty_pro' ),
				'select-font-family'    => esc_attr__( 'Select a font-family', 'fitty_pro' ),
				'variant'               => esc_attr__( 'Variant', 'fitty_pro' ),
				'subsets'               => esc_attr__( 'Subset', 'fitty_pro' ),
				'size'                  => esc_attr__( 'Size', 'fitty_pro' ),
				'height'                => esc_attr__( 'Height', 'fitty_pro' ),
				'spacing'               => esc_attr__( 'Spacing', 'fitty_pro' ),
				'ultra-light'           => esc_attr__( 'Ultra-Light 100', 'fitty_pro' ),
				'ultra-light-italic'    => esc_attr__( 'Ultra-Light 100 Italic', 'fitty_pro' ),
				'light'                 => esc_attr__( 'Light 200', 'fitty_pro' ),
				'light-italic'          => esc_attr__( 'Light 200 Italic', 'fitty_pro' ),
				'book'                  => esc_attr__( 'Book 300', 'fitty_pro' ),
				'book-italic'           => esc_attr__( 'Book 300 Italic', 'fitty_pro' ),
				'regular'               => esc_attr__( 'Normal 400', 'fitty_pro' ),
				'italic'                => esc_attr__( 'Normal 400 Italic', 'fitty_pro' ),
				'medium'                => esc_attr__( 'Medium 500', 'fitty_pro' ),
				'medium-italic'         => esc_attr__( 'Medium 500 Italic', 'fitty_pro' ),
				'semi-bold'             => esc_attr__( 'Semi-Bold 600', 'fitty_pro' ),
				'semi-bold-italic'      => esc_attr__( 'Semi-Bold 600 Italic', 'fitty_pro' ),
				'bold'                  => esc_attr__( 'Bold 700', 'fitty_pro' ),
				'bold-italic'           => esc_attr__( 'Bold 700 Italic', 'fitty_pro' ),
				'extra-bold'            => esc_attr__( 'Extra-Bold 800', 'fitty_pro' ),
				'extra-bold-italic'     => esc_attr__( 'Extra-Bold 800 Italic', 'fitty_pro' ),
				'ultra-bold'            => esc_attr__( 'Ultra-Bold 900', 'fitty_pro' ),
				'ultra-bold-italic'     => esc_attr__( 'Ultra-Bold 900 Italic', 'fitty_pro' ),
				'invalid-value'         => esc_attr__( 'Invalid Value', 'fitty_pro' ),
				'add-new'           	=> esc_attr__( 'Add new', 'fitty_pro' ),
				'row'           		=> esc_attr__( 'row', 'fitty_pro' ),
				'limit-rows'            => esc_attr__( 'Limit: %s rows', 'fitty_pro' ),
				'open-section'          => esc_attr__( 'Press return or enter to open this section', 'fitty_pro' ),
				'back'                  => esc_attr__( 'Back', 'fitty_pro' ),
				'reset-with-icon'       => sprintf( esc_attr__( '%s Reset', 'fitty_pro' ), '<span class="dashicons dashicons-image-rotate"></span>' ),
				'text-align'            => esc_attr__( 'Text Align', 'fitty_pro' ),
				'text-transform'        => esc_attr__( 'Text Transform', 'fitty_pro' ),
				'none'                  => esc_attr__( 'None', 'fitty_pro' ),
				'capitalize'            => esc_attr__( 'Capitalize', 'fitty_pro' ),
				'uppercase'             => esc_attr__( 'Uppercase', 'fitty_pro' ),
				'lowercase'             => esc_attr__( 'Lowercase', 'fitty_pro' ),
				'initial'               => esc_attr__( 'Initial', 'fitty_pro' ),
				'select-page'           => esc_attr__( 'Select a Page', 'fitty_pro' ),
				'open-editor'           => esc_attr__( 'Open Editor', 'fitty_pro' ),
				'close-editor'          => esc_attr__( 'Close Editor', 'fitty_pro' ),
				'switch-editor'         => esc_attr__( 'Switch Editor', 'fitty_pro' ),
				'hex-value'             => esc_attr__( 'Hex Value', 'fitty_pro' ),
			);

			// Apply global changes from the kirki/config filter.
			// This is generally to be avoided.
			// It is ONLY provided here for backwards-compatibility reasons.
			// Please use the kirki/{$config_id}/l10n filter instead.
			$config = apply_filters( 'kirki/config', array() );
			if ( isset( $config['i18n'] ) ) {
				$translation_strings = wp_parse_args( $config['i18n'], $translation_strings );
			}

			// Apply l10n changes using the kirki/{$config_id}/l10n filter.
			return apply_filters( 'kirki/' . $config_id . '/l10n', $translation_strings );

		}
	}
}
