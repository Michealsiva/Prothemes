<?php  
/**
 * Created by PhpStorm.
 * User: venkat
 * Date: 2/5/16
 * Time: 4:32 PM        
 */   
           
include_once( get_template_directory() . '/admin/kirki/kirki.php' );   
include_once( get_template_directory() . '/admin/kirki-helpers/class-theme-kirki.php' ); 
     
 
Fitty_Kirki::add_config( 'fitty_pro', array(     
    'capability'    => 'edit_theme_options',                  
    'option_type'   => 'theme_mod',          
) );               
     
// Flat option start //   

//  site identity section // 

Fitty_Kirki::add_section( 'title_tagline', array(
    'title'          => __( 'Site Identity','fitty_pro' ),
    'description'    => __( 'Site Header Options', 'fitty_pro'),       
    'priority'       => 8,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'logo_title',
    'label'    => __( 'Enable Logo as Title', 'fitty_pro' ),
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'priority' => 5,
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => 'off',   
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'tagline',
    'label'    => __( 'Show site Tagline', 'fitty_pro' ), 
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => 'on',
) );  

// home panel //
/*
Fitty_Kirki::add_panel( 'home_options', array(     
    'title'       => __( 'Home', 'fitty_pro' ),
    'description' => __( 'Home Page Related Options', 'fitty_pro' ),     
) );  


// home page type section

 Fitty_Kirki::add_section( 'home_type_section', array(
    'title'          => __( 'PRO Home - General Settings','fitty_pro' ),
    'description'    => __( 'Home Page options', 'fitty_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'enable_home_default_content',
    'label'    => __( 'Enable Home Page Default Content', 'fitty_pro' ),
    'section'  => 'home_type_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Use pagebuilder to built pro home page (or) Use prebuilt layout','fitty_pro'),
) );  


// Slider section 

Fitty_Kirki::add_section( 'slider_section', array(
    'title'          => __( 'Slider Section','fitty_pro' ),
    'description'    => __( 'Home Page Slider Related Options', 'fitty_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );
Fitty_Kirki::add_field( 'fitty_pro', array(  
    'settings' => 'slider_field',  
    'label'    => __( 'Enable Slider Post ( Section )', 'fitty_pro' ),
    'section'  => 'slider_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Slider Post in home page','fitty_pro'),
) );
 
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'slider_cat',
    'label'    => __( 'Slider Posts category', 'fitty_pro' ),
    'section'  => 'slider_section',
    'type'     => 'select',
    'choices' => Kirki_Helper::get_terms( 'category' ),
    'active_callback' => array(
        array(
            'setting'  => 'slider_field', 
            'operator' => '==',
            'value'    => true, 
        ),
    ),
    'tooltip' => __('Create post ( Goto Dashboard => Post => Add New ) and Post Featured Image ( Preferred size is 1200 x 450 pixels ) as taken as slider image and Post Content as taken as Flexcaption.','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'slider_count',
    'label'    => __( 'No. of Sliders', 'fitty_pro' ),
    'section'  => 'slider_section',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 999,
        'step' => 1,
    ),
    'default'  => 2,
    'active_callback' => array(
        array(
            'setting'  => 'slider_field',
            'operator' => '==',
            'value'    => true,
        ),                                                                                                                                                                                                                                                                                                                                                                          
    ),
    'tooltip' => __('Enter number of slides you want to display under your selected Category','fitty_pro'),
) );

// service section 

Fitty_Kirki::add_section( 'service_section', array(
    'title'          => __( 'Service Section','fitty_pro' ),
    'description'    => __( 'Home Page - Service Related Options', 'fitty_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Fitty_Kirki::add_field( 'fitty_pro', array(  
    'settings' => 'service_field',  
    'label'    => __( 'Enable Service Section', 'fitty_pro' ),
    'section'  => 'service_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Service section in home page','fitty_pro'),
) );

for ( $i = 1 ; $i <= 3 ; $i++ ) {
    //Create the settings Once, and Loop through it.
    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'service_section_icon_'.$i,
        'label'    => sprintf(__( 'Service Section Icons #%1$s', 'fitty_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'text',
        'description' => sprintf(__( '%1$s (fa fa-apple) ', 'fitty_pro' ), '<a href="http://fontawesome.io/icons/">Type FontAwesome icons</a>' ),          
        'active_callback' => array(
            array(
                'setting'  => 'service_field',
                'operator' => '==',
                'value'    => true,
            ),                                                                                                                                                                                                                                                                                                                                                                          
        ),
    ) );

    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'service_'.$i,
        'label'    => sprintf(__( 'Service Section #%1$s', 'fitty_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'dropdown-pages', 
        'active_callback' => array(
            array(
                'setting'  => 'service_field',
                'operator' => '==',
                'value'    => true,
            ),                                                                                                                                                                                                                                                                                                                                                                          
        ),        
    ) );
}

// latest blog section 

Fitty_Kirki::add_section( 'latest_blog_section', array(
    'title'          => __( 'Latest Blog Section','fitty_pro' ),
    'description'    => __( 'Home Page - Latest Blog Options', 'fitty_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'enable_recent_post_service',
    'label'    => __( 'Enable Recent Post Section', 'fitty_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),

    'default'  => 'on',
    'tooltip' => __('Enable recent post section in home page','fitty_pro'),
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'recent_posts_count',
    'label'    => __( 'No. of Recent Posts', 'fitty_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'number',
    'choices' => array(
        'min' => 2,
        'max' => 99,
        'step' => 2,
    ),
    'default'  => 6,
    'active_callback' => array(
        array(
            'setting'  => 'enable_recent_post_service',
            'operator' => '==',
            'value'    => true,
        ),

    ),
) );
*/

// general panel      

Fitty_Kirki::add_panel( 'general_panel', array(   
    'title'       => __( 'General Settings', 'fitty_pro' ),  
    'description' => __( 'general settings', 'fitty_pro' ),         
) );
//  Page title bar section // 

Fitty_Kirki::add_section( 'header-pagetitle-bar', array(   
    'title'          => __( 'Page Title Bar & Breadcrumb','fitty_pro' ),
    'description'    => __( 'Page Title bar related options', 'fitty_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) ); 
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'global_page_title_bar',
    'label'    => __( 'Check the box if you want to use a global page title bar settings. This option overrides the page options', 'fitty_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'checkbox',
    'default' => '0',
) );   

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'page_titlebar',  
    'label'    => __( 'Page Title Bar', 'fitty_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( 'Show Bar and Content', 'fitty_pro' ),
        2 => __('Hide','fitty_pro'),
    ),
    'default' => 1,
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'page_titlebar_text',  
    'label'    => __( 'Page Title Bar Text', 'fitty_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        0 => __( 'Show', 'fitty_pro' ),
        1 => __( 'Hide', 'fitty_pro' ), 
    ),
    'default' => 0,
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'breadcrumb',  
    'label'    => __( 'Hide Breadcrumb', 'fitty_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'checkbox',
    'default'  => 0,
) ); 

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'breadcrumb_char',
    'label'    => __( 'Breadcrumb Character', 'fitty_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( ' >> ', 'fitty_pro' ),
        2 => __( ' / ', 'fitty_pro' ),
        3 => __( ' > ', 'fitty_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'breadcrumb',
            'operator' => '==',
            'value'    => 0,
        ),
    ),
    //'sanitize_callback' => 'allow_htmlentities'
) );

//  pagination section // 

Fitty_Kirki::add_section( 'general-pagination', array(   
    'title'          => __( 'Pagination','fitty_pro' ),
    'description'    => __( 'Pagination related options', 'fitty_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'numeric_pagination',
    'label'    => __( 'Numeric Pagination', 'fitty_pro' ),   
    'section'  => 'general-pagination',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Numbered', 'fitty_pro' ),
        'off' => esc_attr__( 'Next/Previous', 'fitty_pro' )
    ),
    'default'  => 'on',
) );

// skin color panel 

Fitty_Kirki::add_panel( 'skin_color_panel', array(   
    'title'       => __( 'Skin Color', 'fitty_pro' ),  
    'description' => __( 'Color Settings', 'fitty_pro' ),         
) );
// color scheme section 

Fitty_Kirki::add_section( 'multiple_color_section', array(
    'title'          => __( 'Color Scheme','fitty_pro' ),
    'description'    => __( 'Select your color scheme', 'fitty_pro'),
    'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 9,
) );  

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'color_scheme',
    'label'    => __( 'Select your color scheme', 'fitty_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'palette',
    'choices'     => array( 
        '1' => array( 
            '#d64391',
        ),
        '2' => array(
            '#297ed9',
        ),
        '3' => array(
            '#00b856',
        ),
        '4' => array(
            '#ff561d',
        ),
        '5' => array(
            '#e3303b',
        ),
        '6' => array(
            '#9a74e7',
        ),
    ),
    'default' => '1',
//'default'  => 'on',
) );
// skin color panel 

Fitty_Kirki::add_panel( 'skin_color_panel', array(   
    'title'       => __( 'Skin Color', 'fitty_pro' ),  
    'description' => __( 'Color Settings', 'fitty_pro' ),         
) );

// Change Color Options  

Fitty_Kirki::add_section( 'primary_color_field', array(
    'title'          => __( 'Change Color Options','fitty_pro' ),
    'description'    => __( 'This will reflect in links, buttons,Navigation and many others. Choose a color to match your site.', 'fitty_pro'),
    'panel'          => 'skin_color_panel', // Not typically needed.
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'enable_primary_color',
    'label'    => __( 'Enable Custom Primary color', 'fitty_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => 'off',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'primary_color',
    'label'    => __( 'Primary color', 'fitty_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => '#d64391', 
    'alpha'  => true,
    'active_callback' => array(
        array (
            'setting'  => 'enable_primary_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array(
        array(
            'element'  => 'input[type="text"]:focus,.tabs.normal ul li a, .tabs ul li a ,
input[type="email"]:focus,
input[type="url"]:focus,
input[type="password"]:focus,.main-navigation a:hover::before, .main-navigation .current_page_item > a::before, .main-navigation .current-menu-item > a::before, .main-navigation .current-menu-parent > a::before, .main-navigation .current_page_ancestor > a::before, .main-navigation .current_page_parent > a::before,
input[type="search"]:focus,.sep,
textarea:focus ,.widget_tag_cloud a ,.ui-accordion h3 span,.left-sidebar .dropcap-book',
            'property' => 'border-color',
        ),
        array(
            'element'  => '.site-footer .scroll-to-top:hover,.flexslider:hover .flex-direction-nav a.flex-next:hover,.portfolioeffects:hover .overlay_icon,button,.share-box ul li a:hover, ol.comment-list .reply:hover a,.page-links ,.post .latest-content a.more-link ,
.services-wrapper .service-section .service-image .fa,.services-wrapper .service-section .service-content .title-divider:before ,
input[type="button"],.comment-meta .edit-link a:hover ,        .post-wrapper .latst-post-wrapper .latest-post-content-wrapper .entry-meta .data-structure,
input[type="reset"],.hentry.sticky ,.flexslider .flex-caption a, .flexslider .flex-caption p a,
input[type="submit"], .nav-links .nav-previous:hover a,.widget_stats-widget .stat-container .icon-wrapper .sow-icon-fontawesome ,.widget_stats-widget .stat-container .icon-wrapper span,
.more-link .nav-previous:hover a, .comment-navigation .nav-previous:hover a,
.main-navigation ul ul li,.menu-toggle ul li a:hover,.gx-pricing-table:hover .btn-normal,
.main-navigation.toggled ul.menu.nav-menu ul li a:hover,.team-member h4,
.slicknav_menu ul li a:hover ,.slicknav_nav .slicknav_row:hover ,.slicknav_btn:hover ,.nav-links .nav-next:hover a,
.more-link .nav-next:hover a, .comment-navigation .nav-next:hover a ,
a.more-link,.widget .ei-slider-thumbs li.ei-slider-element,.tabs.normal ul li a:hover, .tabs ul li a:hover ,
ul.ei-slider-thumbs li.ei-slider-element,ul.filter-options li a:hover, ul.filter-options li .selected,
.woocommerce #content div.product .woocommerce-tabs ul.tabs li a:hover,
.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,.service-wrapper .service-content p a,
.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li a:hover,
.woocommerce-page div.product .woocommerce-tabs ul.tabs li a:hover,
.woocommerce #content div.product .woocommerce-tabs ul.tabs li.active,
.woocommerce div.product .woocommerce-tabs ul.tabs li.active,
.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active,.toggle .toggle-title,
.woocommerce-page div.product .woocommerce-tabs ul.tabs li.active,.woocommerce #content nav.woocommerce-pagination ul li a:focus,
.woocommerce #content nav.woocommerce-pagination ul li a:hover,
.woocommerce #content nav.woocommerce-pagination ul li span.current,
.woocommerce nav.woocommerce-pagination ul li a:focus,.ui-accordion .ui-accordion-header-active,.callout-widget a:hover,#secondary .left-sidebar .callout-widget,
.woocommerce nav.woocommerce-pagination ul li a:hover,.dropcap-circle,
.dropcap-box,.dropcap-book ,.left-sidebar .dropcap-circle,
.left-sidebar .dropcap-box , .site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,.so-widget-skills-widget .skill-container .skill .skill-percentage,
.woocommerce nav.woocommerce-pagination ul li span.current,    .so-widget-flexslider-widget .flexcarousel .flex-direction-nav a:hover, .so-widget-recent-posts-widget .flexcarousel .flex-direction-nav a:hover,.mptt-shortcode-row,
.mptt-shortcode-wrapper .mptt-shortcode-table tr.mptt-shortcode-row th,.mptt-shortcode-wrapper .mptt-navigation-tabs .active a ,
.woocommerce-page #content nav.woocommerce-pagination ul li a:focus,
.woocommerce-page #content nav.woocommerce-pagination ul li a:hover,.icon-box a.more-button:hover,
.woocommerce-page #content nav.woocommerce-pagination ul li span.current,
.woocommerce-page nav.woocommerce-pagination ul li a:focus, .portfolio-excerpt .more-link, .site-footer .footer-widgets .widget_calendar table caption,
.woocommerce-page nav.woocommerce-pagination ul li a:hover,.widget_calendar table caption ,
.woocommerce-page nav.woocommerce-pagination ul li span.current ,.woocommerce a.remove,.widget_search .search-form input[type="submit"],.widget_tag_cloud a ,
.site-footer .widget_social-networks-widget ul li a .fa,      .widget_fitty-latest-product-widget ul .four.columns .product-lists .product-content .product-bottom, .widget_fitty-latest-product-widget ul li .product-lists .product-content .product-bottom,
.site-footer .share-box ul li a .fa,.withtip:before ,.widget_fitty-latest-product-widget ul a.added_to_cart,
.scroll-to-top',
            'property' => 'background-color',
        ),
        array(
            'element'  => '.site-footer .footer-widgets a:hover ,.site-info .left-sidebar .textwidget ul li a:hover,.site-info p a,.site-info .widget_nav_menu a:hover,
.main-navigation a:hover,.site-footer .widget.widget_ourteam-widget:hover .team-content h4,.site-footer .footer-widgets .calendar_wrap a:hover,
#secondary .left-sidebar .widget.widget_ourteam-widget .team-content h4 ,.site-footer .widget_testimonial-widget ul li .client,.portfolioeffects .content-details h3 a:hover, .work .content-details h3 a:hover,
.icon-box .icon-wrapper span,.so-widget-list-widget .sow-icon-fontawesome, .so-widget-list-widget .list-image,
.comment-author .fn a, .left-sidebar .widget_social-networks-widget ul li a:hover i,ol.comment-list article .fn:hover ,.order-total .amount,
.cart-subtotal .amount,.woocommerce #content table.cart a.remove,.breadcrumb a:hover,.service-wrapper .service-content h4 a,
.woocommerce table.cart a.remove,.portfolioeffects .content-details h3 a:hover ,.widget_recent-work-widget .portfolioeffects .content-details h3 a:hover, .widget_recent-work-widget .work .content-details h3 a:hover,
.woocommerce-page #content table.cart a.remove,ul#portfolio li h3 a:hover,.dropcap,
.woocommerce-page table.cart a.remove ,.ui-accordion h3 span,.left-sidebar .dropcap,
.main-navigation .current_page_item > a,.comment-metadata a, .hentry.post h1 a:hover ,
.services-wrapper .service-section .service-content .title-divider a:hover, .post-wrapper .latst-post-wrapper h4 a:hover ,
.main-navigation .current-menu-item > a,.services-wrapper a.more-link, .post-wrapper a.more-link ,
.main-navigation .current-menu-parent > a, .pullright:before,
.pullleft:before,.widget_recent-posts-widget .recent-posts .latest-post-details h3 a:hover, .widget_recent-posts-widget .recent-posts-carousel .latest-post-details h3 a:hover,
.pullnone:before,.widget_recent-posts-widget .recent-posts .latest-post-details .btn-readmore, .widget_recent-posts-widget .recent-posts-carousel .latest-post-details .btn-readmore,v,
.left-sidebar .widget_recent-posts-widget .flex-recent-posts li a ,
.main-navigation .current_page_ancestor > a,.widget-area .widget_rss span, .widget-area .widget_rss a:hover,
.main-navigation .current_page_parent > a,.nav-links .nav-previous:hover a .meta-nav,
.more-link .nav-previous:hover a .meta-nav, .comment-navigation .nav-previous:hover a .meta-nav,.nav-links .nav-next:hover a .meta-nav,
.more-link .nav-next:hover a .meta-nav, .comment-navigation .nav-next:hover a .meta-nav,
.woocommerce .woocommerce-breadcrumb a:hover,.site-footer .widget_calendar table a ,
.woocommerce-page .woocommerce-breadcrumb a:hover,.widget-area ul li a:hover ,#secondary #recentcomments a:hover ,.widget_calendar table th a:hover,
.widget_calendar table td a:hover,.site-footer .widget_recent-posts-widget .latest-post-details h3 a::before',  
            'property' => 'color',
        ),
        array(
            'element'  => '.woocommerce #content input.button:hover,.tabs.normal ul li .tabulous_active, .tabs ul li .tabulous_active,
.woocommerce #respond input#submit:hover,
.woocommerce a.button:hover,
.woocommerce button.button:hover,
.woocommerce input.button:hover,
.woocommerce-page #content input.button:hover,
.woocommerce-page #respond input#submit:hover,
.woocommerce-page a.button:hover,
.woocommerce-page button.button:hover,.site-footer .widget_social-networks-widget ul li a .fa:hover,
.site-footer .share-box ul li a .fa:hover ,
.woocommerce-page input.button:hover,.site-footer .widget.widget_skill-widget .skill-container .skill-percentage,
.left-sidebar .widget.widget_skill-widget .skill-container .skill-percentage',
            'property' => 'background-color',
            'suffix' => '!important',
        ),
        array(
            'element' => '.post-navigation a, .branding .site-branding .site-title a:hover',
            'property' => 'color',
            'suffix' => '!important',
        ),
        array(
            'element' => '.gx-pricing-table:hover .gx-table-header,.withtip.top:after',
            'property' => 'border-top-color',
        ),
        array(
            'element' => '.comment-respond h3:after,  .tabs.normal ul, .tabs ul,.withtip.bottom:after',
            'property' => 'border-bottom-color',
        ),
        array(
            'element'  => '.pullright,
.pullleft,
.pullnone,.withtip.left:after',
            'property' => 'border-left-color',
        ),
        array(
            'element'  => '.withtip.right:after',
            'property' => 'border-right-color',
        ),
    ),
) );


Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'enable_secondary_color',
    'label'    => __( 'Enable Custom Secondary color', 'fitty_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => 'off',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'secondary_color',
    'label'    => __( 'Secondary Color', 'fitty_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => '#202020',
    'alpha'  => true,
    'active_callback' => array(
        array(
            'setting'  => 'enable_secondary_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array(
        array(
            'element' => 'h1, h2, h3, h4, h5, h6 ,.widget_fitty-latest-product-widget ul .four.columns .product-lists .button:hover, .widget_fitty-latest-product-widget ul li .product-lists .button:hover,        .widget_fitty-latest-product-widget ul .four.columns .product-lists .button:hover:before, .widget_fitty-latest-product-widget ul li .product-lists .button:hover:before,  .site-footer .so-widget-style-outlet-pro-latest-product-widget .latest-product-normal .four.columns .product-content h2, .site-footer .so-widget-style-outlet-pro-latest-product-widget .latest-product-normal li .product-content h2, .site-footer .so-widget-style-outlet-pro-latest-product-widget .latest-product-carousel .four.columns .product-content h2, .site-footer .so-widget-style-outlet-pro-latest-product-widget .latest-product-carousel li .product-content h2,
.service-wrapper .service-content h4 a:hover,.so-widget-skills-widget .skill-container .skill span,
.skill-circle .chart-per,.skill-circle .label,.gx-pricing-table .gx-table-content li .fa,.gx-pricing-table .price-btn .btn-normal,      .widget_recent-posts-widget .recent-posts .latest-post-details h3 a, .widget_recent-posts-widget .recent-posts-carousel .latest-post-details h3 a ,.widget_recent-posts-widget .recent-posts .latest-post-details .btn-readmore:hover, .widget_recent-posts-widget .recent-posts-carousel .latest-post-details .btn-readmore:hover,
.widget_recent-posts-widget .recent-posts-slider .flex-caption h4 p.btn-slider a,
.so-widget-testimonial-widget ul li p.client a ,.gx-pricing-table .gx-table-rate ,.flexslider .flex-caption p a:hover ,.ui-accordion .ui-accordion-content,.breadcrumb a,.breadcrumb .breadcrumb-left h4, .breadcrumb .breadcrumb-right,
ul#portfolio li h3 a ,.portfolioeffects .overlay_icon a:hover i,.woocommerce .woocommerce-breadcrumb ,.woocommerce-breadcrumb-class. .widget_calendar table th a, .widget_calendar table td a,.widget_calendar table th,
.widget_calendar table tbody tr:nth-child(even) th, .widget_calendar table tbody tr:nth-child(even) td,.widget_calendar table tbody tr:nth-child(odd) th,.widget_calendar table tbody tr:nth-child(odd) td,.widget-area .widget_rss a ,.widget-area .widget_rss .widget-title .rsswidget,.widget_search .search-form input[type="search"] ,
.widget_search .search-form input[type="search"]:focus,
.page-links a ,.post .latest-content .entry-content,.post .latest-content .entry-content p,
table,table thead tr th,.entry-meta .date-structure:hover .dd,  .entry-meta span:hover i,.entry-meta span:hover a,
.main-navigation .sub-menu a:hover, .main-navigation .sub-menu .current-menu-item > a, .main-navigation .sub-menu .current-menu-parent > a,.post-navigation .meta-previuous-post, .post-navigation .meta-next-post,
.nav-links .meta-nav,.top-nav a:hover,.top-nav ul li a:hover,.share-box .widget-title,
.more-link .meta-nav, .comment-navigation .meta-nav,.comment-author,.comment-author .fn a:hover,ol.comment-list article .fn,ol.comment-list li.byuser .comment-metadata a:hover,
.comment-metadata a:hover,.hentry.sticky .entry-meta .date-structure:hover .dd ,.hentry.sticky h1.entry-title a:hover ,
.post-wrapper .latst-post-wrapper,.post-wrapper .latst-post-wrapper h4 a, .services-wrapper a.more-link:hover, .post-wrapper a.more-link:hover,
.comment-content p,.woocommerce ul.products li.product .price,
.woocommerce-page ul.products li.product .price,
.woocommerce #content div.product p.price,
.woocommerce #content div.product span.price,
.woocommerce div.product p.price,.share-box .widget-title,
.woocommerce div.product span.price,
.woocommerce-page #content div.product p.price,
.woocommerce-page #content div.product span.price,
.woocommerce-page div.product p.price,
.woocommerce-page div.product span.price,.top-nav .theme-social-network a:hover ,
.tabs.normal ul li a, .tabs ul li a,.tabs.normal .tabs_container,
.tabs .tabs_container',
            'property' => 'color',
        ),
        array(
            'element' => 'button:hover,
input[type="button"]:hover,
input[type="reset"]:hover,
input[type="submit"]:hover,button:focus,
input[type="button"]:focus,
input[type="reset"]:focus,
input[type="submit"]:focus,
button:active,
input[type="button"]:active,
input[type="reset"]:active,
input[type="submit"]:active,.site-footer .dropcap-box',
            'property' => 'border-color',
            
        ),
        array(
            'element' => 'button:hover,.site-footer .footer-widgets .widget_tag_cloud a:hover,
.widget_tag_cloud a:hover,.service-wrapper .service-content p a:hover ,.site-footer,    .site-footer .footer-widgets .calendar_wrap tbody tr:nth-child(odd) th, .site-footer .footer-widgets .calendar_wrap tbody tr:nth-child(odd) td,    .site-footer .footer-widgets .calendar_wrap tbody tr:nth-child(even) th, .site-footer .footer-widgets .calendar_wrap tbody tr:nth-child(even) td,.site-footer .footer-widgets .calendar_wrap thead th,
.icon-box a.more-button, ul.filter-options li a,.widget_recent-posts-widget .recent-posts-carousel ol.flex-control-paging li a.flex-active, .widget_recent-posts-widget .recent-posts-carousel ol.flex-control-paging li a:hover,
input[type="button"]:hover,.post .latest-content a.more-link:hover,    .site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev:hover,
.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next:hover,
input[type="reset"]:hover,#secondary .left-sidebar .callout-widget a:hover,
input[type="submit"]:hover,.header-image,a.more-link:hover,ol.comment-list .reply a,
.flexslider .flex-caption a:hover, .flexslider .flex-caption p a:hover,.flex-direction-nav a:hover,
.woocommerce #content table.cart a.remove:hover,.flexslider .flex-direction-nav a:hover ,
.woocommerce table.cart a.remove:hover,  .so-widget-flexslider-widget .flexcarousel .flex-direction-nav a, .so-widget-recent-posts-widget .flexcarousel .flex-direction-nav a,
.woocommerce-page #content table.cart a.remove:hover, .team-social ul li a:hover ,
.woocommerce-page table.cart a.remove:hover,.woocommerce #content nav.woocommerce-pagination ul li,
.woocommerce #content nav.woocommerce-pagination ul,.woocommerce #content div.product .woocommerce-tabs ul.tabs li,
.woocommerce div.product .woocommerce-tabs ul.tabs li,
.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li,
.woocommerce-page div.product .woocommerce-tabs ul.tabs li ,.portfolio-excerpt .more-link:hover',
            'property' => 'background-color',
        ),

        array(
            'element' => '.left-sidebar .widget.widget_skill-widget .skill-container .skill',
            'property' => 'background-color',
            'suffix'  => '!important',
        ),
        array(
            'element' => '.post-navigation a:hover,.hentry.sticky .entry-meta a:hover,.entry-meta .cat-links a:hover',
            'property' => 'color',
            'suffix'  => '!important',
        ),
    ),
) );

/* navigation bg color */
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'enable_nav_bg_color',
    'label'    => __( 'Enable Navigation Background color', 'fitty_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => 'off',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'nav_bg_color',
    'label'    => __( 'Navigation Background Color', 'fitty_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => '#202020',
    'alpha'  => true,
    'active_callback' => array(
        array(
            'setting'  => 'enable_nav_bg_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array(
        array(
            'element' => '.header-image',
            'property' => 'background-color',
            //'suffix'  => '!important',
        ),
    ),
) );
/* submenu bg color */
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'enable_submenu_bg_color',
    'label'    => __( 'Enable Submenu Background color', 'fitty_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => 'off',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'submenu_bg_color',
    'label'    => __( 'Submenu Background Color', 'fitty_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => '#d64391',
    'alpha'  => true,
    'active_callback' => array(
        array(
            'setting'  => 'enable_submenu_bg_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array(
        array(
            'element' => '.main-navigation ul ul li',
            'property' => 'background-color',
            //'suffix'  => '!important',
        ),
        array(
            'element' => '.main-navigation a:hover::before, .main-navigation .current_page_item > a::before, .main-navigation .current-menu-item > a::before, .main-navigation .current-menu-parent > a::before, .main-navigation .current_page_ancestor > a::before, .main-navigation .current_page_parent > a::before',
            'property' => 'border-color',
        ),
         array(
            'element' => '        .main-navigation a:hover, .main-navigation .current_page_item > a, .main-navigation .current-menu-item > a, .main-navigation .current-menu-parent > a, .main-navigation .current_page_ancestor > a, .main-navigation .current_page_parent > a',
            'property' => 'color',
        ),
    ),
) );



// typography panel //  

Fitty_Kirki::add_panel( 'typography', array( 
    'title'       => __( 'Typography', 'fitty_pro' ),
    'description' => __( 'Typography and Link Color Settings', 'fitty_pro' ),
) );
   
    Fitty_Kirki::add_section( 'typography_section', array(
        'title'          => __( 'General Settings','fitty_pro' ),
        'description'    => __( 'General Settings', 'fitty_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );
        

    Fitty_Kirki::add_section( 'body_font', array(
        'title'          => __( 'Body Font','fitty_pro' ), 
        'description'    => __( 'Specify the body font properties', 'fitty_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) ); 

    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'body_typography',
        'label'    => __( 'Enable Custom body Settings', 'fitty_pro' ),
        'section'  => 'body_font',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
            'off' => esc_attr__( 'Disable', 'fitty_pro' )
        ),
        'tooltip' => __('Turn on to body typography and turn off for default typography','fitty_pro'),
        'default'  => 'off',
    ) );


    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'body',
        'label'    => __( 'Body Settings', 'fitty_pro' ),
        'section'  => 'body_font', 
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Open Sans', 
            'variant'        => 'regular',
            'font-size'      => '16px',  
            'line-height'    => '1.5',
            'letter-spacing' => '0',
            'color'          => '#202020', 
        ),
        'output'      => array(
            array(
                'element' => 'body',
                //'suffix' => '!important',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'body_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );


    Fitty_Kirki::add_section( 'heading_section', array(
        'title'          => __( 'Heading Font','fitty_pro' ),
        'description'    => __( 'Specify typography of H1, H2, H3, H4, H5, H6', 'fitty_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'heading_one_typography',
        'label'    => __( 'Enable Custom H1 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
            'off' => esc_attr__( 'Disable', 'fitty_pro' )
        ),
        'tooltip' => __('Turn on to H1 typography and turn off for default typography','fitty_pro'),
        'default'  => 'off',
    ) );


    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'h1',  
        'label'    => __( 'H1 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '48px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h1',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_one_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );
    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'heading_two_typography',
        'label'    => __( 'Enable Custom H2 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
            'off' => esc_attr__( 'Disable', 'fitty_pro' )
        ),
        'tooltip' => __('Turn on to H2 typography and turn off for default typography','fitty_pro'),
        'default'  => 'off',
    ) );


    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'h2',
        'label'    => __( 'H2 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '36px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h2',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_two_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'heading_three_typography',
        'label'    => __( 'Enable Custom H3 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
            'off' => esc_attr__( 'Disable', 'fitty_pro' )
        ),
        'tooltip' => __('Turn on to H3 typography and turn off for default typography','fitty_pro'),
        'default'  => 'off',
    ) );


    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'h3',
        'label'    => __( 'H3 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default' => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '30px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h3',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_three_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'heading_four_typography',
        'label'    => __( 'Enable Custom H4 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
            'off' => esc_attr__( 'Disable', 'fitty_pro' )
        ),
        'tooltip' => __('Turn on to H4 typography and turn off for default typography','fitty_pro'),
        'default'  => 'off',
    ) );


    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'h4',
        'label'    => __( 'H4 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '24px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h4',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_four_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'heading_five_typography',
        'label'    => __( 'Enable Custom H5 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
            'off' => esc_attr__( 'Disable', 'fitty_pro' )
        ),
        'tooltip' => __('Turn on to H5 typography and turn off for default typography','fitty_pro'),
        'default'  => 'off',
    ) );



    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'h5',
        'label'    => __( 'H5 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '18px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h5',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_five_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );

    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'heading_six_typography',
        'label'    => __( 'Enable Custom H6 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
            'off' => esc_attr__( 'Disable', 'fitty_pro' )
        ),
        'tooltip' => __('Turn on to H6 typography and turn off for default typography','fitty_pro'),
        'default'  => 'off',
    ) );



    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'h6',
        'label'    => __( 'H6 Settings', 'fitty_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway', 
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h6',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_six_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    // navigation font 
    Fitty_Kirki::add_section( 'navigation_section', array(
        'title'          => __( 'Navigation Font','fitty_pro' ),
        'description'    => __( 'Specify Navigation font properties', 'fitty_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'navigation_font_status',
        'label'    => __( 'Enable Navigation Font Settings', 'fitty_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
            'off' => esc_attr__( 'Disable', 'fitty_pro' )
        ),
        'tooltip' => __('Turn on to Navigation Font typography and turn off for default typography','fitty_pro'),
        'default'  => 'off',
    ) );

    Fitty_Kirki::add_field( 'fitty_pro', array(
        'settings' => 'navigation_font',
        'label'    => __( 'Navigation Font Settings', 'fitty_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Open Sans',
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8', 
            'letter-spacing' => '0',
            'color'          => '#ffffff',
        ),
        'output'      => array(
            array(
                'element' => '.main-navigation a',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'navigation_font_status',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );



// header panel //  

Fitty_Kirki::add_panel( 'header_panel', array(     
    'title'       => __( 'Header', 'fitty_pro' ),
    'description' => __( 'Header Related Options', 'fitty_pro' ), 
) );  

/* STICKY HEADER section */     
  
Fitty_Kirki::add_section( 'stricky_header', array(
    'title'          => __( 'Sticky Menu','fitty_pro' ),
    'description'    => __( 'sticky header', 'fitty_pro'),
    'panel'          => 'header_panel', // Not typically needed.
) );
Fitty_Kirki::add_field( 'fitty_pro', array(    
    'settings' => 'sticky_header',
    'label'    => __( 'Enable Sticky Header', 'fitty_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => 'on',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'sticky_header_position',
    'label'    => __( 'Enable Sticky Header Position', 'fitty_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'top'  => esc_attr__( 'Top', 'fitty_pro' ),
        'bottom' => esc_attr__( 'Bottom', 'fitty_pro' )
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'sticky_header',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'top',
) );


/*
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'header_top_margin',
    'label'    => __( 'Header Top Margin', 'fitty_pro' ),
    'description' => __('Select the top margin of header in pixels','fitty_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'header_bottom_margin',
    'label'    => __( 'Header Bottom Margin', 'fitty_pro' ),
    'description' => __('Select the bottom margin of header in pixels','fitty_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );*/

Fitty_Kirki::add_section( 'header_image', array(
    'title'          => __( 'Header Background Image','fitty_pro' ),
    'description'    => __( 'Custom Header Image options', 'fitty_pro'),
    'panel'          => 'header_panel', // Not typically needed.  
) );

Fitty_Kirki::add_field( 'fitty_pro', array(   
    'settings' => 'header_bg_size',
    'label'    => __( 'Header Background Size', 'fitty_pro' ),
    'section'  => 'header_image',
    'type'     => 'radio-buttonset', 
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'fitty_pro' ),
        'contain' => esc_attr__( 'Contain', 'fitty_pro' ),
        'auto'  => esc_attr__( 'Auto', 'fitty_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'fitty_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Header Background Image Size','fitty_pro'),
) );

/*Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'header_height',
    'label'    => __( 'Header Background Image Height', 'fitty_pro' ),
    'section'  => 'header_image',
    'type'     => 'number',
    'choices' => array(
        'min' => 100,
        'max' => 600,
        'step' => 1,
    ),
    'default'  => '213',
) ); */
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'header_bg_repeat',
    'label'    => __( 'Header Background Repeat', 'fitty_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'fitty_pro'),
        'repeat' => esc_attr__('Repeat', 'fitty_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','fitty_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'repeat',  
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'header_bg_position', 
    'label'    => __( 'Header Background Position', 'fitty_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'fitty_pro'),
        'center center' => esc_attr__('Center Center', 'fitty_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'fitty_pro'),
        'left top' => esc_attr__('Left Top', 'fitty_pro'),
        'left center' => esc_attr__('Left Center', 'fitty_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'fitty_pro'),
        'right top' => esc_attr__('Right Top', 'fitty_pro'),
        'right center' => esc_attr__('Right Center', 'fitty_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'center center',  
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'header_bg_attachment',
    'label'    => __( 'Header Background Attachment', 'fitty_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'fitty_pro'),
        'fixed' => esc_attr__('Fixed', 'fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'scroll',  
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'header_overlay',
    'label'    => __( 'Enable Header( Background ) Overlay', 'fitty_pro' ),
    'section'  => 'header_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => 'off',
) );
  
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'header_overlay_color',
    'label'    => __( 'Header Overlay ( Background )color', 'fitty_pro' ),
    'section'  => 'header_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'output'   => array(
        array(
            'element'  => '.overlay-header',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

/*
/* e-option start */
/*
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'custon_favicon',
    'label'    => __( 'Custom Favicon', 'fitty_pro' ),
    'section'  => 'header',
    'type'     => 'upload',
    'default'  => '',
) ); */
/* e-option start */ 
/* Blog page section */


/* Blog panel */

Fitty_Kirki::add_panel( 'blog_panel', array(     
    'title'       => __( 'Blog', 'fitty_pro' ),
    'description' => __( 'Blog Related Options', 'fitty_pro' ),     
) ); 
Fitty_Kirki::add_section( 'blog', array(
    'title'          => __( 'Blog Page','fitty_pro' ),
    'description'    => __( 'Blog Related Options', 'fitty_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
  
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'blog_layout',
    'label'    => __( 'Select Blog Page Layout you prefer', 'fitty_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1  => esc_attr__( 'Default ( One Column )', 'fitty_pro' ),
        2 => esc_attr__( 'Two Columns ', 'fitty_pro' ),
        3 => esc_attr__( 'Three Columns ( Without Sidebar ) ', 'fitty_pro' ),
        4 => esc_attr__( 'Two Columns With Masonry', 'fitty_pro' ),
        5 => esc_attr__( 'Three Columns With Masonry ( Without Sidebar ) ', 'fitty_pro' ),
        6 => esc_attr__( 'Blog FullWidth', 'fitty_pro' ),
    ),
    'default'  => 1,
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'featured_image',
    'label'    => __( 'Enable Featured Image', 'fitty_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for blog page','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'more_text',
    'label'    => __( 'More Text', 'fitty_pro' ),
    'section'  => 'blog',
    'type'     => 'text',
    'description' => __('Text to display in case of text too long','fitty_pro'),
    'default' => __('Read More','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'featured_image_size',
    'label'    => __( 'Choose the Featured Image Size for Blog Page', 'fitty_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1 => esc_attr__( 'Large Featured Image', 'fitty_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'fitty_pro' ),
        3 => esc_attr__( 'Original Size', 'fitty_pro' ),
        4 => esc_attr__( 'Medium', 'fitty_pro' ),
        5 => esc_attr__( 'Large', 'fitty_pro' ), 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Set large and medium image size: Goto Dashboard => Settings => Media', 'fitty_pro') ,
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'enable_single_post_top_meta',
    'label'    => __( 'Enable to display top post meta data', 'fitty_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'single_post_top_meta',
    'label'    => __( 'Activate and Arrange the Order of Top Post Meta elements', 'fitty_pro' ),
    'section'  => 'blog',
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'fitty_pro' ),
        2 => esc_attr__( 'author', 'fitty_pro' ),
        3 => esc_attr__( 'comment', 'fitty_pro' ),
        4 => esc_attr__( 'category', 'fitty_pro' ),
        5 => esc_attr__( 'tags', 'fitty_pro' ),
        6 => esc_attr__( 'edit', 'fitty_pro' ),
    ),
    'default'  => array(1, 2, 3,6),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_top_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','fitty_pro'),

) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'enable_single_post_bottom_meta',
    'label'    => __( 'Enable to display bottom post meta data', 'fitty_pro' ),
    'section'  => 'blog', 
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','fitty_pro'),
    'default'  => 'on',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'single_post_bottom_meta',
    'label'    => __( 'Activate and arrange the Order of Bottom Post Meta elements', 'fitty_pro' ),
    'section'  => 'blog',    
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'fitty_pro' ),
        2 => esc_attr__( 'author', 'fitty_pro' ),
        3 => esc_attr__( 'comment', 'fitty_pro' ),
        4 => esc_attr__( 'category', 'fitty_pro' ),
        5 => esc_attr__( 'tags', 'fitty_pro' ),
        6 => esc_attr__( 'edit', 'fitty_pro' ),
    ),
    'default'  => array(4,5),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_bottom_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','fitty_pro'),
) );


/* Single Blog page section */

Fitty_Kirki::add_section( 'single_blog', array(
    'title'          => __( 'Single Blog Page','fitty_pro' ),
    'description'    => __( 'Single Blog Page Related Options', 'fitty_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'single_featured_image',
    'label'    => __( 'Enable Single Post Featured Image', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for Single Post Page','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'single_featured_image_size',
    'label'    => __( 'Choose the featured image display type for Single Post Page', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Large Featured Image', 'fitty_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'fitty_pro' ),
        3 => esc_attr__( 'FullWidth Featured Image', 'fitty_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'author_bio_box',
    'label'    => __( 'Enable Author Bio Box below single post', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'off',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'related_posts',
    'label'    => __( 'Show Related Posts', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Show the Related Post for Single Blog Page','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'related_posts_hierarchy',
    'label'    => __( 'Related Posts Must Be Shown As:', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Related Posts By Tags', 'fitty_pro' ),
        2 => esc_attr__( 'Related Posts By Categories', 'fitty_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'related_posts',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Select the Hierarchy','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'comments',
    'label'    => __( ' Show Comments', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Show the Comments for Single Blog Page','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'social_sharing_box',
    'label'    => __( 'Show social sharing options box below single post', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
) );

//social sharing box section

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'facebook_sb',
    'label'    => __( 'Enable facebook sharing option below single post', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'twitter_sb',
    'label'    => __( 'Enable twitter sharing option below single post', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'linkedin_sb',
    'label'    => __( 'Enable linkedin sharing option below single post', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'google-plus_sb',
    'label'    => __( 'Enable googleplus sharing option below single post', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'email_sb',
    'label'    => __( 'Enable email sharing option below single post', 'fitty_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
/* FOOTER SECTION 
footer panel */

Fitty_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'fitty_pro' ),
    'description' => __( 'Footer Related Options', 'fitty_pro' ),     
) );  

Fitty_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','fitty_pro' ),
    'description'    => __( 'Footer related options', 'fitty_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'fitty_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','fitty_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'fitty_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'fitty_pro' ),
        2  => esc_attr__( '2', 'fitty_pro' ),
        3  => esc_attr__( '3', 'fitty_pro' ),
        4  => esc_attr__( '4', 'fitty_pro' ),
    ),
    'default'  => 4,
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'fitty_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'fitty_pro' ),
    'description' => __('Select the top margin of footer in pixels','fitty_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Fitty_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','fitty_pro' ),
    'description'    => __( 'Custom Footer Image options', 'fitty_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'fitty_pro' ),
        'contain' => esc_attr__( 'Contain', 'fitty_pro' ),
        'auto'  => esc_attr__( 'Auto', 'fitty_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'fitty_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'fitty_pro'),
        'repeat' => esc_attr__('Repeat', 'fitty_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','fitty_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',   
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'fitty_pro'),
        'center center' => esc_attr__('Center Center', 'fitty_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'fitty_pro'),
        'left top' => esc_attr__('Left Top', 'fitty_pro'),
        'left center' => esc_attr__('Left Center', 'fitty_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'fitty_pro'),
        'right top' => esc_attr__('Right Top', 'fitty_pro'),
        'right center' => esc_attr__('Right Center', 'fitty_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'fitty_pro'),
        'fixed' => esc_attr__('Fixed', 'fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => 'off',
) );
  
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer_image',
            'property' => 'background-color',
        ),
    ),
) );


// single page section //

Fitty_Kirki::add_section( 'single_page', array(
    'title'          => __( 'Single Page','fitty_pro' ),
    'description'    => __( 'Single Page Related Options', 'fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'single_page_featured_image',
    'label'    => __( 'Enable Single Page Featured Image', 'fitty_pro' ),
    'section'  => 'single_page',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'single_page_featured_image_size',
    'label'    => __( 'Single Page Featured Image Size', 'fitty_pro' ),
    'section'  => 'single_page',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( 'Normal', 'fitty_pro' ),
        2 => esc_attr__( 'FullWidth', 'fitty_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_page_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

// Layout section //

Fitty_Kirki::add_section( 'layout', array( 
    'title'          => __( 'Layout','fitty_pro' ),
    'description'    => __( 'Layout Related Options', 'fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'site-style',
    'label'    => __( 'Site Style', 'fitty_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'wide' =>  esc_attr__('Wide', 'fitty_pro'),
        'boxed' =>  esc_attr__('Boxed', 'fitty_pro'),
        'fluid' =>  esc_attr__('Fluid', 'fitty_pro'),  
        //'static' =>  esc_attr__('Static ( Non Responsive )', 'fitty_pro'),
    ),
    'default'  => 'wide',
    'tooltip' => __('Choose the default site layout.','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'global_sidebar_layout',
    'label'    => __( 'Check the box if you want to use a global sidebar on all pages. This option overrides the page options', 'fitty_pro' ),
    'section'  => 'layout',
    'type'     => 'checkbox',
    'default' => '0',
) );


Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'sidebar_position',
    'label'    => __( 'Main Layout', 'fitty_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-image',   
    'description' => __('Select main content and sidebar arrangement.','fitty_pro'),
    'choices' => array(
        'left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cl.png',
        'right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cr.png',
        'two-sidebar' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cm.png',  
        'two-sidebar-left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cl.png',
        'two-sidebar-right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cr.png',
        'fullwidth' =>  get_template_directory_uri() . '/admin/kirki/assets/images/1c.png',
        'no-sidebar' =>  get_template_directory_uri() . '/images/no-sidebar.png',
    ),
    'default'  => 'right', 
    'tooltip' => __('global sidebar on all pages. This option overrides the page layout sidebar options','fitty_pro'),
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'body_top_margin',
    'label'    => __( 'Body Top Margin', 'fitty_pro' ),
    'description' => __('Select the top margin of body element in pixels','fitty_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-top',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'body_bottom_margin',
    'label'    => __( 'Body Bottom Margin', 'fitty_pro' ),
    'description' => __('Select the bottom margin of body element in pixels','fitty_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-bottom',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );

/* LAYOUT SECTION  */
/*
Fitty_Kirki::add_section( 'layout', array(
    'title'          => __( 'Layout','fitty_pro' ),   
    'description'    => __( 'Layout settings that affects overall site', 'fitty_pro'),
    'panel'          => 'fitty_pro_options', // Not typically needed.
) );



Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'primary_sidebar_width',
    'label'    => __( 'Primary Sidebar Width', 'fitty_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'fitty_pro' ),
        '2' => __( 'Two Column', 'fitty_pro' ),
        '3' => __( 'Three Column', 'fitty_pro' ),
        '4' => __( 'Four Column', 'fitty_pro' ),
        '5' => __( 'Five Column ', 'fitty_pro' ),
    ),
    'default'  => '5',  
    'tooltip' => __('Select the width of the Primary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'secondary_sidebar_width',
    'label'    => __( 'Secondary Sidebar Width', 'fitty_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'fitty_pro' ),
        '2' => __( 'Two Column', 'fitty_pro' ),
        '3' => __( 'Three Column', 'fitty_pro' ),
        '4' => __( 'Four Column', 'fitty_pro' ),
        '5' => __( 'Five Column ', 'fitty_pro' ),
    ),            
    'default'  => '5',  
    'tooltip' => __('Select the width of the Secondary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','fitty_pro'),
) ); 

*/

/* FOOTER SECTION 
footer panel */

Fitty_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'fitty_pro' ),
    'description' => __( 'Footer Related Options', 'fitty_pro' ),     
) );  

Fitty_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','fitty_pro' ),
    'description'    => __( 'Footer related options', 'fitty_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'fitty_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','fitty_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'fitty_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'fitty_pro' ),
        2  => esc_attr__( '2', 'fitty_pro' ),
        3  => esc_attr__( '3', 'fitty_pro' ),
        4  => esc_attr__( '4', 'fitty_pro' ),
    ),
    'default'  => 4,
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'fitty_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'fitty_pro' ),
    'description' => __('Select the top margin of footer in pixels','fitty_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Fitty_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','fitty_pro' ),
    'description'    => __( 'Custom Footer Image options', 'fitty_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'fitty_pro' ),
        'contain' => esc_attr__( 'Contain', 'fitty_pro' ),
        'auto'  => esc_attr__( 'Auto', 'fitty_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'fitty_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'fitty_pro'),
        'repeat' => esc_attr__('Repeat', 'fitty_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','fitty_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'fitty_pro'),
        'center center' => esc_attr__('Center Center', 'fitty_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'fitty_pro'),
        'left top' => esc_attr__('Left Top', 'fitty_pro'),
        'left center' => esc_attr__('Left Center', 'fitty_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'fitty_pro'),
        'right top' => esc_attr__('Right Top', 'fitty_pro'),
        'right center' => esc_attr__('Right Center', 'fitty_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'fitty_pro'),
        'fixed' => esc_attr__('Fixed', 'fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => 'off',
) );
  
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'fitty_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.overlay-footer',
            'property' => 'background-color',
        ),
    ),
) );


 if( class_exists( 'WooCommerce' ) ) {
    Fitty_Kirki::add_section( 'woocommerce_section', array(
        'title'          => __( 'WooCommerce','fitty_pro' ),
        'description'    => __( 'Theme options related to woocommerce', 'fitty_pro'),
        'priority'       => 11, 
        'theme_supports' => '', // Rarely needed.
    ) );
    Fitty_Kirki::add_field( 'woocommerce', array(
        'settings' => 'woocommerce_sidebar',
        'label'    => __( 'Enable Woocommerce Sidebar', 'fitty_pro' ),
        'description' => __('Enable Sidebar for shop page','fitty_pro'),
        'section'  => 'woocommerce_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
            'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
        ),

        'default'  => 'on',
    ) );
}
    
// background color ( rename )

Fitty_Kirki::add_section( 'colors', array(
    'title'          => __( 'Background Color','fitty_pro' ),
    'description'    => __( 'This will affect overall site background color', 'fitty_pro'),
    //'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 11,
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'general_background_color',
    'label'    => __( 'General Background Color', 'fitty_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-color',
        ),
    ),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'content_background_color',
    'label'    => __( 'Content Background Color', 'fitty_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'description' => __('when you are select boxed layout content background color will reflect the grid area','fitty_pro'), 
    'alpha' => true, 
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'general_background_image',
    'label'    => __( 'General Background Image', 'fitty_pro' ),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-image',
        ),
    ),
) );

// background image ( general & boxed layout ) //


Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'general_background_repeat',
    'label'    => __( 'General Background Repeat', 'fitty_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'fitty_pro'),
        'repeat' => esc_attr__('Repeat', 'fitty_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','fitty_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'general_background_size',
    'label'    => __( 'General Background Size', 'fitty_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'fitty_pro' ),
        'contain' => esc_attr__( 'Contain', 'fitty_pro' ),
        'auto'  => esc_attr__( 'Auto', 'fitty_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'fitty_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'general_background_attachment',
    'label'    => __( 'General Background Attachment', 'fitty_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'fitty_pro'),
        'fixed' => esc_attr__('Fixed', 'fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'general_background_position',
    'label'    => __( 'General Background Position', 'fitty_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'fitty_pro'),
        'center center' => esc_attr__('Center Center', 'fitty_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'fitty_pro'),
        'left top' => esc_attr__('Left Top', 'fitty_pro'),
        'left center' => esc_attr__('Left Center', 'fitty_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'fitty_pro'),
        'right top' => esc_attr__('Right Top', 'fitty_pro'),
        'right center' => esc_attr__('Right Center', 'fitty_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );


/* CONTENT BACKGROUND ( boxed background image )*/

Fitty_Kirki::add_field( 'fitty_pro', array(  
    'settings' => 'content_background_image',
    'label'    => __( 'Content Background Image', 'fitty_pro' ),
    'description' => __('when you are select boxed layout content background image will reflect the grid area','fitty_pro'),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-image',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'content_background_repeat',
    'label'    => __( 'Content Background Repeat', 'fitty_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'fitty_pro'),
        'repeat' => esc_attr__('Repeat', 'fitty_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','fitty_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'content_background_size',
    'label'    => __( 'Content Background Size', 'fitty_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'fitty_pro' ),
        'contain' => esc_attr__( 'Contain', 'fitty_pro' ),
        'auto'  => esc_attr__( 'Auto', 'fitty_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'fitty_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'content_background_attachment',
    'label'    => __( 'Content Background Attachment', 'fitty_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'fitty_pro'),
        'fixed' => esc_attr__('Fixed', 'fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'content_background_position',
    'label'    => __( 'Content Background Position', 'fitty_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'fitty_pro'),
        'center center' => esc_attr__('Center Center', 'fitty_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'fitty_pro'),
        'left top' => esc_attr__('Left Top', 'fitty_pro'),
        'left center' => esc_attr__('Left Center', 'fitty_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'fitty_pro'),
        'right top' => esc_attr__('Right Top', 'fitty_pro'),
        'right center' => esc_attr__('Right Center', 'fitty_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'fitty_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );

/* pro theme options */

//  animation section 

Fitty_Kirki::add_section( 'animation_section', array(
    'title'          => __( 'Animation','fitty_pro' ),
    'description'    => __( 'Animation that affects overall site', 'fitty_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );    

Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'animation_effect',
    'label'    => __( 'Enable Animation Effect', 'fitty_pro' ),   
    'section'  => 'animation_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fitty_pro' ),
        'off' => esc_attr__( 'Disable', 'fitty_pro' ) 
    ),
    'default'  => 'on',
) );

// custom JS section

Fitty_Kirki::add_section( 'custom_js_section', array(
    'title'          => __( 'Custom JS','fitty_pro' ),
    'description'    => __( 'Custom JS', 'fitty_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
 Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'custom_js',
    'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'fitty_pro' ),
    'section'  => 'custom_js_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
) ); 


// Tracking section 

Fitty_Kirki::add_section( 'analytics_section', array(
    'title'          => __( 'Tracking Code','fitty_pro' ),
    'description'    => __( 'Tracking Code', 'fitty_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'analytics',
    'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'fitty_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
    'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'analytics_place',
    'label'    => __( 'Enable to Load Tracking Code in Footer', 'fitty_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'fitty_pro' ),
        '2' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => '2',
    'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','fitty_pro'),
) );


//  lightbox section //

Fitty_Kirki::add_section( 'light_box', array(
    'title'          => __( 'Light Box','fitty_pro' ),
    'description'    => __( 'Light Box Settings', 'fitty_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'lightbox_theme',
    'label'    => __( 'Lightbox Theme', 'fitty_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => esc_attr__( 'pp_default', 'fitty_pro' ),
        '2' => esc_attr__( 'light-rounded', 'fitty_pro' ),
        '3' => esc_attr__( 'dark-rounded', 'fitty_pro' ),
        '4' => esc_attr__( 'light-square', 'fitty_pro' ),
        '5' => esc_attr__( 'dark-square', 'fitty_pro' ),
        '6' => esc_attr__( 'facebook', 'fitty_pro' ),
    ),
    'default'  => '1',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'lightbox_animation_speed',
    'label'    => __( 'Animation Speed', 'fitty_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'fast' => esc_attr__( 'Fast', 'fitty_pro' ),
        'slow' => esc_attr__( 'Slow', 'fitty_pro' ),
        'normal' => esc_attr__( 'Normal', 'fitty_pro' ),
    ),
    'default'  => 'fast',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'lightbox_slideshow',
    'label'    => __( 'Autoplay Gallery Speed', 'fitty_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 100,
        'step' => 10,
    ),
    'default'  => 50,
    'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'lightbox_autoplay_slideshow',
    'label'    => __( 'Enable Autoplay Gallery', 'fitty_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'fitty_pro' ),
        '2' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => '2',
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'lightbox_opacity',
    'label'    => __( 'Select Background Opacity', 'fitty_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 1,
        'step' => 0.1,
    ),
    'default'  => 0.5,
    'tooltip' => __('Enter 0.1 to 1.0','fitty_pro'),
) );
Fitty_Kirki::add_field( 'fitty_pro', array(
    'settings' => 'lightbox_overlay_gallery',
    'label'    => __( 'Show Gallery Thumbnails', 'fitty_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array( 
        '1'  => esc_attr__( 'Enable', 'fitty_pro' ),
        '2' => esc_attr__( 'Disable', 'fitty_pro' )
    ),
    'default'  => '1',
) );


 

         
do_action('fitty_pro_child_customizer_options');
