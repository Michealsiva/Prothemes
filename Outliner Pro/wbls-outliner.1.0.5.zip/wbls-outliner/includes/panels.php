<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts
 *
 * @param $layouts
 */
if (!function_exists('wbls_outliner_prebuilt_page_layouts') ) {   
function wbls_outliner_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-outliner'),
    'description' => __('Pre Built Layout for  home page', 'wbls-outliner'),
    'widgets' =>  array(
        0 => 
    array (
      'title' => 'Who We Are',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque semper scelerisque mi, ac dapibus sem sagittis sit amet. Donec rhoncus ex nec eros commodo eleifend.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '8f032851-c3d1-4bdd-82a9-32359f68c6ad',
        'style' => 
        array (
          'class' => 'header-center-border content-text-black ',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'src' => 'http://outliner.webulous.in/wp-content/uploads/2016/09/home-screen.png',
      'href' => 'http://outliner.webulous.in/wp-content/uploads/2016/09/home-screen.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '4b247a32-4d46-472a-a3ba-7a5437dc7d06',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '316',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '315',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '314',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '313',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '56a2ff63410da',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '765bda52-077c-40ec-b4c9-530af85713a9',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Responsive Layout',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque fringilla, libero at mattis vulputate.',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 3,
        'widget_id' => 'e31c8bf4-4344-45cd-98c1-8786ce1c0a25',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Responsive Layout',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque fringilla, libero at mattis vulputate.',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 4,
        'widget_id' => '2dc2c52c-44c0-43b1-84a3-224659c93379',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Fully Customizable',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque fringilla, libero at mattis vulputate.',
      'icon' => 'fa-cog',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 5,
        'widget_id' => '68ef8e6a-1435-44b9-827a-8b76cb979d9e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Font Awesome',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque fringilla, libero at mattis vulputate.',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 3,
        'id' => 6,
        'widget_id' => 'b7f0ec7c-01f7-4f8c-881d-905b7189a14c',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'SOME OF OUR MOST IMPORTANT PROJECTS',
            'count' => '12',
            'type' => 'isotope',
            'panels_info' => 
            array (
              'class' => 'Wbls_Recent_Work_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '734e221a-733f-44bd-9e68-96dbfcdedde9',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '57ceae4428ca9',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '957e8f41-5b94-41e0-bae8-c1f22f50023e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Response',
            'text' => '[accordion_group][accordion title="Nunc consequat dui ac feugiat molestie"] Nulla tempus interdumnare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut u nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, id congue dui risus faucibus nisl. Nulla tempus interdumnare placerat tellus ut accumsan. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, . Praesent nunc dui, egestas a leo quis, euismod dapibus massa. [/accordion][accordion title="Mauris sed nisl ac nisl scelerisque blandit."]  Praesent nunc dui, egestas a leo quis, euismod dapibus massa. Fusce vitae velit est. In hac habitasse platea dictumstMaecenas posuere non nulla in dignissim. in faucibus. Vestibulum pharetra diam vel metus mattis, quis consequat quam pharetra. Curabitur sit amet ligula posuere, venenatis neque sed, feugiat nibh. Duis consectetur ipsum ac imperdiet tincidunt. Duis aliquet at lacus feugiat volutpat. Donec dignissim odio in tellus porttitor congue. Aenean enim erat, elementum ac dolor at, convallis pharetra mi.  [/accordion][accordion title="Vivamus ut felis eget elit tincidunt"]Nulla tempus interdum nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa.Vivamus suscipit quis massa nec bibendum. Fusce lacinia et lectus et facilisis. posuere augue. Fusce vitae ipsum facilisis, tincidunt mi et, condimentum libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed bibendum sed lorem ut aliquet. Quisque nisi ipsum, lobortis nec imperdiet eu, convallis sed purus. Morbi mollis pharetra lobortis[/accordion][accordion title="Aliquam vitae arcu in felis porttitor "]In rutrum faucibus varius. . Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl  Praesent luctus tellus sit amet mauris varius efficitur. Sed blandit tellus a justo ullamcorper, eget ornare orci aliquet. Aliquam erat volutpat. Integer ultricies accumsan nisi, vel elementum dolor pellentesque sed. Aliquam efficitur nisl ante, nec feugiat nisi interdum et. [/accordion][/accordion_group]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '066a9837-7a9a-4105-bbec-b9904dd942f8',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'LITTLE BIT ABOUT US',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. minim veniam, quis nostrud exercitation ullamco. Etiam sit amet fringilla lacus.Sed vulputate tempor ex, semper imperdiet velit efficitur id. Phasellus eget pellentesque libero. Proin pulvinar molestie tellus, non blandit tellus ultricies at. Aenean ac neque fringilla, interdum ex a, tristique nulla. Aliquam sed velit ipsum.  Sed commodo sapien a justo finibus auctor.  Praesent ultrices dolor id feugiat dictum. Ut blandit metus tincidunt lacus faucibus, a imperdiet libero scelerisque. Quisque quis commodo dui, vitae molestie nisl. Curabitur feugiat ex quis lorem accumsan convallis.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'b157e1f1-c6dd-4e4e-b44d-122c575ed8fe',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'list' => '*Lorem ipsum dolor sit amet, consectetur adipiscing elit.
*Maecenas faucibus tempor malesuada  sagittis efficitur.
*Vivamus nec enim eget mi luctus imperdiet eu sed massa.
*Mauris mollis euismod felis quis hendrerit.
*Pellentesque ante est, vehicula volutpat  amet.',
            'icon' => 'fa-check',
            'color' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_List_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '214660a4-4662-4cfb-b7fd-955e02df6fdb',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => 'header-ld-border',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.46686746987951999,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.53313253012048001,
          ),
        ),
      ),
      'builder_id' => '57ceb09ee2ce8',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'widget_id' => '2131e9b0-88a4-49a1-81c2-1e68db2006ec',
        'style' => 
        array (
          'class' => 'header-ld-border',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'OUR TEAM',
            'text' => 'Our advantages: quality, speed, reliability',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'e0e0d384-8b32-4772-ba5a-d7c342d78150',
              'style' => 
              array (
                'class' => 'header-para-primaryborder',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => ' Nullam ac tellus orci. Suspendisse id orci nec augue tempor tincidunt. Vestibulum a odio erat. Aenean consequat finibus Maecenas dapibus efficitur dui in euismod.',
            'image_url' => 'http://outliner.webulous.in/wp-content/uploads/2016/09/ourteam-two.png',
            'title' => 'Harvey Dent',
            'designation' => 'CEO',
            'linkedin' => 'http://Linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'fce060fa-cfe9-4880-901b-cc15a37fb08b',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Vestibulum porta faucibus dignissim. Duis non mollis dui. Phasellus metus erat, commodo quis odio at, malesuada tincidunt dolor. Morbi nec  Donec sit amet  eget vestibulum massa',
            'image_url' => 'http://outliner.webulous.in/wp-content/uploads/2016/09/ourteam-three.png',
            'title' => 'Boddy Kingman',
            'designation' => 'MANAGER',
            'linkedin' => 'http://Linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '3b9e1d9c-bd1d-4688-9bf8-d664c27a0bdb',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Quisque quis metus at mi semper porta. Phasellus erat justo, sagittis ut est nec, vestibulum laoreet enim.  tempus ut vitae libero. Interdum et malesuada fames ac ante ipsum primis in faucibus. ',
            'image_url' => 'http://outliner.webulous.in/wp-content/uploads/2016/09/ourteam-one.png',
            'title' => 'Bill Cerag',
            'designation' => 'DEVELOPER',
            'linkedin' => 'http://Linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => 'f7f250bc-f654-4c8a-930b-6fd60cd13bd5',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '57ceb003813eb',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '480840ca-d2d4-4459-ae46-830b5f8022d5',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'OUR SKILLS',
      'text' => 'Nulla laoreet justo non laoreet blandit',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 10,
        'widget_id' => 'aa54dc65-48b9-43de-93eb-3b53f552cd59',
        'style' => 
        array (
          'class' => 'header-para-whiteborder header-para-primaryborder',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Skills',
            'panels_info' => 
            array (
              'class' => 'Wbls_Skill_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'd809ac4f-63a8-4dd3-bc63-c487fc01901b',
              'style' => 
              array (
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '57ceb003814cc',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'widget_id' => 'd5536c28-ff4c-4f3f-8abc-2757739c164c',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'RECENT POST',
      'text' => 'Check some of our Recent Post from our Blog',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'widget_id' => '4d5f3c0f-21ef-49e5-93a4-ebb20bd31286',
        'style' => 
        array (
          'class' => 'header-para-primaryborder',
          'padding' => '2px',
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => '',
      'count' => '3',
      'type' => 'normal',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Posts_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 13,
        'widget_id' => '50ea985e-c16e-4240-b924-c4a83b4ee088',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'slider' => 'clients',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 14,
        'widget_id' => '2159a367-07cd-4252-8f67-d6246da54dba',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern stat-white',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'class' => 'standard-width',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern',
        'background_image_attachment' => 444,
        'background_display' => 'cover',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'standard-width',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-white-bg',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern',
        'bottom_margin' => '0px',
        'background_image_attachment' => 464,
        'background_display' => 'cover',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'standard-width ',
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'padding' => '30px',
        'row_stretch' => 'full',
        'background' => '#de3c2f',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    11 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    
    ),

  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-outliner'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-outliner'),
    'widgets' => array(
            0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'WE MAKE THE WEB A BETTER PLACE',
            'text' => 'Nulla tempus malesuada Fusce vitae velit est.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'text-upper',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec mollis. Quisque convallis libero in sapien pharetra tincidunt. Aliquam elit ante, malesuada id, tempor eu, gravida id, odio. Maecenas suscipit, risus et eleifend imperdiet, nisi orci ullamcorper massa, et adipiscing orci velit quis magna. Praesent sit amet ligula id orci venenatis auctor. Donec mollis. Quisque convallis libero in sapien pharetra tincidunt. Aliquam elit ante, malesuada id, tempor eu, gravida id, odio. Maecenas suscipit, risus et eleifend imperdiet, nisi orci ullamcorper massa, et adipiscing orci velit quis magna. 


nibh, id congue dui risus faucibus nisl. Nulla tempus interdum nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. Fusce vitae velit est. In hac habitasse platenibh, id congue dui risus faucibus nisl. Nulla tempus interdum nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa.Maecenas suscipit, risus et eleifend imperdiet, nisi orci ullamcorper massa, et adipiscing orci velit quis magna.',
            'filter' => 'on',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => 'Praesent elementum condimentum eros, aliquam sagittis nibh tempus vel. Ut aliquam fringilla dolor eu vehicula. Proin laoreet, dolor in lobortis porttitor, leo erat pretium est, ac elementum nisi ligula et arcu. Donec elementum nisi sed dolor fermentum posuere. Nam vel quam vitae purus blandit molestie. Donec commodo velit ac purus auctor fringilla. Proin viverra sit amet turpis quis suscipit. Pellentesque fermentum, mauris at convallis fringilla, augue ipsum hendrerit eros, nec gravida ligula lorem eget erat.


Ut faucibus est massa, non blandit dolor accumsan non. Fusce tristique vel ex ut condimentum. Suspendisse pellentesque porttitor magna a rhoncus. Donec pulvinar gravida elit id scelerisque. Duis elementum bibendum nulla, id fermentum felis facilisis at. Sed pretium iaculis sem, nec vehicula lacus eleifend in. Maecenas lorem dolor, faucibus quis eros quis, facilisis auctor libero. In consectetur, dui sit amet dapibus tempus, massa ligula ullamcorper neque, et ullamcorper nisl nulla quis libero. Quisque mollis egestas ornare.',
            'filter' => 'on',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'content-text-black  header-para-primaryborder',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => 'bottom-gap',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '55baf33a1e35b',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '316',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '315',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '314',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '313',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => 'white-title',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '56a307de91ceb',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'class' => 'clr-white',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'OUR RESPONSE',
            'text' => '[accordion_group][accordion title="Nunc consequat dui ac feugiat molestie"] Nulla tempus interdumnare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut u nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, id congue dui risus faucibus nisl. Nulla tempus interdumnare placerat tellus ut accumsan. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, . Praesent nunc dui, egestas a leo quis, euismod dapibus massa. Praesent nunc dui, egestas a leo quis, euismod dapibus massa.  [/accordion][accordion title="Mauris  scelerisque blandit."]  Praesent nunc dui, egestas a leo quis, euismod dapibus massa. Fusce vitae velit est. In hac habitasse platea dictumstMaecenas posuere non nulla in dignissim. in faucibus. Vestibulum pharetra diam vel metus mattis, quis consequat quam pharetra. Curabitur sit amet ligula posuere, venenatis neque sed, feugiat nibh. Duis consectetur ipsum ac imperdiet tincidunt. Duis aliquet at lacus feugiat volutpat. Donec dignissim odio in tellus porttitor congue. Aenean enim erat, elementum ac dolor at, convallis pharetra mi. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, id congue dui risus faucibus nisl. Nulla tempus interdumnare placerat tellus ut accumsan. Praesent   [/accordion][accordion title="Vivamus ut felis eget elit tincidunt"]Nulla tempus interdum nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa.Vivamus suscipit quis massa nec bibendum. Fusce lacinia et lectus et facilisis. posuere augue. Fusce vitae ipsum facilisis, tincidunt mi et, condimentum libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed bibendum sed lorem ut aliquet. Quisque nisi ipsum, lobortis nec imperdiet eu, convallis sed purus. Morbi mollis pharetra lobortis. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, id congue dui risus faucibus nisl. Nulla tempus interdumnare placerat tellus ut accumsan.  [/accordion][accordion title="Aliquam vitae arcu in felis porttitor "]In rutrum faucibus varius. . Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl  Praesent luctus tellus sit amet mauris varius efficitur. Sed blandit tellus a justo ullamcorper, eget ornare orci aliquet. Aliquam erat volutpat. Integer ultricies accumsan nisi, vel elementum dolor pellentesque sed. Aliquam efficitur nisl ante, nec feugiat nisi interdum et.  Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, id congue dui risus faucibus nisl. Nulla tempus interdumnare placerat tellus ut accumsan. Praesent nunc dui, egestas a leo quis, euismod dapibus massa.  [/accordion][/accordion_group]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'header-ld-border',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'OUR SKILLS',
            'panels_info' => 
            array (
              'class' => 'Wbls_Skill_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 1,
              'style' => 
              array (
                'class' => 'skill-black',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.49297188755019999,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.050200803212849997,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.45682730923694997,
          ),
        ),
      ),
      'builder_id' => '55c0517f5aaf8',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'class' => 'header-ld-border',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now ',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern stat-white',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'standard-width',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),

        ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'wbls-outliner'),
      'description' => __( 'Pre Built layout for features page', 'wbls-outliner'),
      'widgets' => array(
            0 => 
    array (
      'title' => '',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'class' => 'header-center-border content-text-black ',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Responsive Layout',
      'text' => 'Outliner is fully responsive and can adapt to any screen size. Resize your browser window to view it!',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Awesome Slider',
      'text' => 'Outliner includes Flex slider. You can use Flex slider anywhere in your site.',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Font Awesome',
      'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Typography',
      'text' => 'Outliner loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
      'icon' => 'fa-font',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Retina Ready',
      'text' => 'Outliner is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 5,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Excellent Support   ',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
      'icon' => 'fa-thumb-tack',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 6,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'Webulous Theme',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Advanced Admin',
      'text' => 'Outliner uses advanced Redux Framework for theme options panel, you can customize any part of your site quickly and easily!',
      'icon' => 'fa-cog',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Page Builder',
      'text' => 'Outliner supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 9,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Page Layouts',
      'text' => 'Outliner offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy (alias)',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 10,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Custom Widget',
      'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
      'icon' => 'fa-beer',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 11,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Shortcode Builder',
      'text' => 'Outliner inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
      'icon' => 'fa-check',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 12,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => 'Demo Content',
      'text' => 'Outliner includes demo content files. You can quickly setup the site like our demo and get started easily!',
      'icon' => 'fa-times',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 2,
        'id' => 13,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'Webulous Theme',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 14,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'title' => 'Woo Commerce',
      'text' => 'Outliner has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!',
      'icon' => 'fa-shopping-cart',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 15,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => 'Social Media',
      'text' => 'Want your users to stay in touch? No problem, Outliner has Social Media icons all throughout the theme!',
      'icon' => 'fa-skype',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 16,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'title' => 'Google Map',
      'text' => 'Outliner includes Google Map as shortcode and widget. So you can use it anywhere in your site!',
      'icon' => 'fa-map-marker',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 2,
        'id' => 17,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'title' => 'Multiple Portfolio',
      'text' => '2 portfolio layouts, 1 blog layouts and alternate layouts for interior pages!',
      'icon' => 'fa-list-alt',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 18,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'title' => 'Multiple Sidebar',
      'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
      'icon' => 'fa-columns',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 1,
        'id' => 19,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    20 => 
    array (
      'title' => 'Customization',
      'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
      'icon' => 'fa-edit (alias)',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 2,
        'id' => 20,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    4 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    7 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    8 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    9 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    10 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    11 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    12 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    13 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    14 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    15 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    16 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    17 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    18 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    19 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    20 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-outliner'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-outliner'),
      'widgets' => array(
            0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'contact us',
            'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d6305.992774595653!2d-122.41157430890459!3d37.790124433800656!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858091edff45bd%3A0x70c4586b1202a605!2sUSA+Hostels+San+Francisco!5e0!3m2!1sen!2sin!4v1407318894507" width="1200" height="300" frameborder="0" style="border:0"></iframe>',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'header-center-border bottom-gap',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[accordion_group][accordion title="HEAD OFFICE"]<p><i class="fa fa-phone-square"></i>  +123 4567 890</p><br><p><i class="fa fa-envelope"></i>  info@gmail.com</p><br><p><i class="fa fa-map-marker"></i> Haffman Parkman, P.O Box 350 Mountain View. United States of America.</p><br> [/accordion][accordion title="branch office (usa)"] <p><i class="fa fa-phone-square"></i> +1 888-234-567</p><br><p><i class="fa fa-envelope"></i>  info@gmail.com</p><br><p> <i class="fa fa-map-marker"></i>  129 East Broadway Blvd,Anaheim, CA. [/accordion][accordion title="branch office (australia)"]<p><i class="fa fa-phone-square"></i>  +123 4567 890</p><br><p><i class="fa fa-envelope"></i>  info@gmail.com</p><br><p><i class="fa fa-map-marker"></i> 13/2 Elizabeth Street Melbourne VLC 3000, Australia [/accordion][/accordion_group]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => 'new-accordion',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => '[contact-form-7 id="5" title="Contact form 1"]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => 'contact-form',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => 'contact-form',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.46993987975952001,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.53006012024047999,
          ),
        ),
      ),
      'builder_id' => '55c05233f093b',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-outliner'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-outliner'),
    'widgets' =>  array(
          0 => 
    array (
      'title' => 'FAQ\'S',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'class' => 'header-para-primaryborder',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '[accordion_group][accordion title="Nunc consequat dui ac feugiat molestie"] Nulla tempus interdumnare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut u nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, id congue dui risus faucibus nisl. Nulla tempus interdumnare placerat tellus ut accumsan. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, . Praesent nunc dui, egestas a leo quis, euismod dapibus massaAenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa.Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa. [/accordion][accordion title="Mauris sed nisl ac nisl scelerisque blandit."]  Praesent nunc dui, egestas a leo quis, euismod dapibus massa. Fusce vitae velit est. In hac habitasse platea dictumstMaecenas posuere non nulla in dignissim. in faucibus. Vestibulum pharetra diam vel metus mattis, quis consequat quam pharetra. Curabitur sit amet ligula posuere, venenatis neque sed, feugiat nibh. Duis consectetur ipsum ac imperdiet tincidunt. Duis aliquet at lacus feugiat volutpat. Donec dignissim odio in tellus porttitor congue. Aenean enim erat, elementum ac dolor at, convallis pharetra mi. Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa. [/accordion][accordion title="Vivamus ut felis eget elit tincidunt"]Nulla tempus interdum nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa.Vivamus suscipit quis massa nec bibendum. Fusce lacinia et lectus et facilisis. posuere augue. Fusce vitae ipsum facilisis, tincidunt mi et, condimentum libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed bibendum sed lorem ut aliquet. Quisque nisi ipsum, lobortis nec imperdiet eu, convallis sed purus. Morbi mollis pharetra lobortis.Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa.[/accordion][accordion title="Aliquam vitae arcu in felis porttitor "]In rutrum faucibus varius. . Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl  Praesent luctus tellus sit amet mauris varius efficitur. Sed blandit tellus a justo ullamcorper, eget ornare orci aliquet. Aliquam erat volutpat. Integer ultricies accumsan nisi, vel elementum dolor pellentesque sed. Aliquam efficitur nisl ante, nec feugiat nisi interdum et. Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa. [/accordion][accordion title="Nunc consequat dui ac feugiat molestie"] Nulla tempus interdumnare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut u nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, id congue dui risus faucibus nisl. Nulla tempus interdumnare placerat tellus ut accumsan. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, . Praesent nunc dui, egestas a leo quis, euismod dapibus massa.Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa. [/accordion][accordion title="Mauris sed nisl ac nisl scelerisque blandit."]  Praesent nunc dui, egestas a leo quis, euismod dapibus massa. Fusce vitae velit est. In hac habitasse platea dictumstMaecenas posuere non nulla in dignissim. in faucibus. Vestibulum pharetra diam vel metus mattis, quis consequat quam pharetra. Curabitur sit amet ligula posuere, venenatis neque sed, feugiat nibh. Duis consectetur ipsum ac imperdiet tincidunt. Duis aliquet at lacus feugiat volutpat. Donec dignissim odio in tellus porttitor congue. Aenean enim erat, elementum ac dolor at, convallis pharetra mi.  Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa.[/accordion][accordion title="Vivamus ut felis eget elit tincidunt"]Nulla tempus interdum nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa.Vivamus suscipit quis massa nec bibendum. Fusce lacinia et lectus et facilisis. posuere augue. Fusce vitae ipsum facilisis, tincidunt mi et, condimentum libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed bibendum sed lorem ut aliquet. Quisque nisi ipsum, lobortis nec imperdiet eu, convallis sed purus. Morbi mollis pharetra lobortis .Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa.[/accordion][accordion title="Aliquam vitae arcu in felis porttitor "]In rutrum faucibus varius. . Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl  Praesent luctus tellus sit amet mauris varius efficitur. Sed blandit tellus a justo ullamcorper, eget ornare orci aliquet. Aliquam erat volutpat. Integer ultricies accumsan nisi, vel elementum dolor pellentesque sed. Aliquam efficitur nisl ante, nec feugiat nisi interdum et.Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa. [/accordion][/accordion_group]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => 'hcc68gmxe9pe3ik9',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'Webulous Theme',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'standard-width',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-outliner'),
    'description' => __('Pre Built Layout for services page', 'wbls-outliner'),
    'widgets' =>  array(
        0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '3',
            'type' => 'normal',
            'content' => 'HAPPY CLIENTS',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'header-para-primaryborder',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Testimonials',
            'count' => '5',
            'panels_info' => 
            array (
              'class' => 'Wbls_Testimonial_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '55bf4b8f4d2f7',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '366366c2-71f0-4fd0-85ba-1252a06e1c0c',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'OUR SERVICES',
            'text' => '',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'header-para-whiteborder header-para-primaryborder',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'RESPONSIVE LAYOUT',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque fringilla, libero at mattis vulputate.',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'RETINA READY',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque fringilla, libero at mattis vulputate.',
            'icon' => 'fa-magic',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'FULLY CUSTOMIZABLE',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque fringilla, libero at mattis vulputate.',
            'icon' => 'fa-cog',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'FONT AWESOME',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque fringilla, libero at mattis vulputate.',
            'icon' => 'fa-flag',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => 'white-title',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '55bf4ba350650',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'ba2e1438-eb52-4b8d-9671-85faece99c68',
        'style' => 
        array (
          'class' => 'clr-white',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'OUR TEAM',
            'text' => 'Our advantages: quality, speed, reliability',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '7bd919a3-f66b-46ad-bc4c-5252880481d5',
              'style' => 
              array (
                'class' => 'header-para-primaryborder',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => ' Nullam ac tellus orci. Suspendisse id orci nec augue tempor tincidunt. Vestibulum a odio erat. Aenean consequat finibus Maecenas dapibus efficitur dui in euismod.',
            'image_url' => 'http://outliner.webulous.in/wp-content/uploads/2016/09/ourteam-two.png',
            'title' => 'Harvey Dent',
            'designation' => 'CEO',
            'linkedin' => 'http://linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'htp://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '8e27e254-d1e3-4972-a711-81138744dbe8',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => ' Nullam ac tellus orci. Suspendisse id orci nec augue tempor tincidunt. Vestibulum a odio erat. Aenean consequat finibus Maecenas dapibus efficitur dui in euismod.',
            'image_url' => 'http://outliner.webulous.in/wp-content/uploads/2016/09/ourteam-three.png',
            'title' => 'Boddy Kingman',
            'designation' => 'MANAGER',
            'linkedin' => 'http://linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'htp://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '47e8858d-e3eb-45a6-9f6b-dd1f16ee9bab',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => ' Nullam ac tellus orci. Suspendisse id orci nec augue tempor tincidunt. Vestibulum a odio erat. Aenean consequat finibus Maecenas dapibus efficitur dui in euismod.',
            'image_url' => 'http://outliner.webulous.in/wp-content/uploads/2016/09/ourteam-one.png',
            'title' => 'Bill Cerag',
            'designation' => 'DEVELOPER',
            'linkedin' => 'http://linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'htp://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '4944df66-13d6-4f96-9f81-af2cbf5b0106',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '57cebc08762f6',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '9b6c9933-56d5-4c45-a978-1350378d0882',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'Webulous Theme',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => 'a0e2b5fd-6426-42f2-ad2b-62cc74c9d659',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'bottom-gap standard-width',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern skill-white',
        'bottom_margin' => '0px',
        'background_image_attachment' => 497,
        'background_display' => 'cover',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-white-bg',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'wbls_outliner_prebuilt_page_layouts');

function wbls_outliner_panels_row_style_fields($fields) {  

    $outliner_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-outliner'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-outliner' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-outliner' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-outliner' ),
        'bounce-animation' => __('bounce-animation','wbls-outliner' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-outliner' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-outliner' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-outliner' ),
        'expandUp-animation' => __('expandUp-animation','wbls-outliner' ),
        'fade-animation' => __('fade-animation','wbls-outliner' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-outliner' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-outliner' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-outliner' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-outliner' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-outliner' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-outliner' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-outliner' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-outliner' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-outliner' ),
        'flip-animation' => __('flip-animation','wbls-outliner' ),
        'flipInX-animation' => __('flipInX-animation','wbls-outliner' ),
        'flipInY-animation' => __('flipInY-animation','wbls-outliner' ),
        'floating-animation' => __('floating-animation','wbls-outliner' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-outliner' ),
        'hatch-animation' => __('hatch-animation','wbls-outliner' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-outliner' ),
        'puffIn-animation' => __('puffIn-animation','wbls-outliner' ),
        'pullDown-animation' => __('pullDown-animation','wbls-outliner' ),
        'pullUp-animation' => __('pullUp-animation','wbls-outliner' ),
        'pulse-animation' => __('pulse-animation','wbls-outliner' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-outliner' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-outliner' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-outliner' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-outliner' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-outliner' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-outliner' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-outliner' ),
        'scale-down-animation' => __('scale-down-animation','wbls-outliner' ),
        'scale-up-animation' => __('scale-up-animation','wbls-outliner' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-outliner' ),
        'slide-left-animation' => __('slide-left-animation','wbls-outliner' ),
        'slide-right-animation' => __('slide-right-animation','wbls-outliner' ),
        'slide-top-animation' => __('slide-top-animation','wbls-outliner' ),
        'slideDown-animation' => __('slideDown-animation','wbls-outliner' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-outliner' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-outliner' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-outliner' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-outliner' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-outliner' ),
        'slideRight-animation' => __('slideRight-animation','wbls-outliner' ),
        'slideUp-animation' => __('slideUp-animation','wbls-outliner' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-outliner' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-outliner' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-outliner' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-outliner' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-outliner' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-outliner' ),
        'swap-animation'  => __('swap-animation','wbls-outliner' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-outliner' ),
        'swing-animation'  => __('swing-animation','wbls-outliner' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-outliner' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-outliner' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-outliner' ), 
        'tossing-animation'  => __('tossing-animation','wbls-outliner' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-outliner' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-outliner' ), 
        'wobble-animation' => __('wobble-animation','wbls-outliner' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-outliner' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'outliner'),
            'type' => 'select',
            'options' => $outliner_animation_name,
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_outliner_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_outliner_panels_row_style_fields');

function wbls_outliner_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_outliner_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_outliner_panels_panels_row_style_attributes', 10, 2);

function wbls_outliner_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Animation', 'wbls-outliner'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_outliner_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_outliner_row_style_groups' );