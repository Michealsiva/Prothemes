<div class="free-home">
	<div class="services-wrapper clearfix">
	     <div class="service"><?php
	        if( has_post_thumbnail() ) : ?>
                <span><a href="<?php echo esc_url( get_permalink() ); ?>"><?php
                    the_post_thumbnail('recent_page_img'); ?></a>
                </span><?php 
	        endif; 
    	     the_title( sprintf( '<h2><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); 
	    	 the_content(); ?>
	    </div>
	</div> 
</div>

 