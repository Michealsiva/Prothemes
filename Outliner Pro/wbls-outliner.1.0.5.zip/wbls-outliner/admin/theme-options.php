<?php
/**
 * Pro customizer options     
 */

add_action('wbls-outliner_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() { 
 

// pro home page section 

		Outliner_Kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-outliner' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-outliner'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) );

		Outliner_Kirki::add_field( 'outliner', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-outliner' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch',
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
				'off' => esc_attr__( 'Disable', 'wbls-outliner' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-outliner'),
			'default'  => 'off',
		) );
		Outliner_Kirki::add_field( 'outliner', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-outliner' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-outliner'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-outliner'),
		) );

//  animation section 

Outliner_Kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-outliner' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-outliner'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-outliner' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Outliner_Kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-outliner' ),
	'description'    => __( 'Custom JS', 'wbls-outliner'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-outliner' ),
	'section'  => 'custom_js_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
) ); 


// Tracking section 

Outliner_Kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-outliner' ),
	'description'    => __( 'Tracking Code', 'wbls-outliner'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'analytics',
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-outliner' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-outliner' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'2' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-outliner'),
) );

// color scheme section 

Outliner_Kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-outliner' ),
	'description'    => __( 'Select your color scheme', 'wbls-outliner'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'color_scheme',
	'label'    => __( 'Select your color scheme', 'wbls-outliner' ),
	'section'  => 'multiple_color_section',
	'type'     => 'palette',
	'choices'     => array(
    '1' => array(
		'#de3c2f',
	),
	'2' => array(
		'#08579c',
	),
	'3' => array(
		'#112c63',
	),
	'4' => array(
		'#0cc065',
	),
	'5' => array(
		'#7ead16',
	),
	'6' => array(
		'#c300bb',
	),
	'7' => array(
		'#7360cb',
	),
	'8' => array(
		'#e18904',
	),
),
'default' => '1',
//'default'  => 'on',
) );

//social network URL
Outliner_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-outliner' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-outliner'),
	'panel'			 => 'social_panel',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-outliner' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-outliner'),
) );

// flexslider section //

Outliner_Kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-outliner' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-outliner'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-outliner' ),
		'2' => esc_attr__( 'Slide', 'wbls-outliner' )
	),
	'default'  => '2',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-outliner' ),
		'2' => esc_attr__( 'Vertical', 'wbls-outliner' )
	),
	'default'  => '1',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => 'on',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => 'on',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => 'on',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => 'on',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => 'off',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => 'off',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => 'off',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'off' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-outliner' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Outliner_Kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-outliner' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-outliner'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-outliner' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'2' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => '2',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-outliner' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-outliner' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-outliner' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'2' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => '2',
) );

//  portfolio settings //

Outliner_Kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-outliner' ),
) );

$post_per_page = get_option('posts_per_page');
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-outliner' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-outliner' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-outliner' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-outliner' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-outliner'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-outliner' ),
		2 => __( 'Show Without "All"', 'wbls-outliner' ),
		3 => __( 'Hide', 'wbls-outliner' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Outliner_Kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-outliner' ),
	'description'    => __( 'Light Box Settings', 'wbls-outliner'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-outliner' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-outliner' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-outliner' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-outliner' ),
		'4' => esc_attr__( 'light-square', 'wbls-outliner' ),
		'5' => esc_attr__( 'dark-square', 'wbls-outliner' ),
		'6' => esc_attr__( 'facebook', 'wbls-outliner' ),
	),
	'default'  => '1',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-outliner' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-outliner' ),
		'slow' => esc_attr__( 'Slow', 'wbls-outliner' ),
		'normal' => esc_attr__( 'Normal', 'wbls-outliner' ),
	),
	'default'  => 'fast',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-outliner' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-outliner' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'2' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => '2',
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-outliner' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-outliner'),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-outliner' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-outliner' ),
		'2' => esc_attr__( 'Disable', 'wbls-outliner' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-outliner' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#1fb2e2',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'input[type="text"]:focus,.icon-top .fa-stack::after,.pullright span::before, .pullleft span::before, .pullnone span::before,
						input[type="email"]:focus,.btn::after, .btn::before, .widget_button-widget a.btn.btn-default::after, .widget_button-widget a.btn.btn-default::before,
						input[type="url"]:focus,.services-wrapper .service span::after,
						input[type="password"]:focus,.post-wrapper .latest-post .latest-post-content a::before,
						input[type="search"]:focus,.post-wrapper .latest-post .latest-post-content a::after,
						textarea:focus,.main-navigation .sub-menu .current_page_item > a:after,
						.main-navigation .sub-menu .current-menu-item > a:after,.tabs.normal ul li .tabulous_active::before, .tabs.normal ul li .tabulous_active::after, .tabs.normal ul li a:hover::before, .tabs.normal ul li a:hover::after, .tabs ul li .tabulous_active::before, .tabs ul li .tabulous_active::after, .tabs ul li a:hover::before, .tabs ul li a:hover::after,
						.main-navigation .sub-menu .current_page_ancestor > a:after, .main-navigation .sub-menu li a:hover:after,.branding .site-branding:before,.free-home .services-wrapper .service span:after,.free-home .post-wrapper .latest-post .latest-post-content a:after,.free-home .post-wrapper .latest-post .latest-post-content a:before,
						.archive .blog-thumb:after, .page-template-blog-fullwidth .blog-thumb:after, .page-template-blog-large .blog-thumb:after, .single-post .blog-thumb:after, .page-template-blog-small .blog-thumb:after,ol.comment-list li.byuser article,ol.comment-list li.byuser .comment-author img, blockquote:before,
						blockquote p:after,.widget.widget_ourteam-widget .team-avatar:after,.widget.widget_skill-widget .skill-container .skill .skill-percentage:before,.widget.widget_skill-widget .skill-container .skill .skill-percentage:after,
						.ui-accordion h3 span,.pullright::after, .pullleft::after, .pullnone::after,.ui-accordion .ui-accordion-header-active span:after,.widget_recent-work-widget ul.filter-options li a:hover:after,ul.filter-options li a:hover:after,.notice a,.btn:after,.widget_button-widget a.btn.btn-default:after,
						.pullright:before,.pullleft:before,.pullnone:before,.toggle-normal .toggle-title .fa-minus:after,.toggle-normal .toggle-title .fa-plus,.circle-icon-box .circle-icon-wrapper .fa-stack i,.circle-icon-box .circle-icon-wrapper .fa-stack i:after,.icon-polygon .circle-icon-wrapper h3.fa-stack,.icon-polygon .circle-icon-wrapper h3.fa-stack:before,.icon-polygon .circle-icon-wrapper h3.fa-stack:after,
						.widget_testimonial-widget .testimonials-wrapper:before,.widget_testimonial-widget ul li .client-pic:after,.widget_testimonial-widget .flex-direction-nav .flex-next:after,.widget_testimonial-widget .flex-direction-nav .flex-prev:after,.icon-horizontal .fa-stack:after,.icon-vertical .fa-stack:after,.widget_image-box-widget .image-box img,
						.widget_list-widget ul li .fa,.archive .blog-thumb::after, .single-post .blog-thumb::after, .home.blog .blog-thumb::after, .blog .blog-thumb::after,.widget_list-widget ol li .fa,.widget_recent-posts-widget .recent-posts li:after,.widget_recent-posts-widget .recent-posts-carousel .flex-viewport li:after,.left-sidebar .dropcap-book,.widget_tag_cloud a,.widget_tag_cloud a:after,.widget_recent-work-widget ul.filter-options li a:hover::before,ul.filter-options li a:hover::before,.widget_tag_cloud a::before ',
			'property' => 'border-color',
		),
		array(
			'element'  => '.withtip.left:after,.icon-polygon .circle-icon-wrapper h3.fa-stack',
			'property' => 'border-left-color',
		),
		array(
			'element'  => ' .withtip.right:after,.icon-polygon .circle-icon-wrapper h3.fa-stack ',
			'property' => 'border-right-color',
		),
		array(
			'element'  => '.main-navigation ul li:hover > ul,.date-structure .dd:after, .date-structure .mm:after, .date-structure .yy:after,.sep:after,.withtip.top:after',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '.home.blog .hentry.post .entry-title::after, .blog .hentry.post .entry-title::after,.page-template-blog-fullwidth .hentry.post .entry-title:after, .page-template-blog-large .hentry.post .entry-title:after, .page-template-blog-small .hentry.post .entry-title:after,.header-para-primaryborder:after,
		.header-ld-border .widget-title:after, .header-ld-border .left:after,.header-center-border .widget-title:after,.our-team:hover h4:after,.portfolio-excerpt h4:after,.withtip.bottom:after',
			'property' => 'border-bottom-color',
		),
		array(
			'element'  => 'a,.main-navigation ul ul a,ol.webulous_page_navi li a,.free-home .services-wrapper .service:hover h6, .free-home .services-wrapper .service:hover h5, .free-home .services-wrapper .service:hover h4, .free-home .services-wrapper .service:hover h3, .free-home .services-wrapper .service:hover h2, .free-home .services-wrapper .service:hover h1,ol.comment-list .reply:before,
							ol.comment-list article .fn,.comment-metadata a:hover,.hentry.post h1 a:hover,.date-structure .dd, .date-structure .mm, .date-structure .yy,
						.entry-meta span:hover i,.entry-meta span:hover a,.entry-footer a:hover span, .entry-footer a:hover i,.entry-footer span:hover i,.entry-footer span:hover a,.page-links a, blockquote:before,
						.breadcrumb .breadcrumb-left #crumbs .fa:hover, .breadcrumb .breadcrumb-left #crumbs a:hover,.nav-bottom-slider-breadcrumb .breadcrumb-right #crumbs a:hover,.order-total .amount,
						.cart-subtotal .amount,.woocommerce #content table.cart a.remove,
						.woocommerce table.cart a.remove,.portfolio-excerpt .more-link,
						.woocommerce-page #content table.cart a.remove,
						.woocommerce-page table.cart a.remove,.widget.widget_skill-widget .skill-container .fa-stack,.breadcrumb-wrap #breadcrumb a:hover,.breadcrumb-wrap #breadcrumb a:hover i,.alert-message a:hover,.notice a:hover,.pullright:before,.pullleft:before,.pullnone:before,
						.circle-icon-box .circle-icon-wrapper .fa-stack i,.circle-icon-box:hover a.link-title,.circle-icon-box:hover a.link-title h4,.circle-icon-box:hover h4,.icon-horizontal:hover a.link-title,
						.icon-horizontal:hover .icon-title,.icon-left:hover .fa-stack i, .icon-top:hover .fa-stack i, .icon-right:hover .fa-stack i,
						.icon-horizontal:hover .fa-stack,.icon-left:hover a.link-title, .icon-left:hover .icon-title, .icon-left:hover .fa-stack, .icon-top:hover a.link-title, .icon-top:hover .icon-title, .icon-top:hover .fa-stack, .icon-right:hover a.link-title, .icon-right:hover .icon-title, .icon-right:hover .fa-stack,
						.icon-vertical:hover a.link-title,.icon-left:hover a.link-title, .icon-left:hover .icon-title, .icon-left:hover .fa-stack, .icon-top:hover a.link-title, .icon-top:hover .icon-title, .icon-top:hover .fa-stack, .icon-right:hover a.link-title, .icon-right:hover .icon-title, .icon-right:hover .fa-stack,
						.icon-vertical:hover .icon-title,.icon-left:hover .fa-stack i, .icon-top:hover .fa-stack i, .icon-right:hover .fa-stack i,
						.icon-vertical:hover .fa-stack,.icon-horizontal:hover .fa-stack i,
						.icon-vertical:hover .fa-stack i,.pullright span::before, .pullleft span::before, .pullnone span::before,.widget_list-widget ul li .fa, .widget_list-widget ol li .fa,.widget_recent-posts-widget .recent-posts .rp-content h4:hover,.widget_recent-posts-widget .recent-posts-carousel .rp-content h4:hover,
						.widget_recent-posts-widget .recent-posts-slider .rp-content h4:hover,.site-footer .icon-horizontal .icon-title,
						.site-footer .icon-vertical .icon-title,.site-footer .widget_list-widget ul li i,.site-footer .widget.widget_ourteam-widget:hover .team-content h4,.site-footer .widget_testimonial-widget ul li .client,.left-sidebar .dropcap,
						.left-sidebar .icon-horizontal .icon-title,.left-sidebar .icon-vertical .icon-title,.left-sidebar .widget_list-widget ul li i,#secondary .left-sidebar .widget.widget_ourteam-widget .team-content h4,.left-sidebar .widget_recent-posts-widget .flex-recent-posts li a,.left-sidebar .widget_social-networks-widget ul li a:hover i,
						#secondary .widget_button-widget .btn.white:hover,.widget-area ul li a:hover,#secondary #recentcomments a,.widget_calendar table th a, .widget_calendar table td a,.widget-area .widget_rss a,.site-footer .footer-widgets #calendar_wrap a,.site-footer .footer-widgets a:hover,.site-info p a',
									'property' => 'color',
		),
		/*array(
			'element'  => 'th a,
							.site-header .social .recentcomments a,
							.header-wrap .site-header .social .recentcomments a,
							.left-sidebar .recentcomments a,
							.left-sidebar .widget_rss a,
							.ei-title h3,
							#secondary .btn-white:hover,
			  				#secondary .widget_button-widget .btn.white:hover',
			'property' => 'color',
			'suffix' => '!important',
		),*/
		array(
			'element'  => '.nav-wrap,.main-navigation ul ul li,.widget.widget_ourteam-widget .team-social ul li a:hover,.main-navigation .sub-menu .current_page_item > a,.site-footer .footer-widgets input[type="submit"],
						.main-navigation .sub-menu .current-menu-item > a,.services-wrapper .service h6::after, .services-wrapper .service h5::after, .services-wrapper .service h4::after, .services-wrapper .service h3::after, .services-wrapper .service h2::after, .services-wrapper .service h1::after,
						.main-navigation .sub-menu .current_page_ancestor > a, .main-navigation .sub-menu li a:hover,ol.webulous_page_navi li a:hover,ol.webulous_page_navi li.bpn-current,.branding .site-branding,.top-nav ul li:hover a,
						.free-home .post-wrapper .latest-post .latest-post-content a,.page-template-blog-fullwidth .more-link, .page-template-blog-large .more-link, .page-template-blog-small .more-link,
						.hentry.sticky,blockquote,.post-wrapper .latest-post .latest-post-content a,
						.contact-form input[type="submit"],.widget.widget_skill-widget .skill-container .skill .skill-percentage,.widget.widget_skill-widget .skill-container .skill .skill-percentage:before,
						.ui-accordion h3,.ui-accordion .ui-accordion-header-active,.widget_recent-work-widget .portfolioeffects .overlay_icon a:hover, .widget_recent-work-widget .work .overlay_icon a:hover,
						.widget_recent-work-widget ul.filter-options li a:hover,.portfolioeffects .overlay_icon a:hover,ul.filter-options li a:hover,ol.flex-control-paging li a.flex-active,.notice,.widget_button-widget a.btn.btn-default,.dropcap-circle,
						.dropcap-box,.dropcap-book,.pullright,.pullleft,.pullnone,.toggle .toggle-title,.withtip:before,.circle-icon-box a.more-button:hover,.circle-icon-box:hover .circle-icon-wrapper .fa-stack i,
						.circle-icon-box:hover a.more-button,.icon-polygon a.more-button,.callout-widget,.widget_testimonial-widget .testimonials-wrapper:after,.widget_testimonial-widget ul li p.client,.widget_testimonial-widget ul li p.client .client-name:before,.widget_social-networks-widget ul li a:hover,.share-box ul li a:hover,
						.icon-horizontal .icon-title:after,.icon-vertical .icon-title:after,.widget_testimonial-widget .flex-direction-nav a,.widget_image-box-widget a.more-button,.widget_recent-posts-widget .recent-posts .rp-content .btn-readmore,.widget_recent-posts-widget .recent-posts-carousel .rp-content .btn-readmore,.widget_recent-posts-widget .recent-posts-slider .rp-content .btn-readmore,.site-footer .footer-bottom ul.menu li.current_page_item a,
						.site-footer .icon-horizontal .fa-stack,.site-footer .icon-vertical .fa-stack,.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,  .site-footer .widget.widget_skill-widget .skill-container .skill-percentage,#secondary .left-sidebar .callout-widget,
						.left-sidebar .dropcap-circle,.icon-left .icon-title::after, .icon-top .icon-title::after, .icon-right .icon-title::after,.left-sidebar .dropcap-box,.left-sidebar .icon-horizontal .fa-stack,
						.left-sidebar .icon-vertical .fa-stack,.tabs.normal ul li .tabulous_active, .tabs.normal ul li a:hover, .tabs ul li .tabulous_active, .tabs ul li a:hover,.tabs.normal li a.tabulous_active span, .tabs li a.tabulous_active span,.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,.left-sidebar .widget.widget_skill-widget .skill-container .skill-percentage,
						.widget_calendar table caption,.home.blog .more-link, .blog .more-link,.widget_tag_cloud a,.slicknav_nav li.current_page_item > a,
						.slicknav_nav li.current-menu-parent > a,.slicknav_nav .slicknav_row:hover,.slicknav_nav a:hover,a.slicknav_btn:hover,.btn, .widget_button-widget a.btn.btn-default',
			'property' => 'background-color',
		),
		array(
			'element'  => '.widget_testimonial-widget .flex-direction-nav a ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
) );

/*Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-outliner' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#222222',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.site-content .navigation a,
							.site-content .more-link,
							.site-content .comment-navigation a,
							.webulous_page_navi li.bpn-current,
							.header-wrap .social ul li a,
							.comment-list > li article .comment-meta .comment-author b:hover,
							.comment-list > li article .comment-meta .comment-author a:hover,
							.comment-list > li article .comment-meta .comment-author cite:hover,
							.comment-list > li article .reply:hover i,
							#primary .sticky .entry-meta a,
					  		#primary .sticky .entry-footer a,
					  		.latest-post-content a.btn-readmore,
					  		.related-posts ul#webulous-related-posts li:hover a,
					  		.site-footer .footer-widgets .widget_archive select,
						    .site-footer .footer-widgets .widget_categories select,
						    .site-footer .footer-widgets .textwidget select,
						    .widget.widget_ourteam-widget .team-content h4 span,
						    .widget_recent-posts-widget .recent-post .readmore a,
						    .alert-message a,
						    .icon-right .icon-title,
							.icon-left .icon-title,
							.icon-right a.link-title,
							.icon-right .icon-title,
							.icon-right .fa-stack,
							.icon-left a.link-title,
							.icon-left .icon-title,
							.icon-left .fa-stack,
							.widget_testimonial-widget ul li .client,
							.single-portfolio .one-third dd a:hover,
							.outliner-process.white-bg,
			  				.outliner-process.white-bg h3.widget-title,
			  				.outliner-process.white-bg .textwidget h4,
			  				.not-found-inner a:hover,
			  				.cnt-address .widget_text p:nth-of-type(1),
							.cnt-address .textwidget p:nth-of-type(1),
							#secondary.sidebar .widget_testimonial-widget h3',
			'property' => 'color',
		),
		array(
			'element' => 'table tr th:hover a,
			  				.site-header .social .recentcomments a:hover	
							.header-wrap .site-header .social .recentcomments a:hover,
							#primary .sticky a:hover,
							#primary .sticky span:hover,
							#primary .sticky time:hover,
							.left-sidebar .recentcomments a:hover,
							.left-sidebar .widget_rss a:hover,
							.wide-cta .call-btn a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),
		array(
			'element' => 'button:hover,
							input[type="button"]:hover,
							input[type="reset"]:hover,
							input[type="submit"]:hover,
							.footer-widgets .textwidget .wpcf7-form input.wpcf7-submit:hover,
							#nav-wrap,
							.main-navigation ul ul li,
							.site-content .more-link:hover,
							.webulous_page_navi li a,
							.webulous_page_navi li.bpn-next-link a,
			  				.webulous_page_navi li.bpn-prev-link a,
			  				.home .flexslider .slides .flex-caption a:hover,
			      			.home .flexslider .slides .flex-caption p a:hover,
			      			.home .flexslider .flex-control-paging li a,
			      			.share-box ul li a,
			      			.site-footer .widget_social-networks-widget ul li a:hover,
			      			#secondary select,
							.footer-widgets select,
							.widget.widget_ourteam-widget ul.team-social li a,
							.widget.widget_ourteam-widget:hover .team-social ul li a:hover,
							.widget.widget_skill-widget .skill-container .skill .skill-percentage,
							.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link,
							.widget_recent-work-widget .portfolio4col .overlay_icon a,
							#filters ul.filter-options li a:hover,
						    #filters ul.filter-options li a.selected,
						    .recent-work-container .recent_work_overlay a.icon-zoom,
						    .portfolioeffects .portfolio_link_icons a,
						    .flexslider .slides .flex-caption a:hover,
			      			.flexslider .slides .flex-caption p a:hover,
			      			.flexslider .flex-control-paging li a,
			      			.widget_recent-work-widget ul.flex-direction-nav a:hover,
			      			.widget_recent-posts-widget .recent-posts-carousel ul.flex-direction-nav a:hover,
			      			.recent-posts-slider .flex-direction-nav a:hover,
			      			.widget_recent-posts-widget .recent-posts-carousel .flex-control-nav li a,
			      			.recent-posts-slider .flex-control-paging li a,
			      			.flex-control-nav li a,
			      			.wide-default .widget_flexslider-widget .flexcarousel .flex-direction-nav a:hover,
			      			.page-slider ul.ei-slider-thumbs li a,
			      			a.btn-white:hover,
			  				.widget_button-widget .btn.white:hover,
			  				.toggle .toggle-title:hover,
			  				.circle-icon-box:hover .circle-icon-wrapper,
			  				.callout-widget .call-btn a,
			  				.wide-dark-grey .callout-widget p.call-btn a:hover,
			  				.widget_wbls-image-widget .image-widget-overlay:hover i:hover,
			  				.error-404.not-found .page-header,
			  				.cnt-form .wpcf7-form input[type="submit"]:hover,
			  				.site-footer .widget_social-networks-widget ul li a,
			  				#secondary.sidebar .callout-widget p.call-btn a:hover',
			'property' => 'background-color',
		),
        array(
			'element' => '.slicknav_menu,
				          .search-form input.search-submit:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element' => '.page-numbers,
				         .outliner-process.white-bg .textwidget img',  
			'property' => 'border-color',
		),
		array(
			'element' => '.site-content .nav-next a span,
							.withtip.left:after,
							.home .flexslider .slides .flex-caption a:after,
			      			.home .flexslider .slides .flex-caption p a:after,
			      			.home .flexslider .flex-direction-nav .flex-nav-next a,
			      			#filters ul.filter-options li a:hover:before,
			        		#filters ul.filter-options li a.selected:before,
			        		.flexslider .slides .flex-caption a:after,
			      			.flexslider .slides .flex-caption p a:after,
			      			.flexslider .flex-direction-nav .flex-nav-next a,
			      			.widget_button-widget .btn.white:hover:after,
			      			.callout-widget .call-btn a:after,
			      			.wide-dark-grey .callout-widget p.call-btn a:hover:after,
			      			.widget_testimonial-widget .flex-direction-nav a.flex-next:hover',
			'property' => 'border-left-color',
		),
		array(
			'element' => 'abbr,acronym,.withtip.bottom:after',
			'property' => 'border-bottom-color',
		),
        array(
			'element' => '.withtip.right:after,.page-numbers:last-child,
			      			.site-content .nav-previous a span,
			      			.home .flexslider .flex-direction-nav .flex-nav-prev a,
			      			.flexslider .flex-direction-nav .flex-nav-prev a,
			      			a.btn-white:hover:before,
			    			.widget_button-widget .btn.white:hover:before,
			    			.callout-widget .call-btn a:before,
			    			.wide-dark-grey .callout-widget p.call-btn a:hover:before,
			    			.widget_testimonial-widget .flex-direction-nav a.flex-prev:hover',
			'property' => 'border-right-color',
		),
        array(
			'element' => '.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link:after',
			'property' => 'border-top-color',
		),
		array(
			'element' => '.site-footer .widget_social-networks-widget ul li a:after',
			'property' => 'border-top-color',
			'suffix' => '!important',
		),
		
	),
) );*/
//  slider panel //

Outliner_Kirki::add_panel( 'slider_panel', array(   
	'title'       => __( 'Slider Settings', 'wbls-outliner' ),  
	'description' => __( 'Flex slider related options', 'wbls-outliner' ), 
	'priority'    => 11,    
) );

//  flexslider section  //

Outliner_Kirki::add_section( 'flex_caption_section', array(
	'title'          => __( 'Flexcaption Settings','wbls-outliner' ),
	'description'    => __( 'Flexcaption Related Options', 'wbls-outliner'),
	'panel'          => 'slider_panel', // Not typically needed.
) );

Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexcaption_bg',
	'label'    => __( 'Select Flexcaption Background Color', 'wbls-outliner' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexcaption_align',
	'label'    => __( 'Select Flexcaption Alignment', 'wbls-outliner' ),
	'section'  => 'flex_caption_section',
	'type'     => 'select',
	'default'  => 'left',
	'choices' => array(
		'left' => esc_attr__( 'Left', 'wbls-outliner' ),
		'right' => esc_attr__( 'Right', 'wbls-outliner' ),
		'center' => esc_attr__( 'Center', 'wbls-outliner' ),
		'justify' => esc_attr__( 'Justify', 'wbls-outliner' ),
	),
	'output'   => array(
		array(
			'element'  => '.home .flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption,.flexslider .slides .flex-caption h1, .flexslider .slides .flex-caption h2, .flexslider .slides .flex-caption h3, .flexslider .slides .flex-caption h4, .flexslider .slides .flex-caption h5, .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption p,.flexslider .slides .flex-caption',
			'property' => 'text-align',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
 Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexcaption_bg_position',
	'label'    => __( 'Select Flexcaption Background Horizontal Position', 'wbls-outliner' ),
	'tooltip' => __('Select how far from right','wbls-outliner'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '0',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'right',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
 Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'wbls-outliner' ),
	'tooltip' => __('Select how far from top','wbls-outliner'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '0',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'top',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexcaption_bg_width',
	'label'    => __( 'Select Flexcaption Background Width', 'wbls-outliner' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '70',
	'tooltip' => __('Select Flexcaption Background Width','wbls-outliner'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexcaption_responsive_bg_width',
	'label'    => __( 'Select Responsive Flexcaption Background Width', 'outliner' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Responsive Flexcaption Background Width, Default width value 100 ( This value will apply for max-width: 768px )','outliner'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'media_query' => '@media (max-width: 768px)',
			'value_pattern' => 'calc($%)',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Outliner_Kirki::add_field( 'outliner', array(
	'settings' => 'flexcaption_color',
	'label'    => __( 'Select Flexcaption Font Color', 'outliner' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption,.home .flexslider .slides .flex-caption p,.flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption p a,.flexslider .slides .flex-caption p a,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption h1,.flexslider .slides .flex-caption h2,.flexslider .slides .flex-caption h3,.flexslider .slides .flex-caption h4,.flexslider .slides .flex-caption h5,.flexslider .slides .flex-caption h6',
			'property' => 'color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );


}

