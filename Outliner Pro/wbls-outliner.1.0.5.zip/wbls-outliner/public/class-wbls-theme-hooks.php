<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 4:55 PM
	 */
if( ! class_exists( 'Wbls_Theme_Hooks' )) {
	class Wbls_Theme_Hooks {

		public function full_width_slider(){
			global $post; 
			remove_action('outliner_before_content','outliner_before_content_free',10); 
			 get_header('blank');   
			$slider_shortcode = get_post_meta( $post->ID, '_wbls_slider_shortcode', true );
			if( $slider_shortcode != '' ) {?>
		       
					<?php echo do_shortcode( $slider_shortcode ); ?>
				
				<header id="masthead" class="site-header nav-bottom" role="banner"> 		
					<div class="branding">
						<div class="container">
						<div class="five columns">
							<div class="logo site-branding">
								<?php if( get_theme_mod('logo_title', false ) && get_theme_mod('logo', '') )  : ?>
									<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url( get_theme_mod('logo')); ?>" alt="logo" ></a>
								<?php else : ?>
									<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
								<?php endif; ?>
								<?php if( get_theme_mod('tagline', true ) ) : ?>
									<h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
								<?php endif; ?>
							</div><!-- .site-branding -->
							</div>
							<div class="eleven columns">
							<nav id="site-navigation" class="main-navigation clearfix" role="navigation">
								<h1 class="menu-toggle"><?php _e( 'Menu', 'wbls-outliner' ); ?></h1>
								<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'wbls-outliner' ); ?></a>
								<?php wp_nav_menu( array( 'theme_location' => 'primary','menu_class' => 'menu nav-menu' ) ); ?>
							</nav><!-- #site-navigation -->
						</div>
						</div>
					</div>
					<?php $breadcrumb = get_theme_mod( 'breadcrumb',true ); ?>
					<div class="container">
						<div class="breadcrumb nav-bottom-slider-breadcrumb">
							<div class="breadcrumb-left eight columns">			
									<?php the_title('<h2>','</h2>');?>
							</div>
							<div class="breadcrumb-right eight columns">
							<?php if( $breadcrumb ) : ?>
									<?php wbls_outliner_breadcrumbs(); ?>
								<?php endif; ?>
							</div>
							
						</div>
					</div>
						
				</header><!-- #masthead -->
		<?php	} else {
					get_header();
		        }
				
		} 
		
		public function single_portfolio($single_template){
		    global $post;
			if( $post->post_type == 'portfolio') {
				$single_template = WBLS_THEME_DIR . 'public/views/single-portfolio.php';
				if( file_exists($single_template) && is_file($single_template) ) {
					 $single_template;
				} else {
					if( defined( 'WBLS_FW_DIR' ) ) {
						$single_template = WBLS_FW_DIR . 'public/views/single-portfolio.php';	
						if( is_file($single_template) && file_exists( $single_template ) ) {
                            $single_template;
						}
					}
					
				}
			}
			return $single_template;
		}

		public function single_post($single_template){    
		    global $post;
		    $post_fullwidth = get_post_meta( $post->ID, '_wbls_full_width_post', true );
			if( $post->post_type == 'post') {
				if ( $post_fullwidth ){
					$single_template = WBLS_THEME_DIR . 'public/views/single-post-fullwidth.php';
				    if( file_exists($single_template) && is_file($single_template) ) {
					    $single_template;
				    } 
				}
			}
			return $single_template;
		}

		public function portfolio_views($file){        
			global $post;
		    $file = WBLS_THEME_DIR . 'public/views/' . get_post_meta( $post->ID, '_wp_page_template', true );
			return $file;
		}

		public function customizer_options($free_options) {   
			$pro_options = array(
	            // typography start //
	            'typography' => array(   
	                'priority'       => 10,
	                'title'          => __('Typography', 'wbls-outliner'),
	                'description'    => __('Typography and Link Color Settings', 'wbls-outliner'),
	                'sections' => array(
	                    'typography_section' => array(
	                        'title' => __('General Settings', 'wbls-outliner'),
	                        'description' => __('','wbls-outliner'),
	                        'fields' => array(
	                            'custom_typography' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Custom Typography', 'wbls-outliner'),
	                                'description' => __('Turn on to customize typography and turn off for default typography.', 'wbls-outliner'),
	                                'default' => 0,
	                            ),

	                        ),    
	                    ),

	                    'body_font' => array(
	                        'title' => __('Body Font','wbls-outliner'),
	                        'description' => __('Specify the body font properties.','wbls-outliner'),
	                        'fields' => array (
	                            'body' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                            ),
	                            'body_color' => array(
	                                'type' => 'color',
	                                'label' => __('Body Color', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#333'
	                            ),
	                        ),
	                    ),
	                    'h1_property' => array(
	                        'title' => __('H1 Font Properties','wbls-outliner'),
	                        'description' => __('Specify the h1 font properties.','wbls-outliner'),
	                        'fields' => array (
	                            'h1' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                            ),
	                            'h1_color' => array(
	                                'type' => 'color',
	                                'label' => __('H1 Color', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#333'
	                            ),
	                        ),
	                    ),
	                    'h2_property' => array(
	                        'title' => __('H2 Font Properties','wbls-outliner'),
	                        'description' => __('Specify the h2 font properties.','wbls-outliner'),
	                        'fields' => array (
	                                'h2' => array(
	                                    'type' => 'typography',
	                                    'label' => __('', 'wbls-outliner'),
	                                    'description' => __('', 'wbls-outliner'),
	                                ),
	                                'h2_color' => array(
	                                    'type' => 'color',
	                                    'label' => __('H2 Color', 'wbls-outliner'),
	                                    'description' => __('', 'wbls-outliner'),
	                                    'sanitize_callback' => 'sanitize_hex_color',
	                                    'transport' => 'postMessage',
	                                    'default' => '#333'
	                                )
	                        ),
	                    ),
	                    'h3_property' => array(
	                        'title' => __('H3 Font Properties','wbls-outliner'),
	                        'description' => __('Specify the h3 font properties.','wbls-outliner'),
	                        'fields' => array (
	                                'h3' => array(
	                                    'type' => 'typography',
	                                    'label' => __('', 'wbls-outliner'),
	                                    'description' => __('', 'wbls-outliner'),
	                                ),
	                                'h3_color' => array(
	                                    'type' => 'color',
	                                    'label' => __('H3 Color', 'wbls-outliner'),
	                                    'description' => __('', 'wbls-outliner'),
	                                    'sanitize_callback' => 'sanitize_hex_color',
	                                    'transport' => 'postMessage',
	                                    'default' => '#333'     
	                                )
	                        ),
	                    ),
	                    'h4_property' => array(
	                        'title' => __('H4 Font Properties','wbls-outliner'),
	                        'description' => __('Specify the h4 font properties.','wbls-outliner'),
	                        'fields' => array (
	                            'h4' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                            ),
	                            'h4_color' => array(
	                                'type' => 'color',
	                                'label' => __('H4 Color', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#333'
	                            )
	                        ),
	                    ),
	                    'h5_property' => array(
	                        'title' => __('H5 Font Properties','wbls-outliner'),
	                        'description' => __('Specify the h5 font properties.','wbls-outliner'),
	                        'fields' => array (
	                            'h5' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                            ),
	                            'h5_color' => array(
	                                'type' => 'color',
	                                'label' => __('H5 Color', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#333'
	                            )
	                        ),
	                    ),
	                    'h6_property' => array(
	                        'title' => __('H6 Font Properties','wbls-outliner'),
	                        'description' => __('Specify the h6 font properties.','wbls-outliner'),
	                        'fields' => array (
	                            'h6' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                            ),
	                            'h6_color' => array(
	                                'type' => 'color',
	                                'label' => __('H6 Color', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#333'
	                            )
	                        ),
	                    ),
	                ),
	            ), // typography panel end //

				'pro_panel' => array(
	                'priority'       => 9,
	                'title'          => __('Pro Options', 'wbls-outliner'),
	                'description'    => __('Pro Options', 'wbls-outliner'),
	                'sections' => array(
	                    'multiple_color_section' => array(
	                        'title' => __('Color Scheme ', 'wbls-outliner'),
	                        'description' => __('Select your color scheme','wbls-outliner'),
	                        'fields' => array(
	                            'color_scheme' => array(        
	                                'type' => 'select',
	                                'label' => __('Select your color scheme.', 'wbls-outliner'),
	                                'description' => __(' ', 'wbls-outliner'),
	                                'choices' => array(
	                                    '1' => __('Default', 'wbls-outliner'),       
	                                    '2' => __('Blue', 'wbls-outliner'),
	                                    '3' => __('DarkBlue', 'wbls-outliner'),       
	                                    '4' => __('Green', 'wbls-outliner'),
	                                    '5' => __('LightGreen', 'wbls-outliner'),   
	                                    '6' => __('Purple', 'wbls-outliner'),
	                                    '7' => __('PurpleLight', 'wbls-outliner'),
	                                    '8' => __('Yellow', 'wbls-outliner'),	  	                                 
	                                ),
	                                'default' => 1,  
                            	),                     
	                        ),
	                    ),
                       'social_network' => array(
                        'title' => __('Social Networks', 'wbls-outliner'),
                        'description' => __(' Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-outliner'),
                        'fields' => array(
                            'digg' => array(
                                'type' => 'text',
                                'label' => __('Digg', 'wbls-outliner'), 
                                'description' => __('Your Digg link ', 'wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'dribbble' => array(
                                'type' => 'text',
                                'label' => __('Dribbble', 'wbls-outliner'),
                                'description' => __('Your Dribbble link ', 'wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'facebook' => array(
                                'type' => 'text',
                                'label' => __('Facebook', 'wbls-outliner'),
                                'description' => __('Your Facebook link', 'wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'twitter' => array(
                                'type' => 'text',
                                'label' => __('Twitter', 'wbls-outliner'),
                                'description' => __('Your Twitter link', 'wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'google_plus' => array(
                                'type' => 'text',
                                'label' => __('Google +', 'wbls-outliner'),
                                'description' => __('Your Google Plus', 'wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',

                            ),
                            'linkedin' => array(
                                'type' => 'text',
                                'label' => __('LinkedIn', 'wbls-outliner'),
                                'description' => __('Your LinkedIn link', 'wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'instagram' => array(
                                'type' => 'text',
                                'label' => __('Instagram', 'wbls-outliner'),
                                'description' => __('Your Instagram link ', 'wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'flickr' => array(
                                'type' => 'text',
                                'label' => __('Flickr', 'wbls-outliner'),
                                'description' => __('Your Flickr link', 'wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'youtube' => array(
                                'type' => 'text',
                                'label' => __('YouTube', 'wbls-outliner'),
                                'description' => __('Your YouTube link', 'wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'vimeo' => array(
                                'type' => 'text',
                                'label' => __('Vimeo', 'wbls-outliner'),
                                'description' => __('Your Vimeo link', 'wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'pinterest' => array(
                                'type' => 'text',
                                'label' => __('Pinterest', 'wbls-outliner'),
                                'description' => __('Your Pinterest link','wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'rss' => array(
                                'type' => 'text',
                                'label' => __('RSS', 'wbls-outliner'),
                                'description' => __('Your RSS link','wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'skype' => array(
                                'type' => 'text',
                                'label' => __('Skype', 'wbls-outliner'),
                                'description' => __('Your Skype link','wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'tumblr' => array(
                                'type' => 'text',
                                'label' => __('Tumblr', 'wbls-outliner'),
                                'description' => __('Your Tumblr link','wbls-outliner'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                        ),
                    ),

						'flex_slider_section' => array(
	                        'title' => __('Flex Slider', 'wbls-outliner'),
	                        'description' => __('Flex Slider Settings','wbls-outliner'),
	                        'fields' => array(
	                            'animation' => array(
	                                'type' => 'select',
	                                'label' => __('Select slider animation effect', 'wbls-outliner'),
	                                'description' => __('Select slider animation effect.', 'wbls-outliner'),
	                                'choices' => array(
	                                    '1' => __('Fade', 'wbls-outliner'),
	                                    '2' => __('Slide', 'wbls-outliner'),
	                                ),
	                                'default' => 2,
	                            ),
	                            'slide_direction' => array(
	                                'type' => 'select',
	                                'label' => __('Select direction to slide ', 'wbls-outliner'),
	                                'description' => __('Select direction to slide (if you are using the "Slide" animation)', 'wbls-outliner'),
	                                'choices' => array(
	                                    '1' => __('Horizontal', 'wbls-outliner'),
	                                    '2' => __('Vertical', 'wbls-outliner'),
	                                ),
	                                'default' => 1,
	                            ),
	                            'flexslider_slideshow_speed' => array(
	                                'type' => 'range',
	                                'label' => __('Slideshow Speed', 'wbls-outliner'),
	                                'description' => __('Set the delay between each slide animation (in milliseconds)', 'wbls-outliner'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 1,
	                                ),
	                                'default' => 50
	                            ),
	                            'flexslider_animation_speed' => array(
	                                'type' => 'range',
	                                'label' => __('Animation Speed', 'wbls-outliner'),
	                                'description' => __('Set the duration of each slide animation (in milliseconds)', 'wbls-outliner'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 1,
	                                ),
	                                'default' => 50
	                            ),
	                            'flexslider_slideshow' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Animate the slideshows automatically', 'wbls-outliner'),
	                                'description' => __('Enable Animate the slideshows automatically', 'wbls-outliner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_smooth_height' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable to Adjust the height of the slideshow to the height of the current slide', 'wbls-outliner'),
	                                'description' => __('Enable Adjust the height of the slideshow to the height of the current slide', 'wbls-outliner'),
	                                'default' => 0,
	                            ),
	                            'flexslider_direction_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable  Display the "Previous/Next" Buttons', 'wbls-outliner'),
	                                'description' => __('Enable  Display the "Previous/Next" Buttons', 'wbls-outliner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_control_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Display the slideshow pagination', 'wbls-outliner'),
	                                'description' => __('Enable Display the slideshow pagination', 'wbls-outliner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_keyboard_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Keyboard Navigation', 'wbls-outliner'),
	                                'description' => __('Enable keyboard navigation', 'wbls-outliner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_mousewheel_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Mouse Wheel Navigation', 'wbls-outliner'),
	                                'description' => __('Enable the mousewheel navigation', 'wbls-outliner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_pauseplay' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Pause / Play event', 'wbls-outliner'),
	                                'description' => __('Enable the "Pause/Play" event', 'wbls-outliner'),
	                                'default' => 0,
	                            ),
	                            'flexslider_randomize' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Random Slides', 'wbls-outliner'),
	                                'description' => __('Enable to Randomize the order of slides in slideshows', 'wbls-outliner'),
	                                'default' => 0,
	                            ),
	                            'flexslider_animation_loop' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Loop Slideshow animations', 'wbls-outliner'),
	                                'description' => __('Enable Loop the slideshow animations', 'wbls-outliner'),
	                                'default' => 0,
	                            ),
	                            'flexslider_pause_on_action' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Pause On Action while navigation', 'wbls-outliner'),
	                                'description' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation', 'wbls-outliner'),
	                                'default' => 1,
	                            ),
	                            'flexslider_pause_on_hover' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Pause On Action while hovering the slides', 'wbls-outliner'),
	                                'description' => __('Enable to Pause the slideshow autoplay when hovering over a slide', 'wbls-outliner'),
	                                'default' => 0,
	                            ),
	                            'flexslider_prev_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Previous" button', 'wbls-outliner'),
	                                'description' => __(' The text to display on the "Previous" button.', 'wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Prev'
	                            ),
	                            'flexslider_next_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Next" button', 'wbls-outliner'),
	                                'description' => __(' The text to display on the "Next" button.', 'wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Next'
	                            ),
	                            'flexslider_play_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Play" button', 'wbls-outliner'),
	                                'description' => __(' The text to display on the "Play" button.', 'wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Play'
	                            ),
	                            'flexslider_pause_text' => array(
	                                'type' => 'text',
	                                'label' => __('The text to display on the "Pause" button', 'wbls-outliner'),
	                                'description' => __(' The text to display on the "Pause" button.', 'wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Pause'
	                            ),

	                        ),
	                    ),
						'flex_carousel' => array(
	                        'title' => __('Flex Carousel Slider', 'wbls-outliner'),
	                        'description' => __('Flex Carousel Settings','wbls-outliner'),
	                        'fields' => array(
	                            'carousel_animation_loop' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Loop through carousel items?', 'wbls-outliner'),
	                                'default' => 0,
	                            ),
	                            'carousel_item_width' => array(
	                                'type' => 'text',
	                                'label' => __('Carousel item width', 'wbls-outliner'),
	                                'default' => 230,
	                                'sanitize_callback' => 'absint'
	                            ),
	                            'carousel_item_margin' => array(
	                                'type' => 'text',
	                                'label' => __('Carousel item margin', 'wbls-outliner'),
	                                'default' => 5,
	                                'sanitize_callback' => 'absint'
	                            ),
	                            'carousel_pagination' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Carousel Pagination', 'wbls-outliner'),
	                                'default' => 1,

	                            ),
	                        ),
                		),
						'light_box' => array(    
	                        'title' => __('Light Box', 'wbls-outliner'),
	                        'description' => __('Light Box Settings ','wbls-outliner'),
	                        'fields' => array(
	                            'lightbox_theme' => array(
	                                'type' => 'select',
	                                'label' => __('Lightbox Theme', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                                'choices' => array(
	                                    '1' => __('pp_default', 'wbls-outliner'),
	                                    '2' => __('light-rounded', 'wbls-outliner'),
	                                    '3' => __('dark-rounded', 'wbls-outliner'),
	                                    '4' => __('light-square', 'wbls-outliner'),
	                                    '5' => __('dark-square', 'wbls-outliner'),
	                                    '6' => __('facebook', 'wbls-outliner'),
	                                ),
	                                'default' => '1',
	                            ),
	                            'lightbox_animation_speed' => array(
	                                'type' => 'select',
	                                'label' => __('Animation Speed', 'wbls-outliner'),
	                                'description' => __('', 'wbls-outliner'),
	                                'choices' => array(
	                                    'fast' => __('Fast', 'wbls-outliner'),
	                                    'slow' => __('Slow', 'wbls-outliner'),
	                                    'normal' => __('Normal', 'wbls-outliner'),
	                                ),
	                                'default' => 'fast',
	                            ),
	                            'lightbox_slideshow' => array( 
	                                'type' => 'range',
	                                'label' => __('Autoplay Gallery Speed', 'wbls-outliner'),
	                                'description' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)', 'wbls-outliner'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 10,
	                                ),
	                                'default' => 50,
	                            ),
	                            'lightbox_autoplay_slideshow' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Autoplay Gallery', 'wbls-outliner'),
	                                'description' => __('Check to autoplay the lightbox gallery', 'wbls-outliner'),
	                                'default' => 0,
	                            ),
	                            'lightbox_opacity' => array(
	                                'type' => 'range',
	                                'label' => __('Select Background Opacity', 'wbls-outliner'),
	                                'description' => __('Enter 0.1 to 1.0', 'wbls-outliner'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 1,
	                                    'step' => 0.1
	                                ),
	                                'default' => 0.5
	                            ),
	                           /* 'lightbox_show_title' => array( 
	                                'type' => 'checkbox',
	                                'label' => __('Check to show  visibility of the title', 'wbls-outliner'),
	                                'description' => __('Select visibility of the title', 'wbls-outliner'),
	                                'default' => 1,
	                            ),*/
	                            'lightbox_overlay_gallery' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Show Gallery Thumbnails', 'wbls-outliner'),
	                                'description' => __('Check to show gallery thumbnails', 'wbls-outliner'),
	                                'default' => 1,
	                            ),
	                          /*  'lightbox_social_tools' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Show social sharing icons', 'wbls-outliner'),
	                                'description' => __('Check to show social sharing icons', 'wbls-outliner'),
	                                'default' => 1,
	                            ),*/

	                        ),
                		),
						'analytics_section' => array(
	                        'title' => __('Tracking Code', 'wbls-outliner'),
	                        'description' => __('Tracking Code','wbls-outliner'),
	                        'fields' => array(
		                        'analytics' => array(
	                                'type' => 'textarea',
	                                'label' => __('Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-outliner'),
	                                'description' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                            ),
	                            'analytics_place' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable to Load Tracking Code in Footer', 'wbls-outliner'),
	                                'description' => __('Check to load analytics in footer. Uncheck to load in header.', 'wbls-outliner'),
	                                'default' => 0,  
	                            ),                   
	                        ),
	                    ),
                       'custom_js_section' => array(
	                        'title' => __(' Custom Js', 'wbls-outliner'),
	                        'description' => __('Custom Js','wbls-outliner'),
	                        'fields' => array(
		                        'custom_js' => array(
	                                'type' => 'textarea',
	                                'label' => __('Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-outliner'),
	                                'description' => __('','wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_text_field',  
                            	),                   
	                        ),
	                    ),
	                    'custom_css_section' => array(
	                        'title' => __(' Custom CSS', 'wbls-outliner'),
	                        'description' => __('Custom CSS','wbls-outliner'),
	                        'fields' => array(
		                        'custom_css' => array(
	                                'type' => 'textarea',
	                                'label' => __('Custom CSS: Quickly add some CSS to your theme by adding it to this block.', 'wbls-outliner'),
	                                'description' => __('','wbls-outliner'),
	                                'sanitize_callback' => 'sanitize_text_field',
                                ),                   
	                        ),
	                    ),

					),
				),


    		); // pro theme option end //

			$options = array_merge($free_options, $pro_options);
			return $options;

		}
	}
}