<?php
$custom = '';	
	$sticky_header_position = get_theme_mod('sticky_header_position');
	if( $sticky_header_position == 'bottom') {
		$custom .= ".sticky-header .branding {  top: auto!important;
			bottom:0; }"."\n";	
		$custom .= ".sticky-header .branding .nav-menu .sub-menu {  top: auto;
			bottom:100%; }"."\n";	
	}

    $portfolio_filter = get_theme_mod('portfolio_filter',1);

	switch ($portfolio_filter) {
		case 2:
			$custom .= " #filters .filter-options li:first-child {
		       	display: none;
		    }"."\n";
			break;
		case 3:
			$custom .= " #filters .filter-options {
		       	display: none;
		    }"."\n";
			break;
	}
	 $page_title_bar_status = get_theme_mod('page_titlebar_text');
     if( $page_title_bar_status == 2 ) {
     	    $custom .= ".breadcrumb .breadcrumb-right {
       			display: none;
       		}"."\n";
          $custom .= ".breadcrumb.nav-bottom-slider-breadcrumb .breadcrumb-left {
            display: none;
          }"."\n";
          $custom .= ".breadcrumb.nav-bottom-slider-breadcrumb .breadcrumb-right {
            display: block; 
          }"."\n";
     }
     if( $page_title_bar_status == 2 && ! get_theme_mod('breadcrumb',true) ) {
          $custom .= ".nav-bottom-slider-breadcrumb {
            border-bottom: none;  
          }"."\n";
     }

      /* home sidebar */
     if( get_theme_mod('home_sidebar',false) ) {
         $custom .= ".home .site-content {
               padding-top:0;
          }"."\n";
     }

     /* customize flexcaption */
     if( get_theme_mod('enable_flex_caption_edit',false) ) {
         $custom .= ".flexslider .slides .flex-caption, .home .flexslider .slides .flex-caption {
               bottom: auto;
               padding-left: 30px;
               padding-top: 30px;
               padding: 30px;
          }"."\n";
          $custom .= ".flexslider .flex-caption h1, .flexslider .flex-caption h2, .flexslider .flex-caption h3, .flexslider .flex-caption h4, .flexslider .flex-caption h5, .flexslider .flex-caption h6, .flexslider .flex-caption p, .flexslider .flex-caption li {
               width: 100%;
          }"."\n";
     }
     
     /* content background color - overwrite */
     if(  get_theme_mod('enable_content_background_color') && empty( get_theme_mod('content_background_image') ) ) {
         $custom .= " .site-content {
               background-image: none;
          }"."\n";
     }

     /* general background color - overwrite */
     if(  get_theme_mod('enable_general_background_color') && empty( get_theme_mod('general_background_image') ) ) {
         $custom .= " body {
              background-image: none;
          }"."\n";
     }


	//Output all the styles
	wp_add_inline_style( $this->plugin_name, $custom );	  
