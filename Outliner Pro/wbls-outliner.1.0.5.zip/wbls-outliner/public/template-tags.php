<?php


add_image_size( 'wbls_outliner_recent_posts_img', 370, 300, true );
add_image_size( 'wbls_outliner_recent_posts_slider_img', 1125, 430, true );
add_image_size( 'wbls-outliner-small-featured-image-width', 450,350, true );
add_image_size( 'wbls-outliner-blog-large-width', 800,350, true );  
add_image_size( 'wbls-outliner_service-img', 100,100, true ); 

function wbls_outliner_widget_title($title) {
	if ( !($title == null) ){
		$title = '<span>' . $title . '</span>';
		return $title;
	}
}

add_filter('widget_title','wbls_outliner_widget_title');   

// portfolio paging nav //

	if ( ! function_exists( 'wbls_fw_paging_nav' ) ) :
		/**
		 * Display navigation to next/previous set of posts when applicable.
		 */
		function wbls_fw_paging_nav() {
			// Don't print empty markup if there's only one page.
			if ( $GLOBALS['wp_query']->max_num_pages < 2 ) {
				return;
			}
			?>
			<nav class="navigation paging-navigation clearfix" role="navigation">
				<h1 class="screen-reader-text"><?php _e( 'Posts navigation', 'wbls-outliner' ); ?></h1>
				<div class="nav-links">

					<?php if ( get_next_posts_link() ) : ?>
						<div class="nav-previous"><?php next_posts_link( __( '<span class="meta-nav"><span>&lsaquo;</span></span> Older posts', 'wbls-outliner' ) ); ?></div>
					<?php endif; ?>

					<?php if ( get_previous_posts_link() ) : ?>
						<div class="nav-next"><?php previous_posts_link( __( 'Newer posts <span class="meta-nav"><span>&rsaquo;</span></span>', 'wbls-outliner' ) ); ?></div>
					<?php endif; ?>

				</div><!-- .nav-links -->
			</nav><!-- .navigation -->
			<?php
		}
	endif;

	if ( ! function_exists( 'wbls_outliner_post_nav' ) ) :
/**
 * Display navigation to next/previous post when applicable.
 */
function wbls_outliner_post_nav() {
	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( get_post()->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous ) {
		return;
	}
	?>
	<nav class="navigation post-navigation clearfix" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Post navigation', 'wbls-outliner' ); ?></h1>
		<div class="nav-links">
			<?php
				previous_post_link( '<div class="nav-previous">%link</div>', _x( '<span class="meta-nav">&larr;</span>&nbsp;%title', 'Previous post link', 'wbls-outliner' ) );
				next_post_link(     '<div class="nav-next">%link</div>',     _x( '%title&nbsp;<span class="meta-nav">&rarr;</span>', 'Next post link',     'wbls-outliner' ) );
			?>
		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
endif;




	if( ! function_exists( 'wbls_fw_pagination' )) {
		/**
		 * Generates Pagination without WP-PageNavi Plugin
		 */

		function wbls_fw_pagination($before = '', $after = '') {
		global $wpdb, $wp_query;
		$request = $wp_query->request;
		$posts_per_page = intval(get_query_var('posts_per_page'));
		$paged = intval(get_query_var('paged'));
		$numposts = $wp_query->found_posts;
		$max_page = $wp_query->max_num_pages;
		if ( $numposts <= $posts_per_page ) { return; }
		if(empty($paged) || $paged == 0) {
			$paged = 1;
		}
		$pages_to_show = 7;
		$pages_to_show_minus_1 = $pages_to_show-1;
		$half_page_start = floor($pages_to_show_minus_1/2);
		$half_page_end = ceil($pages_to_show_minus_1/2);
		$start_page = $paged - $half_page_start;
		if($start_page <= 0) {
			$start_page = 1;
		}
		$end_page = $paged + $half_page_end;
		if(($end_page - $start_page) != $pages_to_show_minus_1) {
			$end_page = $start_page + $pages_to_show_minus_1;
		}
		if($end_page > $max_page) {
			$start_page = $max_page - $pages_to_show_minus_1;
			$end_page = $max_page;
		}
		if($start_page <= 0) {
			$start_page = 1;
		}
		echo $before.'<nav class="page-navigation"><ol class="webulous_page_navi pagination">'."";
		if ($start_page >= 2 && $pages_to_show < $max_page) {
			$first_page_text = __( "First", 'wbls-outliner' );
			echo '<li class="bpn-first-page-link rippler rippler-default"><a href="'.get_pagenum_link().'" title="'.$first_page_text.'">'.$first_page_text.'</a></li>';
		}
		echo '<li class="bpn-prev-link rippler rippler-default">';
		previous_posts_link('&nbsp;');
		echo '</li>';
		for($i = $start_page; $i  <= $end_page; $i++) {
			if($i == $paged) {
				echo '<li class="bpn-current">'.$i.'</li>';
			} else {
				echo '<li class="rippler rippler-default"><a href="'.get_pagenum_link($i).'">'.$i.'</a></li>';
			}
		}
		echo '<li class="bpn-next-link rippler rippler-default">';
		next_posts_link('&nbsp;');
		echo '</li>';
		if ($end_page < $max_page) {
			$last_page_text = __( "Last", 'wbls-outliner' );
			echo '<li class="bpn-last-page-link rippler rippler-default"><a href="'.get_pagenum_link($max_page).'" title="'.$last_page_text.'">'.$last_page_text.'</a></li>';
		}
		echo '</ol></nav>'.$after."";
	}
	} /* wbls_pagination */

	
//  Readmore button html wrapper //

function add_more_link_class_wrapper( $link, $text  ) {

	$html = '';

		$html .= '<p class="portfolio-readmore"><a class="more-link"' . $link . '</a></p>';

	return $html;
}


add_filter( 'the_content_more_link', 'add_more_link_class_wrapper', 10, 2 );
 

	// Related Posts Function (call using wbls_outliner_related_posts(); ) /NecessarY/ May be write a shortcode?
	function wbls_outliner_related_posts() {
		echo '<ul id="webulous-related-posts">';
		global $post;
		$tags = wp_get_post_tags($post->ID);
		$tag_arr = '';
		if($tags) {
			foreach($tags as $tag) { $tag_arr .= $tag->slug . ','; }
	        $args = array(
	        	'tag' => $tag_arr,
	        	'numberposts' => 5, /* you can change this to show more */
	        	'post__not_in' => array($post->ID)
	     	);
	        $related_posts = get_posts($args);
	        if($related_posts) {
	        	foreach ($related_posts as $post) : setup_postdata($post); ?>
		           	<li class="related_post">
		           		<a class="entry-unrelated" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('recent-work'); ?></a>
		           		<a class="entry-unrelated" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
		           	</li>
		        <?php endforeach; }
		    else {
	            echo '<li class="no_related_post">' . __( 'No Related Posts Yet!', 'wbls-outliner' ) . '</li>'; 
			 }
		}else{
			echo '<li class="no_related_post">' . __( 'No Related Posts Yet!', 'wbls-outliner' ) . '</li>';
		}
		wp_reset_query();
		
		echo '</ul>';
	}

	if ( ! function_exists( 'wbls_outliner_entry_footer' ) ) :
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function wbls_outliner_entry_footer() {   
	// Hide category and tag text for pages.
	if ( 'post' == get_post_type() ) {
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( __( ', ', 'wbls-outliner' ) );
		if ( $categories_list && outliner_categorized_blog() ) {
			printf( ' <span class="cat-links"><i class="fa fa-folder-open"></i>' . __( '%1$s ', 'wbls-outliner' ) . '</span>', $categories_list );
		}

		/* translators: used between list items, there is a space after the comma */
		$tags_list = get_the_tag_list( '', __( ', ', 'wbls-outliner' ) );
		if ( $tags_list ) {
			printf( '<span class="tags-links"><i class="fa fa-tags"></i> ' . __( '%1$s ', 'wbls-outliner' ) . '</span>', $tags_list );
		}
	}

	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		echo '<span class="comments-link">';
		comments_popup_link( __( '<i class="fa fa-comments"></i>Leave a comment', 'wbls-outliner' ), __( '<i class="fa fa-comments"></i> 1 Comment', 'wbls-outliner' ), __( '<i class="fa fa-comments"></i> % Comments', 'wbls-outliner' ) );
		echo '</span>';
	}
}
endif;

if ( ! function_exists( 'wbls_outliner_posted_on' ) ) :   
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function wbls_outliner_posted_on() {
	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';
	}

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

	$posted_on = sprintf(
		_x( '%s', 'post date', 'wbls-outliner' ),
		'<i class="fa fa-clock-o"></i> <span><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a></span>'
	);

	$byline = sprintf(
		_x( '%s', 'post author', 'wbls-outliner' ),
		'<i class="fa fa-user"></i> <span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	echo '<span class="posted-on">' . $posted_on . '</span><span class="byline"> ' . $byline . '</span>';
	edit_post_link( __( 'Edit', 'wbls-outliner' ), ' <span class="edit-link"><i class="fa fa-pencil"></i>', '</span>' );

}
endif;

/**
  * Generates Breadcrumb Navigation
  */
 
 if( ! function_exists( 'wbls_outliner_breadcrumbs' )) {
 
	function wbls_outliner_breadcrumbs() {
		/* === OPTIONS === */
		$text['home']     = __( '<i class="fa fa-home"></i>','wbls-outliner' ); // text for the 'Home' link
		$text['category'] = __( 'Archive by Category "%s"','wbls-outliner' ); // text for a category page
		$text['search']   = __( 'Search Results for "%s" Query','wbls-outliner' ); // text for a search results page
		$text['tag']      = __( 'Posts Tagged "%s"','wbls-outliner' ); // text for a tag page
		$text['author']   = __( 'Articles Posted by %s','wbls-outliner' ); // text for an author page
		$text['404']      = __( 'Error 404','wbls-outliner' ); // text for the 404 page

		$showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
		$showOnHome  = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show
		$breadcrumb_char = get_theme_mod( 'breadcrumb_char', '1' );
		if ( $breadcrumb_char ) {
		 switch ( $breadcrumb_char ) {
		 	case '2' :
		 		$delimiter = ' / ';
		 		break;
		 	case '3':
		 		$delimiter = ' > ';
		 		break;
		 	case '1':
		 	default:
		 		$delimiter = ' &raquo; ';
		 		break;
		 }
		}

		$before      = '<span class="current">'; // tag before the current crumb
		$after       = '</span>'; // tag after the current crumb
		/* === END OF OPTIONS === */

		global $post;
		$homeLink = home_url() . '/';
		$linkBefore = '<span typeof="v:Breadcrumb">';
		$linkAfter = '</span>';
		$linkAttr = ' rel="v:url" property="v:title"';
		$link = $linkBefore . '<a' . $linkAttr . ' href="%1$s">%2$s</a>' . $linkAfter;

		if (is_home() || is_front_page()) {

			if ($showOnHome == 1) echo '<div id="crumbs"><a href="' . $homeLink . '">' . $text['home'] . '</a></div>';

		} else {

			echo '<div id="crumbs" xmlns:v="http://rdf.data-vocabulary.org/#">' . sprintf($link, $homeLink, $text['home']) . $delimiter;

			if ( is_category() ) {
				$thisCat = get_category(get_query_var('cat'), false);
				if ($thisCat->parent != 0) {
					$cats = get_category_parents($thisCat->parent, TRUE, $delimiter);
					$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
					$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
					echo $cats;
				}
				echo $before . sprintf($text['category'], single_cat_title('', false)) . $after;

			} elseif ( is_search() ) {
				echo $before . sprintf($text['search'], get_search_query()) . $after;

			} elseif ( is_day() ) {
				echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;
				echo sprintf($link, get_month_link(get_the_time('Y'),get_the_time('m')), get_the_time('F')) . $delimiter;
				echo $before . get_the_time('d') . $after;

			} elseif ( is_month() ) {
				echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;
				echo $before . get_the_time('F') . $after;

			} elseif ( is_year() ) {
				echo $before . get_the_time('Y') . $after;

			} elseif ( is_single() && !is_attachment() ) {
				if ( get_post_type() != 'post' ) {
					$post_type = get_post_type_object(get_post_type());
					$slug = $post_type->rewrite;
					printf($link, $homeLink . '/' . $slug['slug'] . '/', $post_type->labels->singular_name);
					if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;
				} else {
					$cat = get_the_category(); $cat = $cat[0];
					$cats = get_category_parents($cat, TRUE, $delimiter);
					if ($showCurrent == 0) $cats = preg_replace("#^(.+)$delimiter$#", "$1", $cats);
					$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
					$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
					echo $cats;
					if ($showCurrent == 1) echo $before . get_the_title() . $after;
				}

			} elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
				$post_type = get_post_type_object(get_post_type());
				echo $before . $post_type->labels->singular_name . $after;

			} elseif ( is_attachment() ) {
				$parent = get_post($post->post_parent);
				$cat = get_the_category($parent->ID); $cat = $cat[0];
				$cats = get_category_parents($cat, TRUE, $delimiter);
				$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
				$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
				echo $cats;
				printf($link, get_permalink($parent), $parent->post_title);
				if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;

			} elseif ( is_page() && !$post->post_parent ) {
				if ($showCurrent == 1) echo $before . get_the_title() . $after;

			} elseif ( is_page() && $post->post_parent ) {
				$parent_id  = $post->post_parent;
				$breadcrumbs = array();
				while ($parent_id) {
					$page = get_page($parent_id);
					$breadcrumbs[] = sprintf($link, get_permalink($page->ID), get_the_title($page->ID));
					$parent_id  = $page->post_parent;
				}
				$breadcrumbs = array_reverse($breadcrumbs);
				for ($i = 0; $i < count($breadcrumbs); $i++) {
					echo $breadcrumbs[$i];
					if ($i != count($breadcrumbs)-1) echo $delimiter;
				}
				if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;

			} elseif ( is_tag() ) {
				echo $before . sprintf($text['tag'], single_tag_title('', false)) . $after;

			} elseif ( is_author() ) {
		 		global $author;
				$userdata = get_userdata($author);
				echo $before . sprintf($text['author'], $userdata->display_name) . $after;

			} elseif ( is_404() ) {
				echo $before . $text['404'] . $after;
			}

			if ( get_query_var('paged') ) {
				if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
				echo __('Page', 'wbls-outliner' ) . ' ' . get_query_var('paged');
				if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
			}

			echo '</div>';

		}
	} // end wbls_outliner_breadcrumbs()

}

/* Blog meta data options */

if ( ! function_exists( 'wbls_outliner_entry_top_meta' ) ) : 
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function wbls_outliner_entry_top_meta() {   
	// Post meta data 
	
	  $single_post_top_meta = get_theme_mod('single_post_top_meta', array(1,2,6) );

	if ( 'post' == get_post_type() ) {  
		foreach ($single_post_top_meta as $key => $value) {
		    if( $value == 1) { ?>
		  	    <span class="date-structure">				
					<span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-clock-o"></i><?php the_time('j M Y'); ?></a></span>	
				</span>
	<?php   }elseif( $value == 2) {
				printf(
					_x( '%s', 'post author', 'wbls-outliner' ),
					'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"><i class="fa fa-user"></i> ' . esc_html( get_the_author() ) . '</a></span>'
				);	
			}elseif( $value == 3)  {
				if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
					echo ' <span class="comments-link"><i class="fa fa-comments"></i>';
					comments_popup_link( __( 'Leave a comment', 'wbls-outliner' ), __( '1 Comment', 'wbls-outliner' ), __( '% Comments', 'wbls-outliner' ) );
					echo '</span>';
			    }
	        }elseif( $value == 4) {
				$categories_list = get_the_category_list( __( ', ', 'wbls-outliner' ) );
				if ( $categories_list ) {
					printf( '<span class="cat-links"><i class="fa fa-folder-open"></i> ' . __( '%1$s ', 'wbls-outliner' ) . '</span>', $categories_list );
				}	
		    }elseif( $value == 5)  {
	    		/* translators: used between list items, there is a space after the comma */
				$tags_list = get_the_tag_list( '', __( ', ', 'wbls-outliner' ) );
				if ( $tags_list ) {
					printf( '<span class="tags-links"><i class="fa fa-tags"></i> ' . __( '%1$s ', 'wbls-outliner' ) . '</span>', $tags_list );
				}			
		    }elseif( $value == 6) {
		        edit_post_link( __( 'Edit', 'wbls-outliner' ), '<span class="edit-link"><i class="fa fa-pencil"></i> ', '</span>' );
		    }
	    }
	}
}

endif;
if ( ! function_exists( 'wbls_outliner_entry_bottom_meta' ) ) : 
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function wbls_outliner_entry_bottom_meta() {   
	// Post meta data 
	
	$single_post_bottom_meta = get_theme_mod('single_post_bottom_meta', array(3,4,5) );

	if ( 'post' == get_post_type() ) {  
		foreach ($single_post_bottom_meta as $key => $value) {
		    if( $value == 1) { ?>
		  	    <span class="date-structure">				
					<span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-clock-o"></i><?php the_time('j M Y'); ?></a></span>	
				</span>
	<?php   }elseif( $value == 2) {
				printf(
					_x( '%s', 'post author', 'wbls-outliner' ),
					'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"><i class="fa fa-user"></i> ' . esc_html( get_the_author() ) . '</a></span>'
				);	
			}elseif( $value == 3)  {
				if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
					echo ' <span class="comments-link"><i class="fa fa-comments"></i>';
					comments_popup_link( __( 'Leave a comment', 'wbls-outliner' ), __( '1 Comment', 'wbls-outliner' ), __( '% Comments', 'wbls-outliner' ) );
					echo '</span>';
			    }
	        }elseif( $value == 4) {
				$categories_list = get_the_category_list( __( ', ', 'wbls-outliner' ) );
				if ( $categories_list ) {
					printf( '<span class="cat-links"><i class="fa fa-folder-open"></i> ' . __( '%1$s ', 'wbls-outliner' ) . '</span>', $categories_list );
				}	
		    }elseif( $value == 5)  {
	    		/* translators: used between list items, there is a space after the comma */
				$tags_list = get_the_tag_list( '', __( ', ', 'wbls-outliner' ) );
				if ( $tags_list ) {
					printf( '<span class="tags-links"><i class="fa fa-tags"></i> ' . __( '%1$s ', 'wbls-outliner' ) . '</span>', $tags_list );
				}			
		    }elseif( $value == 6) {
		        edit_post_link( __( 'Edit', 'wbls-outliner' ), '<span class="edit-link"><i class="fa fa-pencil"></i> ', '</span>' );
		    }
	    }
	}
}

endif;

/*  Site Layout Option  */
if ( ! function_exists( 'wbls_outliner_layout_class' ) ) {
	function wbls_outliner_layout_class() {
	     $sidebar_position = get_theme_mod( 'sidebar_position', 'right' ); 
		     if( 'fullwidth' == $sidebar_position ) {
		     	echo 'sixteen';
		     }elseif('two-sidebar' == $sidebar_position || 'two-sidebar-left' == $sidebar_position || 'two-sidebar-right' == $sidebar_position ) {
		     	echo 'eight';
		     }
		     else{
		     	echo 'eleven';
		     }
		     if ( 'no-sidebar' == $sidebar_position ) {
		     	echo ' no-sidebar';
		     }
	}
}

/* Two Sidebar Left action */

add_action('wbls_outliner_two_sidebar_left','wbls_outliner_double_sidebar_left'); 

    if ( ! function_exists( 'wbls_outliner_double_sidebar_left' ) ) {
		 function wbls_outliner_double_sidebar_left() {
		    $sidebar_position = get_theme_mod( 'sidebar_position', 'right' ); 
				if( 'two-sidebar' == $sidebar_position || 'two-sidebar-left' == $sidebar_position ) :
					 get_sidebar('left'); 
				endif; 
				if('two-sidebar-left' == $sidebar_position || 'left' == $sidebar_position ):
					get_sidebar(); 
				endif;
		 }
	}	    

/* Two Sidebar Right action */

 add_action('wbls_outliner_two_sidebar_right','wbls_outliner_double_sidebar_right'); 	

 if ( ! function_exists( 'wbls_outliner_double_sidebar_right' ) ) {
    function wbls_outliner_double_sidebar_right() {
  	    $sidebar_position = get_theme_mod( 'sidebar_position', 'right' ); 
		 if( 'two-sidebar' == $sidebar_position || 'two-sidebar-right' == $sidebar_position || 'right' == $sidebar_position) :
			 get_sidebar(); 
		endif; 	
		if('two-sidebar-right' == $sidebar_position ):
			get_sidebar('left'); 
		endif;   	
    }
}


/* dynamic sidebar for pro */

add_action('init','wbls_outliner_dynamic_sidebar');
if( !function_exists('wbls_outliner_dynamic_sidebar') ) { 
	function wbls_outliner_dynamic_sidebar() {
		remove_action('outliner_sidebar_right_widget','outliner_sidebar_right_widget');
		add_action('outliner_sidebar_right_widget','wbls_outliner_dynamic_sidebar_right_widget');

		if( !function_exists('wbls_outliner_dynamic_sidebar_right_widget') ) { 
			function wbls_outliner_dynamic_sidebar_right_widget() {

				if( function_exists('generated_dynamic_sidebar') ) {
				    generated_dynamic_sidebar();
			    }elseif ( is_active_sidebar( 'sidebar-1' ) ) {
					 dynamic_sidebar('sidebar-1');
				}else { ?>
					<aside id="meta" class="widget">
						<h4 class="widget-title"><?php _e( 'Meta', 'outliner' ); ?></h4>
						<ul>
							<?php wp_register(); ?>
							<li><?php wp_loginout(); ?></li>
							<?php wp_meta(); ?>
						</ul>
			        </aside><?php 
			    }  
			}
		}
    }
}


if( ! function_exists( 'outliner_featured_image' ) ) {
	function outliner_featured_image() {
		$featured_image_size = get_theme_mod ('featured_image_size', 1);
		if ( has_post_thumbnail() && ! post_password_required() ) :
			if( $featured_image_size == 1 ) :
				the_post_thumbnail('outliner-blog-full-width');
			elseif( $featured_image_size == 2 ) :
				the_post_thumbnail('outliner-small-featured-image-width');
			elseif( $featured_image_size == 3 ) :
				the_post_thumbnail('full');
			elseif( $featured_image_size == 4 ) :
				the_post_thumbnail('medium');
			elseif( $featured_image_size == 5 ) :
				the_post_thumbnail('large');
			endif;
		endif;
	}
}

/* recent work widgets add options */

function wbls_outliner_recent_work_widgets_add_option( $widget, $return, $instance ) {
  
    // widget id 
    if ( 'recent-work-widget' == $widget->id_base ) { 

        // Display the description option.    
		$portfolio_cat = isset( $instance['portfolio_cat'] ) ? $instance['portfolio_cat'] : '';
		$portfolio_column = isset( $instance['portfolio_column'] ) ? $instance['portfolio_column'] : 4 ;

		?>      <p>   
				    <label for="<?php echo $widget->get_field_id('portfolio_cat') ?>"><?php _e(' Select Category ', 'wbls-outliner') ?></label>
					<?php wp_dropdown_categories( array( 'name' => $widget->get_field_name( 'portfolio_cat' ), 'show_option_all' => 'All Category', 'selected' => $portfolio_cat ) ); ?>
				</p>   
	            <p>
					<label for="<?php echo $widget->get_field_id('portfolio_column') ?>"><?php _e('Select Portfolio Column ', 'wbls-outliner') ?></label>
					<select id="<?php echo $widget->get_field_id('portfolio_column') ?>" name="<?php echo $widget->get_field_name('portfolio_column') ?>">
						<option value="4" <?php selected($portfolio_column, "4") ?>>Four Column</option>
						<option value="3" <?php selected($portfolio_column, "3") ?>>Three Column</option>
						<option value="2" <?php selected($portfolio_column, "2") ?>>Two Column</option>
					</select>  
				</p>    
        <?php
    } 
}             
//add_filter('in_widget_form', 'wbls_outliner_recent_work_widgets_add_option', 10, 3 );   

function wbls_outliner_recent_work_widgets_save_option( $instance, $new_instance ) {
    $instance['portfolio_cat'] = ( ! empty( $new_instance['portfolio_cat'] ) ) ? strip_tags( $new_instance['portfolio_cat'] ) : '';
    $instance['portfolio_column'] = ( ! empty( $new_instance['portfolio_column'] ) ) ? strip_tags( $new_instance['portfolio_column'] ) : '';
 	
    return $instance;         
}  

//add_filter( 'widget_update_callback', 'wbls_outliner_recent_work_widgets_save_option', 10, 3 );

/* Custom CSS Filed merge with the wp additional css
*  Remove get_theme_mod('custom_css')
*  add those css to wp css itself
*  Version4.7
*/
if( !function_exists('wbls_outliner_custom_css_migrate') ) {
    function wbls_outliner_custom_css_migrate(){
		if ( version_compare( $GLOBALS['wp_version'], '4.7', '>=' ) ) {

			if ( function_exists( 'wp_update_custom_css_post' ) ) {
			    // Migrate any existing theme CSS to the core option added in WordPress 4.7.
			    $css = get_theme_mod( 'custom_css' ); 
			    if ( $css ) {
			        $core_css = wp_get_custom_css(); // Preserve any CSS already added to the core option.
			        $return = wp_update_custom_css_post( $core_css . $css );     
			         //echo '<pre>',print_r($return),'</pre>';
			        if ( ! is_wp_error( $return ) ) {
			            // Remove the old theme_mod, so that the CSS is stored in only one place moving forward.
			            remove_theme_mod( 'custom_css' );
			        }
			    }
			}
		}
    }
}
add_action( 'after_setup_theme', 'wbls_outliner_custom_css_migrate' );
