<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts
 *
 * @param $layouts
 */
if (!function_exists('wbls_greenr_prebuilt_page_layouts') ) {   
function wbls_greenr_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-greenr'),
    'description' => __('Pre Built Layout for  home page', 'wbls-greenr'),
    'widgets' =>  array(
       0 => 
    array (
      'type' => 'circle',
      'title' => 'Responsive Layout ',
      'text' => 'Integer tincidunt leo sit amet nunc facilisis, vitae tristique tellus dictum. Morbi facilisis eros justo, ut semper urna faucibus at.',
      'icon' => 'fa-plane',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '2c4869fb-0a19-41e6-9aa7-8d109594da49',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'type' => 'circle',
      'title' => 'Awesome Slider',
      'text' => 'Integer tincidunt leo sit amet nunc facilisis, vitae tristique tellus dictum. Morbi facilisis eros justo, ut semper urna faucibus at.',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => '5759fa0e-20b6-48b5-8bb5-9e6b56a65f07',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Retina Ready',
      'text' => 'Integer tincidunt leo sit amet nunc facilisis, vitae tristique tellus dictum. Morbi facilisis eros justo, ut semper urna faucibus at.',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 2,
        'widget_id' => '9556b812-3577-42ad-9786-07f716d1a78c',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Page Builder',
      'text' => 'Integer tincidunt leo sit amet nunc facilisis, vitae tristique tellus dictum. Morbi facilisis eros justo, ut semper urna faucibus at.',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 3,
        'id' => 3,
        'widget_id' => 'e9aef188-f63d-4f0b-b07e-3d304450fc8d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'image_url' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/ourteam-one.png',
      'title' => 'Harvey Dent',
      'designation' => 'CEO',
      'linkedin' => 'http://linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'http://twitter.com/',
      'facebook' => 'http://www.facebook.com/',
      'panels_info' => 
      array (
        'class' => 'Wbls_Ourteam_Widget',
        'grid' => 1,
        'cell' => 0,
        'id' => 4,
        'widget_id' => 'd7550646-8348-41bd-bfaf-dd4822b18fed',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'image_url' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/ourteam-four.png',
      'title' => 'Emma Watson',
      'designation' => 'Designer',
      'linkedin' => 'http://linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'http://twitter.com/',
      'facebook' => 'http://www.facebook.com/',
      'panels_info' => 
      array (
        'class' => 'Wbls_Ourteam_Widget',
        'grid' => 1,
        'cell' => 1,
        'id' => 5,
        'widget_id' => '8af2274d-9a97-4501-995f-d293b7bb0aca',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'image_url' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/ourteam-three1.png',
      'title' => 'Bill Cerag',
      'designation' => 'Developer',
      'linkedin' => 'http://linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'http://twitter.com/',
      'facebook' => 'http://www.facebook.com/',
      'panels_info' => 
      array (
        'class' => 'Wbls_Ourteam_Widget',
        'grid' => 1,
        'cell' => 2,
        'id' => 6,
        'widget_id' => 'df88e3bd-ddd2-4ba1-bb19-187a4ed73f32',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'image_url' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/ourteam-two.png',
      'title' => 'John Doe',
      'designation' => 'Programmer',
      'linkedin' => 'http://linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'http://twitter.com/',
      'facebook' => 'http://www.facebook.com/',
      'panels_info' => 
      array (
        'class' => 'Wbls_Ourteam_Widget',
        'grid' => 1,
        'cell' => 3,
        'id' => 7,
        'widget_id' => '89e73b4b-c6d8-4dd2-ba4e-c0fa48cdb8e7',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Our Mission',
      'text' => '[accordion_group][accordion title="2011"]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem.[/accordion][accordion title="2012"] Sed nec massa lorem. Phasellus ut tincidunt velit, id scelerisque lorem. Nullam nisl tortor, mollis ut massa in, dapibus tincidunt libero. Pellentesque pretium posuere turpis eget dignissim. Curabitur sapien lorem, feugiat et velit et, vehicula aliquet urna. Vivamus pellentesque lorem at urna suscipit, at vulputate est ultricies. Aliquam ultrices nec massa sed adipiscing. Pellentesque feugiat sodales tellus. Ut tempus aliquam felis, quis consequat nunc hendrerit eget. Praesent sollicitudin nunc eu sollicitudin placerat. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="2013"]Aliquam non lacus in lacus aliquet blandit. Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. Sed ut augue vitae augue vestibulum pulvinar. Fusce commodo ultricies volutpat. Vivamus quis nulla porta, faucibus metus eu, tempus dolor. Ut sed faucibus mi, ac volutpat lectus. Morbi a rhoncus erat. Mauris et metus posuere, imperdiet urna at, congue risus. Nunc at ante sed ipsum porttitor scelerisque semper non libero. Vivamus feugiat nisl sit amet mi tristique dictum. Donec id magna facilisis, euismod sem bibendum, interdum lorem. [/accordion][/accordion_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'd968e5fc-c4b0-4bb2-a961-e6a36728e8af',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Skills',
      'panels_info' => 
      array (
        'class' => 'Wbls_Skill_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 9,
        'widget_id' => 'ae4f4426-f486-4831-b7ac-2f17bc2b0612',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'src' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/About-Us.png',
      'href' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/About-Us.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'grid' => 3,
        'cell' => 0,
        'id' => 10,
        'widget_id' => '4739972b-1ed2-4a4c-a9a5-207597a3bbb7',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => '',
      'text' => '<h2>WordPress & Marketing</h2>
<h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h4>
<p>In ut dui sed tortor commodo consequat. Aenean sed est ultricies, interdum urna ut, sollicitudin ipsum. Mauris ut turpis tincidunt, hendrerit nibh vel, consequat sapien. Praesent quis lorem non risus fringilla pellentesque. Praesent pulvinar magna est, at fermentum nibh gravida sit amet.</p>
[button link="http://webulous.in/" target="_self" color="btn-success" size="btn-large"]Download[/button]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 11,
        'widget_id' => 'ff7e246a-814b-4dc8-a13d-c0ea79434eea',
        'style' => 
        array (
          'class' => 'services-2',
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => '',
      'text' => '<h2>Our Latest Projects</h2>
Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 12,
        'widget_id' => '768e37ff-0145-4824-a18f-f09e1dfe20a3',
        'style' => 
        array (
          'class' => 'content-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => '',
      'count' => '12',
      'type' => 'isotope',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Work_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 13,
        'widget_id' => 'f0fd7c1c-62ae-420d-b7a2-33fcc9719cc8',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'title' => 'Testimonials',
      'count' => '5',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 14,
        'widget_id' => 'd8589bf2-3484-4363-a3f7-b60d5696ca84',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'Webulous Themes',
      'url' => 'http://webulousthemes.com/',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 15,
        'widget_id' => '20c306cb-5538-4a83-b031-293d9841d3a8',
        'style' => 
        array (
          'class' => 'section-pattern',
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => 'Recent Work',
      'count' => '12',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Work_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 16,
        'widget_id' => '34a6a88c-8ce0-46de-a5a6-cf78a4dd8365',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'height' => '30',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 17,
        'widget_id' => 'a2a69fa5-9236-4e64-9821-3754a2022ee2',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'class' => 'section-pattern',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'section-pattern',
        'background' => '#020202',
        'background_display' => 'tile',
        'border_color' => '#020202',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-bg',
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-pattern',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.25,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.25,
    ),
    2 => 
    array (
      'grid' => 0,
      'weight' => 0.25,
    ),
    3 => 
    array (
      'grid' => 0,
      'weight' => 0.25,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    5 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    6 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    7 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    8 => 
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
    9 => 
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
    10 => 
    array (
      'grid' => 3,
      'weight' => 0.5,
    ),
    11 => 
    array (
      'grid' => 3,
      'weight' => 0.5,
    ),
    12 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    13 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    14 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    15 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    16 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    ),

  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-greenr'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-greenr'),
    'widgets' => array(
        0 => 
    array (
      'title' => '',
      'text' => '<h2>Welcome</h2>
<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'd00cb988-096e-4d04-b3aa-092b9debefd3',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'src' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/aboutus.jpg',
      'href' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/aboutus.jpg',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => 'f47d81e8-e17f-4155-87ca-d66381252322',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'image_url' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/ourteam-one.png',
      'title' => 'Harvey Dent',
      'designation' => 'CEO',
      'linkedin' => 'http://linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'http://twitter.com/',
      'facebook' => 'http://www.facebook.com/',
      'panels_info' => 
      array (
        'class' => 'Wbls_Ourteam_Widget',
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'f58702ff-6fdf-4efc-9029-372002e39fde',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'image_url' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/ourteam-four.png',
      'title' => 'Emma Watson',
      'designation' => 'Designer',
      'linkedin' => 'http://linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'http://twitter.com/',
      'facebook' => 'http://www.facebook.com/',
      'panels_info' => 
      array (
        'class' => 'Wbls_Ourteam_Widget',
        'grid' => 1,
        'cell' => 1,
        'id' => 3,
        'widget_id' => '21d80e62-9515-40e3-b59a-943170c659b1',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'image_url' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/ourteam-three1.png',
      'title' => 'Bill Cerag',
      'designation' => 'Developer',
      'linkedin' => 'http://linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'http://twitter.com/',
      'facebook' => 'http://www.facebook.com/',
      'panels_info' => 
      array (
        'class' => 'Wbls_Ourteam_Widget',
        'grid' => 1,
        'cell' => 2,
        'id' => 4,
        'widget_id' => 'ef4bb9c5-b2b3-45aa-b1b4-c50289447a98',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'image_url' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/ourteam-two.png',
      'title' => 'John Doe',
      'designation' => 'Programmer',
      'linkedin' => 'http://linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'http://twitter.com/',
      'facebook' => 'http://www.facebook.com/',
      'panels_info' => 
      array (
        'class' => 'Wbls_Ourteam_Widget',
        'grid' => 1,
        'cell' => 3,
        'id' => 5,
        'widget_id' => '6ba67372-64c8-4cc0-a59f-621511f5d8d7',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Testimonials',
      'count' => '5',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '31b6c36f-ab68-4e80-a363-b8c5250dcfe3',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout',
      'title' => 'Webulous Themes',
      'url' => 'http://webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '08d30c8c-d1ea-4775-a9ba-5fff08f7a815',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'slider' => '38',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'ca0e6942-1c8d-42cd-8a4f-486fcae3cdba',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'class' => 'section-pattern',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-bg',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-pattern',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.5,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.5,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    5 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
        ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'wbls-greenr'),
      'description' => __( 'Pre Built layout for features page', 'wbls-greenr'),
      'widgets' => array(
               0 => 
    array (
      'title' => '',
      'text' => '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin interdum ipsum nisl, id vulputate erat euismod nec. Integer tincidunt leo sit amet nunc facilisis, vitae tristique tellus dictum.</p>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Responsive Layout',
      'text' => 'Greenr is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
      'icon' => 'fa-desktop',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Awesome Slider',
      'text' => 'Greenr includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
      'icon' => 'fa-tablet',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Font Awesome',
      'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Typography ',
      'text' => 'Greenr loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
      'icon' => 'fa-font',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Retina Ready',
      'text' => 'Greenr is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 5,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Excellent Support',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
      'icon' => 'fa-thumb-tack',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 6,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Advanced Admin',
      'text' => 'Greenr uses advanced Redux Framework for theme options panel, you can customize any part of your site quickly and easily!',
      'icon' => 'fa-cog',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Page Builder',
      'text' => 'Greenr is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 8,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Page Layout',
      'text' => 'Greenr offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy (alias)',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 9,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Custom Widget',
      'text' => 'Greenr We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate! ',
      'icon' => 'fa-beer',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 10,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Shortcode Builder',
      'text' => 'Greenr inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!.',
      'icon' => 'fa-check',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 11,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Demo Content',
      'text' => 'Greenr includes demo content files. You can quickly setup the site like our demo and get started easily!.',
      'icon' => 'fa-check',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 12,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => 'Woo Commerce',
      'text' => 'Greenr has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!.',
      'icon' => 'fa-shopping-cart',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 13,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'title' => 'Testimonials',
      'text' => 'With our testimonial post type, shortcode and widget, Displaying testimonials is a breeze..',
      'icon' => 'fa-rocket',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 14,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'title' => 'Social Media',
      'text' => 'Want your users to stay in touch? No problem, Greenr has Social Media icons all throughout the theme!',
      'icon' => 'fa-skype',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 2,
        'id' => 15,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => 'Google Map',
      'text' => 'Greenr includes Goole Map as shortcode and widget. So, you can use it anywhere in your site!.',
      'icon' => 'fa-map-marker',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 16,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'title' => 'Multiple Portfolio',
      'text' => '7 portfolio layouts, 3 blog layouts and multiple other alternate layouts for interior pages!.',
      'icon' => 'fa-list',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 1,
        'id' => 17,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'title' => 'Multiple Sidebar ',
      'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!.',
      'icon' => 'fa-columns',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 2,
        'id' => 18,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'title' => 'Customization',
      'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
      'icon' => 'fa-edit (alias)',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 19,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    20 => 
    array (
      'title' => 'Improvements',
      'text' => 'We love our theme and customers. We are committed to improve and add new features to Greenr!.',
      'icon' => 'fa-signal',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 20,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    21 => 
    array (
      'title' => 'Uniq Designs',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
      'icon' => 'fa-pencil',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 2,
        'id' => 21,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    22 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout',
      'title' => 'Webulous Themes',
      'url' => 'http://webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 22,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    23 => 
    array (
      'slider' => '38',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 23,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    4 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    6 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    7 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-pattern',
        'background_display' => 'tile',
      ),
    ),
    9 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    8 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    9 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    10 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    11 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    12 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    13 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    14 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    15 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    16 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    17 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    18 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    19 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    20 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    21 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    22 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    23 => 
    array (
      'grid' => 9,
      'weight' => 1,
    ),
    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-greenr'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-greenr'),
      'widgets' => array(
         0 => 
    array (
      'title' => '',
      'text' => '<h2>Greenr Offices</h2>
<p>11 Hamill Avenue San Degigo, CA 92191</p>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '<h2>Contact Info</h2>
<p>Phone: 0123456789<br/>
Email: venkat@codinggeek.com</p>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => '',
      'text' => '[contact-form-7 id="1326" title="Contact form 1"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => '',
      'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6927348.966198939!2d135.0016983!3d-32.028801!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6aa7589e5be8c7f3%3A0xdb7e79993dfad0d8!2sSouth+Australia%2C+Australia!5e0!3m2!1sen!2sin!4v1419078257280" width="1100" height="450" frameborder="0" style="border:0"></iframe>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-pattern',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.28343359515674998,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.71656640484324996,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-greenr'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-greenr'),
    'widgets' =>  array(
       0 => 
    array (
      'height' => '10',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '[accordion_group][accordion title="Nunc consequat dui ac feugiat molestie"] Nulla tempus interdumnare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut u nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, id congue dui risus faucibus nisl. Nulla tempus interdumnare placerat tellus ut accumsan. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, . Praesent nunc dui, egestas a leo quis, euismod dapibus massaAenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa.Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa. [/accordion][accordion title="Mauris sed nisl ac nisl scelerisque blandit."]  Praesent nunc dui, egestas a leo quis, euismod dapibus massa. Fusce vitae velit est. In hac habitasse platea dictumstMaecenas posuere non nulla in dignissim. in faucibus. Vestibulum pharetra diam vel metus mattis, quis consequat quam pharetra. Curabitur sit amet ligula posuere, venenatis neque sed, feugiat nibh. Duis consectetur ipsum ac imperdiet tincidunt. Duis aliquet at lacus feugiat volutpat. Donec dignissim odio in tellus porttitor congue. Aenean enim erat, elementum ac dolor at, convallis pharetra mi. Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa. [/accordion][accordion title="Vivamus ut felis eget elit tincidunt"]Nulla tempus interdum nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa.Vivamus suscipit quis massa nec bibendum. Fusce lacinia et lectus et facilisis. posuere augue. Fusce vitae ipsum facilisis, tincidunt mi et, condimentum libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed bibendum sed lorem ut aliquet. Quisque nisi ipsum, lobortis nec imperdiet eu, convallis sed purus. Morbi mollis pharetra lobortis.Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa.[/accordion][accordion title="Aliquam vitae arcu in felis porttitor "]In rutrum faucibus varius. . Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl  Praesent luctus tellus sit amet mauris varius efficitur. Sed blandit tellus a justo ullamcorper, eget ornare orci aliquet. Aliquam erat volutpat. Integer ultricies accumsan nisi, vel elementum dolor pellentesque sed. Aliquam efficitur nisl ante, nec feugiat nisi interdum et. Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa. [/accordion][accordion title="Curabitur euismod nisl vel tortor dapibus,"]  Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut u nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, id congue dui risus faucibus nisl. Nulla tempus interdumnare placerat tellus ut accumsan. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. nibh, . Praesent nunc dui, egestas a leo quis, euismod dapibus massa.Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa. [/accordion][accordion title=" Pellentesque est erat, sodales eu varius  luctus."]  Pellentesque est erat, sodales eu varius vel, luctus Praesent nunc dui, egestas a leo quis, euismod dapibus massa. Fusce vitae velit est. In hac habitasse platea dictumstMaecenas posuere non nulla in dignissim. in faucibus. Vestibulum pharetra diam vel metus mattis, quis consequat quam pharetra. Curabitur sit amet ligula posuere, venenatis neque sed, feugiat nibh. Duis consectetur ipsum ac imperdiet tincidunt. Duis aliquet at lacus feugiat volutpat. Donec dignissim odio in tellus porttitor congue. Aenean enim erat, elementum ac dolor at, convallis pharetra mi.  Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa.[/accordion][accordion title="Quisque sodales liber luctus hendrerit."] Posuere augue. Fusce vitae ipsum facilisis,Nulla tempus interdum nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa.Vivamus suscipit quis massa nec bibendum. Fusce lacinia et lectus et facilisis. posuere augue. Fusce vitae ipsum facilisis, tincidunt mi et, condimentum libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed bibendum sed lorem ut aliquet. Quisque nisi ipsum, lobortis nec imperdiet eu, convallis sed purus. Morbi mollis pharetra lobortis .Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa.[/accordion][accordion title=" Fusce vulputate null at vehicula arcu blandit "] Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl  Praesent luctus tellus sit amet mauris varius efficitur. Sed blandit tellus a justo ullamcorper, eget ornare orci aliquet. Aliquam erat volutpat. Integer ultricies accumsan nisi, vel elementum dolor pellentesque sed. Aliquam efficitur nisl ante, nec feugiat nisi interdum et.Aenean rutrum rutrum ipsum at sagittis. Nulla et nibh libero. Cras sit amet elementum tellus, nec vestibulum quam. Quisque pharetra facilisis turpis, eget rhoncus lorem suscipit vitae. Aenean non fringilla leo. Maecenas vitae purus sit amet diam gravida commodo nec in tortor. Donec dapibus et ipsum non luctus. Mauris sit amet condimentum metus. Nunc et justo at sapien vehicula ullamcorper. Mauris eget ante eleifend, consequat est vel, congue massa.  Fusce vulputate nulla diam, at vehicula arcu blandit [/accordion][/accordion_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout',
      'title' => 'Webulous Themes',
      'url' => 'http://webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'padding' => '20px',
        'background_display' => 'cover',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-pattern',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-greenr'),
    'description' => __('Pre Built Layout for services page', 'wbls-greenr'),
    'widgets' =>  array(
         0 => 
    array (
      'height' => '14',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '43409c82-a32b-494a-8c91-b7502622d299',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Multi-Purpose',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque ultrices, justo at fringilla iaculis, nibh quam porttitor tortor, sed blandit arcu lacus in odio. Duis in sapien ornare, lacinia orci non, tincidunt ante. Praesent vehicula enim lorem, ut facilisis turpis euismod ut. Suspendisse potenti. Morbi ac efficitur nibh. ',
      'icon' => 'fa-plane',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '6e03de41-168f-4f66-a116-ffad92495e18',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Web Development',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque ultrices, justo at fringilla iaculis, nibh quam porttitor tortor, sed blandit arcu lacus in odio. Duis in sapien ornare, lacinia orci non, tincidunt ante. Praesent vehicula enim lorem, ut facilisis turpis euismod ut. Suspendisse potenti. Morbi ac efficitur nibh. ',
      'icon' => 'fa-leaf',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'widget_id' => '6b99f735-370b-430d-8c83-73d14e023e48',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Marketing',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque ultrices, justo at fringilla iaculis, nibh quam porttitor tortor, sed blandit arcu lacus in odio. Duis in sapien ornare, lacinia orci non, tincidunt ante. Praesent vehicula enim lorem, ut facilisis turpis euismod ut. Suspendisse potenti. Morbi ac efficitur nibh. ',
      'icon' => 'fa-cog',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 3,
        'widget_id' => 'f4838fa2-8383-4630-847f-8aae7e7e17fd',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'HTML & CSS',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque ultrices, justo at fringilla iaculis, nibh quam porttitor tortor, sed blandit arcu lacus in odio. Duis in sapien ornare, lacinia orci non, tincidunt ante. Praesent vehicula enim lorem, ut facilisis turpis euismod ut. Suspendisse potenti. Morbi ac efficitur nibh. ',
      'icon' => 'fa-html5',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 4,
        'widget_id' => '3e31940c-9ee1-4d42-a327-db39589c2032',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => '',
      'text' => '[headline level="1" type="normal" align="tcenter"]Our Process[/headline]
<p>Duis congue arcu ut nisl euismod gravida. Sed iaculis diam sit amet odio tincidunt, et lacinia eros elementum. Vestibulum vulputate tortor id odio luctus, quis porta est ultrices. Vivamus et rhoncus sem. Quisque tincidunt, purus sed eleifend lacinia, eros lorem ultrices tortor, at euismod lacus nunc id leo. Maecenas at ligula eget ex ultricies malesuada. Sed interdum, quam eget sagittis molestie, felis dui convallis lacus, vel semper mauris metus in libero.</p>',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '443e2acb-3eda-482b-8750-a856f5425dfc',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    6 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'src' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/Two3.png',
            'href' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/Two3.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '21e0671a-73f9-45ba-9a41-1a3bb0519b8c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/Three4.png',
            'href' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/Three4.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'c26ab3db-1a5e-4733-a291-d11a712ba462',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'src' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/Three3.png',
            'href' => 'http://greenr.webulous.in/wp-content/uploads/2016/08/Three3.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => 'c20f1b63-c627-4164-9c7a-46ead765b2c2',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '',
            'text' => '[headline level="2" type="normal" align="tcenter"]Design[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 3,
              'widget_id' => 'df491811-b45b-47c4-94c9-21a81e5217d6',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '',
            'text' => '[headline level="2" type="normal" align="tcenter"]Plan[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 4,
              'widget_id' => 'befa5f81-fb08-4853-88d9-749214a588ad',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => '',
            'text' => '[headline level="2" type="normal" align="tcenter"]Deliver[/headline]
',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 5,
              'widget_id' => '1ccd29c1-0960-43ac-8bc7-4fe84c3be2f3',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'no_margin' => 'on',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          5 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
        ),
      ),
      'builder_id' => '57c6a7ff41531',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 3,
        'cell' => 0,
        'id' => 6,
        'widget_id' => 'cc706c7e-98ca-4d16-8fcb-db1067769a3e',
        'style' => 
        array (
          'class' => 'section-pattern',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'slider' => 'carousel',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '73714ebe-1d1e-44f8-9552-96a1ccb46359',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-pattern',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.5,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.5,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'wbls_greenr_prebuilt_page_layouts');

function wbls_greenr_panels_row_style_fields($fields) {  

    $greenr_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-greenr'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-greenr' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-greenr' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-greenr' ),
        'bounce-animation' => __('bounce-animation','wbls-greenr' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-greenr' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-greenr' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-greenr' ),
        'expandUp-animation' => __('expandUp-animation','wbls-greenr' ),
        'fade-animation' => __('fade-animation','wbls-greenr' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-greenr' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-greenr' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-greenr' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-greenr' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-greenr' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-greenr' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-greenr' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-greenr' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-greenr' ),
        'flip-animation' => __('flip-animation','wbls-greenr' ),
        'flipInX-animation' => __('flipInX-animation','wbls-greenr' ),
        'flipInY-animation' => __('flipInY-animation','wbls-greenr' ),
        'floating-animation' => __('floating-animation','wbls-greenr' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-greenr' ),
        'hatch-animation' => __('hatch-animation','wbls-greenr' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-greenr' ),
        'puffIn-animation' => __('puffIn-animation','wbls-greenr' ),
        'pullDown-animation' => __('pullDown-animation','wbls-greenr' ),
        'pullUp-animation' => __('pullUp-animation','wbls-greenr' ),
        'pulse-animation' => __('pulse-animation','wbls-greenr' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-greenr' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-greenr' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-greenr' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-greenr' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-greenr' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-greenr' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-greenr' ),
        'scale-down-animation' => __('scale-down-animation','wbls-greenr' ),
        'scale-up-animation' => __('scale-up-animation','wbls-greenr' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-greenr' ),
        'slide-left-animation' => __('slide-left-animation','wbls-greenr' ),
        'slide-right-animation' => __('slide-right-animation','wbls-greenr' ),
        'slide-top-animation' => __('slide-top-animation','wbls-greenr' ),
        'slideDown-animation' => __('slideDown-animation','wbls-greenr' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-greenr' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-greenr' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-greenr' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-greenr' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-greenr' ),
        'slideRight-animation' => __('slideRight-animation','wbls-greenr' ),
        'slideUp-animation' => __('slideUp-animation','wbls-greenr' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-greenr' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-greenr' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-greenr' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-greenr' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-greenr' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-greenr' ),
        'swap-animation'  => __('swap-animation','wbls-greenr' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-greenr' ),
        'swing-animation'  => __('swing-animation','wbls-greenr' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-greenr' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-greenr' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-greenr' ), 
        'tossing-animation'  => __('tossing-animation','wbls-greenr' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-greenr' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-greenr' ), 
        'wobble-animation' => __('wobble-animation','wbls-greenr' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-greenr' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'greenr'),
            'type' => 'select',
            'options' => $greenr_animation_name,
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_greenr_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_greenr_panels_row_style_fields');

function wbls_greenr_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_greenr_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_greenr_panels_panels_row_style_attributes', 10, 2);

function wbls_greenr_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Animation', 'wbls-greenr'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_greenr_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_greenr_row_style_groups' );



