<?php
/**
 * Pro customizer options     
 */

add_action('wbls-greenr_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() { 

// pro home page section 

		Greenr_Kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-greenr' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-greenr'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) );

		Greenr_Kirki::add_field( 'greenr', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-greenr' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch',
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
				'off' => esc_attr__( 'Disable', 'wbls-greenr' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-greenr'),
			'default'  => 'off',
		) );
		Greenr_Kirki::add_field( 'greenr', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-greenr' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-greenr'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-greenr'),
		) );

//  animation section 

Greenr_Kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-greenr' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-greenr'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-greenr' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Greenr_Kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-greenr' ),
	'description'    => __( 'Custom JS', 'wbls-greenr'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-greenr' ),
	'section'  => 'custom_js_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ),
) ); 

// Tracking section 

Greenr_Kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-greenr' ),
	'description'    => __( 'Tracking Code', 'wbls-greenr'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'analytics',
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-greenr' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ),
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-greenr' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'2' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-greenr'),
) );

// color scheme section 

Greenr_Kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-greenr' ),
	'description'    => __( 'Select your color scheme', 'wbls-greenr'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'color_scheme',
	'label'    => __( 'Select your color scheme', 'wbls-greenr' ),
	'section'  => 'multiple_color_section',
	'type'     => 'palette',
	'choices'     => array(
    '1' => array(
		'#56cc00',
	),
	'2' => array(
		'#4c89db',
	),
	'3' => array(
		'#ab4b00',
	),
	'4' => array(
		'#ec1d23',
	),
	'5' => array(
		'#cd0074',
	),
	'6' => array(
		'#f2bc04',
	),
	'7' => array(
		'#1f9e9c',
	),
	'8' => array(
		'#269926',
	),
	'9' => array(
		'#1ec185',
	),
	'10' => array(
		'#56cc00',
	),
	'11' => array(
		'#003366',
	),
),
'default' => '1',
//'default'  => 'on',
) );
//social network URL
Greenr_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-greenr' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-greenr'),
	'panel'			 => 'social_panel',
) );

Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-greenr' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-greenr'),
) );

// flexslider section //

Greenr_Kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-greenr' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-greenr'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-greenr' ),
		'2' => esc_attr__( 'Slide', 'wbls-greenr' )
	),
	'default'  => '2',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-greenr' ),
		'2' => esc_attr__( 'Vertical', 'wbls-greenr' )
	),
	'default'  => '1',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => 'on',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => 'on',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => 'on',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => 'on',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => 'off',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => 'off',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => 'off',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'off' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-greenr' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Greenr_Kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-greenr' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-greenr'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-greenr' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'2' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => '2',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-greenr' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-greenr' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-greenr' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'2' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => '2',
) );

//  portfolio settings //

Greenr_Kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-greenr' ),
) );

$post_per_page = get_option('posts_per_page');
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-greenr' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-greenr' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-greenr' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-greenr' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-greenr'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-greenr' ),
		2 => __( 'Show Without "All"', 'wbls-greenr' ),
		3 => __( 'Hide', 'wbls-greenr' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Greenr_Kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-greenr' ),
	'description'    => __( 'Light Box Settings', 'wbls-greenr'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-greenr' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-greenr' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-greenr' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-greenr' ),
		'4' => esc_attr__( 'light-square', 'wbls-greenr' ),
		'5' => esc_attr__( 'dark-square', 'wbls-greenr' ),
		'6' => esc_attr__( 'facebook', 'wbls-greenr' ),
	),
	'default'  => '1',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-greenr' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-greenr' ),
		'slow' => esc_attr__( 'Slow', 'wbls-greenr' ),
		'normal' => esc_attr__( 'Normal', 'wbls-greenr' ),
	),
	'default'  => 'fast',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-greenr' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-greenr' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'2' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => '2',
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-greenr' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-greenr'),
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-greenr' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-greenr' ),
		'2' => esc_attr__( 'Disable', 'wbls-greenr' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-greenr' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#56cc00',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'input[type="text"]:focus,.dropcap-book,.widget_image-box-widget .image-box img,.home .site-content .circle-icon-box:hover,
input[type="email"]:focus,.widget_social-networks-widget ul li a:hover,
.share-box ul li a:hover,ul.filter-options li a:hover,.circle-icon-box:hover p.fa-stack,
ul.filter-options li a.selected,.dropcap-circle,.pullleft,.home .site-content .circle-icon-box:hover p.fa-stack,
.pullright,.toggle .toggle-title .icn,.toggle .toggle-content,.flex-container .flex-direction-nav a:hover,
input[type="url"]:focus,.ei-slider-thumbs li.ei-slider-element,.circle-icon-box:hover,
input[type="password"]:focus,.post-navigation .nav-links a:hover,
input[type="search"]:focus,.widget.widget_ourteam-widget .team-social ul li a:hover,
textarea:focus,.site-content .wpcf7-form input[type="submit"],.services .four.columns:hover,.services .four.columns:hover .service-title p',
			'property' => 'border-color',
		),
		array(
			'element'  => '.pullleft,.withtip.left:after,.pullright',
			'property' => 'border-left-color',
		),
		array(
			'element'  => '.withtip.right:after',
			'property' => 'border-right-color',
		),
		array(
			'element'  => '.icon-horizontal .service,.tabs.normal ul li .tabulous_active, .tabs.normal ul li a:hover, .tabs ul li .tabulous_active, .tabs ul li a:hover,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a,.icon-horizontal .service,
.tabs-container ul.ui-tabs-nav li a:hover,.icon-horizontal .service,.withtip.top:after,.home .site-content .circle-icon-box:hover p.fa-stack',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '.main-navigation a:hover,.social li a:hover,.home .callout-widget .callout-btn a,.callout-widget .callout-btn a,.home .site-content .circle-icon-box:hover,
.circle-icon-box p.more-button a,.main-navigation .current_page_item > a,.sep,.withtip.bottom:after,
.main-navigation .current-menu-item > a,.portfolio-excerpt a.btn-readmore,
.main-navigation .current-menu-ancestor > a,.widget_recent-work-widget .flex-direction-nav a.flex-prev,
.widget_recent-work-widget .flex-direction-nav a.flex-next,.flex-container .flex-direction-nav a',
			'property' => 'border-bottom-color',
		),
		array(
			'element'  => 'a,.main-navigation a:hover::before,.widget_calendar td a,.site-content .widget.widget_ourteam-widget .team-content h4,	
.cart-subtotal .amount,.woocommerce #content table.cart a.remove,
.main-navigation a:hover,.ei-title h3,.site-footer .widget.widget_ourteam-widget .team-content li a:hover,.breadcrumb #breadcrumb a,.pullnone:before,
.tabs-container ul.ui-tabs-nav li.ui-tabs-active a,.widget_recent-work-widget .recent_work_overlay .fa:hover,.widget_recent-work-widget .work-title h4 a:hover,
.tabs-container ul.ui-tabs-nav li a:hover,.copy a:hover,.main-navigation a:hover:before,.main-navigation .current_page_item > a,.site-footer .widget_social-networks-widget ul li a:hover,
.main-navigation .current-menu-item > a,.ui-accordion .ui-accordion-header-active span.fa,.ui-accordion .ui-accordion .ui-accordion-header:hover,.entry-footer a:hover,.widget-area .widget_calendar caption,.main-navigation ul.menu.nav-menu > li.current-menu-ancestor > a,
.main-navigation .current-menu-ancestor > a,.circle-icon-box:hover p.fa-stack i,.footer-top .widget_calendar a:hover,h1.entry-title a:hover,
.widget-area .widget_calendar th,.toggle .toggle-title .icn,.main-navigation ul.menu.nav-menu > li.current-menu-ancestor
.current_page_item > a:before,.footer-top a:hover,.content-details h3 a:hover,.icon-vertical .fa-stack i,.services .four.columns:hover .service-title p i,.flex-container .flex-caption,.widget_testimonial-widget ul li p.client strong,.footer-widgets .widget_calendar caption',
			'property' => 'color',
		),
		array(
			'element'  => '#header-bottom .logo .site-title a',
			'property' => 'color',
			'suffix' => '!important',
		),
		array(
			'element'  => '.services .four.columns .service-title p,.site-content .widget.widget_ourteam-widget .team-social ul li a,table td#today,input[type="text"]:focus,.site-footer .footer-bottom ul.menu li a:hover,.site-footer .footer-bottom ul.menu li.current_page_item a,.widget_recent-work-widget .flex-direction-nav a.flex-prev,
.widget_recent-work-widget .flex-direction-nav a.flex-next,.widget_recent-posts-gallery-widget .recent-post,.widget_recent-posts-gallery-widget .recent-post:hover a img,
input[type="email"]:focus,.portfolio-excerpt a.btn-readmore,.page-navigation ol li.bpn-current,.page-navigation ol li.bpn-current:hover,
input[type="url"]:focus,.page-navigation ol li a:hover,.callout-widget .callout-btn a,.page-navigation ol li.bpn-current:hover,
input[type="password"]:focus,.comment-navigation .nav-next a:hover,.section-bg .flex-control-paging li a.flex-active,.flex-container .flex-direction-nav a ,.widget_recent-posts-gallery-widget .recent-post .post-title:before,.ui-accordion .ui-accordion-header-active,
.comment-navigation .nav-previous a:hover,.post-thumb .blog-thumb
.page-links a,.home .callout-widget .callout-btn a,.flex-control-paging li a.flex-active,.circle-icon-box .circle-icon-wrapper p.fa-stack,.icon-horizontal .icon-wrapper .fa-stack,
.flex-control-paging li a:hover,.dropcap-circle,.circle-icon-box p.more-button a,
.dropcap-box,.toggle .toggle-title:hover,.withtip:before,.widget_image-box-widget a.more-button,
.widget.widget_skill-widget .skill-content,.ui-accordion h3 span.fa,.widget_recent-work-widget .recent_work_overlay,
input[type="search"]:focus,.post-navigation .nav-links a:hover,.ui-accordion h3:hover,.widget_calendar td#today,
textarea:focus,.site-content .wpcf7-form input[type="submit"],.site-footer a.more-button',
			'property' => 'background-color',
		),
		array(
			'element'  => '.footer-bottom ul.menu li.current_page_item a,.site-footer .footer-bottom ul.menu li.current_page_item a ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element'  => '.portfolioeffects:hover .portfolio_overlay,.widget_wbls-image-widget .image-widget-overlay:hover .image-widget-overlay-icon',
			'property' => 'background-color',
		),
	),
) );

Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-greenr' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#000',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => 'blockquote cite a ,input[type="text"],.alert-message a,.alert-message a:hover,.toggle .toggle-title,.circle-icon-box:hover h3,
.circle-icon-box:hover a.link-title,.site-footer .circle-icon-box .circle-icon-wrapper p.fa-stack,.site-footer .circle-icon-box .circle-icon-wrapper h3,.site-footer .flex-caption h1,.site-footer .flex-caption h2,.site-footer .flex-caption h3,.site-footer .flex-caption h4,.site-footer .flex-caption h5,.site-footer .flex-caption li,.site-footer a.more-button:hover,
.site-footer .widget.widget_recent-work-widget .flex-direction-nav a.flex-prev:hover,
.site-footer .widget.widget_recent-work-widget .flex-direction-nav a.flex-next:hover,
input[type="email"],.tabs-container ul.ui-tabs-nav li a,.widget_recent-work-widget .work-title h4 a,
input[type="url"],.widget_social-networks-widget ul li a,.breadcrumb #breadcrumb a:hover,
.share-box ul li a,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a,.site-footer .flex-direction-nav a.flex-prev,
.site-footer .flex-direction-nav a.flex-next,
.tabs-container ul.ui-tabs-nav li a:hover,.widget_recent-work-widget .recent_work_overlay .fa ,
input[type="password"],.widget.widget_ourteam-widget .team-social ul li a,.widget.widget_ourteam-widget .team-content p,
input[type="search"],h1.entry-title a,ul.filter-options li a,ul.filter-options li a:hover,
ul.filter-options li a.selected,.widget_recent-posts-gallery-widget h4,.content-details h3 a,.flex-container .flex-caption a,
textarea,.tagcloud a,.logo h1 a:hover,.footer-top .tagcloud :hover,#portfolio h4 a:hover,.flex-container .flex-caption,
blockquote:before,.comment-navigation .nav-next a:hover,.site-footer .widget.widget_recent-work-widget .flex-direction-nav a.flex-prev:hover:before,
.site-footer .widget.widget_recent-work-widget .flex-direction-nav a.flex-next:hover:before,
.comment-navigation .nav-previous a:hover,.main-navigation ul a,.main-navigation ul ul a:before,.page-navigation ol li a,.page-navigation ol li.bpn-current,.page-navigation ol li.bpn-current:hover,.post-navigation .nav-links a',
			'property' => 'color',
		),
		/*array(
			'element' => 'table tr th:hover a,
			  				.site-header .social .recentcomments a:hover	
							.header-wrap .site-header .social .recentcomments a:hover,
							#primary .sticky a:hover,
							#primary .sticky span:hover,
							#primary .sticky time:hover,
							.left-sidebar .recentcomments a:hover,
							.left-sidebar .widget_rss a:hover,
							.wide-cta .call-btn a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),*/
		array(
			'element' => '.callout-widget .callout-btn a:hover,.site-footer .widget_image-box-widget a.more-button:hover,
.widget_image-box-widget a.more-button:hover,
.circle-icon-box p.more-button a:hover,.portfolio-excerpt a.btn-readmore:hover,.widget_recent-work-widget .flex-direction-nav a.flex-prev:hover,
.widget_recent-work-widget .flex-direction-nav a.flex-next:hover,.site-content .wpcf7-form input[type="submit"]:hover,.comment-navigation .nav-next a,
.comment-navigation .nav-previous a,.copy,.flex-container .flex-direction-nav a:hover',
			'property' => 'background-color',
		),
       array(
			'element' => '.site-content .wpcf7-form input[type="submit"]:hover,.site-footer .widget.widget_recent-work-widget .flex-direction-nav a.flex-prev:hover:before,
.site-footer .widget.widget_recent-work-widget .flex-direction-nav a.flex-next:hover:before,.callout-widget .callout-btn a:hover,.widget_image-box-widget a.more-button:hover,
.circle-icon-box p.more-button a:hover,.portfolio-excerpt a.btn-readmore:hover,.widget_recent-work-widget .flex-direction-nav a.flex-prev:hover,
.widget_recent-work-widget .flex-direction-nav a.flex-next:hover,.flex-container .flex-direction-nav a:hover,
.ui-accordion .ui-accordion-header-active span.fa,.sticky,ol.comment-list li.byuser',  
			'property' => 'border-color',
		),
		/*
		 array(
			'element' => '.slicknav_menu,
				          .search-form input.search-submit:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element' => '.site-content .nav-next a span,
							.withtip.left:after,
							.home .flexslider .slides .flex-caption a:after,
			      			.home .flexslider .slides .flex-caption p a:after,
			      			.home .flexslider .flex-direction-nav .flex-nav-next a,
			      			#filters ul.filter-options li a:hover:before,
			        		#filters ul.filter-options li a.selected:before,
			        		.flexslider .slides .flex-caption a:after,
			      			.flexslider .slides .flex-caption p a:after,
			      			.flexslider .flex-direction-nav .flex-nav-next a,
			      			.widget_button-widget .btn.white:hover:after,
			      			.callout-widget .call-btn a:after,
			      			.wide-dark-grey .callout-widget p.call-btn a:hover:after,
			      			.widget_testimonial-widget .flex-direction-nav a.flex-next:hover',
			'property' => 'border-left-color',
		),
	
        array(
			'element' => '.withtip.right:after,.page-numbers:last-child,
			      			.site-content .nav-previous a span,
			      			.home .flexslider .flex-direction-nav .flex-nav-prev a,
			      			.flexslider .flex-direction-nav .flex-nav-prev a,
			      			a.btn-white:hover:before,
			    			.widget_button-widget .btn.white:hover:before,
			    			.callout-widget .call-btn a:before,
			    			.wide-dark-grey .callout-widget p.call-btn a:hover:before,
			    			.widget_testimonial-widget .flex-direction-nav a.flex-prev:hover',
			'property' => 'border-right-color',
		),
        array(
			'element' => '.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link:after',
			'property' => 'border-top-color',
		),
		array(
			'element' => '.site-footer .widget_social-networks-widget ul li a:after',
			'property' => 'border-top-color',
			'suffix' => '!important',
		),*/
		array(
			'element' => '.flex-container .flex-caption a:before,.alert-message,.services-2 .textwidget a.btn:before ',
			'property' => 'border-bottom-color',
		),
	),
) );
//  slider panel //

Greenr_Kirki::add_panel( 'slider_panel', array(   
	'title'       => __( 'Slider Settings', 'greenr' ),  
	'description' => __( 'Flex slider related options', 'greenr' ), 
	'priority'    => 11,    
) );

//  flexslider section  //

Greenr_Kirki::add_section( 'flex_caption_section', array(
	'title'          => __( 'Flexcaption Settings','greenr' ),
	'description'    => __( 'Flexcaption Related Options', 'greenr'),
	'panel'          => 'slider_panel', // Not typically needed.
) );

Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexcaption_bg',
	'label'    => __( 'Select Flexcaption Background Color', 'greenr' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexcaption_align',
	'label'    => __( 'Select Flexcaption Alignment', 'greenr' ),
	'section'  => 'flex_caption_section',
	'type'     => 'select',
	'default'  => 'left',
	'choices' => array(
		'left' => esc_attr__( 'Left', 'greenr' ),
		'right' => esc_attr__( 'Right', 'greenr' ),
		'center' => esc_attr__( 'Center', 'greenr' ),
		'justify' => esc_attr__( 'Justify', 'greenr' ),
	),
	'output'   => array(
		array(
			'element'  => '.home .flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption,.flexslider .slides .flex-caption h1, .flexslider .slides .flex-caption h2, .flexslider .slides .flex-caption h3, .flexslider .slides .flex-caption h4, .flexslider .slides .flex-caption h5, .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption p,.flexslider .slides .flex-caption',
			'property' => 'text-align',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );
 Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexcaption_bg_position',
	'label'    => __( 'Select Flexcaption Background Horizontal Position', 'greenr' ),
	'tooltip' => __('Select how far from right, Default value left = 5 ( in % )','greenr'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '5',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'right',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) ); 
 Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'greenr' ),
	'tooltip' => __('Select how far from top, Default value top = 5 ( in % )','greenr'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '5',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'top',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) ); 
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexcaption_bg_width',
	'label'    => __( 'Select Flexcaption Background Width', 'greenr' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '90',
	'tooltip' => __('Select Flexcaption Background Width , Default width value 90','greenr'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) ); 
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexcaption_responsive_bg_width',
	'label'    => __( 'Select Responsive Flexcaption Background Width', 'greenr' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Responsive Flexcaption Background Width, Default width value 100 ( This value will apply for max-width: 768px )','greenr'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'media_query' => '@media (max-width: 768px)',
			'value_pattern' => 'calc($%)',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );
Greenr_Kirki::add_field( 'greenr', array(
	'settings' => 'flexcaption_color',
	'label'    => __( 'Select Flexcaption Font Color', 'greenr' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption,.home .flexslider .slides .flex-caption p,.flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption h1,.flexslider .slides .flex-caption h2,.flexslider .slides .flex-caption h3,.flexslider .slides .flex-caption h4,.flexslider .slides .flex-caption h5,.flexslider .slides .flex-caption h6',
			'property' => 'color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );

 if( class_exists( 'WooCommerce' ) ) {
	Greenr_Kirki::add_section( 'woocommerce_section', array(
		'title'          => __( 'WooCommerce','greenr' ),
		'description'    => __( 'Theme options related to woocommerce', 'greenr'),
		'priority'       => 11, 

		'theme_supports' => '', // Rarely needed.
	) );
	Greenr_Kirki::add_field( 'woocommerce', array(
		'settings' => 'woocommerce_sidebar',
		'label'    => __( 'Enable Woocommerce Sidebar', 'greenr' ),
		'description' => __('Enable Sidebar for shop page','greenr'),
		'section'  => 'woocommerce_section',
		'type'     => 'switch',
		'choices' => array(
			'on'  => esc_attr__( 'Enable', 'greenr' ),
			'off' => esc_attr__( 'Disable', 'greenr' ) 
		),

		'default'  => 'on',
	) );
}

}

