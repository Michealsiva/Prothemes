(function( $ ) {

	$(function() {

		docs = $('<a class="greenr-docs doc"></a>')
			.attr('href','http://www.webulousthemes.com/greenr-pro/') 
			.attr('target','_blank')
			.text('Documentation');

		support = $('<a class="greenr-docs question"></a>')
			.attr('href','http://www.webulousthemes.com/support-ticket/')
			.attr('target','_blank')
			.text('Ask a Question');

		$('#customize-info .preview-notice').append(docs);
		$('#customize-info .preview-notice').append(support);

		$('.greenr-docs').on('click',function(e){
			e.stopPropagation();
		});
		
		
	});

})( jQuery );
