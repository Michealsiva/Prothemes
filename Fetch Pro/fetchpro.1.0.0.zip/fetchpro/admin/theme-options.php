<?php  
/**
 * Created by PhpStorm.
 * User: venkat
 * Date: 2/5/16
 * Time: 4:32 PM        
 */    
           
include_once( get_template_directory() . '/admin/kirki/kirki.php' );   
include_once( get_template_directory() . '/admin/kirki-helpers/class-theme-kirki.php' ); 
     

Fetch_Kirki::add_config( 'fetch_pro', array(     
    'capability'    => 'edit_theme_options',                  
    'option_type'   => 'theme_mod',          
) );               
     
// Flat option start //   

//  site identity section // 

Fetch_Kirki::add_section( 'title_tagline', array(
    'title'          => __( 'Site Identity','fetch_pro' ),
    'description'    => __( 'Site Header Options', 'fetch_pro'),       
    'priority'       => 8,                                                                                                                
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'logo_title',
    'label'    => __( 'Enable Logo as Title', 'fetch_pro' ),
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'priority' => 5,
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' )
    ),
    'default'  => 'off',   
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'tagline',
    'label'    => __( 'Show site Tagline', 'fetch_pro' ), 
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' )
    ),
    'default'  => 'on',
) );  

// home panel //

Fetch_Kirki::add_panel( 'home_options', array(     
    'title'       => __( 'Home', 'fetch_pro' ),
    'description' => __( 'Home Page Related Options', 'fetch_pro' ),     
) );  


// home page type section

 Fetch_Kirki::add_section( 'home-fetch', array(
    'title'          => __( 'PRO Home - General Settings','fetch_pro' ),
    'description'    => __( 'Home Page options', 'fetch_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'enable_home_default_content',
    'label'    => __( 'Enable Home Page Default Content', 'fetch_pro' ),
    'section'  => 'home-fetch',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Use pagebuilder to built pro home page (or) Use prebuilt layout','fetch_pro'),
) );  


// Slider section   

Fetch_Kirki::add_section( 'slider-section', array(
    'title'          => __( 'Slider Section','fetch_pro' ),
    'description'    => __( 'Home Page Slider Related Options', 'fetch_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );
Fetch_Kirki::add_field( 'fetch_pro', array(  
    'settings' => 'slider_field',  
    'label'    => __( 'Enable Slider Post ( Section )', 'fetch_pro' ),
    'section'  => 'slider-section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Slider Post in home page','fetch_pro'),
) );
 
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'slider_cat',
    'label'    => __( 'Slider Posts category', 'fetch_pro' ),
    'section'  => 'slider-section',
    'type'     => 'select',
    'choices' => Kirki_Helper::get_terms( 'category' ),
    'active_callback' => array(
        array(
            'setting'  => 'slider_field', 
            'operator' => '==',
            'value'    => true, 
        ),
    ),
    'tooltip' => __('Create post ( Goto Dashboard => Post => Add New ) and Post Featured Image ( Preferred size is 1200 x 450 pixels ) as taken as slider image and Post Content as taken as Flexcaption.','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'slider_count',
    'label'    => __( 'No. of Sliders', 'fetch_pro' ),
    'section'  => 'slider-section',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 999,
        'step' => 1,
    ),
    'default'  => 2,
    'active_callback' => array(
        array(
            'setting'  => 'slider_field',
            'operator' => '==',
            'value'    => true,
        ),                                                                             
    ),
    'tooltip' => __('Enter number of slides you want to display under your selected Category','fetch_pro'),
) );

// service section 

Fetch_Kirki::add_section( 'service_section', array(
    'title'          => __( 'Service Section','fetch_pro' ),
    'description'    => __( 'Home Page - Service Related Options', 'fetch_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Fetch_Kirki::add_field( 'fetch_pro', array(  
    'settings' => 'service_section_status',  
    'label'    => __( 'Enable Service Section', 'fetch_pro' ),
    'section'  => 'service_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Service section in home page','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'service_section_title',
    'label'    => __( 'Service Section Title & Description', 'fetch_pro' ),
    'section'  => 'service_section',
    'type'     => 'dropdown-pages', 
) );

for ( $i = 1 ; $i <= 4 ; $i++ ) {
    //Create the settings Once, and Loop through it.
    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'service_section_icon_'.$i,
        'label'    => sprintf(__( 'Service Section Icons #%1$s', 'fetch_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'text',
        'description' => sprintf(__( '%1$s (fa fa-apple) ', 'fetch_pro' ), '<a href="http://fontawesome.io/icons/">Type FontAwesome icons</a>' ),          
        'active_callback' => array(
            array(
                'setting'  => 'service_section_status',
                'operator' => '==',
                'value'    => true,
            ),                                                                       
        ),
    ) );

    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'service_section_'.$i,
        'label'    => sprintf(__( 'Service Section #%1$s', 'fetch_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'dropdown-pages', 
        'active_callback' => array(
            array(
                'setting'  => 'service_section_status',
                'operator' => '==',
                'value'    => true,
            ),          
        ),    
    ) );
    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'service_color_'.$i,
        'label'    => sprintf(__( 'Choose Service Section Icons #%1$s', 'fetch_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'color', 
        'active_callback' => array(
            array(
                'setting'  => 'service_section_status',
                'operator' => '==',
                'value'    => true,
            ),                                                                        
        ),        
    ) );
}
 
// Image section 

Fetch_Kirki::add_section( 'about-us-section', array(
    'title'          => __( 'About Us Section','fetch_pro' ),
    'description'    => __( 'Home Page - Related Options', 'fetch_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Fetch_Kirki::add_field( 'fetch_pro', array(  
    'settings' => 'aboutus_section_status',   
    'label'    => __( 'Enable to Show About Us Section', 'fetch_pro' ),
    'section'  => 'about-us-section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Image content section in home page','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'aboutus_section_title',
    'label'    => __( 'Section Title & Description', 'fetch_pro' ),
    'section'  => 'about-us-section',
    'type'     => 'dropdown-pages', 
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'aboutus_section_form',
    'label'    => __( 'AboutUs Form', 'fetch_pro' ),
    'description' => __('Copy and paste the shortcode of the form from the contact form 7', 'fetch_pro'),
    'section'  => 'about-us-section',
    'type'     => 'text', 
    'sanitize_callback' => 'wp_kses_post',
) );


Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'aboutus_section_img',
    'label'    => __( 'Image content Section', 'fetch_pro' ),
    'section'  => 'about-us-section',
    'type'     => 'dropdown-pages', 
    'active_callback' => array(
        array(
            'setting'  => 'aboutus_section_status',
            'operator' => '==',
            'value'    => true,
        ),          
    ),    
) );



// latest blog section 

Fetch_Kirki::add_section( 'latest_blog_section', array(
    'title'          => __( 'Latest Blog Section','fetch_pro' ),
    'description'    => __( 'Home Page - Latest Blog Options', 'fetch_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'enable_recent_post_service',
    'label'    => __( 'Enable Recent Post Section', 'fetch_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),

    'default'  => 'on',
    'tooltip' => __('Enable recent post section in home page','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'recent_post_section_title',
    'label'    => __( 'Recent Post Section Title & Description', 'fetch_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'dropdown-pages', 
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'recent_posts_count',
    'label'    => __( 'No. of Recent Posts', 'fetch_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'number',
    'choices' => array(
        'min' => 2,
        'max' => 99,
        'step' => 2,
    ),
    'default'  =>3,
    'active_callback' => array(
        array(
            'setting'  => 'enable_recent_post_service',
            'operator' => '==',
            'value'    => true,
        ),

    ),
) );


// general panel      

Fetch_Kirki::add_panel( 'general_panel', array(   
    'title'       => __( 'General Settings', 'fetch_pro' ),  
    'description' => __( 'general settings', 'fetch_pro' ),         
) );
//  Page title bar section // 

Fetch_Kirki::add_section( 'header-pagetitle-bar', array(   
    'title'          => __( 'Page Title Bar & Breadcrumb','fetch_pro' ),
    'description'    => __( 'Page Title bar related options', 'fetch_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) ); 
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'global_page_title_bar',
    'label'    => __( 'Check the box if you want to use a global page title bar settings. This option overrides the page options', 'fetch_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'checkbox',
    'default' => '0',
) );   

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'page_titlebar',  
    'label'    => __( 'Page Title Bar', 'fetch_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( 'Show Bar and Content', 'fetch_pro' ),
        2 => __('Hide','fetch_pro'),
    ),
    'default' => 1,
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'page_titlebar_text',  
    'label'    => __( 'Page Title Bar Text', 'fetch_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        0 => __( 'Show', 'fetch_pro' ),
        1 => __( 'Hide', 'fetch_pro' ), 
    ),
    'default' => 0,
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'breadcrumb',  
    'label'    => __( 'Hide Breadcrumb', 'fetch_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'checkbox',
    'default'  => 0,
) ); 

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'breadcrumb_char',
    'label'    => __( 'Breadcrumb Character', 'fetch_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( ' >> ', 'fetch_pro' ),
        2 => __( ' / ', 'fetch_pro' ),
        3 => __( ' > ', 'fetch_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'breadcrumb',
            'operator' => '==',
            'value'    => 0,
        ),
    ),
    //'sanitize_callback' => 'allow_htmlentities'
) );

//  pagination section // 

Fetch_Kirki::add_section( 'general-pagination', array(   
    'title'          => __( 'Pagination','fetch_pro' ),
    'description'    => __( 'Pagination related options', 'fetch_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'numeric_pagination',
    'label'    => __( 'Numeric Pagination', 'fetch_pro' ),   
    'section'  => 'general-pagination',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Numbered', 'fetch_pro' ),
        'off' => esc_attr__( 'Next/Previous', 'fetch_pro' )
    ),
    'default'  => 'on',
) );

// skin color panel 

Fetch_Kirki::add_panel( 'skin_color_panel', array(   
    'title'       => __( 'Skin Color', 'fetch_pro' ),  
    'description' => __( 'Color Settings', 'fetch_pro' ),         
) );
// color scheme section 

Fetch_Kirki::add_section( 'multiple_color_section', array(
    'title'          => __( 'Color Scheme','fetch_pro' ),
    'description'    => __( 'Select your color scheme', 'fetch_pro'),
    'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 9,
) );  

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'color_scheme',
    'label'    => __( 'Select your color scheme', 'fetch_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'palette',
    'choices'     => array( 
        '1' => array( 
            '#3c82f4',
        ),
        '2' => array(
            '#00b9b4',
        ),
        '3' => array(
            '#fd005f',
        ),
        '4' => array(
            '#96c142',
        ),
        '5' => array(
            '#f8752d',
        ),
        '6' => array(
            '#eda835',
        ),
        '7' => array(
            '#00a1d8',
        ),
    ),
    'default' => '1',
//'default'  => 'on',
) );

/* custom color stylesheet */

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'enable_custom_color_scheme',
    'label'    => __( 'Enable Custom color scheme', 'fetch_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' )
    ),
    'default'  => 'off',
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'custom_color_scheme',
    'label'    => __( 'Select custom color scheme', 'fetch_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'color',
    'default'  => '#3c82f4',
    'alpha'  => false,
    'active_callback' => array(
        array (
            'setting'  => 'enable_custom_color_scheme',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

/* pagebuilder style override */
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'enable_so_custom_color',
    'label'    => __( 'Enable this Option to change color choosen by pagebuilder', 'fetch_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' )
    ),
    'default'  => 'off',
    'tooltip' => __('while change the color scheme this option is also change the pagebuilder row and widget related option color in order to match color scheme','fetch_pro'),

) );

// typography panel //  

Fetch_Kirki::add_panel( 'typography', array( 
    'title'       => __( 'Typography', 'fetch_pro' ),
    'description' => __( 'Typography and Link Color Settings', 'fetch_pro' ),
) );
   
    Fetch_Kirki::add_section( 'typography_section', array(
        'title'          => __( 'General Settings','fetch_pro' ),
        'description'    => __( 'General Settings', 'fetch_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );
        

    Fetch_Kirki::add_section( 'body_font', array(
        'title'          => __( 'Body Font','fetch_pro' ), 
        'description'    => __( 'Specify the body font properties', 'fetch_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) ); 

    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'body_typography',
        'label'    => __( 'Enable Custom body Settings', 'fetch_pro' ),
        'section'  => 'body_font',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
            'off' => esc_attr__( 'Disable', 'fetch_pro' )
        ),
        'tooltip' => __('Turn on to body typography and turn off for default typography','fetch_pro'),
        'default'  => 'off',
    ) );


    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'body',
        'label'    => __( 'Body Settings', 'fetch_pro' ),
        'section'  => 'body_font', 
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Open Sans', 
            'variant'        => 'regular',
            'font-size'      => '16px',  
            'line-height'    => '1.5',
            'letter-spacing' => '0',
            'color'          => '#202020', 
        ),
        'output'      => array(
            array(
                'element' => 'body',
                //'suffix' => '!important',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'body_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );


    Fetch_Kirki::add_section( 'heading_section', array(
        'title'          => __( 'Heading Font','fetch_pro' ),
        'description'    => __( 'Specify typography of H1, H2, H3, H4, H5, H6', 'fetch_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'heading_one_typography',
        'label'    => __( 'Enable Custom H1 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
            'off' => esc_attr__( 'Disable', 'fetch_pro' )
        ),
        'tooltip' => __('Turn on to H1 typography and turn off for default typography','fetch_pro'),
        'default'  => 'off',
    ) );


    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'h1',  
        'label'    => __( 'H1 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '48px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h1',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_one_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );
    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'heading_two_typography',
        'label'    => __( 'Enable Custom H2 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
            'off' => esc_attr__( 'Disable', 'fetch_pro' )
        ),
        'tooltip' => __('Turn on to H2 typography and turn off for default typography','fetch_pro'),
        'default'  => 'off',
    ) );


    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'h2',
        'label'    => __( 'H2 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '36px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h2',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_two_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'heading_three_typography',
        'label'    => __( 'Enable Custom H3 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
            'off' => esc_attr__( 'Disable', 'fetch_pro' )
        ),
        'tooltip' => __('Turn on to H3 typography and turn off for default typography','fetch_pro'),
        'default'  => 'off',
    ) );


    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'h3',
        'label'    => __( 'H3 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default' => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '30px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h3',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_three_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'heading_four_typography',
        'label'    => __( 'Enable Custom H4 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
            'off' => esc_attr__( 'Disable', 'fetch_pro' )
        ),
        'tooltip' => __('Turn on to H4 typography and turn off for default typography','fetch_pro'),
        'default'  => 'off',
    ) );


    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'h4',
        'label'    => __( 'H4 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '24px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h4',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_four_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'heading_five_typography',
        'label'    => __( 'Enable Custom H5 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
            'off' => esc_attr__( 'Disable', 'fetch_pro' )
        ),
        'tooltip' => __('Turn on to H5 typography and turn off for default typography','fetch_pro'),
        'default'  => 'off',
    ) );



    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'h5',
        'label'    => __( 'H5 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '18px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h5',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_five_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );

    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'heading_six_typography',
        'label'    => __( 'Enable Custom H6 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
            'off' => esc_attr__( 'Disable', 'fetch_pro' )
        ),
        'tooltip' => __('Turn on to H6 typography and turn off for default typography','fetch_pro'),
        'default'  => 'off',
    ) );



    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'h6',
        'label'    => __( 'H6 Settings', 'fetch_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway', 
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h6',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_six_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    // navigation font 
    Fetch_Kirki::add_section( 'navigation_section', array(
        'title'          => __( 'Navigation Font','fetch_pro' ),
        'description'    => __( 'Specify Navigation font properties', 'fetch_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'navigation_font_status',
        'label'    => __( 'Enable Navigation Font Settings', 'fetch_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
            'off' => esc_attr__( 'Disable', 'fetch_pro' )
        ),
        'tooltip' => __('Turn on to Navigation Font typography and turn off for default typography','fetch_pro'),
        'default'  => 'off',
    ) );

    Fetch_Kirki::add_field( 'fetch_pro', array(
        'settings' => 'navigation_font',
        'label'    => __( 'Navigation Font Settings', 'fetch_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Open Sans',
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8', 
            'letter-spacing' => '0',
            'color'          => '#ffffff',
        ),
        'output'      => array(
            array(
                'element' => '.main-navigation a',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'navigation_font_status',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );



// header panel //  

Fetch_Kirki::add_panel( 'header_panel', array(     
    'title'       => __( 'Header', 'fetch_pro' ),
    'description' => __( 'Header Related Options', 'fetch_pro' ), 
) );  

/* STICKY HEADER section */     
  
Fetch_Kirki::add_section( 'stricky_header', array(
    'title'          => __( 'Sticky Menu','fetch_pro' ),
    'description'    => __( 'sticky header', 'fetch_pro'),
    'panel'          => 'header_panel', // Not typically needed.
) );
Fetch_Kirki::add_field( 'fetch_pro', array(    
    'settings' => 'sticky_header',
    'label'    => __( 'Enable Sticky Header', 'fetch_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' )
    ),
    'default'  => 'on',
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'sticky_header_position',
    'label'    => __( 'Enable Sticky Header Position', 'fetch_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'top'  => esc_attr__( 'Top', 'fetch_pro' ),
        'bottom' => esc_attr__( 'Bottom', 'fetch_pro' )
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'sticky_header',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'top',
) );


/*
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'header_top_margin',
    'label'    => __( 'Header Top Margin', 'fetch_pro' ),
    'description' => __('Select the top margin of header in pixels','fetch_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'header_bottom_margin',
    'label'    => __( 'Header Bottom Margin', 'fetch_pro' ),
    'description' => __('Select the bottom margin of header in pixels','fetch_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );*/

Fetch_Kirki::add_section( 'header_image', array(
    'title'          => __( 'Header Background Image','fetch_pro' ),
    'description'    => __( 'Custom Header Image options', 'fetch_pro'),
    'panel'          => 'header_panel', // Not typically needed.  
) );

Fetch_Kirki::add_field( 'fetch_pro', array(   
    'settings' => 'header_bg_size',
    'label'    => __( 'Header Background Size', 'fetch_pro' ),
    'section'  => 'header_image',
    'type'     => 'radio-buttonset', 
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'fetch_pro' ),
        'contain' => esc_attr__( 'Contain', 'fetch_pro' ),
        'auto'  => esc_attr__( 'Auto', 'fetch_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'fetch_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Header Background Image Size','fetch_pro'),
) );

/*Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'header_height',
    'label'    => __( 'Header Background Image Height', 'fetch_pro' ),
    'section'  => 'header_image',
    'type'     => 'number',
    'choices' => array(
        'min' => 100,
        'max' => 600,
        'step' => 1,
    ),
    'default'  => '213',
) ); */
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'header_bg_repeat',
    'label'    => __( 'Header Background Repeat', 'fetch_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'fetch_pro'),
        'repeat' => esc_attr__('Repeat', 'fetch_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','fetch_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'repeat',  
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'header_bg_position', 
    'label'    => __( 'Header Background Position', 'fetch_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'fetch_pro'),
        'center center' => esc_attr__('Center Center', 'fetch_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'fetch_pro'),
        'left top' => esc_attr__('Left Top', 'fetch_pro'),
        'left center' => esc_attr__('Left Center', 'fetch_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'fetch_pro'),
        'right top' => esc_attr__('Right Top', 'fetch_pro'),
        'right center' => esc_attr__('Right Center', 'fetch_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'center center',  
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'header_bg_attachment',
    'label'    => __( 'Header Background Attachment', 'fetch_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'fetch_pro'),
        'fixed' => esc_attr__('Fixed', 'fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'scroll',  
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'header_overlay',
    'label'    => __( 'Enable Header( Background ) Overlay', 'fetch_pro' ),
    'section'  => 'header_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' )
    ),
    'default'  => 'off',
) );
  
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'header_overlay_color',
    'label'    => __( 'Header Overlay ( Background )color', 'fetch_pro' ),
    'section'  => 'header_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'output'   => array(
        array(
            'element'  => '.overlay-header',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

/*
/* e-option start */
/*
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'custon_favicon',
    'label'    => __( 'Custom Favicon', 'fetch_pro' ),
    'section'  => 'header',
    'type'     => 'upload',
    'default'  => '',
) ); */
/* e-option start */ 
/* Blog page section */


/* Blog panel */

Fetch_Kirki::add_panel( 'blog_panel', array(     
    'title'       => __( 'Blog', 'fetch_pro' ),
    'description' => __( 'Blog Related Options', 'fetch_pro' ),     
) ); 
Fetch_Kirki::add_section( 'blog', array(
    'title'          => __( 'Blog Page','fetch_pro' ),
    'description'    => __( 'Blog Related Options', 'fetch_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
  
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'blog_layout',
    'label'    => __( 'Select Blog Page Layout you prefer', 'fetch_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1  => esc_attr__( 'Default ( One Column )', 'fetch_pro' ),
        2 => esc_attr__( 'Two Columns ', 'fetch_pro' ),
        3 => esc_attr__( 'Three Columns ( Without Sidebar ) ', 'fetch_pro' ),
        4 => esc_attr__( 'Two Columns With Masonry', 'fetch_pro' ),
        5 => esc_attr__( 'Three Columns With Masonry ( Without Sidebar ) ', 'fetch_pro' ),
        6 => esc_attr__( 'Blog FullWidth', 'fetch_pro' ),
    ),
    'default'  => 1,
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'featured_image',
    'label'    => __( 'Enable Featured Image', 'fetch_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for blog page','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'more_text',
    'label'    => __( 'More Text', 'fetch_pro' ),
    'section'  => 'blog',
    'type'     => 'text',
    'description' => __('Text to display in case of text too long','fetch_pro'),
    'default' => __('Read More','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'featured_image_size',
    'label'    => __( 'Choose the Featured Image Size for Blog Page', 'fetch_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1 => esc_attr__( 'Large Featured Image', 'fetch_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'fetch_pro' ),
        3 => esc_attr__( 'Original Size', 'fetch_pro' ),
        4 => esc_attr__( 'Medium', 'fetch_pro' ),
        5 => esc_attr__( 'Large', 'fetch_pro' ), 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Set large and medium image size: Goto Dashboard => Settings => Media', 'fetch_pro') ,
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'enable_single_post_top_meta',
    'label'    => __( 'Enable to display top post meta data', 'fetch_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'single_post_top_meta',
    'label'    => __( 'Activate and Arrange the Order of Top Post Meta elements', 'fetch_pro' ),
    'section'  => 'blog',
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'fetch_pro' ),
        2 => esc_attr__( 'author', 'fetch_pro' ),
        3 => esc_attr__( 'comment', 'fetch_pro' ),
        4 => esc_attr__( 'category', 'fetch_pro' ),
        5 => esc_attr__( 'tags', 'fetch_pro' ),
        6 => esc_attr__( 'edit', 'fetch_pro' ),
    ),
    'default'  => array(1, 2, 3,6),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_top_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','fetch_pro'),

) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'enable_single_post_bottom_meta',
    'label'    => __( 'Enable to display bottom post meta data', 'fetch_pro' ),
    'section'  => 'blog', 
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','fetch_pro'),
    'default'  => 'on',
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'single_post_bottom_meta',
    'label'    => __( 'Activate and arrange the Order of Bottom Post Meta elements', 'fetch_pro' ),
    'section'  => 'blog',    
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'fetch_pro' ),
        2 => esc_attr__( 'author', 'fetch_pro' ),
        3 => esc_attr__( 'comment', 'fetch_pro' ),
        4 => esc_attr__( 'category', 'fetch_pro' ),
        5 => esc_attr__( 'tags', 'fetch_pro' ),
        6 => esc_attr__( 'edit', 'fetch_pro' ),
    ),
    'default'  => array(4,5),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_bottom_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','fetch_pro'),
) );


/* Single Blog page section */

Fetch_Kirki::add_section( 'single_blog', array(
    'title'          => __( 'Single Blog Page','fetch_pro' ),
    'description'    => __( 'Single Blog Page Related Options', 'fetch_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'single_featured_image',
    'label'    => __( 'Enable Single Post Featured Image', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for Single Post Page','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'single_featured_image_size',
    'label'    => __( 'Choose the featured image display type for Single Post Page', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Large Featured Image', 'fetch_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'fetch_pro' ),
        3 => esc_attr__( 'FullWidth Featured Image', 'fetch_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'author_bio_box',
    'label'    => __( 'Enable Author Bio Box below single post', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'off',
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'related_posts',
    'label'    => __( 'Show Related Posts', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Show the Related Post for Single Blog Page','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'related_posts_hierarchy',
    'label'    => __( 'Related Posts Must Be Shown As:', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Related Posts By Tags', 'fetch_pro' ),
        2 => esc_attr__( 'Related Posts By Categories', 'fetch_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'related_posts',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Select the Hierarchy','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'comments',
    'label'    => __( ' Show Comments', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Show the Comments for Single Blog Page','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'social_sharing_box',
    'label'    => __( 'Show social sharing options box below single post', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
) );

//social sharing box section

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'facebook_sb',
    'label'    => __( 'Enable facebook sharing option below single post', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'twitter_sb',
    'label'    => __( 'Enable twitter sharing option below single post', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'linkedin_sb',
    'label'    => __( 'Enable linkedin sharing option below single post', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'google-plus_sb',
    'label'    => __( 'Enable googleplus sharing option below single post', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'email_sb',
    'label'    => __( 'Enable email sharing option below single post', 'fetch_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
/* FOOTER SECTION 
footer panel */

Fetch_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'fetch_pro' ),
    'description' => __( 'Footer Related Options', 'fetch_pro' ),     
) );  

Fetch_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','fetch_pro' ),
    'description'    => __( 'Footer related options', 'fetch_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'fetch_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','fetch_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'fetch_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'fetch_pro' ),
        2  => esc_attr__( '2', 'fetch_pro' ),
        3  => esc_attr__( '3', 'fetch_pro' ),
        4  => esc_attr__( '4', 'fetch_pro' ),
    ),
    'default'  => 4,
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'fetch_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'fetch_pro' ),
    'description' => __('Select the top margin of footer in pixels','fetch_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Fetch_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','fetch_pro' ),
    'description'    => __( 'Custom Footer Image options', 'fetch_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'fetch_pro' ),
        'contain' => esc_attr__( 'Contain', 'fetch_pro' ),
        'auto'  => esc_attr__( 'Auto', 'fetch_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'fetch_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'fetch_pro'),
        'repeat' => esc_attr__('Repeat', 'fetch_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','fetch_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',   
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'fetch_pro'),
        'center center' => esc_attr__('Center Center', 'fetch_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'fetch_pro'),
        'left top' => esc_attr__('Left Top', 'fetch_pro'),
        'left center' => esc_attr__('Left Center', 'fetch_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'fetch_pro'),
        'right top' => esc_attr__('Right Top', 'fetch_pro'),
        'right center' => esc_attr__('Right Center', 'fetch_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'fetch_pro'),
        'fixed' => esc_attr__('Fixed', 'fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' )
    ),
    'default'  => 'off',
) );
  
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer_image',
            'property' => 'background-color',
        ),
    ),
) );


// single page section //

Fetch_Kirki::add_section( 'single_page', array(
    'title'          => __( 'Single Page','fetch_pro' ),
    'description'    => __( 'Single Page Related Options', 'fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'single_page_featured_image',
    'label'    => __( 'Enable Single Page Featured Image', 'fetch_pro' ),
    'section'  => 'single_page',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'single_page_featured_image_size',
    'label'    => __( 'Single Page Featured Image Size', 'fetch_pro' ),
    'section'  => 'single_page',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( 'Normal', 'fetch_pro' ),
        2 => esc_attr__( 'FullWidth', 'fetch_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_page_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

// Layout section //

Fetch_Kirki::add_section( 'layout', array( 
    'title'          => __( 'Layout','fetch_pro' ),
    'description'    => __( 'Layout Related Options', 'fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'site-style',
    'label'    => __( 'Site Style', 'fetch_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'wide' =>  esc_attr__('Wide', 'fetch_pro'),
        'boxed' =>  esc_attr__('Boxed', 'fetch_pro'),
        'fluid' =>  esc_attr__('Fluid', 'fetch_pro'),  
        //'static' =>  esc_attr__('Static ( Non Responsive )', 'fetch_pro'),
    ),
    'default'  => 'wide',
    'tooltip' => __('Choose the default site layout.','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'global_sidebar_layout',
    'label'    => __( 'Check the box if you want to use a global sidebar on all pages. This option overrides the page options', 'fetch_pro' ),
    'section'  => 'layout',
    'type'     => 'checkbox',
    'default' => '0',
) );


Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'sidebar_position',
    'label'    => __( 'Main Layout', 'fetch_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-image',   
    'description' => __('Select main content and sidebar arrangement.','fetch_pro'),
    'choices' => array(
        'left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cl.png',
        'right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cr.png',
        'two-sidebar' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cm.png',  
        'two-sidebar-left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cl.png',
        'two-sidebar-right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cr.png',
        'fullwidth' =>  get_template_directory_uri() . '/admin/kirki/assets/images/1c.png',
        'no-sidebar' =>  get_template_directory_uri() . '/images/no-sidebar.png',
    ),
    'default'  => 'right', 
    'tooltip' => __('global sidebar on all pages. This option overrides the page layout sidebar options','fetch_pro'),
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'body_top_margin',
    'label'    => __( 'Body Top Margin', 'fetch_pro' ),
    'description' => __('Select the top margin of body element in pixels','fetch_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-top',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'body_bottom_margin',
    'label'    => __( 'Body Bottom Margin', 'fetch_pro' ),
    'description' => __('Select the bottom margin of body element in pixels','fetch_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-bottom',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );

/* LAYOUT SECTION  */
/*
Fetch_Kirki::add_section( 'layout', array(
    'title'          => __( 'Layout','fetch_pro' ),   
    'description'    => __( 'Layout settings that affects overall site', 'fetch_pro'),
    'panel'          => 'fetch_pro_options', // Not typically needed.
) );



Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'primary_sidebar_width',
    'label'    => __( 'Primary Sidebar Width', 'fetch_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'fetch_pro' ),
        '2' => __( 'Two Column', 'fetch_pro' ),
        '3' => __( 'Three Column', 'fetch_pro' ),
        '4' => __( 'Four Column', 'fetch_pro' ),
        '5' => __( 'Five Column ', 'fetch_pro' ),
    ),
    'default'  => '5',  
    'tooltip' => __('Select the width of the Primary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'secondary_sidebar_width',
    'label'    => __( 'Secondary Sidebar Width', 'fetch_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'fetch_pro' ),
        '2' => __( 'Two Column', 'fetch_pro' ),
        '3' => __( 'Three Column', 'fetch_pro' ),
        '4' => __( 'Four Column', 'fetch_pro' ),
        '5' => __( 'Five Column ', 'fetch_pro' ),
    ),            
    'default'  => '5',  
    'tooltip' => __('Select the width of the Secondary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','fetch_pro'),
) ); 

*/

/* FOOTER SECTION 
footer panel */

Fetch_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'fetch_pro' ),
    'description' => __( 'Footer Related Options', 'fetch_pro' ),     
) );  

Fetch_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','fetch_pro' ),
    'description'    => __( 'Footer related options', 'fetch_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'fetch_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','fetch_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'fetch_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'fetch_pro' ),
        2  => esc_attr__( '2', 'fetch_pro' ),
        3  => esc_attr__( '3', 'fetch_pro' ),
        4  => esc_attr__( '4', 'fetch_pro' ),
    ),
    'default'  => 4,
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'fetch_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'fetch_pro' ),
    'description' => __('Select the top margin of footer in pixels','fetch_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Fetch_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','fetch_pro' ),
    'description'    => __( 'Custom Footer Image options', 'fetch_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'fetch_pro' ),
        'contain' => esc_attr__( 'Contain', 'fetch_pro' ),
        'auto'  => esc_attr__( 'Auto', 'fetch_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'fetch_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'fetch_pro'),
        'repeat' => esc_attr__('Repeat', 'fetch_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','fetch_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'fetch_pro'),
        'center center' => esc_attr__('Center Center', 'fetch_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'fetch_pro'),
        'left top' => esc_attr__('Left Top', 'fetch_pro'),
        'left center' => esc_attr__('Left Center', 'fetch_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'fetch_pro'),
        'right top' => esc_attr__('Right Top', 'fetch_pro'),
        'right center' => esc_attr__('Right Center', 'fetch_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'fetch_pro'),
        'fixed' => esc_attr__('Fixed', 'fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' )
    ),
    'default'  => 'off',
) );
  
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'fetch_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.overlay-footer',
            'property' => 'background-color',
        ),
    ),
) );


 if( class_exists( 'WooCommerce' ) ) {
    Fetch_Kirki::add_section( 'woocommerce_section', array(
        'title'          => __( 'WooCommerce','fetch_pro' ),
        'description'    => __( 'Theme options related to woocommerce', 'fetch_pro'),
        'priority'       => 11, 
        'theme_supports' => '', // Rarely needed.
    ) );
    Fetch_Kirki::add_field( 'woocommerce', array(
        'settings' => 'woocommerce_sidebar',
        'label'    => __( 'Enable Woocommerce Sidebar', 'fetch_pro' ),
        'description' => __('Enable Sidebar for shop page','fetch_pro'),
        'section'  => 'woocommerce_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
            'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
        ),

        'default'  => 'on',
    ) );
}
    
// background color ( rename )

Fetch_Kirki::add_section( 'colors', array(
    'title'          => __( 'Background Color','fetch_pro' ),
    'description'    => __( 'This will affect overall site background color', 'fetch_pro'),
    //'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 11,
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'general_background_color',
    'label'    => __( 'General Background Color', 'fetch_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-color',
        ),
    ),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'content_background_color',
    'label'    => __( 'Content Background Color', 'fetch_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'description' => __('when you are select boxed layout content background color will reflect the grid area','fetch_pro'), 
    'alpha' => true, 
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'general_background_image',
    'label'    => __( 'General Background Image', 'fetch_pro' ),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-image',
        ),
    ),
) );

// background image ( general & boxed layout ) //


Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'general_background_repeat',
    'label'    => __( 'General Background Repeat', 'fetch_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'fetch_pro'),
        'repeat' => esc_attr__('Repeat', 'fetch_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','fetch_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'general_background_size',
    'label'    => __( 'General Background Size', 'fetch_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'fetch_pro' ),
        'contain' => esc_attr__( 'Contain', 'fetch_pro' ),
        'auto'  => esc_attr__( 'Auto', 'fetch_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'fetch_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'general_background_attachment',
    'label'    => __( 'General Background Attachment', 'fetch_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'fetch_pro'),
        'fixed' => esc_attr__('Fixed', 'fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'general_background_position',
    'label'    => __( 'General Background Position', 'fetch_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'fetch_pro'),
        'center center' => esc_attr__('Center Center', 'fetch_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'fetch_pro'),
        'left top' => esc_attr__('Left Top', 'fetch_pro'),
        'left center' => esc_attr__('Left Center', 'fetch_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'fetch_pro'),
        'right top' => esc_attr__('Right Top', 'fetch_pro'),
        'right center' => esc_attr__('Right Center', 'fetch_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );


/* CONTENT BACKGROUND ( boxed background image )*/

Fetch_Kirki::add_field( 'fetch_pro', array(  
    'settings' => 'content_background_image',
    'label'    => __( 'Content Background Image', 'fetch_pro' ),
    'description' => __('when you are select boxed layout content background image will reflect the grid area','fetch_pro'),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-image',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'content_background_repeat',
    'label'    => __( 'Content Background Repeat', 'fetch_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'fetch_pro'),
        'repeat' => esc_attr__('Repeat', 'fetch_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','fetch_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'content_background_size',
    'label'    => __( 'Content Background Size', 'fetch_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'fetch_pro' ),
        'contain' => esc_attr__( 'Contain', 'fetch_pro' ),
        'auto'  => esc_attr__( 'Auto', 'fetch_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'fetch_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'content_background_attachment',
    'label'    => __( 'Content Background Attachment', 'fetch_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'fetch_pro'),
        'fixed' => esc_attr__('Fixed', 'fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'content_background_position',
    'label'    => __( 'Content Background Position', 'fetch_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'fetch_pro'),
        'center center' => esc_attr__('Center Center', 'fetch_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'fetch_pro'),
        'left top' => esc_attr__('Left Top', 'fetch_pro'),
        'left center' => esc_attr__('Left Center', 'fetch_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'fetch_pro'),
        'right top' => esc_attr__('Right Top', 'fetch_pro'),
        'right center' => esc_attr__('Right Center', 'fetch_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'fetch_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );

/* pro theme options */

//  animation section 

Fetch_Kirki::add_section( 'animation_section', array(
    'title'          => __( 'Animation','fetch_pro' ),
    'description'    => __( 'Animation that affects overall site', 'fetch_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );    

Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'animation_effect',
    'label'    => __( 'Enable Animation Effect', 'fetch_pro' ),   
    'section'  => 'animation_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'fetch_pro' ),
        'off' => esc_attr__( 'Disable', 'fetch_pro' ) 
    ),
    'default'  => 'on',
) );

// custom JS section

Fetch_Kirki::add_section( 'custom_js_section', array(
    'title'          => __( 'Custom JS','fetch_pro' ),
    'description'    => __( 'Custom JS', 'fetch_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
 Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'custom_js',
    'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'fetch_pro' ),
    'section'  => 'custom_js_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
) ); 


// Tracking section 

Fetch_Kirki::add_section( 'analytics_section', array(
    'title'          => __( 'Tracking Code','fetch_pro' ),
    'description'    => __( 'Tracking Code', 'fetch_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'analytics',
    'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'fetch_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
    'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'analytics_place',
    'label'    => __( 'Enable to Load Tracking Code in Footer', 'fetch_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'fetch_pro' ),
        '2' => esc_attr__( 'Disable', 'fetch_pro' )
    ),
    'default'  => '2',
    'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','fetch_pro'),
) );


//  lightbox section //

Fetch_Kirki::add_section( 'light_box', array(
    'title'          => __( 'Light Box','fetch_pro' ),
    'description'    => __( 'Light Box Settings', 'fetch_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'lightbox_theme',
    'label'    => __( 'Lightbox Theme', 'fetch_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => esc_attr__( 'pp_default', 'fetch_pro' ),
        '2' => esc_attr__( 'light-rounded', 'fetch_pro' ),
        '3' => esc_attr__( 'dark-rounded', 'fetch_pro' ),
        '4' => esc_attr__( 'light-square', 'fetch_pro' ),
        '5' => esc_attr__( 'dark-square', 'fetch_pro' ),
        '6' => esc_attr__( 'facebook', 'fetch_pro' ),
    ),
    'default'  => '1',
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'lightbox_animation_speed',
    'label'    => __( 'Animation Speed', 'fetch_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'fast' => esc_attr__( 'Fast', 'fetch_pro' ),
        'slow' => esc_attr__( 'Slow', 'fetch_pro' ),
        'normal' => esc_attr__( 'Normal', 'fetch_pro' ),
    ),
    'default'  => 'fast',
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'lightbox_slideshow',
    'label'    => __( 'Autoplay Gallery Speed', 'fetch_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 100,
        'step' => 10,
    ),
    'default'  => 50,
    'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'lightbox_autoplay_slideshow',
    'label'    => __( 'Enable Autoplay Gallery', 'fetch_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'fetch_pro' ),
        '2' => esc_attr__( 'Disable', 'fetch_pro' )
    ),
    'default'  => '2',
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'lightbox_opacity',
    'label'    => __( 'Select Background Opacity', 'fetch_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 1,
        'step' => 0.1,
    ),
    'default'  => 0.5,
    'tooltip' => __('Enter 0.1 to 1.0','fetch_pro'),
) );
Fetch_Kirki::add_field( 'fetch_pro', array(
    'settings' => 'lightbox_overlay_gallery',
    'label'    => __( 'Show Gallery Thumbnails', 'fetch_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array( 
        '1'  => esc_attr__( 'Enable', 'fetch_pro' ),
        '2' => esc_attr__( 'Disable', 'fetch_pro' )
    ),
    'default'  => '1',
) );


 

         
do_action('fetch_pro_child_customizer_options');
