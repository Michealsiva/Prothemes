<?php

if ( ! class_exists( 'Fetch_Pro_Widgets' ) ) {

	class Fetch_Pro_Widgets {

	    /* Inclue All Widget folders */
	    public function Fetch_Pro_get_widgets_folder( $folders ) {
	    	$sow_path = WP_PLUGIN_DIR . '/so-widgets-bundle/widgets/';
			$current_settings = get_option( 'siteorigin_panels_settings', array() );
			/* if( empty($current_settings['widget_bundle_widgets']) ) {
				if( $sow_path === $folders[0] ) {
				   unset($folders[0]);    
			    }   
			} */   
			 
			$folders[] = get_template_directory() . '/pro/widgets/';
			return $folders;
		} 

	    /* Site Origin Widget Bundle Webulous widgets Group & Tab */
		public function Fetch_Pro_add_widgets_group($widgets) {
				$fetch_pro_widgets = array(
				    
				);
				foreach($fetch_pro_widgets as $fetch_pro_widget) {
					if( isset( $widgets[$fetch_pro_widget] ) ) {
						$widgets[$fetch_pro_widget]['groups'] = array('theme');
					}
				} 
				return $widgets;
		}   
    

		public function Fetch_Pro_filter_active_widgets($active){
			$active_widgets = array(
				
			);
			
			foreach ($active_widgets as $value ) {
			   $active[$value] = true;
			} 
		   
		    return $active;
		}   

	}
	
}


