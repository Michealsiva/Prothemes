<?php


/**
 * Integrates this theme with SiteOrigin Page Builder.
 *
 * @package bizplan Pro
 * @since 1.0
 * @license GPL 2.0   
 */
    

/**    
 * Adds default page layouts
 *
 * Adds default page layouts to SiteOrigin Page Builder prebuilt layout section
 *
 * @param $layouts        
 */
if ( ! class_exists('BizPlan_Pro_Prebuilt_Layouts')) { 

    class BizPlan_Pro_Prebuilt_Layouts { 
        public function layouts($layouts) {     
           $layouts['default-home'] = array ( 
				'name' => __('BizPlan Pro Home', 'bizplan_pro'),
				'description' => __('Pre Built Layout for  home page', 'bizplan_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/home.json',

			);

			$layouts['about-us'] = array(
				'name' => __('About Us Page', 'bizplan_pro'),
				'description' => __( 'Pre Built layout for about us page', 'bizplan_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/about-us.json',
			);

			$layouts['contact-us'] = array(
				'name' => __('Contact Us Page', 'bizplan_pro'),
				'description' => __( 'Pre Built layout for contact us page', 'bizplan_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/contact-us.json',
			);

			$layouts['faq'] = array (
				'name' => __('FAQ Page', 'bizplan_pro'),
				'description' => __('Pre Built Layout for faq page', 'bizplan_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/faq.json',
			);
    		return $layouts; 
        }     

    }

}


