<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'BizPlan_Pro_Theme_Less_File' ) ) {  
	class BizPlan_Pro_Theme_Less_File {
    
      /*  public function bizplan_pro_recent_work_less_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/less/file-name.less';  
        } */
		public function bizplan_pro_button_less_file( $filename, $instance, $widget  ) {
        }       
        
	}
}
