<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'BizPlan_Pro_Theme_fields' ) ) {  
	class BizPlan_Pro_Theme_fields {
	
       /* Add Or Override the widegt fields */
        public function bizplan_pro_extend_heading_form($form_options, $widget) {
	          $form_options['divider'] = array(
			  	'type' => 'checkbox',
		        'label' => __( 'Enable Heading Divider', 'bizplan_pro' ),
		        'default' => true  
			  );  
			  $form_options['divider_color'] = array(
			  	'type' => 'color',
		        'label' => __( 'Choose Heading Divider Color', 'bizplan_pro' ),
			  ); 
			  
			  return $form_options; 

        }  

     
	}
}

