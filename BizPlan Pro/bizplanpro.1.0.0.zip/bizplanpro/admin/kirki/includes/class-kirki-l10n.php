<?php
/**
 * Internationalization helper.
 *
 * @package     Kirki
 * @category    Core
 * @author      Aristeides Stathopoulos
 * @copyright   Copyright (c) 2016, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/https://opensource.org/licenses/MIT
 * @since       1.0
 */

if ( ! class_exists( 'Kirki_l10n' ) ) {

	/**
	 * Handles translations
	 */
	class Kirki_l10n {

		/**
		 * The plugin textdomain
		 *
		 * @access protected
		 * @var string
		 */
		protected $textdomain = 'bizplan_pro';

		/**
		 * The class constructor.
		 * Adds actions & filters to handle the rest of the methods.
		 *
		 * @access public
		 */
		public function __construct() {

			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		}

		/**
		 * Load the plugin textdomain
		 *
		 * @access public
		 */
		public function load_textdomain() {

			if ( null !== $this->get_path() ) {
				load_textdomain( $this->textdomain, $this->get_path() );
			}
			load_plugin_textdomain( $this->textdomain, false, Kirki::$path . '/languages' );

		}

		/**
		 * Gets the path to a translation file.
		 *
		 * @access protected
		 * @return string Absolute path to the translation file.
		 */
		protected function get_path() {
			$path_found = false;
			$found_path = null;
			foreach ( $this->get_paths() as $path ) {
				if ( $path_found ) {
					continue;
				}
				$path = wp_normalize_path( $path );
				if ( file_exists( $path ) ) {
					$path_found = true;
					$found_path = $path;
				}
			}

			return $found_path;

		}

		/**
		 * Returns an array of paths where translation files may be located.
		 *
		 * @access protected
		 * @return array
		 */
		protected function get_paths() {

			return array(
				WP_LANG_DIR . '/' . $this->textdomain . '-' . get_locale() . '.mo',
				Kirki::$path . '/languages/' . $this->textdomain . '-' . get_locale() . '.mo',
			);

		}

		/**
		 * Shortcut method to get the translation strings
		 *
		 * @static
		 * @access public
		 * @param string $config_id The config ID. See Kirki_Config.
		 * @return array
		 */
		public static function get_strings( $config_id = 'global' ) {

			$translation_strings = array(
				'background-color'      => esc_attr__( 'Background Color', 'bizplan_pro' ),
				'background-image'      => esc_attr__( 'Background Image', 'bizplan_pro' ),
				'no-repeat'             => esc_attr__( 'No Repeat', 'bizplan_pro' ),
				'repeat-all'            => esc_attr__( 'Repeat All', 'bizplan_pro' ),
				'repeat-x'              => esc_attr__( 'Repeat Horizontally', 'bizplan_pro' ),
				'repeat-y'              => esc_attr__( 'Repeat Vertically', 'bizplan_pro' ),
				'inherit'               => esc_attr__( 'Inherit', 'bizplan_pro' ),
				'background-repeat'     => esc_attr__( 'Background Repeat', 'bizplan_pro' ),
				'cover'                 => esc_attr__( 'Cover', 'bizplan_pro' ),
				'contain'               => esc_attr__( 'Contain', 'bizplan_pro' ),
				'background-size'       => esc_attr__( 'Background Size', 'bizplan_pro' ),
				'fixed'                 => esc_attr__( 'Fixed', 'bizplan_pro' ),
				'scroll'                => esc_attr__( 'Scroll', 'bizplan_pro' ),
				'background-attachment' => esc_attr__( 'Background Attachment', 'bizplan_pro' ),
				'left-top'              => esc_attr__( 'Left Top', 'bizplan_pro' ),
				'left-center'           => esc_attr__( 'Left Center', 'bizplan_pro' ),
				'left-bottom'           => esc_attr__( 'Left Bottom', 'bizplan_pro' ),
				'right-top'             => esc_attr__( 'Right Top', 'bizplan_pro' ),
				'right-center'          => esc_attr__( 'Right Center', 'bizplan_pro' ),
				'right-bottom'          => esc_attr__( 'Right Bottom', 'bizplan_pro' ),
				'center-top'            => esc_attr__( 'Center Top', 'bizplan_pro' ),
				'center-center'         => esc_attr__( 'Center Center', 'bizplan_pro' ),
				'center-bottom'         => esc_attr__( 'Center Bottom', 'bizplan_pro' ),
				'background-position'   => esc_attr__( 'Background Position', 'bizplan_pro' ),
				'background-opacity'    => esc_attr__( 'Background Opacity', 'bizplan_pro' ),
				'on'                    => esc_attr__( 'ON', 'bizplan_pro' ),
				'off'                   => esc_attr__( 'OFF', 'bizplan_pro' ),
				'all'                   => esc_attr__( 'All', 'bizplan_pro' ),
				'cyrillic'              => esc_attr__( 'Cyrillic', 'bizplan_pro' ),
				'cyrillic-ext'          => esc_attr__( 'Cyrillic Extended', 'bizplan_pro' ),
				'devanagari'            => esc_attr__( 'Devanagari', 'bizplan_pro' ),
				'greek'                 => esc_attr__( 'Greek', 'bizplan_pro' ),
				'greek-ext'             => esc_attr__( 'Greek Extended', 'bizplan_pro' ),
				'khmer'                 => esc_attr__( 'Khmer', 'bizplan_pro' ),
				'latin'                 => esc_attr__( 'Latin', 'bizplan_pro' ),
				'latin-ext'             => esc_attr__( 'Latin Extended', 'bizplan_pro' ),
				'vietnamese'            => esc_attr__( 'Vietnamese', 'bizplan_pro' ),
				'hebrew'                => esc_attr__( 'Hebrew', 'bizplan_pro' ),
				'arabic'                => esc_attr__( 'Arabic', 'bizplan_pro' ),
				'bengali'               => esc_attr__( 'Bengali', 'bizplan_pro' ),
				'gujarati'              => esc_attr__( 'Gujarati', 'bizplan_pro' ),
				'tamil'                 => esc_attr__( 'Tamil', 'bizplan_pro' ),
				'telugu'                => esc_attr__( 'Telugu', 'bizplan_pro' ),
				'thai'                  => esc_attr__( 'Thai', 'bizplan_pro' ),
				'serif'                 => _x( 'Serif', 'font style', 'bizplan_pro' ),
				'sans-serif'            => _x( 'Sans Serif', 'font style', 'bizplan_pro' ),
				'monospace'             => _x( 'Monospace', 'font style', 'bizplan_pro' ),
				'font-family'           => esc_attr__( 'Font Family', 'bizplan_pro' ),
				'font-size'             => esc_attr__( 'Font Size', 'bizplan_pro' ),
				'font-weight'           => esc_attr__( 'Font Weight', 'bizplan_pro' ),
				'line-height'           => esc_attr__( 'Line Height', 'bizplan_pro' ),
				'font-style'            => esc_attr__( 'Font Style', 'bizplan_pro' ),
				'letter-spacing'        => esc_attr__( 'Letter Spacing', 'bizplan_pro' ),
				'top'                   => esc_attr__( 'Top', 'bizplan_pro' ),
				'bottom'                => esc_attr__( 'Bottom', 'bizplan_pro' ),
				'left'                  => esc_attr__( 'Left', 'bizplan_pro' ),
				'right'                 => esc_attr__( 'Right', 'bizplan_pro' ),
				'center'                => esc_attr__( 'Center', 'bizplan_pro' ),
				'justify'               => esc_attr__( 'Justify', 'bizplan_pro' ),
				'color'                 => esc_attr__( 'Color', 'bizplan_pro' ),
				'add-image'             => esc_attr__( 'Add Image', 'bizplan_pro' ),
				'change-image'          => esc_attr__( 'Change Image', 'bizplan_pro' ),
				'no-image-selected'     => esc_attr__( 'No Image Selected', 'bizplan_pro' ),
				'add-file'              => esc_attr__( 'Add File', 'bizplan_pro' ),
				'change-file'           => esc_attr__( 'Change File', 'bizplan_pro' ),
				'no-file-selected'      => esc_attr__( 'No File Selected', 'bizplan_pro' ),
				'remove'                => esc_attr__( 'Remove', 'bizplan_pro' ),
				'select-font-family'    => esc_attr__( 'Select a font-family', 'bizplan_pro' ),
				'variant'               => esc_attr__( 'Variant', 'bizplan_pro' ),
				'subsets'               => esc_attr__( 'Subset', 'bizplan_pro' ),
				'size'                  => esc_attr__( 'Size', 'bizplan_pro' ),
				'height'                => esc_attr__( 'Height', 'bizplan_pro' ),
				'spacing'               => esc_attr__( 'Spacing', 'bizplan_pro' ),
				'ultra-light'           => esc_attr__( 'Ultra-Light 100', 'bizplan_pro' ),
				'ultra-light-italic'    => esc_attr__( 'Ultra-Light 100 Italic', 'bizplan_pro' ),
				'light'                 => esc_attr__( 'Light 200', 'bizplan_pro' ),
				'light-italic'          => esc_attr__( 'Light 200 Italic', 'bizplan_pro' ),
				'book'                  => esc_attr__( 'Book 300', 'bizplan_pro' ),
				'book-italic'           => esc_attr__( 'Book 300 Italic', 'bizplan_pro' ),
				'regular'               => esc_attr__( 'Normal 400', 'bizplan_pro' ),
				'italic'                => esc_attr__( 'Normal 400 Italic', 'bizplan_pro' ),
				'medium'                => esc_attr__( 'Medium 500', 'bizplan_pro' ),
				'medium-italic'         => esc_attr__( 'Medium 500 Italic', 'bizplan_pro' ),
				'semi-bold'             => esc_attr__( 'Semi-Bold 600', 'bizplan_pro' ),
				'semi-bold-italic'      => esc_attr__( 'Semi-Bold 600 Italic', 'bizplan_pro' ),
				'bold'                  => esc_attr__( 'Bold 700', 'bizplan_pro' ),
				'bold-italic'           => esc_attr__( 'Bold 700 Italic', 'bizplan_pro' ),
				'extra-bold'            => esc_attr__( 'Extra-Bold 800', 'bizplan_pro' ),
				'extra-bold-italic'     => esc_attr__( 'Extra-Bold 800 Italic', 'bizplan_pro' ),
				'ultra-bold'            => esc_attr__( 'Ultra-Bold 900', 'bizplan_pro' ),
				'ultra-bold-italic'     => esc_attr__( 'Ultra-Bold 900 Italic', 'bizplan_pro' ),
				'invalid-value'         => esc_attr__( 'Invalid Value', 'bizplan_pro' ),
				'add-new'           	=> esc_attr__( 'Add new', 'bizplan_pro' ),
				'row'           		=> esc_attr__( 'row', 'bizplan_pro' ),
				'limit-rows'            => esc_attr__( 'Limit: %s rows', 'bizplan_pro' ),
				'open-section'          => esc_attr__( 'Press return or enter to open this section', 'bizplan_pro' ),
				'back'                  => esc_attr__( 'Back', 'bizplan_pro' ),
				'reset-with-icon'       => sprintf( esc_attr__( '%s Reset', 'bizplan_pro' ), '<span class="dashicons dashicons-image-rotate"></span>' ),
				'text-align'            => esc_attr__( 'Text Align', 'bizplan_pro' ),
				'text-transform'        => esc_attr__( 'Text Transform', 'bizplan_pro' ),
				'none'                  => esc_attr__( 'None', 'bizplan_pro' ),
				'capitalize'            => esc_attr__( 'Capitalize', 'bizplan_pro' ),
				'uppercase'             => esc_attr__( 'Uppercase', 'bizplan_pro' ),
				'lowercase'             => esc_attr__( 'Lowercase', 'bizplan_pro' ),
				'initial'               => esc_attr__( 'Initial', 'bizplan_pro' ),
				'select-page'           => esc_attr__( 'Select a Page', 'bizplan_pro' ),
				'open-editor'           => esc_attr__( 'Open Editor', 'bizplan_pro' ),
				'close-editor'          => esc_attr__( 'Close Editor', 'bizplan_pro' ),
				'switch-editor'         => esc_attr__( 'Switch Editor', 'bizplan_pro' ),
				'hex-value'             => esc_attr__( 'Hex Value', 'bizplan_pro' ),
			);

			// Apply global changes from the kirki/config filter.
			// This is generally to be avoided.
			// It is ONLY provided here for backwards-compatibility reasons.
			// Please use the kirki/{$config_id}/l10n filter instead.
			$config = apply_filters( 'kirki/config', array() );
			if ( isset( $config['i18n'] ) ) {
				$translation_strings = wp_parse_args( $config['i18n'], $translation_strings );
			}

			// Apply l10n changes using the kirki/{$config_id}/l10n filter.
			return apply_filters( 'kirki/' . $config_id . '/l10n', $translation_strings );

		}
	}
}
