<?php 
/*
	Template Name: Blog Full Width
 */
get_header();
get_template_part('breadcrumb'); ?>	
	

	<?php do_action('royal_before_content'); ?>

	<div id="content" class="site-content">
	  <div class="container">

		<div id="primary" class="content-area sixteen columns">

			<main id="main" class="site-main" role="main">

				<?php
					$query_string ="post_type=post&paged=$paged";
					query_posts($query_string);
					$num_of_posts = $wp_query->post_count;
				?>		
					
	<?php if ( have_posts() ) : ?>
	<?php /* Start the Loop */ ?>
	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<div class="entry-content">        
			<?php	$featured_image = get_theme_mod('featured_image',true); 
					$featured_image_size = get_theme_mod ('featured_image_size','1');
			     if( $featured_image ) : ?>    
					<div class="thumb blog-thumb">
						<?php if( $featured_image_size == '1' ) :
								if( has_post_thumbnail() && ! post_password_required() ) :   
									the_post_thumbnail('wbls-royal-blog-full-width'); 
								endif;
							else:
								if( has_post_thumbnail() && ! post_password_required() ) :   
									the_post_thumbnail('wbls-royal-small-featured-image-width');
								endif;
								 
							endif;
						?>
					</div>
				<?php endif; ?>

				<div class="entry-body">
					<header class="entry-header">
						<div class="entry-meta header-entry-meta">
							<a class="box-title" href="<?php the_permalink(); ?>" rel="bookmark"><i class="fa fa-photo"></i></a>
							<?php wbls_royal_post_date(); ?>
						</div><!-- .entry-meta -->								
						<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1>
						<?php if ( get_theme_mod('enable_single_post_top_meta',true ) ): ?>
					    <div class="entry-title-meta">
							<?php if(function_exists('wbls_royal_entry_top_meta') ) {
							     wbls_royal_entry_top_meta();
							} ?>
						</div>
					<?php endif; ?>
						<!--<div class="entry-title-meta">
							<?php wbls_royal_posted_on(); ?>
							<?php wbls_royal_entry_footer(); ?>
						</div>-->
					</header>

					<?php echo '<div class="blog-content blog-content-wrapper">' . get_the_content(__('Readmore','wbls-royal') ) . '</div>'; ?>
					
				<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
				
				<?php if(function_exists('wbls_royal_entry_bottom_meta') ) { ?>
					<footer class="entry-footer"><?php
				        wbls_royal_entry_bottom_meta(); ?>
				    </footer><!-- .entry-footer --><?php
				} ?>
			
			<?php endif;?>				
		</div>


				<?php
					wp_link_pages( array(
						'before' => '<div class="page-links">' . __( 'Pages:', 'wbls-royal' ),
						'after'  => '</div>',
					) );
				?>
			</div><!-- .entry-content -->
			
		</article><!-- #post-## -->
     <?php endwhile; ?>

		<?php 
			if(  get_theme_mod ('numeric_pagination',true) && function_exists( 'wbls_royal_pagination' ) ) : 
					wbls_royal_pagination();   
				else :
					wbls_royal_posts_nav();     
				endif; 
		?>

		<?php else : ?>

			<?php get_template_part( 'content', 'none' ); ?>

		<?php endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->
		
<?php get_footer(); ?>