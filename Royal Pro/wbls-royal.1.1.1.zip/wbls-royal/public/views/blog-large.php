<?php 
/*
	Template Name: Blog Large 
 */
get_header();
get_template_part('breadcrumb'); ?>	

	<div id="content" class="site-content">
		<div class="container">
		
		
		<?php do_action('wbls_royal_two_sidebar_left'); ?>

		<div id="primary" class="content-area <?php wbls_royal_layout_class(); ?> columns">
			<main id="main" class="site-main blog-content" role="main">

				<?php
					$query_string ="post_type=post&paged=$paged";
					query_posts($query_string);
					$num_of_posts = $wp_query->post_count;
				?>		
					
<?php if ( have_posts() ) : ?>
<?php /* Start the Loop */ ?>
	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<div class="entry-content">            
			<?php	$featured_image = get_theme_mod('featured_image',true); 
					$featured_image_size = get_theme_mod ('featured_image_size','1');
			     if( $featured_image ) : ?>    
					<div class="thumb blog-thumb"><?php
						if( function_exists( 'wbls_royal_featured_image' ) ) :
							wbls_royal_featured_image();
						endif; ?>
					</div>
				<?php endif; ?>

				<div class="entry-body">
					<header class="entry-header">
						<div class="entry-meta header-entry-meta">
							<a class="box-title" href="<?php the_permalink(); ?>" rel="bookmark"><i class="fa fa-photo"></i></a>
							<?php wbls_royal_post_date(); ?>
						</div><!-- .entry-meta -->								
						<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1>
						<?php if ( get_theme_mod('enable_single_post_top_meta',true ) ): ?>
					    <div class="entry-title-meta">
							<?php if(function_exists('wbls_royal_entry_top_meta') ) {
							     wbls_royal_entry_top_meta();
							} ?>
						</div>
						<!--<div class="entry-title-meta">
							<?php wbls_royal_posted_on(); ?>
							<?php wbls_royal_entry_footer(); ?>
						</div>-->
					<?php endif; ?>
					</header>

				<?php echo '<div class="blog-content blog-content-wrapper">' . get_the_content(__('Readmore','wbls-royal')) . '</div>'; ?>
			<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
				<?php if(function_exists('wbls_royal_entry_bottom_meta') ) { ?>
					<footer class="entry-footer"><?php
				        wbls_royal_entry_bottom_meta(); ?>
				    </footer><!-- .entry-footer --><?php
				} ?>
			<?php endif;?>				
		</div>

				<?php
					wp_link_pages( array(
						'before' => '<div class="page-links">' . __( 'Pages:', 'wbls-royal' ),
						'after'  => '</div>',
					) );
				?>
			</div><!-- .entry-content -->
			
		</article><!-- #post-## -->
     <?php endwhile; ?>

		<?php 
			if(  get_theme_mod ('numeric_pagination',true) && function_exists( 'wbls_royal_pagination' ) ) : 
					wbls_royal_pagination();
				else :
					wbls_royal_posts_nav();     
				endif; 
		?>

		<?php else : ?>

			<?php get_template_part( 'content', 'none' ); ?>

		<?php endif; 
		wp_reset_query(); ?>

		</main><!-- #main -->
	</div><!-- #primary -->

	<?php do_action('wbls_royal_two_sidebar_right'); ?>


<?php get_footer(); ?>