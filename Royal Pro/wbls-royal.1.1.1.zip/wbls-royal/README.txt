=== Webulous Royal Pro ===
Contributors: webulous
Donate link: https://www.webulousthemes.com/
Tags: comments, spam
Requires at least: 4.0.0
Tested up to: 4.7.3
Stable tag: 1.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin converts free version of Royal theme into pro version.

== Description ==

This plugin converts free version of Royal theme into pro version.


== Installation ==

1. Upload `wbls-royal` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. This is a screen shot 

== Changelog == 

= 1.1.1 =
* Fix Stats Count Warning Error.
* Fix Performance speed issue.
* Woocommerce Gallery issue fixed.

= 1.1.0 =
* Merge Custom css option to WP option
* Parent Link Navigation For Responsive.


= 1.0.9 =
* Added option for recent work widget

= 1.0.8 =
* Fix recent post responsive bug

= 1.0.7 =
* Fix Tracking code bug
* Fix single clock demo content bug
* Compatible with site origin widget bundle  

= 1.0.6 =
* Fix style issue 

= 1.0.5 =
* Customizer Changed to kirki  
* Added More Options

= 1.0.4 =
* Fix Socila Icon Style bug
* Added Animation dropdown list & Padding field options
* Added animation count script

= 1.0.3 =
* Modify the styles 

= 1.0.2 =
* Fix License activation issue

= 1.0.1 =
* Change Update file & Enable License Key Activation 

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.1.1 =
* Fix Stats Count Warning Error.
* Fix Performance speed issue.
* Woocommerce Gallery issue fixed.
