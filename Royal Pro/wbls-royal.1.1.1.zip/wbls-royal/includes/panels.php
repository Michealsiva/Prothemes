<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts
 *
 * @param $layouts
 */
if (!function_exists('webulous_prebuilt_page_layouts') ) {   
function webulous_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-royal'),
    'description' => __('Pre Built Layout for  home page', 'wbls-royal'),
    'widgets' =>  array(
        0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '[headline level="2" type="seperator" align="tcenter"]About Us[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '7e3506dc-3d50-4875-b9f0-6eb7de5fefdf',
              'style' => 
              array (
                'class' => 'slideDown-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'DESIGNING',
            'text' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Integer a fermentum neque eu consequat velit. Integer velit dolor tempor vel venenatis a congue ac mi. Sed neque ipsum, volutpat porttitor eros in fermentum varius eros.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '27fcd39b-eb91-4a8f-8945-da03326fa168',
              'style' => 
              array (
                'class' => 'slideDown-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'PHOTOGRAPHY',
            'text' => ' Fusce maximus urna suscipit feugiat facilisis, diam leo dictum quam a sagittis arcu dui facilisis enim. Nullam tristique augue et sem imperdiet aliquet. Sed a egestas ante Donec ac arcu nec nibh efficitur viverra vel vitae enim.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 2,
              'widget_id' => 'bc9a473d-df6e-4319-b040-70c647aef8a3',
              'style' => 
              array (
                'class' => 'slideDown-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'PRODUCTION',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tincidunt purus justo, at vestibulum metus dapibus nec. In hac habitasse platea dictumst. Proin semper auctor augue, ut cursus mauris iaculis eleifend. Morbi nibh felis, facilisis id dignissim quis.

[button link="" target="_self" color="btn" size="btn-normal"]Know More[/button]
',
            'filter' => 'on',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 3,
              'widget_id' => '1a8dc6ff-437e-48fa-8416-48f0dc86a528',
              'style' => 
              array (
                'class' => 'slideDown-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'src' => 'http://royal.webulous.in/wp-content/uploads/2016/07/Design.png',
                  'href' => 'http://royal.webulous.in/wp-content/uploads/2016/07/Design.png',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Image_Widget',
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'widget_id' => '6f656795-63bc-4bd7-8bb5-048912b7295b',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'src' => 'http://royal.webulous.in/wp-content/uploads/2016/07/Photography.png',
                  'href' => 'http://royal.webulous.in/wp-content/uploads/2016/07/Photography.png',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Image_Widget',
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 1,
                    'widget_id' => '592dd258-a31d-473f-8ba7-e50a0d1dfdb2',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'src' => 'http://royal.webulous.in/wp-content/uploads/2016/07/Prodection.png',
                  'href' => 'http://royal.webulous.in/wp-content/uploads/2016/07/Prodection.png',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Image_Widget',
                    'grid' => 0,
                    'cell' => 1,
                    'id' => 2,
                    'widget_id' => 'e54c3658-e8e0-40d5-bb59-308003641bd1',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 2,
                  'style' => 
                  array (
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 0.5,
                ),
                1 => 
                array (
                  'grid' => 0,
                  'weight' => 0.5,
                ),
              ),
            ),
            'builder_id' => '577ddf30715ec',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'grid' => 1,
              'cell' => 1,
              'id' => 4,
              'widget_id' => '8f706533-14f2-44f3-aa0e-ce8a2dd93567',
              'style' => 
              array (
                'class' => 'slideDown-animation',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '577ddf307156e',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '7c03de1c-8499-4f9c-aacb-50e93c211b4d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '423',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '01548fb6-668a-404d-9ae7-6d07de1a4955',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '422',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '4960fdf1-0f9c-496c-9e81-b4e5ea97425f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '421',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => 'f1c920f9-8c84-4ba3-917e-d1f412a34909',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '420',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'widget_id' => 'ef1f2af8-4512-492b-a0a7-1cb0673b3f45',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577e33dbb0f87',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '9d36ed5a-13ad-4a1f-93f3-1a1e41bfc7e0',
        'style' => 
        array (
          'class' => 'ourservice',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Our Services',
      'text' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Cras hendrerit est lectus eu convallis arcu iaculis viverra. There are many variations of passages of Lorem Ipsum available majority have suffered alteration injected humour.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '9373a110-d562-4785-85b4-cf841f8d7fcb',
        'style' => 
        array (
          'class' => 'our-services pullDown-animation',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Responsive Design',
            'text' => 'Royal is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'right',
            'more' => 'Read More',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'f3fefb6e-a58d-4ebc-8764-edd07ea7df25',
              'style' => 
              array (
                'class' => 'fadeInLeft-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Retina Ready',
            'text' => 'Royal is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
            'icon' => 'fa-magic',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'right',
            'more' => 'Read More',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'd8cf4206-6de7-483b-b54e-ed018347139b',
              'style' => 
              array (
                'class' => 'fadeInLeft-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Awesome Slider',
            'text' => 'Royal includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
            'icon' => 'fa-random',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'right',
            'more' => 'Read More',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 2,
              'widget_id' => 'fd053b6b-1759-4318-a112-f0f4f2e868dc',
              'style' => 
              array (
                'class' => 'fadeInLeft-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'src' => 'http://royal.webulous.in/wp-content/uploads/2016/07/ourclients_03.png',
            'href' => 'http://royal.webulous.in/wp-content/uploads/2016/07/ourclients_03.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 3,
              'widget_id' => '1fba12fb-a6f4-472c-83b1-a501d81c6047',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'SOCIAL MEDIA',
            'text' => 'Want your users to stay in touch? No problem, Royal has Social Media icons all throughout the theme!',
            'icon' => 'fa-skype',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 4,
              'widget_id' => '19568e20-5bb6-4910-b078-6d324f747255',
              'style' => 
              array (
                'class' => 'fadeInRight-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => 'TYPOGRAPHY ',
            'text' => 'Royal loves Typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
            'icon' => 'fa-font',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => 'Read More',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 5,
              'widget_id' => 'ebf42e8e-0fe7-426e-b327-ced9e1b7871b',
              'style' => 
              array (
                'class' => 'fadeInRight-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'title' => 'PAGE BUILDER ',
            'text' => 'Royal supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page Builder visual editor.',
            'icon' => 'fa-plus',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => 'Read More',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 6,
              'widget_id' => 'dfc22415-25ee-4b50-9e49-b13b6efaf09c',
              'style' => 
              array (
                'class' => 'fadeInRight-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '577ddf30717d1',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '346d6f99-fb8c-4a80-8f1a-53d57dec25a6',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Royal Process',
            'text' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Cras hendrerit lectus eu convallis arcu iaculis viverra. There are many variations of passages of  available majority have suffered alteration injected humour.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '03383531-9fd0-4219-9569-69b01fa9df09',
              'style' => 
              array (
                'class' => 'process-top-section stretchLeft-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '<img src="http://royal.webulous.in/wp-content/uploads/2016/07/meetomg.png"/>
[headline level="4" type="normal" align="tcenter"]Meeting[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '8a9c158a-8047-4181-8c7b-7600aaff7cfc',
              'style' => 
              array (
                'class' => 'stretchLeft-animation',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
          2 => 
          array (
            'title' => '',
            'text' => '<img src="http://royal.webulous.in/wp-content/uploads/2016/07/service-design.png" />
[headline level="4" type="normal" align="tcenter"]Design[/headline]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => 'ca6f9e66-98ac-4b60-ade4-eec20c30767d',
              'style' => 
              array (
                'class' => 'stretchLeft-animation',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '',
            'text' => '<img src="http://royal.webulous.in/wp-content/uploads/2016/07/Developements-.png" />
[headline level="4" type="normal" align="tcenter"]Development[/headline]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '1f9d8340-7f18-4032-afc1-33ce1a10656f',
              'style' => 
              array (
                'class' => 'stretchLeft-animation',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '',
            'text' => '<img src="http://royal.webulous.in/wp-content/uploads/2016/07/Final-Work.png" />
[headline level="4" type="normal" align="tcenter"]Final Work[/headline]',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => '2cefacfd-2387-4390-b32d-71f0ff6659c0',
              'style' => 
              array (
                'class' => 'stretchLeft-animation',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577ddf76d65ba',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '11e0a36b-c780-4d3c-9155-cf2a7407c425',
        'style' => 
        array (
          'class' => 'royal-process',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Our Portfolio',
      'text' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Suspendisse lectus turpis pulvinar iaculis dapibus at gravida vel erat. Pellentesque in pulvinar justo Sed vel risus enim Nullam massa nisl cursus ut varius vitae mattis sed neque.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '8357bf8a-101f-4b16-a15a-b17aec8e9ee8',
        'style' => 
        array (
          'class' => 'our-services expandUp-animation',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Recent Work',
      'count' => '9',
      'type' => 'isotope',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Work_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 6,
        'widget_id' => 'fb09c073-4df1-411a-99c3-33634b52f0a0',
        'style' => 
        array (
          'class' => 'txt-center stretchRight-animation',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Testimonials',
      'count' => '4',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '63197bbd-52f2-4ce3-8336-26a85b7e2775',
        'style' => 
        array (
          'class' => 'fadeInUpBig-animation',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Our Team',
      'text' => 'Class aptent taciti sociosq litora torquent per conubia nostra per inceptos himenaeos. Nulla eu neque dolor Praesent maximus lacus sed mauris efficitur sollicitudin. Donec eu fringilla dui vitae ultricies magna. ',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 8,
        'widget_id' => '3373cabc-e416-4c53-be99-c8250ee0fdde',
        'style' => 
        array (
          'class' => 'our-services pullDown-animation',
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex Nam aliquet ultrices porta.',
            'image_url' => 'http://royal.webulous.in/wp-content/uploads/2016/07/four1.png',
            'title' => 'Jessica Lee',
            'designation' => 'Manager',
            'linkedin' => 'www.linkedin.com',
            'google' => 'www.google.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'ae01558c-77b7-40f4-859e-6c1974137f1b',
              'style' => 
              array (
                'class' => 'pullDown-animation',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex Nam aliquet ultrices porta.',
            'image_url' => 'http://royal.webulous.in/wp-content/uploads/2016/07/42.png',
            'title' => 'Louis Johnson ',
            'designation' => 'Designer',
            'linkedin' => 'www.linkedin.com',
            'google' => 'www.google.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'edbcc49c-9fcc-4d68-9096-4dc0ab7d18cc',
              'style' => 
              array (
                'class' => 'pullDown-animation',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex. Nam aliquet ultrices porta.',
            'image_url' => 'http://royal.webulous.in/wp-content/uploads/2016/07/32.png',
            'title' => 'Merry Doe ',
            'designation' => 'Developer',
            'linkedin' => 'www.linkedin.com',
            'google' => 'www.google.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '87fd89ee-3610-4950-91e8-b8468f19b0fb',
              'style' => 
              array (
                'class' => 'pullDown-animation',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex. Nam aliquet ultrices porta.',
            'image_url' => 'http://royal.webulous.in/wp-content/uploads/2016/07/22.png',
            'title' => 'Drake Brown ',
            'designation' => 'Programmer',
            'linkedin' => 'www.linkedin.com',
            'google' => 'www.google.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'widget_id' => 'b4a28dae-b8f3-4643-8e5e-cc9c3a0b62db',
              'style' => 
              array (
                'class' => 'pullDown-animation',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577dfabcea1b2',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 9,
        'widget_id' => 'b8918359-1825-422e-ab52-96d72d723e0e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Clients',
            'text' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'dce25423-fe94-4031-b3aa-8e172f4ef541',
              'style' => 
              array (
                'class' => 'flex-slider-title fadeInUpBig-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'slider' => 'home-clients',
            'type' => 'carousel',
            'panels_info' => 
            array (
              'class' => 'Wbls_FlexSlider_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'd629c181-06fa-4215-bf6c-77f07d4c3451',
              'style' => 
              array (
                'class' => 'fadeInUpBig-animation',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '577e249296ba8',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 10,
        'cell' => 0,
        'id' => 10,
        'widget_id' => '408c2467-e6f5-4273-9a98-3121d62a3fad',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Recent Posts',
      'text' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Cras hendrerit lectus eu convallis arcu iaculis viverra. There are many variations of passages of available majority have suffered alteration injected humour.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 11,
        'widget_id' => '1720f709-b23e-423c-9fcd-1c61065597e0',
        'style' => 
        array (
          'class' => 'our-services fadeInUpBig-animation',
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => '  ',
      'count' => '3',
      'type' => 'normal',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Posts_Widget',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 12,
        'widget_id' => 'b3ec631b-6ee2-4e13-90cc-1694e3872cb9',
        'style' => 
        array (
          'class' => 'fadeInUpBig-animation',
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'aboutus',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'white-pattern',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'animation-row3',
        'background_display' => 'cover',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern animation-row4',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'animation-row5',
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'animation-row6',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern animation-row7',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    9 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'animation-row9',
        'background_display' => 'tile',
      ),
    ),
    10 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern',
        'background_display' => 'tile',
      ),
    ),
    11 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    12 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'animation-row11',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 9,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 10,
      'weight' => 1,
    ),
    11 => 
    array (
      'grid' => 11,
      'weight' => 1,
    ),
    12 => 
    array (
      'grid' => 12,
      'weight' => 1,
    ),
    
    ),

  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-royal'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-royal'),
    'widgets' => array(
            0 => 
    array (
      'title' => 'About Us',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '81f27bc6-65cb-4627-a81f-c872f53a94bb',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'src' => 'http://royal.webulous.in/wp-content/uploads/2016/07/About-Us.png',
      'href' => 'http://royal.webulous.in/wp-content/uploads/2016/07/About-Us.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'grid' => 0,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '8df78b6c-8669-4dd3-bd9c-c0611990c4d4',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Skills',
      'panels_info' => 
      array (
        'class' => 'Wbls_Skill_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 2,
        'widget_id' => '93380d92-715c-4c99-aef5-9ab54c866ca0',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Responsive Layout ',
            'text' => 'Royal is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read More',
            'more_url' => 'www.Webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '03326c2a-2792-44ab-a22e-44e8c43a8705',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Testimonials',
            'text' => ' With our testimonial post type, shortcode and widget, Displaying testimonials is a breeze',
            'icon' => 'fa-rocket',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read More',
            'more_url' => 'www.Webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '30909d2a-3feb-46e3-85ed-2aebd8c6b804',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Awesome Slider',
            'text' => 'Royal includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
            'icon' => 'fa-random',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read More',
            'more_url' => 'http://webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '25b05f33-de54-425c-96b4-a88aacf06b01',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
        ),
      ),
      'builder_id' => '577de10a0f7d6',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 1,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '436bbe92-390a-4b6f-9e95-e77e2d7d9fc6',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Royal Process',
            'text' => 'Class aptent taciti sociosq litora torquent per conubia nostra per inceptos himenaeos. Nulla eu neque dolor Praesent maximus lacus sed mauris efficitur sollicitudin. Donec eu fringilla dui vitae ultricies magna.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '48c19f63-bcbe-4294-9742-9662890de1b3',
              'style' => 
              array (
                'class' => 'process-top-section',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '<img src="http://royal.webulous.in/wp-content/uploads/2016/07/meeting1.png" />
[headline level="4" type="normal" align="tcenter"]Meeting[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'ca46f486-76e8-480c-9cc5-69199a142ce7',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
          2 => 
          array (
            'title' => '',
            'text' => '<img src="http://royal.webulous.in/wp-content/uploads/2016/07/design1.png" />
[headline level="4" type="normal" align="tcenter"]Design[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => 'aa9ad6e2-4dc6-492f-9315-9152bc8326d4',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
          3 => 
          array (
            'title' => '',
            'text' => '<img src="http://royal.webulous.in/wp-content/uploads/2016/07/developing1.png" />
[headline level="4" type="normal" align="tcenter"]Development[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => 'd9714d53-1f52-4d77-94f0-81f75240760d',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
          4 => 
          array (
            'title' => '',
            'text' => '<img src="http://royal.webulous.in/wp-content/uploads/2016/07/final-work1.png" />
[headline level="4" type="normal" align="tcenter"]Final Work[/headline]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => 'c0874b28-224b-4893-b417-31dadc260f2a',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577de10a0f839',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '82caad0c-658e-456b-a19f-45418b56db6b',
        'style' => 
        array (
          'class' => 'royal-process white-bg',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Testimonials',
      'count' => '4',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'widget_id' => 'cb13c590-34e1-4320-91fd-3e5468975f62',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Our Team',
      'text' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Cras hendrerit est lectus eu convallis arcu iaculis viverra. There are many variations of passages of Lorem Ipsum available majority have suffered alteration injected humour.',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 4,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '133e39b6-6d6f-43a4-8a02-de6cc68a2774',
        'style' => 
        array (
          'class' => 'our-services',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    7 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex Nam aliquet ultrices porta.',
            'image_url' => 'http://royal.webulous.in/wp-content/uploads/2016/07/four1.png',
            'title' => 'Jessica Lee',
            'designation' => 'Manager',
            'linkedin' => 'https://www.webulousthemes.com/',
            'google' => 'http://www.googleplus.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'e643abcd-46e9-47d8-a21c-6c93d63a4cd5',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex Nam aliquet ultrices porta.',
            'image_url' => 'http://royal.webulous.in/wp-content/uploads/2016/07/42.png',
            'title' => 'Louis Johnson',
            'designation' => 'Designer',
            'linkedin' => 'https://www.webulousthemes.com/',
            'google' => 'http://www.googleplus.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'e3f313ee-d083-4e53-b53e-fa1ec3899f6b',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex Nam aliquet ultrices porta.',
            'image_url' => 'http://royal.webulous.in/wp-content/uploads/2016/07/32.png',
            'title' => 'Merry Doe',
            'designation' => 'Developer',
            'linkedin' => 'https://www.webulousthemes.com/',
            'google' => 'http://www.googleplus.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '37bc1195-ca05-44f1-b95a-5940b65bc8f9',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex Nam aliquet ultrices porta.',
            'image_url' => 'http://royal.webulous.in/wp-content/uploads/2016/07/22.png',
            'title' => 'Drake Brown',
            'designation' => 'Programmer',
            'linkedin' => 'https://www.webulousthemes.com/',
            'google' => 'http://www.googleplus.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'widget_id' => '44da49f4-df51-4dce-be5e-5286002709f3',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577de10a0f9ed',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 5,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '0135c100-9cba-40a0-a974-859e9580329b',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Morbi viverra tempus ullamcorpe. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 8,
        'widget_id' => '2bfd6760-1bcb-4551-ab01-b8c0bfbe6eba',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'white-pattern',
        'background_display' => 'cover',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.5,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.5,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
        ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'wbls-royal'),
      'description' => __( 'Pre Built layout for features page', 'wbls-royal'),
      'widgets' => array(
      0 => 
    array (
      'type' => 'circle',
      'title' => 'Responsive Layout',
      'text' => 'Royal is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'type' => 'circle',
      'title' => 'Typography',
      'text' => 'Royal loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
      'icon' => 'fa-font',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'type' => 'circle',
      'title' => 'Awesome Slider',
      'text' => 'Royal includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'type' => 'circle',
      'title' => 'Retina Ready',
      'text' => 'Royal is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => 'lg',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'type' => 'circle',
      'title' => 'Font Awesome',
      'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => 'lg',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 4,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'type' => 'circle',
      'title' => 'Excellent Support',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
      'icon' => 'fa-beer',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 5,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 6,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'type' => 'circle',
      'title' => 'Customization',
      'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
      'icon' => 'fa-cog',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 7,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'type' => 'circle',
      'title' => 'Custom Widget',
      'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
      'icon' => 'fa-beer',
      'icon_background_color' => '',
      'icon_size' => 'lg',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 8,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'type' => 'circle',
      'title' => 'Page Builder',
      'text' => 'Royal supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 9,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'type' => 'circle',
      'title' => 'Shortcode Builder',
      'text' => 'Royal includes lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
      'icon' => 'fa-check',
      'icon_background_color' => '',
      'icon_size' => 'lg',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 10,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'type' => 'circle',
      'title' => 'Page Layout',
      'text' => 'Royal offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy (alias)',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 11,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'type' => 'circle',
      'title' => 'Demo Content',
      'text' => 'Royal includes demo content files. You can quickly setup the site like our demo and get started easily!',
      'icon' => 'fa-close',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 12,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 13,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'type' => 'circle',
      'title' => 'Woo Commerce',
      'text' => 'Royal has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!',
      'icon' => 'fa-shopping-cart',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'grid' => 4,
        'cell' => 0,
        'id' => 14,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
    15 => 
    array (
      'type' => 'circle',
      'title' => 'Google Map',
      'text' => 'Royal includes Google Map as shortcode and widget. So, you can use it anywhere in your site!',
      'icon' => 'fa-map-marker',
      'icon_background_color' => '',
      'icon_size' => 'lg',
      'more' => '',
      'more_url' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'grid' => 4,
        'cell' => 0,
        'id' => 15,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
    16 => 
    array (
      'type' => 'circle',
      'title' => 'Testimonials',
      'text' => 'With our testimonial post type, shortcode and widget, Displaying testimonials is a breeze.',
      'icon' => 'fa-rocket',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'grid' => 4,
        'cell' => 1,
        'id' => 16,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
    17 => 
    array (
      'type' => 'circle',
      'title' => 'Multiple Portfolio',
      'text' => '7 portfolio layouts, 3 blog layouts and multiple other alternate layouts for interior pages!',
      'icon' => 'fa-columns',
      'icon_background_color' => '',
      'icon_size' => 'lg',
      'more' => '',
      'more_url' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'grid' => 4,
        'cell' => 1,
        'id' => 17,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
    18 => 
    array (
      'type' => 'circle',
      'title' => 'Social Media',
      'text' => 'Want your users to stay in touch? No problem, Royal has Social Media icons all throughout the theme!',
      'icon' => 'fa-skype',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'grid' => 4,
        'cell' => 2,
        'id' => 18,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
    19 => 
    array (
      'type' => 'circle',
      'title' => 'Multiple Sidebar',
      'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
      'icon' => 'fa-copy',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'grid' => 4,
        'cell' => 2,
        'id' => 19,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    9 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    10 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-royal'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-royal'),
      'widgets' => array(
        0 => 
    array (
      'title' => '',
      'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387145.86626889417!2d-74.2581879779189!3d40.70531105474913!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sin!4v1454914074669" width="1200" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '11ce9666-58a7-4e85-81a5-e76fb05fcf9d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Send a Message',
            'text' => 'Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. 
[contact-form-7 id="4" title="Contact form 1"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '8e1e1388-42c1-4f7e-a9fe-68688ea185ba',
              'style' => 
              array (
                'class' => 'cnt-form',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Contact Us',
            'text' => 'Fusce commodo ultricies volutpat. Vivamus quis nulla porta faucibus metus eu, tempus dolor. Ut sed faucibus mi ac volutpat lectus. ',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'db592b31-73e7-4f0c-8590-da6304d3df02',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'src' => 'http://royal.webulous.in/wp-content/uploads/2016/07/contact-us-1.png',
                  'href' => 'http://royal.webulous.in/wp-content/uploads/2016/07/contact-us-1.png',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Image_Widget',
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'widget_id' => '8bb520c0-c835-4ba6-ba12-f5c885230acc',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'animation_class' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                      'link_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'Address',
                  'text' => '[icon icon="fa-map-marker" size="" style=""]
430 Main Ave Norwalk,CT',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 1,
                    'id' => 1,
                    'widget_id' => '9bf4d49a-9473-46f8-8859-910df152507a',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'title' => 'Phone Numbers',
                  'text' => '[icon icon="fa-phone" size="" style=""]
(012)-345-6789 - (012)-345-6789',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 1,
                    'id' => 2,
                    'widget_id' => 'b51db8ad-9725-4987-96a4-a2cada107990',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                3 => 
                array (
                  'title' => 'Email',
                  'text' => '[icon icon="fa-envelope" size="" style=""]
information@domain.com',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 1,
                    'id' => 3,
                    'widget_id' => 'ce2c4846-78eb-4fc7-b7ed-0a3a78123aa7',
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 2,
                  'style' => 
                  array (
                    'class' => '',
                    'cell_class' => '',
                    'row_css' => '',
                    'background_image' => '',
                    'bottom_border' => '',
                    'background' => '',
                    'top_border' => '',
                    'bottom_margin' => '',
                    'gutter' => '',
                    'padding' => '',
                    'row_stretch' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 0.5,
                ),
                1 => 
                array (
                  'grid' => 0,
                  'weight' => 0.5,
                ),
              ),
            ),
            'builder_id' => '577de226b7918',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'grid' => 0,
              'cell' => 1,
              'id' => 2,
              'widget_id' => 'b6da290b-b2b9-4ffd-b5d9-536a868bb57a',
              'style' => 
              array (
                'class' => 'cnt-address',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '577de226b78ca',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'ebb8f970-8faf-4059-bc6b-f704c8d85391',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '69133231-c757-4b90-97d5-aa36d887432d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-royal'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-royal'),
    'widgets' =>  array(
          0 => 
    array (
      'title' => '',
      'text' => '[toggle title="Vivamus semper tincidunt tincidunt." open="0"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title=" Donec facilisis fringilla faucibus. " open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.[/toggle][gap height="20"]

[toggle title=" Fusce ultricies sapien libero pharetra." open="0"]Vivamus semper tincidunt tincidunt. Nunc ultrices est massa, id laoreet mauris eleifend eu. Donec dictum felis mauris, quis vestibulum risus tempus id. Nulla vulputate vehicula dui, non faucibus lorem congue sit amet.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="Maecenas ut pretium mauris." open="0"]Nam quis interdum nulla. Donec porttitor nibh est, eu tempus nisi pellentesque ac. Maecenas ut pretium mauris. Quisque nunc justo, placerat non luctus euismod, placerat sit amet ex. Nunc molestie nisl ac molestie ultricies.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="Quisque  placerat luctus euismod." open="0"]Aenean convallis ipsum felis, eu commodo nulla vestibulum a. Praesent rhoncus elit sed libero mollis, quis ullamcorper risus mattis. Morbi rutrum nunc nec nisl porta malesuada. Suspendisse vel diam mattis, gravida sapien non, bibendum leo.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leoNunc sit amet justo lectus. Curabitur vel ipsum ac nisi malesuada pellentesque. Aenean aliquet tempus eros et volutpat. Aliquam non tincidunt erat. Vivamus sit amet massa sem. Nulla nec risus eget elit iaculis lobortis fringilla ac lorem. Fusce scelerisque id ipsum ac pulvinar.[/toggle][gap height="20"]

[toggle title="Curabitur ac egestas dolor  dapibus ." open="0"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title=" Aliquam non tincidunt erat. " open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.[/toggle][gap height="20"]

[toggle title=" Sed varius tincidunt metus eu aliquam.  " open="0"]Sed varius tincidunt metus eu aliquam. Sed sollicitudin lectus at nibh faucibus, eu sagittis enim consequat. In hac habitasse platea dictumst. In blandit viverra elit, commodo porttitor augue pharetra semper. Nulla finibus est nunc, sed porta turpis vehicula at. Aliquam blandit malesuada euismod.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.[/toggle][gap height="20"]
',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-royal'),
    'description' => __('Pre Built Layout for services page', 'wbls-royal'),
    'widgets' =>  array(
      0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'src' => 'http://royal.webulous.in/wp-content/uploads/2016/07/who-we-are.png',
            'href' => 'http://royal.webulous.in/wp-content/uploads/2016/07/who-we-are.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'af567a16-26d0-41f7-bcd6-a6b990e4a668',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Who We Are',
            'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever when an unknown printer took a galley of type and scrambled it to make a type specimen book. ',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '3647a522-91d6-4c40-b37e-e894f7c67d4b',
              'style' => 
              array (
                'class' => 'whyus',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'src' => 'http://royal.webulous.in/wp-content/uploads/2016/07/mission-vision.png',
            'href' => 'http://royal.webulous.in/wp-content/uploads/2016/07/mission-vision.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '0821be84-68c2-4b51-893a-896c51efb236',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Mission & Vision',
            'text' => 'There are many variations of passages of Lorem Ipsum available but the majority have suffered alteration in some form, by injected humour words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 3,
              'widget_id' => '69666d99-58ef-4426-8f2c-c08fe8bce829',
              'style' => 
              array (
                'class' => 'whyus',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'src' => 'http://royal.webulous.in/wp-content/uploads/2016/07/support.png',
            'href' => 'http://royal.webulous.in/wp-content/uploads/2016/07/support.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 2,
              'id' => 4,
              'widget_id' => '5f270ba1-078b-4985-a1d9-e94c8166f0c7',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => 'Our Support',
            'text' => ' All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over Latin words combined with a handful of model sentence structures.  ',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 5,
              'widget_id' => '4aecb2be-d0f9-4d0d-98cb-ca47ed37ca2f',
              'style' => 
              array (
                'class' => 'whyus',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
        ),
      ),
      'builder_id' => '577de1ee4b70f',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '110d8721-9df8-46f6-9d24-b7612cdaf96d',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '313c16bd-7be5-4e29-beb1-8f9541e20503',
        'style' => 
        array (
          'class' => 'content-center2',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Core Features',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. ',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '06a7a462-715f-4793-8fa7-b3850524b904',
        'style' => 
        array (
          'class' => 'process-top-section',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Custom Widget',
            'text' => 'Royal We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
            'icon' => 'fa-beer',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'right',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '54321724-5bcb-453d-b457-701dac5ea48b',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Woo Commerce',
            'text' => 'Royal has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!.',
            'icon' => 'fa-shopping-cart',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'right',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'da58aa86-e280-47ec-a575-f5e24529d042',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Shortcode Builder',
            'text' => 'Royal inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!.',
            'icon' => 'fa-check',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'right',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 2,
              'widget_id' => '93c7878b-a75c-405e-a4c1-847a31cce1d5',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'src' => 'http://royal.webulous.in/wp-content/uploads/2016/07/mobile_13.png',
            'href' => 'http://royal.webulous.in/wp-content/uploads/2016/07/mobile_13.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 3,
              'widget_id' => '9d1aca08-5bd2-42b7-9527-8236f933f1f7',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Social Media',
            'text' => 'Want your users to stay in touch? No problem, Royal has Social Media icons all throughout the theme!',
            'icon' => 'fa-skype',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 4,
              'widget_id' => '542b95ed-6d2f-416b-8965-9acff2111be4',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => 'Demo Content  ',
            'text' => 'Royal includes demo content files. You can quickly setup the site like our demo and get started easily!.',
            'icon' => 'fa-times',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 5,
              'widget_id' => '2d2958bb-1397-479c-ba6c-501ed947b1a6',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'title' => 'Page Layout',
            'text' => 'Royal offers many different page layouts so you can quickly and easily create your pages with no hassle!',
            'icon' => 'fa-copy (alias)',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 6,
              'widget_id' => 'e24d0238-9507-4565-b2ce-8d9214dc358f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
        ),
      ),
      'builder_id' => '577de1ee4b82d',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '8d6b077c-9f5f-4081-b1cd-20bf3adf8912',
        'style' => 
        array (
          'background_image_attachment' => 194,
          'background_display' => 'center',
        ),
      ),
    ),
    4 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Lorem Ipsum is simply dummy text ',
            'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.

 It was popularised in the 1960s  and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
[button link="" target="_self" color="btn-inverse" size="btn-normal"]FEATURES[/button]  [button link="" target="_self" color="btn-inverse" size="btn-normal"]STARTED[/button]
',
            'filter' => 'on',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '8714d0f7-5a1a-472b-99f4-9bb35e18545c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://royal.webulous.in/wp-content/uploads/2016/07/service.png',
            'href' => 'http://royal.webulous.in/wp-content/uploads/2016/07/service.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '91557560-7f6d-4faa-afb7-f2273e23b7c7',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => 'wide-pattern features',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '577de1ee4b8b7',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 4,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '62e28538-887e-48e7-b798-63b3adb827d1',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Why Choose Us',
            'text' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '712e5335-286c-4759-a233-88311c698a2c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Best Features',
            'text' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'd77467ae-cda4-4ae8-bc25-944cbab5f627',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => '[tabs_group type="normal"][tabs title="Responsive"]Nulla pulvinar tempus nisl, at elementum arcu lacinia eu. Aliquam erat volutpat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla pulvinar tempus nisl, at elementum arcu lacinia eu. Aliquam erat volutpat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.Nulla pulvinar tempus nisl, at elementum arcu lacinia eu. Aliquam erat volutpat. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. [/tabs][tabs title="Retina Ready"]Proin malesuada metus id consectetur mattis. Quisque faucibus nec augue sit amet aliquam. Phasellus vel egestas ipsum, vitae laoreet ipsum. Maecenas eget metus gravida, ultrices ligula in, molestie tellus. Proin malesuada metus id consectetur mattis. Quisque faucibus nec augue sit amet aliquam. Phasellus vel egestas ipsum, vitae laoreet ipsum. Maecenas eget metus gravida, ultrices ligula in, molestie tellus. Quisque faucibus nec augue sit amet aliquam. Phasellus vel egestas ipsum, vitae laoreet ipsum. Maecenas eget metus gravida, ultrices ligula in, molestie tellus.[/tabs][tabs title="Features"]Sed vitae orci at risus faucibus dapibus id vel est. Maecenas aliquet ac arcu quis laoreet. Proin porta velit id nisi placerat dapibus. Morbi eleifend libero diam, a tincidunt turpis laoreet in Proin malesuada metus id consectetur mattis. Quisque faucibus nec augue sit amet aliquam. Phasellus vel egestas ipsum, vitae laoreet ipsum. Maecenas eget metus gravida, ultrices ligula in, molestie tellus. Morbi eleifend libero diam, a tincidunt turpis laoreet in Proin malesuada metus id consectetur mattis. Quisque faucibus nec augue sit amet aliquam. Phasellus vel egestas ipsum, vitae laoreet ipsum. Maecenas eget metus gravida, ultrices ligula in, molestie tellus.[/tabs][/tabs_group]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 2,
              'widget_id' => '0a0cac64-5a0c-408c-9721-c058b0fd64ee',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '',
            'text' => '[accordion_group][accordion title="Theme Options"]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. Cras venenatis a nibh ut placerat. Vivamus a mauris non quam pretium lobortis non ac odio. [/accordion][accordion title="Great Support"] Sed nec massa lorem. Phasellus ut tincidunt velit, id scelerisque lorem. Nullam nisl tortor, mollis ut massa in, dapibus tincidunt libero. Pellentesque pretium posuere turpis eget dignissim. Curabitur sapien lorem, feugiat et velit et, vehicula aliquet urna. Vivamus pellentesque lorem at urna suscipit, at vulputate est ultricies. Aliquam ultrices nec massa sed adipiscing.[/accordion][accordion title="Awesome Design"]Pellentesque feugiat sodales tellus. Ut tempus aliquam felis, quis consequat nunc hendrerit eget. Praesent sollicitudin nunc eu sollicitudin placerat. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][/accordion_group]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 3,
              'widget_id' => 'a26039d0-548a-4dd4-ba88-698c4ae9d6a8',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '577de1ee4b91e',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 5,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '89fd801b-ec0a-4d49-8da8-642776d06945',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 6,
        'widget_id' => 'befebde7-7c73-46bf-aaf8-ca6cf4c9f5fb',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern',
        'background_display' => 'cover',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'royal-process white-bg',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_attachment' => 194,
        'background_display' => 'center',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'webulous_prebuilt_page_layouts');

function wbls_royal_panels_row_style_fields($fields) {  

    $royal_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-royal'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-royal' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-royal' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-royal' ),
        'bounce-animation' => __('bounce-animation','wbls-royal' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-royal' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-royal' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-royal' ),
        'expandUp-animation' => __('expandUp-animation','wbls-royal' ),
        'fade-animation' => __('fade-animation','wbls-royal' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-royal' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-royal' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-royal' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-royal' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-royal' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-royal' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-royal' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-royal' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-royal' ),
        'flip-animation' => __('flip-animation','wbls-royal' ),
        'flipInX-animation' => __('flipInX-animation','wbls-royal' ),
        'flipInY-animation' => __('flipInY-animation','wbls-royal' ),
        'floating-animation' => __('floating-animation','wbls-royal' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-royal' ),
        'hatch-animation' => __('hatch-animation','wbls-royal' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-royal' ),
        'puffIn-animation' => __('puffIn-animation','wbls-royal' ),
        'pullDown-animation' => __('pullDown-animation','wbls-royal' ),
        'pullUp-animation' => __('pullUp-animation','wbls-royal' ),
        'pulse-animation' => __('pulse-animation','wbls-royal' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-royal' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-royal' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-royal' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-royal' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-royal' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-royal' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-royal' ),
        'scale-down-animation' => __('scale-down-animation','wbls-royal' ),
        'scale-up-animation' => __('scale-up-animation','wbls-royal' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-royal' ),
        'slide-left-animation' => __('slide-left-animation','wbls-royal' ),
        'slide-right-animation' => __('slide-right-animation','wbls-royal' ),
        'slide-top-animation' => __('slide-top-animation','wbls-royal' ),
        'slideDown-animation' => __('slideDown-animation','wbls-royal' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-royal' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-royal' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-royal' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-royal' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-royal' ),
        'slideRight-animation' => __('slideRight-animation','wbls-royal' ),
        'slideUp-animation' => __('slideUp-animation','wbls-royal' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-royal' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-royal' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-royal' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-royal' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-royal' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-royal' ),
        'swap-animation'  => __('swap-animation','wbls-royal' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-royal' ),
        'swing-animation'  => __('swing-animation','wbls-royal' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-royal' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-royal' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-royal' ), 
        'tossing-animation'  => __('tossing-animation','wbls-royal' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-royal' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-royal' ), 
        'wobble-animation' => __('wobble-animation','wbls-royal' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-royal' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'royal'),
            'type' => 'select',
            'options' => $royal_animation_name,
    );


    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_royal_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_royal_panels_row_style_fields');

function wbls_royal_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Animation', 'wbls-royal'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_royal_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_royal_row_style_groups' );