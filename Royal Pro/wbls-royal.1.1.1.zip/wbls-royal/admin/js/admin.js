(function( $ ) {

	$(function() {

		docs = $('<a class="royal-docs doc"></a>')
			.attr('href','https://www.webulousthemes.com/royal-pro/') 
			.attr('target','_blank')
			.text('Documentation');

		support = $('<a class="royal-docs question"></a>')
			.attr('href','https://www.webulousthemes.com/support-ticket/')
			.attr('target','_blank')
			.text('Ask a Question');

		$('#customize-info .preview-notice').append(docs);
		$('#customize-info .preview-notice').append(support);

		$('.royal-docs').on('click',function(e){
			e.stopPropagation();
		});
		
		
	});

})( jQuery );