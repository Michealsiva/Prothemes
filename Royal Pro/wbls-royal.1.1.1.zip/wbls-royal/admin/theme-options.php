<?php
/**
 * Pro customizer options     
 */

add_action('wbls-royal_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() { 

Royal_Kirki::add_panel( 'pro_panel', array(   
	'title'       => __( 'Pro Options', 'wbls-royal' ),  
	'description' => __( 'Pro Options', 'wbls-royal' ),         
   ) );     

// pro home page section 

		Royal_Kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-royal' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-royal'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) );

		Royal_Kirki::add_field( 'royal', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-royal' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch',
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
				'off' => esc_attr__( 'Disable', 'wbls-royal' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-royal'),
			'default'  => 'off',
		) );
		Royal_Kirki::add_field( 'royal', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-royal' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-royal'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-royal'),
		) );

//W3Cache Option
		Royal_Kirki::add_section( 'cache_section', array(
			'title'          => __( 'Miscellaneous Settings','wbls-royal' ),
		) );

		Royal_Kirki::add_field( 'royal', array(
			'settings' => 'total-cache',
			'label'    => __( 'Enable to remove query strings from static resource', 'wbls-royal' ),
			'section'  => 'cache_section',
			'type'     => 'switch',
			'description'    => __( 'Enable this option for remove the Query String and Increase your site performance load Time', 'wbls-royal'),
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
				'off' => esc_attr__( 'Disable', 'wbls-royal' )
			),
			'default'  => 'off',
		) );


//  animation section 

Royal_Kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-royal' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-royal'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Royal_Kirki::add_field( 'royal', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-royal' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Royal_Kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-royal' ),
	'description'    => __( 'Custom JS', 'wbls-royal'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Royal_Kirki::add_field( 'royal', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-royal' ),
	'section'  => 'custom_js_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
) ); 


// Tracking section 

Royal_Kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-royal' ),
	'description'    => __( 'Tracking Code', 'wbls-royal'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'analytics',
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-royal' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-royal' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'2' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-royal'),
) );

// color scheme section 

Royal_Kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-royal' ),
	'description'    => __( 'Select your color scheme', 'wbls-royal'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Royal_Kirki::add_field( 'royal', array(
	'settings' => 'color_scheme',
	'label'    => __( 'Select your color scheme', 'wbls-royal' ),
	'section'  => 'multiple_color_section',
	'type'     => 'palette',
	'choices'     => array(
    '1' => array(
		'#5f015b',
	),
	'2' => array(
		'#5761e7',
	),
	'3' => array(
		'#137b7a',
	),
	'4' => array(
		'#1ec851',
	),
	'5' => array(
		'#ff7e20',
	),
	'6' => array(
		'#de3c2f',
	),
	
),
'default' => '1',
//'default'  => 'on',
) );

//Social Network URL Section
Royal_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-royal' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-royal'),
	'panel'			 => 'social_panel',
) );

Royal_Kirki::add_field( 'royal', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-royal'),
) );


// flexslider section //

Royal_Kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-royal' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-royal'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-royal' ),
		'2' => esc_attr__( 'Slide', 'wbls-royal' )
	),
	'default'  => '2',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-royal' ),
		'2' => esc_attr__( 'Vertical', 'wbls-royal' )
	),
	'default'  => '1',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => 'on',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => 'on',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => 'on',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => 'on',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => 'off',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => 'off',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => 'off',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'off' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-royal' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Royal_Kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-royal' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-royal'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-royal' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'2' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => '2',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-royal' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-royal' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-royal' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'2' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => '2',
) );
//Social Network URL Section
Royal_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-royal' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-royal'),
	'panel'			 => 'social_panel',
) );

Royal_Kirki::add_field( 'royal', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-royal' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-royal'),
) );

//  portfolio settings //

Royal_Kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-royal' ),
	'priority'  =>10,
) );

$post_per_page = get_option('posts_per_page');
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-royal' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-royal' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-royal' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-royal' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-royal'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-royal' ),
		2 => __( 'Show Without "All"', 'wbls-royal' ),
		3 => __( 'Hide', 'wbls-royal' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Royal_Kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-royal' ),
	'description'    => __( 'Light Box Settings', 'wbls-royal'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-royal' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-royal' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-royal' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-royal' ),
		'4' => esc_attr__( 'light-square', 'wbls-royal' ),
		'5' => esc_attr__( 'dark-square', 'wbls-royal' ),
		'6' => esc_attr__( 'facebook', 'wbls-royal' ),
	),
	'default'  => '1',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-royal' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-royal' ),
		'slow' => esc_attr__( 'Slow', 'wbls-royal' ),
		'normal' => esc_attr__( 'Normal', 'wbls-royal' ),
	),
	'default'  => 'fast',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-royal' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-royal' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'2' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => '2',
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-royal' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-royal'),
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-royal' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-royal' ),
		'2' => esc_attr__( 'Disable', 'wbls-royal' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Royal_Kirki::add_field( 'royal', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-royal' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#830b7e',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'input[type="text"]:focus,.toggle .toggle-content,.wide-stats .circle-icon-box:hover .icon-wrapper,
				input[type="email"]:focus,.ui-accordion .ui-accordion-content,.widget_image-box-widget .image-box img,
				input[type="url"]:focus,.dropcap-box,.toggle .toggle-title,.circle-icon-box .icon-wrapper,
				input[type="password"]:focus,.ui-accordion h3,.circle-icon-box:hover .icon-wrapper,.widget_image-box-widget a.more-button:hover,
				input[type="search"]:focus,.home .post-wrapper .latest-post:hover h4,.cnt-form .wpcf7-form input[type="text"]:focus,
				.cnt-form .wpcf7-form input[type="email"]:focus,.sidebar .dropcap-book,
				.cnt-form .wpcf7-form input[type="tel"]:focus,
				.cnt-form .wpcf7-form input[type="url"]:focus,
				.cnt-form .wpcf7-form input[type="password"]:focus,
				.cnt-form .wpcf7-form input[type="number"]:focus,
				.cnt-form .wpcf7-form textarea:focus,
				textarea:focus,ol.comment-list li.byuser article,.home .post-wrapper .latest-post:hover ',
			'property' => 'border-color',
		),
		array(
			'element'  => 'blockquote',
			'property' => 'border-left-color',
		),
		array(
			'element'  => ' blockquote',
			'property' => 'border-right-color',
		),
		array(
			'element'  => '
				.header-wrap .social ul li a:hover:after,.widget_flexslider-widget .flexcarousel .flex-direction-nav a:hover:after,ol.webulous_page_navi li a:after, ol.webulous_page_navi li.bpn-current:after, .widget.widget_ourteam-widget ul.team-social li a:after, .widget.widget_ourteam-widget .team-avator:after, .widget_recent-work-widget .recent_work_overlay .icon-link:after, .widget_recent-work-widget ul.flex-direction-nav a:after, .widget_recent-work-widget .portfolio3col .overlay_icon a:after, .portfolioeffects .portfolio_link_icons a:after, .widget_flexslider-widget .flexcarousel .flex-direction-nav a:after, .alert-message:after,
				.widget_button-widget .btn:after,.widget_testimonial-widget ul.flex-direction-nav li a:after, .entry-header .header-entry-meta:after,
				.entry-body .header-entry-meta:after,.widget_social-networks-widget ul li a:after,.icon-right .fa-stack:after,
				.icon-left .fa-stack:after,#filters ul.filter-options li a:hover::after, #filters ul.filter-options li a.selected::after,
				.share-box ul li a:after,#filters ul.filter-options li a:hover:after,
				#filters ul.filter-options li a.selected:after,.widget.widget_ourteam-widget .team-avator:after,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a:after,
				.tabs-container ul.ui-tabs-nav li a:hover:after,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a:after,.widget_recent-work-widget .portfolio3col:hover .overlay_icon a.icon-zoom:hover:after,.widget.widget_ourteam-widget .team-avatar::after, .our-team .team-avatar::after',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '#filters ul.filter-options li a:hover, #filters ul.filter-options li a.selected',
			'property' => 'border-bottom-color',
		),
		array(
			'element'  => '.dropcap,.pullleft:before,.related-posts ul#webulous-related-posts li a:hover,.toggle .toggle-title:hover,.circle-icon-box .icon-wrapper p.fa-stack i,
				.pullright:before,a:visited,.cnt-address .widget_text .fa,.pullnone:before,#filters ul.filter-options li a:hover,.widget_recent-posts-gallery-widget .recent-post .entry-author a:hover,
				#filters ul.filter-options li a.selected,.widget.widget_ourteam-widget:hover .team-content h4,.ui-accordion h3:hover span.ui-icon.fa,
				.page-links,.entry-header .entry-title-meta span:hover,.entry-header .entry-title-meta a:hover,
				.entry-body .entry-title-meta a:hover,.single footer.entry-meta a:hover,.site-footer .widget_list-widget ul li i,
				.entry-body .entry-title-meta span:hover,.site-footer .callout-widget .call-btn a,.sidebar ul li a:hover,#secondary .widget_rss a,.widget_tag_cloud a,
				.footer-top ul li a:hover,.sidebar .icon-horizontal .icon-title,.sidebar .widget_list-widget ul li i,#secondary.sidebar .widget.widget_ourteam-widget .team-content p,
				#secondary.sidebar .widget.widget_ourteam-widget .team-content h4 span,#secondary .btn-white:hover,
				#secondary .widget_button-widget .btn.white:hover,
				.sidebar .icon-vertical .icon-title,.sidebar .dropcap,.content-area .widget_list-widget ul li i, .content-area .widget_list-widget ol li i..widget_calendar table th a, .widget_calendar table td a,.site-footer .footer-top a:hover,
				.page-links a:hover,.home .post-wrapper .latest-post:hover h4,.portfolioeffects:hover .content-details p a:hover,
				.portfolioeffects:hover .content-details h3 a:hover,.widget_testimonial-widget ul.flex-direction-nav li a:hover,.widget_testimonial-widget ul li .client,
				.hentry.sticky h1.entry-title a:hover,.hentry.sticky a:hover,.hentry.post h1 a:hover,.comment-metadata a:hover,ol.comment-list .reply a:hover:before,.header-wrap .contact a:hover,a.more-link:hover,.site-main .comment-navigation a,.site-header #search .search-box:hover i',
			'property' => 'color',
		),
		/*array(
			'element'  => 'th a,
							.site-header .social .recentcomments a,
							.header-wrap .site-header .social .recentcomments a,
							.left-sidebar .recentcomments a,
							.left-sidebar .widget_rss a,
							.ei-title h3,
							#secondary .btn-white:hover,
			  				#secondary .widget_button-widget .btn.white:hover',
			'property' => 'color',
			'suffix' => '!important',
		),*/
		array(
			'element'  => 'input[type="button"],.widget_testimonial-widget h3:after, .our-services .textwidget:after, .flex-slider-title h3.widget-title:after,.icon-right .fa-stack,.widget_webulous-image-widget i,.ourservice .panel-grid-cell,
				.icon-left .fa-stack,.portfolioeffects .portfolio_link_icons a,.portfolioeffects .content-details h3:after,.widget_recent-posts-gallery-widget .recent-post .readmore a,.widget_recent-work-widget ul.flex-direction-nav a,.widget_recent-work-widget .portfolio3col .overlay_icon a,
				.widget_recent-work-widget .recent_work_overlay .icon-link,.widget.widget_skill-widget .skill-container .skill .skill-percentage,.widget.widget_ourteam-widget .team-avator,.header-wrap .social ul li a:hover,.footer-bottom,.widget_social-networks-widget ul li a,
				.share-box ul li a,.entry-header .header-entry-meta a.box-title,
				.entry-body .header-entry-meta a.box-title,.widget .ei-slider-thumbs li.ei-slider-element,.dropcap-circle,.wide-stats .circle-icon-box:hover .icon-wrapper,
				.dropcap-box,.dropcap-book,.cnt-form .wpcf7-form input[type="submit"],.dropcap-book,.sep:before,.circle-icon-box:hover .icon-wrapper,
				ul.ei-slider-thumbs li.ei-slider-element,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a:before,
				.tabs-container ul.ui-tabs-nav li a:hover:before, .tabs-container ul.ui-tabs-nav li.ui-tabs-active a:before,
				input[type="reset"],.sidebar .dropcap-circle,.sidebar .icon-horizontal .fa-stack,
				.sidebar .icon-vertical .fa-stack,#secondary.sidebar .widget_testimonial-widget .testimonial-container .testimonials,
				.sidebar .dropcap-box,ol.webulous_page_navi li a,.ui-accordion .ui-accordion-header-active,.widget_calendar table th,
				input[type="submit"],.nav-wrap,.widget_recent-posts-gallery-widget .recent-post .entry-date a,.main-navigation ul ul li,.navigation a:hover,.widget.widget_ourteam-widget .team-content h4 span,
				.comment-navigation a:hover,#secondary.sidebar .callout-widget,.not-found-inner,.home .services,.ui-accordion .ui-accordion-header:hover,.widget_flexslider-widget .flexcarousel .flex-direction-nav a:hover,.widget_recent-work-widget .portfolio3col:hover .overlay_icon,.widget.widget_ourteam-widget .team-avatar, .our-team .team-avatar,
				.widget_recent-posts-widget .recent-post .entry-date a',
			'property' => 'background-color',
		),
		array(
			'element'  => '.widget_recent-work-widget .portfolio3col:hover .overlay_icon a.icon-zoom:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element'  =>'.widget_recent-work-widget .portfolio3col:hover .overlay_icon',
			'property' =>'Opacity',
			'value' =>0.5,
		),
	),
) );

Royal_Kirki::add_field( 'royal', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-royal' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#000',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => 'input[type="text"],
				input[type="email"],.not-found-inner a:hover,.cnt-form .wpcf7-form input[type="text"],
				.cnt-form .wpcf7-form input[type="email"],
				.cnt-form .wpcf7-form input[type="tel"],
				.cnt-form .wpcf7-form input[type="url"],
				.cnt-form .wpcf7-form input[type="password"],
				.cnt-form .wpcf7-form input[type="number"],
				.cnt-form .wpcf7-form textarea,
				input[type="url"],.footer-bottom p a:hover,#secondary.sidebar .widget_testimonial-widget h3,
				input[type="password"],.entry-meta span a:hover,#filters ul.filter-options li a,.sidebar .widget_siteorigin-panels-postloop article h1 a:hover,
				.entry-footer span a:hover,.widget_testimonial-widget ul li .client strong,
				input[type="search"],.search-form input[type="search"],.widget_testimonial-widget .testimony p:before,
				textarea,input[type="text"]:focus,#secondary .widget_rss .widget-title .rsswidget,
				input[type="email"]:focus,.footer-top ul li a,.tabs-container ul.ui-tabs-nav li a,.site-footer .footer-bottom ul.menu li a:hover,.site-footer .footer-bottom ul.menu li.current_page_item a,.site-footer .widget_siteorigin-panels-postloop article h1 a:hover,
				input[type="url"]:focus,.byuser .comment-metadata a:hover,.widget_tag_cloud a:hover,
				.byuser .comment-content a:hover,.hentry.sticky code,.footer-bottom .widget_nav_menu a:hover,
				input[type="password"]:focus,.nav-links .meta-nav,.hentry.post h1 a,.widget.widget_ourteam-widget .team-content h4,
				.more-link .meta-nav,.screen-reader-text:hover, .screen-reader-text:active, .screen-reader-text:focus,
				input[type="search"]:focus,.header-wrap .social ul li a,.error-404.not-found,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a,
				.tabs-container ul.ui-tabs-nav li a:hover,.site-footer .widget_social-networks-widget ul li a:hover,.royal-process.white-bg .textwidget h4,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a,
				textarea:focus,a.more-link,.site-main .comment-navigation a:hover,#filters ul.filter-options li a:hover:before,
				#filters ul.filter-options li a.selected:before',
			'property' => 'color',
		),
		/*array(
			'element' => 'table tr th:hover a,
			  				.site-header .social .recentcomments a:hover	
							.header-wrap .site-header .social .recentcomments a:hover,
							#primary .sticky a:hover,
							#primary .sticky span:hover,
							#primary .sticky time:hover,
							.left-sidebar .recentcomments a:hover,
							.left-sidebar .widget_rss a:hover,
							.wide-cta .call-btn a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),*/
		array(
			'element' => 'button:hover,ul.ei-slider-thumbs li a,.widget .ei-slider-thumbs li a:hover,.widget_testimonial-widget ul.flex-direction-nav li a,
				.cnt-form .wpcf7-form input[type="submit"]:hover,.site-footer .widget_social-networks-widget ul li a,
				ul.ei-slider-thumbs li a:hover,.withtip:before,.circle-icon-box .more-button a,.error-404.not-found .page-header,
				.widget_recent-posts-gallery-widget .recent-post .readmore a:hover,.site-footer .footer-top,.widget_social-networks-widget ul li a:hover,
				.share-box ul li a:hover,.widget_flexslider-widget .flexcarousel .flex-direction-nav a,.widget_recent-work-widget .portfolio3col:hover .overlay_icon a:hover,
				input[type="button"]:hover,.page-links,.widget.widget_ourteam-widget ul.team-social li a:hover,
				input[type="reset"]:hover,.home .services h4,.page-slider .ei-slider-thumbs li a,.widget.widget_skill-widget .skill-container .skill .skill-percentage span,
				input[type="submit"]:hover,.widget_webulous-image-widget .image-widget-overlay:hover i:hover,.sidebar .widget.widget_flexslider-widget .flexcarousel .flex-direction-nav a.flex-prev,
				.sidebar .widget.widget_flexslider-widget .flexcarousel .flex-direction-nav a.flex-next,
				.portfolioeffects:hover .content-details .portfolio_link_icons a:hover,.comment-navigation .nav-previous,.widget_recent-posts-gallery-widget .recent-post .entry-date,
				.paging-navigation .nav-previous,.header-wrap,.icon-right:hover .fa-stack,.widget_testimonial-widget .flex-control-nav a.flex-active,.widget_image-box-widget a.more-button:hover,
				.icon-left:hover .fa-stack,.site-footer .widget.widget_flexslider-widget .flexcarousel .flex-direction-nav a.flex-prev,
				.site-footer .widget.widget_flexslider-widget .flexcarousel .flex-direction-nav a.flex-next,.entry-header .header-entry-meta,.entry-header .header-entry-meta a.box-title:hover,
				.entry-body .header-entry-meta a.box-title:hover,.panel-row-style-wide-black,
				.entry-body .header-entry-meta,.widget.widget_ourteam-widget:hover .team-content h4 span,.widget.widget_ourteam-widget:hover .team-avator,
				.post-navigation .nav-previous,.navigation a,.callout-widget a:hover,ol.webulous_page_navi li.bpn-current, .flexslider ol.flex-control-paging li a.flex-active,
				.comment-navigation a,.sidebar .widget.widget_skill-widget .skill-container .skill,#secondary.sidebar .callout-widget p.call-btn a:hover,ol.webulous_page_navi li a:hover,.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link,
				.site-footer .scroll-to-top,.site-footer .scroll-to-top:hover',
			'property' => 'background-color',
		),
       /* array(
			'element' => '.slicknav_menu,
				          .search-form input.search-submit:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element' => '.page-numbers,
				         .royal-process.white-bg .textwidget img',  
			'property' => 'border-color',
		),*/
		array(
			'element' => '.withtip.left:after,.aboutus h3.widget-title:before',
			'property' => 'border-left-color',
		),
		array(
			'element' => 'abbr, acronym,.withtip.bottom:after',
			'property' => 'border-bottom-color',
		),
        array(
			'element' => '.withtip.right:after',
			'property' => 'border-right-color',
		),
        array(
			'element' => 'ol.webulous_page_navi li a:hover:after,.icon-right:hover .fa-stack:after,.entry-header .header-entry-meta:after,
				.entry-body .header-entry-meta:after,.site-footer .widget_social-networks-widget ul li a:after,
				.withtip.top:after, .circle-icon-box .more-button a:after,.widget.widget_ourteam-widget ul.team-social li a:hover::after,
				.widget_testimonial-widget ul.flex-direction-nav li a:after,
				.widget_button-widget a.btn.black:after,.callout-widget a:hover:after,.widget_flexslider-widget .flexcarousel .flex-direction-nav a:after,.portfolioeffects:hover .content-details .portfolio_link_icons a:hover:after,.widget_recent-posts-gallery-widget .recent-post .entry-date:after,.widget_recent-work-widget .portfolio3col:hover .overlay_icon a:hover:after,.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link:after,.widget.widget_ourteam-widget ul.team-social li a:hover:after,ol.webulous_page_navi li.bpn-current:after,.widget_social-networks-widget ul li a:hover:after,
				.share-box ul li a:hover:after,.widget.widget_ourteam-widget:hover .team-avator:after,.widget.widget_skill-widget .skill-container .skill .skill-percentage span:after',
			'property' => 'border-top-color',
		),
		/*array(
			'element' => '.site-footer .widget_social-networks-widget ul li a:after',
			'property' => 'border-top-color',
			'suffix' => '!important',
		),*/
		
	),
) );

//  slider panel //

Royal_Kirki::add_panel( 'slider_panel', array(   
	'title'       => __( 'Slider Settings', 'wbls-royal' ),  
	'description' => __( 'Flex slider related options', 'wbls-royal' ), 
	'priority'    => 11,    
) );

//  flexslider section  //

Royal_Kirki::add_section( 'flex_caption_section', array(
	'title'          => __( 'Flexcaption Settings','wbls-royal' ),
	'description'    => __( 'Flexcaption Related Options', 'wbls-royal'),
	'panel'          => 'slider_panel', // Not typically needed.
) );

Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexcaption_bg',
	'label'    => __( 'Select Flexcaption Background Color', 'wbls-royal' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => 'rgba(255, 255, 255, 0.5)',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flexslider .flex-caption h1, .flexslider .flex-caption h2,
							 .flexslider .flex-caption h3, .flexslider .flex-caption h4, .flexslider .flex-caption h5, 
							 .flexslider .flex-caption h6, 
							.flexslider .flex-caption p, .flexslider .flex-caption li',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexcaption_align',
	'label'    => __( 'Select Flexcaption Alignment', 'wbls-royal' ),
	'section'  => 'flex_caption_section',
	'type'     => 'select',
	'default'  => 'left',
	'choices' => array(
		'left' => esc_attr__( 'Left', 'royal' ),
		'right' => esc_attr__( 'Right', 'royal' ),
		'center' => esc_attr__( 'Center', 'royal' ),
		'justify' => esc_attr__( 'Justify', 'royal' ),
	),
	'output'   => array(
		array(
			'element'  => '.home .flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption,.flexslider .slides .flex-caption h1, .flexslider .slides .flex-caption h2, .flexslider .slides .flex-caption h3, .flexslider .slides .flex-caption h4, .flexslider .slides .flex-caption h5, .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption p,.flexslider .slides .flex-caption',
			'property' => 'text-align',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );
 Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexcaption_bg_position',
	'label'    => __( 'Select Flexcaption Background Horizontal Position', 'wbls-royal' ),
	'tooltip' => __('Select how far from right, Default value Right = 0 ( in % )','wbls-royal'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '0',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'right',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
		
) ); 
 Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'wbls-royal' ),
	'tooltip' => __('Select how far from top, Default value top= 0 ( in % )','wbls-royal'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '0',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'top',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) ); 
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexcaption_bg_width',
	'label'    => __( 'Select Flexcaption Background Width', 'wbls-royal' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '50',
	'tooltip' => __('Select Flexcaption Background Width , Default width value 50','wbls-royal'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) ); 
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexcaption_responsive_bg_width',
	'label'    => __( 'Select Responsive Flexcaption Background Width', 'wbls-royal' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Responsive Flexcaption Background Width, Default width value 100 ( This value will apply for max-width: 768px )','royal'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'media_query' => '@media (max-width: 768px)',
			'value_pattern' => 'calc($%)',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );
Royal_Kirki::add_field( 'royal', array(
	'settings' => 'flexcaption_color',
	'label'    => __( 'Select Flexcaption Font Color', 'wbls-royal' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '#fff',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.home .flexslider .slides .flex-caption p a,.flex-caption,.home .flexslider .slides .flex-caption p,.flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption h1,.flexslider .slides .flex-caption h2,.flexslider .slides .flex-caption h3,.flexslider .slides .flex-caption h4,.flexslider .slides .flex-caption h5,.flexslider .slides .flex-caption h6',
			'property' => 'color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
	
) );
}

