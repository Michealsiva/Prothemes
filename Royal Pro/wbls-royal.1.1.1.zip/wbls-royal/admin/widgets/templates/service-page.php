<div class="services-wrapper clearfix">
     <div class="services">
        <div class="service-featured">
         <?php the_title( sprintf( '<h4>', esc_url( get_permalink() ) ), '</h4>' ); ?>
	    	<?php if( has_post_thumbnail() ) : ?>
                <a href="<?php echo esc_url( get_permalink() ); ?>">                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
	    		<?php the_post_thumbnail('wbls_royal_service-thumbnail'); ?></a>
	    	<?php endif; ?>
    	</div>	    	   
	    <?php the_content(); ?>
    </div>
</div>             

