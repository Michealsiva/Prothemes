<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts
 *
 * @param $layouts
 */    

if (!function_exists('webulous_prebuilt_page_layouts') ) {
 function webulous_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-newgenn'),
    'description' => __('Pre Built Layout for  home page', 'wbls-newgenn'),
    'widgets' =>  array(
        0 => 
    array (
      'title' => 'Welcome to Theme',
      'text' => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam feugiat vitae ultricies eget tempor sit amet ante. Donec eu libero sit amet quam egestas semper.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '316e6122-74f3-4649-b34b-3ffbb2499e6f',
        'style' => 
        array (
          'class' => 'content-center wel-text title-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'type' => 'circle',
            'title' => 'Excellent Support',
            'text' => ' We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
            'icon' => 'fa-thumb-tack',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'ca65e2d7-8b68-4b2c-848a-799f690dc1a2',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'type' => 'circle',
            'title' => 'Retina Ready',
            'text' => 'NewGenn is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
            'icon' => 'fa-magic',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '20acc0b5-0b5f-4cc7-b3d8-a7c57a908275',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'type' => 'circle',
            'title' => 'Customization',
            'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
            'icon' => 'fa-cog',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => 'ded07959-9e66-4f0e-9986-7ba96aceec97',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'type' => 'circle',
            'title' => 'Page Builder',
            'text' => 'NewGenn supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
            'icon' => 'fa-plus',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'widget_id' => 'db4d346e-7dab-4fb8-b940-75896f326d3d',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577cea69eb412',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '90d65bec-1451-451b-9496-53f8f2c9d36d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'style' => 'default',
      'panels_info' => 
      array (
        'class' => 'Wbls_Divider_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'b27b2c8e-bf25-4755-9320-00c8e9a1a3c3',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Graphic Design, Html & Css Development...',
            'text' => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.
<br>
[button link="http://webulousthemes.com/" target="_self" color="btn" size="btn-normal"]We\'re Back Theme[/button]
',
            'filter' => 'on',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '296e2f0e-0444-4ad1-9590-e033839f3524',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Skills',
            'panels_info' => 
            array (
              'class' => 'Wbls_Skill_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'a50d691f-acf2-492f-882f-092f5f30fdd0',
              'style' => 
              array (
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '577cea69eb482',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => 'dca3d180-9913-418d-979b-8509a5112635',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Testimonials',
      'count' => '5',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 4,
        'widget_id' => 'f0b28ccc-5963-401a-8a3f-9f9a711863af',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'src' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/Mobile.png',
      'href' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/Mobile.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '9bf213b9-cfbd-47a4-8397-67bfe9dcbc93',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Running Facts',
            'text' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Phasellus tincidunt mi vitae porttitor rutrum. Duis consequat massa nec est ornare a suscipit metus iaculis.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '80347fcb-687b-47ce-8f56-46cd3b6ca083',
              'style' => 
              array (
                'class' => 'text-head',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
          1 => 
          array (
            'title' => '402',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '172c28d6-8048-4883-9b0c-d16064b4293e',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '405',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 2,
              'widget_id' => '36bbe535-85bf-4603-91a0-ef066443448f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '403',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 3,
              'widget_id' => '4b0202f4-f149-4e6f-ab8c-6af716ff3c63',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '406',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 4,
              'widget_id' => 'df6cc751-55a7-4338-9a6f-435a2e23d187',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => '404',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 5,
              'widget_id' => '80b76e92-1d3d-45dc-b947-00cf1bcd7967',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'title' => '407',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 6,
              'widget_id' => 'fd099f1e-9a91-4379-826b-a08e1cc3bae7',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
        ),
      ),
      'builder_id' => '577e40a19b35f',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 5,
        'cell' => 1,
        'id' => 6,
        'widget_id' => '979e55a3-d1e7-48cb-8b6b-a46d2a6892bb',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Recent Work',
      'count' => '12',
      'type' => 'isotope',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Work_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '7f2a551d-54cd-4f59-afa5-cd453101d336',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Work Process',
            'text' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'c2014c37-938c-489e-8c76-0fa507a4d2b1',
              'style' => 
              array (
                'class' => 'title-divider',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Analysis',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus tincidunt mi vitae porttitor rutrum.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '87fc0990-50cb-491e-a48d-8583ea0b4fd7',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Design',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus tincidunt mi vitae porttitor rutrum.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '8c5a0f0d-c4ee-42cf-b910-8dd6ad5dfbbf',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Development',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus tincidunt mi vitae porttitor rutrum.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '04df50e5-6bb6-41db-aab8-b53192538455',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Support',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus tincidunt mi vitae porttitor rutrum.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => '1f51f0fb-0342-4758-b03f-a61133ad2d92',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => 'work-process',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577e40a19b468',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 7,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'e095e0b7-4877-47e6-8ae2-da663e27b0a9',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'style' => 'default',
      'panels_info' => 
      array (
        'class' => 'Wbls_Divider_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 9,
        'widget_id' => 'fb343bc3-f776-4844-92c3-3b5bac83a5a9',
        'style' => 
        array (
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Recent Posts',
      'count' => '2',
      'type' => 'normal',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Posts_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 10,
        'widget_id' => 'a1afb525-8bbb-4718-a6fc-b235f65dfdd8',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Our Features',
      'text' => '[toggle title="Vivamus semper tincidunt tincidunt." open="0"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title=" Donec facilisis fringilla faucibus. " open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.[/toggle][gap height="20"]

[toggle title=" Fusce ultricies sapien libero pharetra." open="0"]Vivamus semper tincidunt tincidunt. Nunc ultrices est massa, id laoreet mauris eleifend eu. Donec dictum felis mauris, quis vestibulum risus tempus id. Nulla vulputate vehicula dui, non faucibus lorem congue sit amet.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="Maecenas ut pretium mauris." open="0"]Nam quis interdum nulla. Donec porttitor nibh est, eu tempus nisi pellentesque ac. Maecenas ut pretium mauris. Quisque nunc justo, placerat non luctus euismod, placerat sit amet ex. Nunc molestie nisl ac molestie ultricies.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="Quisque  placerat luctus euismod." open="0"]Aenean convallis ipsum felis, eu commodo nulla vestibulum a. Praesent rhoncus elit sed libero mollis, quis ullamcorper risus mattis. Morbi rutrum nunc nec nisl porta malesuada. Suspendisse vel diam mattis, gravida sapien non, bibendum leo.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leoNunc sit amet justo lectus. Curabitur vel ipsum ac nisi malesuada pellentesque. Aenean aliquet tempus eros et volutpat. Aliquam non tincidunt erat. Vivamus sit amet massa sem. Nulla nec risus eget elit iaculis lobortis fringilla ac lorem. Fusce scelerisque id ipsum ac pulvinar.[/toggle][gap height="20"]




',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 9,
        'cell' => 1,
        'id' => 11,
        'widget_id' => 'a7bbd62d-1f23-45fb-a187-10fae1c7724e',
        'style' => 
        array (
          'class' => 'accordion-row',
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'slider' => 'home-clients',
            'type' => 'carousel',
            'panels_info' => 
            array (
              'class' => 'Wbls_FlexSlider_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '56b2fb67ea004',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 10,
        'cell' => 0,
        'id' => 12,
        'widget_id' => 'b095608a-9d17-4e7c-ad07-bcc3cf719760',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Meet Our Team',
            'text' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '55d1a435-11ee-40f3-99a6-710146b16ba6',
              'style' => 
              array (
                'class' => 'title-divider',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Nullam in neque enim. Praesent at felis imperdiet, bibendum purus dignissim, varius orci. Cras sodales velit risus, quis bibendum diam faucibus at.',
            'image_url' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/ourteam-1.png',
            'title' => 'Eric John',
            'designation' => 'CEO',
            'linkedin' => 'http://www.linkedin.com',
            'google' => 'http://www.googlepuls.com',
            'twitter' => 'http://www.twitter.com',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'd8fd7abd-9dad-4557-972b-899d075af25d',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Nullam in neque enim. Praesent at felis imperdiet, bibendum purus dignissim, varius orci. Cras sodales velit risus, quis bibendum diam faucibus at.',
            'image_url' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/ourteam-2.png',
            'title' => 'Mizuki Yuong',
            'designation' => 'Designer',
            'linkedin' => 'http://www.linkedin.com',
            'google' => 'http://www.googlepuls.com',
            'twitter' => 'http://www.twitter.com',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => 'e5e32dac-fe00-4270-a219-85b4ef3512f0',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Nullam in neque enim. Praesent at felis imperdiet, bibendum purus dignissim, varius orci. Cras sodales velit risus, quis bibendum diam faucibus at.',
            'image_url' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/ourteam-3.png',
            'title' => 'Robertson',
            'designation' => 'Manger',
            'linkedin' => 'http://www.linkedin.com',
            'google' => 'http://www.googlepuls.com',
            'twitter' => 'http://www.twitter.com',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '7337a47f-ec7b-4072-9163-3452dcc559ac',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '577cea69eb519',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 13,
        'widget_id' => '8ade87e5-1de8-4371-a1da-6c7139333a82',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'src' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/uniq-features.png',
      'href' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/uniq-features.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 14,
        'widget_id' => 'f2d2196c-3dfb-4350-bc52-2ebefc1f6369',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Creative Wordpress Theme',
            'text' => '[headline level="2" type="normal" align="tleft"]Our Unique Features[/headline]
Lorem Ipsum is simply dummy text of the printing and typesetting industry. ',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'title' => 'Shortcodes',
                  'text' => 'NewGenn inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
                  'icon' => 'fa-check',
                  'icon_background_color' => '',
                  'icon_size' => '4x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => true,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'Page Layout',
                  'text' => 'NewGenn offers many different page layouts so you can quickly and easily create your pages with no hassle!',
                  'icon' => 'fa-copy',
                  'icon_background_color' => '',
                  'icon_size' => '4x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => true,
                    'grid' => 0,
                    'cell' => 1,
                    'id' => 1,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'title' => 'Demo Content',
                  'text' => ' NewGenn includes demo content files. You can quickly setup the site like our demo and get started easily!',
                  'icon' => 'fa-thumb-tack',
                  'icon_background_color' => '',
                  'icon_size' => '4x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => true,
                    'grid' => 1,
                    'cell' => 0,
                    'id' => 2,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                3 => 
                array (
                  'title' => 'Woo Commerce',
                  'text' => 'NewGenn has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!',
                  'icon' => 'fa-shopping-cart',
                  'icon_background_color' => '',
                  'icon_size' => '4x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => true,
                    'grid' => 1,
                    'cell' => 1,
                    'id' => 3,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 2,
                  'style' => 
                  array (
                    'class' => '',
                    'cell_class' => '',
                    'row_css' => '',
                    'background_image' => '',
                    'bottom_border' => '',
                    'background' => '',
                    'top_border' => '',
                    'bottom_margin' => '',
                    'gutter' => '',
                    'padding' => '',
                    'row_stretch' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                  ),
                ),
                1 => 
                array (
                  'cells' => 2,
                  'style' => 
                  array (
                    'class' => '',
                    'cell_class' => '',
                    'row_css' => '',
                    'background_image' => '',
                    'bottom_border' => '',
                    'background' => '',
                    'top_border' => '',
                    'bottom_margin' => '',
                    'gutter' => '',
                    'padding' => '',
                    'row_stretch' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 0.5,
                ),
                1 => 
                array (
                  'grid' => 0,
                  'weight' => 0.5,
                ),
                2 => 
                array (
                  'grid' => 1,
                  'weight' => 0.5,
                ),
                3 => 
                array (
                  'grid' => 1,
                  'weight' => 0.5,
                ),
              ),
            ),
            'builder_id' => '55e0093792334',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '56b3032334922',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 12,
        'cell' => 1,
        'id' => 15,
        'widget_id' => 'bfce0c68-3820-4bee-8fe0-58e967b6afbb',
        'style' => 
        array (
          'class' => 'our-features',
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 13,
        'cell' => 0,
        'id' => 16,
        'widget_id' => 'e6c3471a-9f1a-4f89-baee-3d4cb89b0dd8',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'aboutus animation-row1',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'center',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-black',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-black',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'center',
      ),
    ),
    9 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'animation-row11',
        'background_display' => 'tile',
      ),
    ),
    10 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-black',
        'background_display' => 'tile',
      ),
    ),
    11 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    12 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'wide-pattern-grey',
        'background_display' => 'tile',
      ),
    ),
    13 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-cta',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 5,
      'weight' => 0.31454545454545002,
    ),
    6 => 
    array (
      'grid' => 5,
      'weight' => 0.68545454545454998,
    ),
    7 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    11 => 
    array (
      'grid' => 9,
      'weight' => 0.5,
    ),
    12 => 
    array (
      'grid' => 10,
      'weight' => 1,
    ),
    13 => 
    array (
      'grid' => 11,
      'weight' => 1,
    ),
    14 => 
    array (
      'grid' => 12,
      'weight' => 0.5,
    ),
    15 => 
    array (
      'grid' => 12,
      'weight' => 0.5,
    ),
    16 => 
    array (
      'grid' => 13,
      'weight' => 1,
    ),
    
    ),  

  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-newgenn'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-newgenn'),
    'widgets' => array(
         0 => 
    array (
      'title' => 'About Theme',
      'text' => '[divider style="solid"]

Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante Donec eu libero sit amet quam. 

Maecenas nec leo ac nulla commodo interdum. Morbi commodo, diam nec pharetra malesuada, libero felis posuere massa, id egestas lorem odio finibus libero.',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'ad4dd509-370c-44d4-99f4-105af8fbfd50',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'slider' => 'about-slide',
      'type' => 'slider',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => 'c1e035a7-6105-4553-8c34-7d6999cc7a52',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Testimonials',
      'count' => '5',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'bd64bc9b-8a90-4404-b296-d1d7ef076870',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Meet Our Team',
            'text' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '6dcdc882-eb2c-4350-98e7-df005bf1f42c',
              'style' => 
              array (
                'class' => 'title-divider',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Nullam in neque enim. Praesent at felis imperdiet, bibendum purus dignissim, varius orci. Cras sodales velit risus, quis bibendum diam faucibus at.',
            'image_url' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/ourteam-1.png',
            'title' => 'Erick Jhon',
            'designation' => 'CEO',
            'linkedin' => 'http://www.linkedin.com/',
            'google' => 'http://www.google.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '7e1cc969-dc25-4c71-8acf-ac47cdc31188',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Nullam in neque enim. Praesent at felis imperdiet, bibendum purus dignissim, varius orci. Cras sodales velit risus, quis bibendum diam faucibus at.',
            'image_url' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/ourteam-2.png',
            'title' => 'Mizuki Yuong ',
            'designation' => 'Manager',
            'linkedin' => 'http://www.linkedin.com/',
            'google' => 'http://www.google.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '0afca0a9-d64d-46ec-8675-8a61a8d1a311',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Nullam in neque enim. Praesent at felis imperdiet, bibendum purus dignissim, varius orci. Cras sodales velit risus, quis bibendum diam faucibus at.',
            'image_url' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/ourteam-3.png',
            'title' => 'Robertson',
            'designation' => 'Photographer',
            'linkedin' => 'http://www.linkedin.com/',
            'google' => 'http://www.google.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com/',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '89031e5a-89ba-42a8-9edd-03be5b453fab',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '577ceb040be8d',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '2a97a82f-5608-4425-a7c3-924726ab874f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '0443a9c2-800c-4d18-834d-2b0fcfcf98d1',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-black',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-cta theme-cta',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.5,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.5,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
        ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'wbls-newgenn'),
      'description' => __( 'Pre Built layout for features page', 'wbls-newgenn'),
      'widgets' => array(
             0 => 
    array (
      'title' => 'Responsive Design',
      'text' => 'NewGenn is fully responsive and can adapt to any screen size. Resize your browser window to view it!',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => ' Awesome Sliders',
      'text' => 'NewGenn includes Flex slider. You can use Flex slider anywhere in your site.',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => ' Font Awesome',
      'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => ' Typography',
      'text' => 'NewGenn loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
      'icon' => 'fa-font',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => ' Retina Ready',
      'text' => 'NewGenn is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 4,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Excellent Support',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
      'icon' => 'fa-support',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 5,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 6,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Advanced Admin',
      'text' => 'NewGenn uses advanced Webulous Framework for theme options panel, you can customize any part of your site quickly and easily!',
      'icon' => 'fa-cog',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
    8 => 
    array (
      'title' => 'Page Builder',
      'text' => 'NewGenn supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 8,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => ' Page Layout',
      'text' => 'NewGenn offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 9,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Custom Widgets',
      'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
      'icon' => 'fa-beer',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 10,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => ' Shortcodes',
      'text' => 'NewGenn inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
      'icon' => 'fa-check',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 11,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Demo Content',
      'text' => 'NewGenn includes demo content files. You can quickly setup the site like our demo and get started easily!',
      'icon' => 'fa-close',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 12,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 13,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'title' => 'Woo Commerce',
      'text' => 'NewGenn has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!',
      'icon' => 'fa-shopping-cart',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 14,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'title' => ' Social Media',
      'text' => 'Want your users to stay in touch? No problem, NewGenn has Social Media icons all throughout the theme!',
      'icon' => 'fa-skype',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 1,
        'id' => 15,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => ' Google Map',
      'text' => 'NewGenn includes Google Map as shortcode and widget. So, you can use it anywhere in your site!',
      'icon' => 'fa-map-marker',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 2,
        'id' => 16,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'title' => 'Multiple Portfolio',
      'text' => '7 portfolio layouts, 3 blog layouts and multiple other alternate layouts for interior pages!',
      'icon' => 'fa-list-alt',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 17,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'title' => 'Multiple Sidebar',
      'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
      'icon' => 'fa-columns',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 18,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'title' => 'Customization',
      'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
      'icon' => 'fa-edit',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 2,
        'id' => 19,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'theme-cta',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    4 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'theme-cta',
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    7 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    8 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    9 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    10 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    11 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    12 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    13 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    14 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    15 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    16 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    17 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    18 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    19 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),

    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-newgenn'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-newgenn'),
      'widgets' => array(
            0 => 
    array (
      'title' => 'Contact Us',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'class' => 'title-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Contact Details',
            'text' => ' Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. ',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'title-seperator',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'title' => '',
                  'text' => '[icon icon="fa-phone" size="" style=""]  012-345-6789

[icon icon="fa-map-marker" size="" style=""] NewGenn WarSaw, Poland Aleje Jerozolimskie 11
',
                  'filter' => 'on',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => '',
                  'text' => '[icon icon="fa fa-envelope" size="" style=""]  newgenn@email.com

[icon icon="fa fa-clock-o" size="" style=""] Monday - Friday - 9:00  to 18.00

[icon icon="fa fa-fax" size="" style=""]  012-345-6789
',
                  'filter' => 'on',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 1,
                    'id' => 1,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 2,
                  'style' => 
                  array (
                    'class' => '',
                    'cell_class' => '',
                    'row_css' => '',
                    'bottom_margin' => '',
                    'gutter' => '',
                    'padding' => '',
                    'row_stretch' => '',
                    'background' => '',
                    'background_image_attachment' => '0',
                    'background_display' => 'tile',
                    'border_color' => '',
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 0.38955823293172998,
                ),
                1 => 
                array (
                  'grid' => 0,
                  'weight' => 0.61044176706827002,
                ),
              ),
            ),
            'builder_id' => '55e420991f7c6',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => 'cnt-details',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Contact Form',
            'text' => '[contact-form-7 id="4" title="Contact form 1"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => 'title-seperator',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '56b32db4ea406',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'class' => 'cnt-form',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Contact Map',
      'text' => '<div id="map_canvas">
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d6305.992774595653!2d-122.41157430890459!3d37.790124433800656!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858091edff45bd%3A0x70c4586b1202a605!2sUSA+Hostels+San+Francisco!5e0!3m2!1sen!2sin!4v1407318894507"  width="1280px" height="500px" frameborder="0" style="border:0""></iframe>
</div>',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'class' => 'title-divider',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    3 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'theme-cta',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-newgenn'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-newgenn'),
    'widgets' =>  array(
          0 => 
    array (
      'title' => 'Faq\'s',
      'text' => '[toggle title="Vivamus semper tincidunt tincidunt." open="0"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title=" Donec facilisis fringilla faucibus. " open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.[/toggle][gap height="20"]

[toggle title=" Fusce ultricies sapien libero pharetra." open="0"]Vivamus semper tincidunt tincidunt. Nunc ultrices est massa, id laoreet mauris eleifend eu. Donec dictum felis mauris, quis vestibulum risus tempus id. Nulla vulputate vehicula dui, non faucibus lorem congue sit amet.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="Maecenas ut pretium mauris." open="0"]Nam quis interdum nulla. Donec porttitor nibh est, eu tempus nisi pellentesque ac. Maecenas ut pretium mauris. Quisque nunc justo, placerat non luctus euismod, placerat sit amet ex. Nunc molestie nisl ac molestie ultricies.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="Quisque  placerat luctus euismod." open="0"]Aenean convallis ipsum felis, eu commodo nulla vestibulum a. Praesent rhoncus elit sed libero mollis, quis ullamcorper risus mattis. Morbi rutrum nunc nec nisl porta malesuada. Suspendisse vel diam mattis, gravida sapien non, bibendum leo.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leoNunc sit amet justo lectus. Curabitur vel ipsum ac nisi malesuada pellentesque. Aenean aliquet tempus eros et volutpat. Aliquam non tincidunt erat. Vivamus sit amet massa sem. Nulla nec risus eget elit iaculis lobortis fringilla ac lorem. Fusce scelerisque id ipsum ac pulvinar.[/toggle][gap height="20"]

[toggle title="Curabitur ac egestas dolor  dapibus ." open="0"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title=" Aliquam non tincidunt erat. " open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.[/toggle][gap height="20"]

[toggle title="Vestibulum in sodales orci." open="0"] Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris placerat eleifend leo.[/toggle][gap height="20"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'class' => 'title-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-cta theme-cta',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-newgenn'),
    'description' => __('Pre Built Layout for services page', 'wbls-newgenn'),
    'widgets' =>  array(
      0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'How to Use',
            'text' => 'Nam laoreet enim at sem malesuada, id ultrices justo cursus. Morbi vel ullamcorper massa. Vestibulum tempus ultricies felis, non volutpat eros lobortis ac. 

Integer felis ipsum, maximus sit amet blandit eu, cursus vel est. Pellentesque in ligula nec arcu fermentum finibus dignissim et nunc. Suspendisse quis est urna.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '24491032-a360-4d56-aeb7-bc053154d741',
              'style' => 
              array (
                'class' => 'title-divider small-divider',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/services.png',
            'href' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/services.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '43e73aca-831f-44d8-b1f6-ea72cdc569fd',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'There are many variations',
            'text' => 'Aenean et cursus diam, eget semper tortor. Sed commodo neque fringilla, suscipit erat et, auctor nunc. Ut ullamcorper sit amet mauris a consectetur. 

<ul>

<li><i class="fa fa-check"></i>     Curabitur ligula augue</li>

<li><i class="fa fa-check"></i>     Cras quis ultrices ante.</li>

<li><i class="fa fa-check"></i>     Praesent suscipit egestas.</li>

<li><i class="fa fa-check"></i>     Eurabitur kigula fugue</li>

</ul>',
            'filter' => 'on',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '95d8c007-47a4-48c7-902a-194b8371c9de',
              'style' => 
              array (
                'class' => 'list-gap',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33029714046566999,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33931517653782001,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33038768299651,
          ),
        ),
      ),
      'builder_id' => '577cebab31586',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '759b44e6-700d-4774-913f-3141c7c9bb21',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Services',
            'text' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'content-center wel-text title-divider ',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Responsive Layout',
            'text' => 'NewGenn is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Customization',
            'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
            'icon' => 'fa-cog',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Awesome Slider',
            'text' => 'NewGenn includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
            'icon' => 'fa-random',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Typography',
            'text' => ' NewGenn loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
            'icon' => 'fa-font',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 2,
              'cell' => 0,
              'id' => 4,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => 'Social Media',
            'text' => 'Want your users to stay in touch? No problem, NewGenn has Social Media icons all throughout the them',
            'icon' => 'fa-skype',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 2,
              'cell' => 1,
              'id' => 5,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'title' => 'Page Layout',
            'text' => 'NewGenn offers many different page layouts so you can quickly and easily create your pages with no hassle!',
            'icon' => 'fa-copy',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 2,
              'cell' => 2,
              'id' => 6,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          2 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          4 => 
          array (
            'grid' => 2,
            'weight' => 0.33333333333332998,
          ),
          5 => 
          array (
            'grid' => 2,
            'weight' => 0.33333333333332998,
          ),
          6 => 
          array (
            'grid' => 2,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '56b45044e54af',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '8a40f757-4614-4ab5-94ac-efd532dc7b14',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'title' => 'Amazing Features',
                  'text' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text.',
                  'panels_info' => 
                  array (
                    'class' => 'WP_Widget_Text',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'style' => 
                    array (
                      'class' => 'title-divider',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'panels_data' => 
                  array (
                    'widgets' => 
                    array (
                      0 => 
                      array (
                        'title' => '',
                        'text' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable.',
                        'panels_info' => 
                        array (
                          'class' => 'WP_Widget_Text',
                          'raw' => false,
                          'grid' => 0,
                          'cell' => 0,
                          'id' => 0,
                          'style' => 
                          array (
                            'class' => '',
                            'widget_css' => '',
                            'padding' => '',
                            'background' => '',
                            'background_image_attachment' => '0',
                            'background_display' => 'tile',
                            'border_color' => '',
                            'font_color' => '',
                          ),
                        ),
                      ),
                      1 => 
                      array (
                        'title' => '',
                        'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum of letters, as opposed to using  making it look like readable English.',
                        'panels_info' => 
                        array (
                          'class' => 'WP_Widget_Text',
                          'raw' => false,
                          'grid' => 0,
                          'cell' => 1,
                          'id' => 1,
                          'style' => 
                          array (
                            'class' => '',
                            'widget_css' => '',
                            'padding' => '',
                            'background' => '',
                            'background_image_attachment' => '0',
                            'background_display' => 'tile',
                            'border_color' => '',
                            'font_color' => '',
                          ),
                        ),
                      ),
                      2 => 
                      array (
                        'title' => '',
                        'text' => '<ul><li><i class="fa fa-check"></i>     Curabitur ligula augue</li><br>
<li><i class="fa fa-check"></i>     Praesent suscipit egestas.</li><br>
<li><i class="fa fa-check"></i>     Cras quis ultrices ante.</li><br>
<li><i class="fa fa-check"></i>     Quisque feugiat tempus</li><br>
</ul>',
                        'panels_info' => 
                        array (
                          'class' => 'WP_Widget_Text',
                          'raw' => false,
                          'grid' => 0,
                          'cell' => 2,
                          'id' => 2,
                          'style' => 
                          array (
                            'class' => '',
                            'widget_css' => '',
                            'padding' => '',
                            'background' => '',
                            'background_image_attachment' => '0',
                            'background_display' => 'tile',
                            'border_color' => '',
                            'font_color' => '',
                          ),
                        ),
                      ),
                    ),
                    'grids' => 
                    array (
                      0 => 
                      array (
                        'cells' => 3,
                        'style' => 
                        array (
                        ),
                      ),
                    ),
                    'grid_cells' => 
                    array (
                      0 => 
                      array (
                        'grid' => 0,
                        'weight' => 0.33333333333332998,
                      ),
                      1 => 
                      array (
                        'grid' => 0,
                        'weight' => 0.33333333333332998,
                      ),
                      2 => 
                      array (
                        'grid' => 0,
                        'weight' => 0.33333333333332998,
                      ),
                    ),
                  ),
                  'builder_id' => '55e3ea00b0b84',
                  'panels_info' => 
                  array (
                    'class' => 'SiteOrigin_Panels_Widgets_Layout',
                    'raw' => true,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 1,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 1,
                ),
              ),
            ),
            'builder_id' => '55e3e84054fd0',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'ef54ecb3-16e5-42a2-83f1-504a9e0b956e',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/amazing-feature.png',
            'href' => 'http://newgenn.webulous.in/wp-content/uploads/2016/07/amazing-feature.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'e4921cf8-966e-4ee5-bbc5-8b4ffe10efd6',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.69678714859437996,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.30321285140561999,
          ),
        ),
      ),
      'builder_id' => '577cebab315ec',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '81a2ef38-dd58-4743-a6fd-be117c60ee74',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '6d048014-9c8e-44de-bb61-f4eb4d64bbfb',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-black',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'theme-cta',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}     

}
add_filter('siteorigin_panels_prebuilt_layouts', 'webulous_prebuilt_page_layouts');

function wbls_newgenn_panels_row_style_fields($fields) {  

    $newgenn_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-newgenn'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-newgenn' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-newgenn' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-newgenn' ),
        'bounce-animation' => __('bounce-animation','wbls-newgenn' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-newgenn' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-newgenn' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-newgenn' ),
        'expandUp-animation' => __('expandUp-animation','wbls-newgenn' ),
        'fade-animation' => __('fade-animation','wbls-newgenn' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-newgenn' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-newgenn' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-newgenn' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-newgenn' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-newgenn' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-newgenn' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-newgenn' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-newgenn' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-newgenn' ),
        'flip-animation' => __('flip-animation','wbls-newgenn' ),
        'flipInX-animation' => __('flipInX-animation','wbls-newgenn' ),
        'flipInY-animation' => __('flipInY-animation','wbls-newgenn' ),
        'floating-animation' => __('floating-animation','wbls-newgenn' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-newgenn' ),
        'hatch-animation' => __('hatch-animation','wbls-newgenn' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-newgenn' ),
        'puffIn-animation' => __('puffIn-animation','wbls-newgenn' ),
        'pullDown-animation' => __('pullDown-animation','wbls-newgenn' ),
        'pullUp-animation' => __('pullUp-animation','wbls-newgenn' ),
        'pulse-animation' => __('pulse-animation','wbls-newgenn' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-newgenn' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-newgenn' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-newgenn' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-newgenn' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-newgenn' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-newgenn' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-newgenn' ),
        'scale-down-animation' => __('scale-down-animation','wbls-newgenn' ),
        'scale-up-animation' => __('scale-up-animation','wbls-newgenn' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-newgenn' ),
        'slide-left-animation' => __('slide-left-animation','wbls-newgenn' ),
        'slide-right-animation' => __('slide-right-animation','wbls-newgenn' ),
        'slide-top-animation' => __('slide-top-animation','wbls-newgenn' ),
        'slideDown-animation' => __('slideDown-animation','wbls-newgenn' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-newgenn' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-newgenn' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-newgenn' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-newgenn' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-newgenn' ),
        'slideRight-animation' => __('slideRight-animation','wbls-newgenn' ),
        'slideUp-animation' => __('slideUp-animation','wbls-newgenn' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-newgenn' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-newgenn' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-newgenn' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-newgenn' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-newgenn' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-newgenn' ),
        'swap-animation'  => __('swap-animation','wbls-newgenn' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-newgenn' ),
        'swing-animation'  => __('swing-animation','wbls-newgenn' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-newgenn' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-newgenn' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-newgenn' ), 
        'tossing-animation'  => __('tossing-animation','wbls-newgenn' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-newgenn' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-newgenn' ), 
        'wobble-animation' => __('wobble-animation','wbls-newgenn' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-newgenn' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'newgenn'),
            'type' => 'select',
            'options' => $newgenn_animation_name,
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_newgenn_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_newgenn_panels_row_style_fields');

function wbls_newgenn_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_newgenn_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_newgenn_panels_panels_row_style_attributes', 10, 2);

function wbls_newgenn_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Animation', 'wbls-newgenn'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_newgenn_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_newgenn_row_style_groups' );