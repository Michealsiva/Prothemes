<?php
$custom = '';	
	$sticky_header_position = get_theme_mod('sticky_header_position') ;
	if( $sticky_header_position == 'bottom') {
		$custom .= ".nav-wrap.sticky-nav {  top: auto!important;
			bottom:0%; }"."\n";	
		$custom .= ".nav-wrap.sticky-nav .nav-menu .sub-menu {  
			bottom:100%; }"."\n";	
	}	

    $portfolio_filter = get_theme_mod('portfolio_filter',1);

	switch ($portfolio_filter) {
		case 2:
			$custom .= " #filters .filter-options li:first-child {
		       	display: none;
		    }"."\n";
			break;
		case 3:
			$custom .= " #filters .filter-options {
		       	display: none;
		    }"."\n";
			break;
	}
	$page_title_bar = get_theme_mod('page_titlebar');
     switch ($page_title_bar) {
     	case 2:
     		$custom .= ".breadcrumb-wrap {
     			background-color: transparent;
     			background-image:none;
     		}"."\n";
     		break;     	
     	case 3:
     		$custom .= ".breadcrumb-wrap {
     			display: none;
     		}"."\n";
     		break;		
     }

     $page_title_bar_status = get_theme_mod('page_titlebar_text');
     if( $page_title_bar_status == 2 ) {
     	    $custom .= ".breadcrumb-wrap .entry-header {
     			display: none;
     		}"."\n";
     }


	//Output all the styles
	wp_add_inline_style( $this->plugin_name, $custom );	  
