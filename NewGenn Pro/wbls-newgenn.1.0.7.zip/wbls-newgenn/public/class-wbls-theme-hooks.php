<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 4:55 PM
	 */
if( ! class_exists( 'Wbls_Theme_Hooks' )) {
	class Wbls_Theme_Hooks {

		public function full_width_slider(){
			global $post;
			$slider_shortcode = get_post_meta( $post->ID, '_wbls_slider_shortcode', true );
			if( $slider_shortcode != '' ) {
				echo '<div class="page-slider">';
				echo do_shortcode( $slider_shortcode );
				echo '</div>';
			}
		}
		
		public function single_portfolio($single_template){
		    global $post;
			if( $post->post_type == 'portfolio') {
				$single_template = WBLS_THEME_DIR . 'public/views/single-portfolio.php';
				if( file_exists($single_template) && is_file($single_template) ) {
					 $single_template;
				} else {
					if( defined( 'WBLS_FW_DIR' ) ) {
						$single_template = WBLS_FW_DIR . 'public/views/single-portfolio.php';
						if( file_exists( $single_template ) && is_file( $single_template ) ) {
							$single_template;
						}
					}
				}
			}
			return $single_template;
		}
		
		public function single_post($single_template){    
		    global $post;
		    $post_fullwidth = get_post_meta( $post->ID, '_wbls_full_width_post', true );
			if( $post->post_type == 'post') {
				if ( $post_fullwidth ){
					$single_template = WBLS_THEME_DIR . 'public/views/single-post-fullwidth.php';
				    if( file_exists($single_template) && is_file($single_template) ) {
					    $single_template;
				    } 
				}
			}
			return $single_template;
		}

		public function portfolio_views($file){   
			global $post;
		    $file = WBLS_THEME_DIR . 'public/views/' . get_post_meta( $post->ID, '_wp_page_template', true );
			return $file;
		}

		
	}
}