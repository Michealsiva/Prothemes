(function( $ ) {

	$(function() {

		docs = $('<a class="newgenn-docs doc"></a>')
			.attr('href','http://www.webulousthemes.com/newgenn-pro/') 
			.attr('target','_blank')
			.text('Documentation');

		support = $('<a class="newgenn-docs question"></a>')
			.attr('href','http://www.webulousthemes.com/support-ticket/')
			.attr('target','_blank')
			.text('Ask a Question');

		$('#customize-info .preview-notice').append(docs);
		$('#customize-info .preview-notice').append(support);

		$('.newgenn-docs').on('click',function(e){
			e.stopPropagation();
		});
		
		
	});

})( jQuery );
