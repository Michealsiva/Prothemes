<?php
/**
 * Pro customizer options     
 */

add_action('wbls-newgenn_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() { 
   

// pro home page section 

		Newgenn_Kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-newgenn' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-newgenn'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) );

		Newgenn_Kirki::add_field( 'newgenn', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-newgenn' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch',
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
				'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-newgenn'),
			'default'  => 'off',
		) );
		Newgenn_Kirki::add_field( 'newgenn', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-newgenn' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-newgenn'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-newgenn'),
		) );

//general settings add -field work process 

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'work_process',
	'label'    => __( 'Work Process Count', 'wbls-newgenn' ),
	'section'  => 'home_type_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'active_callback' => array(
		array(
			'setting'  => 'page-builder',
			'operator' => '==',
			'value'    => true,
		),
	),   
	'default'  => 'off', 
	'tooltip' => __('Enable work process count','wbls-newgenn'),
) );

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'home_sidebar',
	'label'    => __( 'Enable sidebar on the Home page', 'newgenn' ),
	'section'  => 'home_type_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'newgenn' ),
		'off' => esc_attr__( 'Disable', 'newgenn' )
	),
	'default'  => 'off',
	'tooltip' => __('Disable by default. If you want to display the sidebars in your frontpage, turn this Enable.','newgenn'),
) );
//  animation section 

Newgenn_Kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-newgenn' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-newgenn'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-newgenn' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Newgenn_Kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-newgenn' ),
	'description'    => __( 'Custom JS', 'wbls-newgenn'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-newgenn' ),
	'section'  => 'custom_js_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ),
) ); 


// Tracking section 

Newgenn_Kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-newgenn' ),
	'description'    => __( 'Tracking Code', 'wbls-newgenn'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'analytics',
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-newgenn' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ),
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-newgenn' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'2' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-newgenn'),
) );

// color scheme section 

Newgenn_Kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-newgenn' ),
	'description'    => __( 'Select your color scheme', 'wbls-newgenn'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Newgenn_Kirki::add_field( 'newgenn', array(
			'settings' => 'color_scheme',
			'label'    => __( 'Select your color scheme', 'wbls-newgenn' ),
			'section'  => 'multiple_color_section',
			'type'     => 'palette',
			'choices'     => array(
	            '1' => array(
					'#ec1d23 ',
				),
				'2' => array(
					'#2d4e9a ',
				),
				'3' => array(
					'#01a89e ',
				),
				'4' => array(
					'#c25187',
				),
				'5' => array(
					'#5d1a59  ',
				),
				'6' => array(
					'#f38b25',
				),
			),
			'default' => '1',
			//'default'  => 'on',
		) );

//Social Network URL Section
newgenn_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-newgenn' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-newgenn'),
	'panel'			 => 'social_panel',
) );

newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-newgenn'),
) );
newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-newgenn' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-newgenn'),
) );

// flexslider section //

Newgenn_Kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-newgenn' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-newgenn'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-newgenn' ),
		'2' => esc_attr__( 'Slide', 'wbls-newgenn' )
	),
	'default'  => '2',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-newgenn' ),
		'2' => esc_attr__( 'Vertical', 'wbls-newgenn' )
	),
	'default'  => '1',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => 'on',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => 'on',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => 'on',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => 'on',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => 'off', 
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => 'off',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => 'off',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'off' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-newgenn' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Newgenn_Kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-newgenn' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-newgenn'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-newgenn' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'2' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => '2',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-newgenn' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-newgenn' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-newgenn' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'2' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => '2',
) );

//  portfolio settings //

Newgenn_Kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-newgenn' ),
) );

$post_per_page = get_option('posts_per_page');
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-newgenn' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-newgenn' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-newgenn' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-newgenn' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-newgenn'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-newgenn' ),
		2 => __( 'Show Without "All"', 'wbls-newgenn' ),
		3 => __( 'Hide', 'wbls-newgenn' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Newgenn_Kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-newgenn' ),
	'description'    => __( 'Light Box Settings', 'wbls-newgenn'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-newgenn' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-newgenn' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-newgenn' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-newgenn' ),
		'4' => esc_attr__( 'light-square', 'wbls-newgenn' ),
		'5' => esc_attr__( 'dark-square', 'wbls-newgenn' ),
		'6' => esc_attr__( 'facebook', 'wbls-newgenn' ),
	),
	'default'  => '1',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-newgenn' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-newgenn' ),
		'slow' => esc_attr__( 'Slow', 'wbls-newgenn' ),
		'normal' => esc_attr__( 'Normal', 'wbls-newgenn' ),
	),
	'default'  => 'fast',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-newgenn' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-newgenn' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'2' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => '2',
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-newgenn' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-newgenn'),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-newgenn' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-newgenn' ),
		'2' => esc_attr__( 'Disable', 'wbls-newgenn' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-newgenn' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#EC1D23',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'input[type="text"]:focus,.widget_testimonial-widget ul.flex-direction-nav li a:hover,
							input[type="email"]:focus,.dropcap-box,
							input[type="url"]:focus,.not-found-inner,
							input[type="password"]:focus,.widget_tag_cloud a,
							input[type="search"]:focus,ol.comment-list li.byuser article,
							ol.comment-list li.byuser .comment-author img
							textarea:focus,.webulous_page_navi li a:hover',
			'property' => 'border-color',
		),
		array(
			'element'  => '.widget-area h3.widget-title:after,.site-footer .widget-area h4.widget-title::after',
			'property' => 'border-left-color',
		),
		array(
			'element'  => '.withtip.top::after',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '.webulous_page_navi li.bpn-current,.widget-area h4.widget-title,.site-footer .footer-widgets h4.widget-title',
			'property' => 'border-bottom-color',
		),
		array(
			'element'  => '.top-nav ul li:hover a,.toggle .toggle-title:hover,.widget_testimonial-widget ul.flex-direction-nav li a:hover:before,
							.dropcap,.icon-left a.link-title,.error-404.not-found a,.widget_stat-widget .stats-circle .icon-wrapper h4,
							.icon-left .fa-stack,.error-404.not-found .page-header .page-title,.entry-header .header-entry-meta,
							.entry-body .header-entry-meta,.entry-header .entry-title-meta span:hover,
							.entry-body .entry-title-meta span:hover,.entry-header .entry-title-meta a:hover,
							.entry-body .entry-title-meta a:hover,.cnt-details .fa,.site-footer .circle-icon-box:hover .icon-wrapper .fa-stack i,
							.icon-right a.link-title,.related-posts ul#webulous-related-posts li a:hover,
							.icon-right .fa-stack,.stats-circle .icon-wrapper h4,.breadcrumb-wrap #breadcrumb a,.widget_recent-posts-gallery-widget .recent-post .post-title h5 a:hover,
							.ui-accordion .ui-accordion-header-active,.ui-accordion h3:hover span.ui-icon.fa,.widget-area .widget_rss a,.footer-bottom ul.menu a:hover,.site-footer .widget-area a:hover,.footer-bottom p a,
							.widget-area ul li a:hover,.widget_calendar table th a, .widget_calendar table td a,.comment-metadata a:hover,.hentry.post h1 a:hover,.page-links a,.post-wrapper .latest-post h5 a:hover',
			'property' => 'color',
		),
		array(
			'element'  => 'button,.widget_social-networks-widget ul li a,.portfolioeffects .portfolio_link_icons a,.widget_recent-work-widget .img-wrap:hover .overlay_icon a:hover,
							.widget.widget_skill-widget .skill-container .skill .skill-percentage,
							input[type="button"],.post-wrapper .latest-post a.btn-readmore:hover,.home .site-content #primary .services-wrapper div h1, .home .site-content #primary .services-wrapper div h2, .home .site-content #primary .services-wrapper div h3, .home .site-content #primary .services-wrapper div h5, .home .site-content #primary .services-wrapper div h6,
							.widget_calendar table caption,.ui-accordion .ui-accordion-header:hover,.flexslider ol.flex-control-paging li a.flex-active,
							input[type="reset"],.hentry.sticky,blockquote,blockquote:before,.services,.page-template-blog-fullwidth .entry-body a.more-link,
							.page-template-blog-large .entry-body a.more-link,.slicknav_nav li.current_page_item > a,
							.slicknav_nav li.current-menu-parent > a,.portfolio-readmore .btn-small,
							.slicknav_nav .slicknav_row:hover,
							.slicknav_nav a:hover,a.slicknav_btn:hover,
							.archive.category .entry-body a.more-link,
							input[type="submit"],.dropcap-circle,.widget_recent-work-widget h3:after, .circle-icon-box .icon-wrapper p.fa-stack:after, .widget_testimonial-widget h3:after, .sep:after, .icon-left .icon-title:after,
							.icon-right .icon-title:after, .wel-text h1:after, .title-divider h3:after, .title-seperator h3:after, .our-features h2:after,
							.dropcap-box,.pullnone,.pullnone:before,.pullleft,
							.pullright,.pullleft:before,.widget_testimonial-widget .flex-control-nav a.flex-active,
							.pullright:before,.circle-icon-box:after,.callout-widget a,
							.widget_button-widget .btn,.main-navigation ul ul li,.btn-normal,
							.webulous_page_navi li.bpn-next-link a,.withtip::before,
							.webulous_page_navi li.bpn-prev-link a,.widget_tag_cloud a:hover,	.portfolio2col.portfolioeffects:hover .content-details,
							.site-footer .scroll-to-top,.home .site-content #primary .services-wrapper div::after,.site-footer .scroll-to-top,.site-footer .scroll-to-top:hover',
			'property' => 'background-color',
		),
	),
) );

/*Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-newgenn' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#222222',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.site-content .navigation a,
							.site-content .more-link,
							.site-content .comment-navigation a,
							.webulous_page_navi li.bpn-current,
							.header-wrap .social ul li a,
							.comment-list > li article .comment-meta .comment-author b:hover,
							.comment-list > li article .comment-meta .comment-author a:hover,
							.comment-list > li article .comment-meta .comment-author cite:hover,
							.comment-list > li article .reply:hover i,
							#primary .sticky .entry-meta a,
					  		#primary .sticky .entry-footer a,
					  		.latest-post-content a.btn-readmore,
					  		.related-posts ul#webulous-related-posts li:hover a,
					  		.site-footer .footer-widgets .widget_archive select,
						    .site-footer .footer-widgets .widget_categories select,
						    .site-footer .footer-widgets .textwidget select,
						    .widget.widget_ourteam-widget .team-content h4 span,
						    .widget_recent-posts-widget .recent-post .readmore a,
						    .alert-message a,
						    .icon-right .icon-title,
							.icon-left .icon-title,
							.icon-right a.link-title,
							.icon-right .icon-title,
							.icon-right .fa-stack,
							.icon-left a.link-title,
							.icon-left .icon-title,
							.icon-left .fa-stack,
							.widget_testimonial-widget ul li .client,
							.single-portfolio .one-third dd a:hover,
							.newgenn-process.white-bg,
			  				.newgenn-process.white-bg h3.widget-title,
			  				.newgenn-process.white-bg .textwidget h4,
			  				.not-found-inner a:hover,
			  				.cnt-address .widget_text p:nth-of-type(1),
							.cnt-address .textwidget p:nth-of-type(1),
							#secondary.sidebar .widget_testimonial-widget h3',
			'property' => 'color',
		),
		array(
			'element' => 'table tr th:hover a,
			  				.site-header .social .recentcomments a:hover	
							.header-wrap .site-header .social .recentcomments a:hover,
							#primary .sticky a:hover,
							#primary .sticky span:hover,
							#primary .sticky time:hover,
							.left-sidebar .recentcomments a:hover,
							.left-sidebar .widget_rss a:hover,
							.wide-cta .call-btn a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),
		array(
			'element' => 'button:hover,
							input[type="button"]:hover,
							input[type="reset"]:hover,
							input[type="submit"]:hover,
							.footer-widgets .textwidget .wpcf7-form input.wpcf7-submit:hover,
							#nav-wrap,
							.main-navigation ul ul li,
							.site-content .more-link:hover,
							.webulous_page_navi li a,
							.webulous_page_navi li.bpn-next-link a,
			  				.webulous_page_navi li.bpn-prev-link a,
			  				.home .flexslider .slides .flex-caption a:hover,
			      			.home .flexslider .slides .flex-caption p a:hover,
			      			.home .flexslider .flex-control-paging li a,
			      			.share-box ul li a,
			      			.site-footer .widget_social-networks-widget ul li a:hover,
			      			#secondary select,
							.footer-widgets select,
							.widget.widget_ourteam-widget ul.team-social li a,
							.widget.widget_ourteam-widget:hover .team-social ul li a:hover,
							.widget.widget_skill-widget .skill-container .skill .skill-percentage,
							.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link,
							.widget_recent-work-widget .portfolio4col .overlay_icon a,
							#filters ul.filter-options li a:hover,
						    #filters ul.filter-options li a.selected,
						    .recent-work-container .recent_work_overlay a.icon-zoom,
						    .portfolioeffects .portfolio_link_icons a,
						    .flexslider .slides .flex-caption a:hover,
			      			.flexslider .slides .flex-caption p a:hover,
			      			.flexslider .flex-control-paging li a,
			      			.widget_recent-work-widget ul.flex-direction-nav a:hover,
			      			.widget_recent-posts-widget .recent-posts-carousel ul.flex-direction-nav a:hover,
			      			.recent-posts-slider .flex-direction-nav a:hover,
			      			.widget_recent-posts-widget .recent-posts-carousel .flex-control-nav li a,
			      			.recent-posts-slider .flex-control-paging li a,
			      			.flex-control-nav li a,
			      			.wide-default .widget_flexslider-widget .flexcarousel .flex-direction-nav a:hover,
			      			.page-slider ul.ei-slider-thumbs li a,
			      			a.btn-white:hover,
			  				.widget_button-widget .btn.white:hover,
			  				.toggle .toggle-title:hover,
			  				.circle-icon-box:hover .circle-icon-wrapper,
			  				.callout-widget .call-btn a,
			  				.wide-dark-grey .callout-widget p.call-btn a:hover,
			  				.widget_wbls-image-widget .image-widget-overlay:hover i:hover,
			  				.error-404.not-found .page-header,
			  				.cnt-form .wpcf7-form input[type="submit"]:hover,
			  				.site-footer .widget_social-networks-widget ul li a,
			  				#secondary.sidebar .callout-widget p.call-btn a:hover',
			'property' => 'background-color',
		),
        array(
			'element' => '.slicknav_menu,
				          .search-form input.search-submit:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element' => '.page-numbers,
				         .newgenn-process.white-bg .textwidget img',  
			'property' => 'border-color',
		),
		array(
			'element' => '.site-content .nav-next a span,
							.withtip.left:after,
							.home .flexslider .slides .flex-caption a:after,
			      			.home .flexslider .slides .flex-caption p a:after,
			      			.home .flexslider .flex-direction-nav .flex-nav-next a,
			      			#filters ul.filter-options li a:hover:before,
			        		#filters ul.filter-options li a.selected:before,
			        		.flexslider .slides .flex-caption a:after,
			      			.flexslider .slides .flex-caption p a:after,
			      			.flexslider .flex-direction-nav .flex-nav-next a,
			      			.widget_button-widget .btn.white:hover:after,
			      			.callout-widget .call-btn a:after,
			      			.wide-dark-grey .callout-widget p.call-btn a:hover:after,
			      			.widget_testimonial-widget .flex-direction-nav a.flex-next:hover',
			'property' => 'border-left-color',
		),
		array(
			'element' => 'abbr,acronym,.withtip.bottom:after',
			'property' => 'border-bottom-color',
		),
        array(
			'element' => '.withtip.right:after,.page-numbers:last-child,
			      			.site-content .nav-previous a span,
			      			.home .flexslider .flex-direction-nav .flex-nav-prev a,
			      			.flexslider .flex-direction-nav .flex-nav-prev a,
			      			a.btn-white:hover:before,
			    			.widget_button-widget .btn.white:hover:before,
			    			.callout-widget .call-btn a:before,
			    			.wide-dark-grey .callout-widget p.call-btn a:hover:before,
			    			.widget_testimonial-widget .flex-direction-nav a.flex-prev:hover',
			'property' => 'border-right-color',
		),
        array(
			'element' => '.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link:after',
			'property' => 'border-top-color',
		),
		array(
			'element' => '.site-footer .widget_social-networks-widget ul li a:after',
			'property' => 'border-top-color',
			'suffix' => '!important',
		),
		
	),
) );*/

 Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_bg',
	'label'    => __( 'Select Flexcaption Background Color', 'wbls-newgenn' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => 'rgba(37, 37, 37, 0.5)', 
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flexslider .flex-caption',
			'property' => 'background-color',	
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_align',
	'label'    => __( 'Select Flexcaption Alignment', 'wbls-newgenn' ),
	'section'  => 'flex_caption_section',
	'type'     => 'select',
	'default'  => 'center',
	'choices' => array(
		'left' => esc_attr__( 'Left', 'wbls-newgenn' ),
		'right' => esc_attr__( 'Right', 'wbls-newgenn' ),
		'center' => esc_attr__( 'Center', 'wbls-newgenn' ),
		'justify' => esc_attr__( 'Justify', 'wbls-newgenn' ),
	),
	'output'   => array(
		array(
			'element'  => '.home .flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption,.flexslider .slides .flex-caption h1, .flexslider .slides .flex-caption h2, .flexslider .slides .flex-caption h3, .flexslider .slides .flex-caption h4, .flexslider .slides .flex-caption h5, .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption p,.flexslider .slides .flex-caption',
			'property' => 'text-align',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),

) );
 Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_bg_position',
	'label'    => __( 'Select Flexcaption Background Horizontal Position', 'wbls-newgenn' ),
	'tooltip' => __('Select how far from left, Default value Left = 0( in % )','wbls-newgenn'),
	'section'  => 'flex_caption_section', 
	'type'     => 'number',
	'default'  => '0',
	'choices'     => array(
		'min'  => 0,
		'max'  => 64,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'left',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
 
) ); 
 Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'wbls-newgenn' ),
	'tooltip' => __('Select how far from bottom, Default value Bottom = 0 ( in % )','wbls-newgenn'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '0',
	'choices'     => array(
		'min'  => -10,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'bottom',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_bg_width',
	'label'    => __( 'Select Flexcaption Background Width', 'wbls-newgenn' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',  
	'tooltip' => __('Select Flexcaption Background Width , Default width value 100','wbls-newgenn'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .flex-caption',
			'property' => 'width',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),

) ); 

Newgenn_Kirki::add_field( 'newgenn', array(
	'settings' => 'flexcaption_color',
	'label'    => __( 'Select Flexcaption Font Color', 'wbls-newgenn' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '#ffffff', 
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption,.home .flexslider .slides .flex-caption p,
			.home .flexslider .slides .flex-caption p a,
			.flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1,
			 .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3,
			  .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, 
			  .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption h1,.flexslider .slides .flex-caption h2,.flexslider .slides .flex-caption h3,.flexslider .slides .flex-caption h4,.flexslider .slides .flex-caption h5,.flexslider .slides .flex-caption h6',
			'property' => 'color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
}



