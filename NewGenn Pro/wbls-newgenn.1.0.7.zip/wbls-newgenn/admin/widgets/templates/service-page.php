<div class="services-wrapper clearfix">
     <a class="service-page" href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark">  
        <div> 
	    	<?php if( has_post_thumbnail() ) : ?>
                <a href="<?php echo esc_url( get_permalink() ); ?>">                  <?php the_post_thumbnail('wbls-newgenn_service-img'); ?></a>
	    	<?php endif; ?>
            <?php the_title( sprintf( '<h4><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' ); ?>
    	    <?php the_content(); ?> 
       </div>
    </a>
</div> 


