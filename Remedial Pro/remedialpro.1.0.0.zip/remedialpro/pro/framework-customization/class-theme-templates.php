<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Remedial_Pro_Theme_templates' ) ) {  
	class Remedial_Pro_Theme_templates {
        public function remedial_pro_recent_post_template_file( $filename, $instance, $widget  ) {
           return get_stylesheet_directory() . '/pro/framework-customization/widgets/recentpost.php';  
        }
         public function remedial_pro_recent_work_template_file( $filename, $instance, $widget  ) {
           return get_stylesheet_directory() . '/pro/framework-customization/widgets/recent-work.php';  
        }
         public function remedial_pro_testimonial_template_file( $filename, $instance, $widget  ) {
           return get_stylesheet_directory() . '/pro/framework-customization/widgets/testimonial.php';  
        }
        public function remedial_pro_heading_template_file( $filename, $instance, $widget  ) {
           return get_stylesheet_directory() . '/pro/framework-customization/widgets/heading.php';  
        }
        public function remedial_pro_stats_template_file( $filename, $instance, $widget  ) {
           return get_stylesheet_directory() . '/pro/framework-customization/widgets/stats.php';  
        }
   
	}
}

         
