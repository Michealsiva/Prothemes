(function($){
	
  if( $.fn.doubleTapToGo ) {
    $( '#site-navigation li:has(ul)' ).doubleTapToGo();  
  }

})(jQuery);