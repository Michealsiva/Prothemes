<?php
/**
 * @package RemedialPro
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>> 
  <?php 
		$featured_image = get_theme_mod( 'featured_image',true );
	    if( $featured_image ) : ?>
			<div class="thumb"><?php
				if( function_exists( 'remedial_pro_featured_image' ) ) :
					remedial_pro_featured_image();
		        endif; ?>
		    </div><?php
		endif; ?> 
		<?php  
	    	if( has_post_format( 'gallery' ) ) { ?>			    	
		    	<div id="gallery-images">
			    	<ul class="slides"><?php
			    		$galleries = get_post_gallery_images( $post );
			    		 foreach ($galleries as $gallery) { ?>
					          <li><img src=<?php echo $gallery; ?>></li>
				    <?php } ?>
			    	</ul>  
		    	</div><?php 
	    	}
	      
	      do_action('remedial_pro_entry_header_before'); ?>

	    <div class="latest-content">
	        <header class="entry-header">  
			    <h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1>
				<?php if ( get_theme_mod('enable_single_post_top_meta', true ) ): ?>
					<footer class="entry-meta">
						<?php if(function_exists('remedial_pro_entry_top_meta') ) {
						    remedial_pro_entry_top_meta(); 
						} ?> 
					</footer><!-- .entry-footer -->
				<?php endif;
				 do_action('remedial_pro_entry_header_after'); ?>
			</header>

	            <div class="entry-content"><?php
					/* translators: %s: Name of current post */
					the_content(); ?>
				</div><?php

				wp_link_pages( array(
					'before' => '<div class="page-links">' . __( 'Pages:', 'remedial_pro' ),
					'after'  => '</div>',
				) );
			?>
		</div>
  <!-- .entry-content -->

    <?php do_action('remedial_pro_entry_footer_before'); ?>

		<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
			<footer class="entry-meta">
				<?php if(function_exists('remedial_pro_entry_bottom_meta') ) {
				     remedial_pro_entry_bottom_meta();
				} ?>
			</footer><!-- .entry-footer -->
		<?php endif; ?>

    <?php do_action('remedial_pro_entry_footer_after'); ?>

</article><!-- #post-## -->