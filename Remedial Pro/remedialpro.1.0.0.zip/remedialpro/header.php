
<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package RemedialPro
 */ 
?><!DOCTYPE html>    
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11"><?php
if ( is_singular() && pings_open() ) { ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>"><?php
} ?>
<?php wp_head(); ?>  
</head>

<body <?php body_class(); ?>>    

<div id="page" class="hfeed site <?php echo remedial_pro_site_style_class(); ?>">
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'remedial_pro' ); ?></a>
	<?php do_action('remedial_pro_before_header'); ?>
   <header id="masthead" class="site-header header-wrap <?php echo remedial_pro_site_style_header_class(); ?>" role="banner">

    <?php do_action('remedial_pro_header_navigation_before'); ?>

	    <div class="branding header-image">
	        <?php if ( get_theme_mod ('header_overlay',false ) ) { 
			   echo '<div class="overlay overlay-header"></div>';     
			} ?>
		    	
			<div class="container">
				<div class="five columns">
					<div class="top-left clearfix">
						<?php dynamic_sidebar('top-left' ); ?>  
					</div> 
				</div>
			   <div class="six columns">    
                   <div class="site-branding"><?php  
					   // $header_text = get_theme_mod( 'header_text' );
						$logo_title = get_theme_mod( 'logo_title' );
						$logo = get_theme_mod( 'logo', '' );  
						$tagline = get_theme_mod( 'tagline',true);
						if( $logo_title && function_exists( 'the_custom_logo' ) ) {
                            the_custom_logo();     
				        }elseif( $logo != '' && $logo_title ) { ?>
						   <h1 class="site-title img-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url($logo) ?>"></a></h1><?php
						}else { ?>
							<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1><?php
						} 
					    if( $tagline ) : ?>
							<p class="site-description"><?php bloginfo( 'description' ); ?></p><?php
					    endif; ?>
                    </div><!-- .site-branding -->
                </div>
                <div class="five columns">
					<div class="top-right clearfix">
						<?php dynamic_sidebar('top-right' ); ?>  
					</div>
				</div>
			</div>
		</div>
		<div class="nav-wrap">
			<div class="container">
				<nav id="site-navigation" class="main-navigation sixteen columns" role="navigation">
					<button class="menu-toggle" aria-controls="menu" aria-expanded="false"><?php echo apply_filters('remedial_pro_responsive_menu_title', __('Primary Menu','remedial_pro') ); ?></button>
					<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
				</nav><!-- #site-navigation -->	
			</div>	
		</div>
			<?php do_action('remedial_pro_header_navigation_end'); ?>

		
		<?php do_action('remedial_pro_header_navigation_after'); ?>
			

		<?php do_action('remedial_pro_after_primary_nav'); ?>
	
		<?php do_action('remedial_pro_header_end'); ?>

    </header><!-- #masthead -->
	<?php do_action('remedial_pro_header_after');

  

