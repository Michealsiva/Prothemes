<?php  
/**
 * Created by PhpStorm.
 * User: venkat
 * Date: 2/5/16
 * Time: 4:32 PM        
 */    
           
include_once( get_template_directory() . '/admin/kirki/kirki.php' );   
include_once( get_template_directory() . '/admin/kirki-helpers/class-theme-kirki.php' ); 
     

Remedial_Kirki::add_config( 'remedial_pro', array(     
    'capability'    => 'edit_theme_options',                  
    'option_type'   => 'theme_mod',          
) );               
     
// Flat option start //   

//  site identity section // 

Remedial_Kirki::add_section( 'title_tagline', array(
    'title'          => __( 'Site Identity','remedial_pro' ),
    'description'    => __( 'Site Header Options', 'remedial_pro'),       
    'priority'       => 8,                                                                                                                
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'logo_title',
    'label'    => __( 'Enable Logo as Title', 'remedial_pro' ),
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'priority' => 5,
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' )
    ),
    'default'  => 'off',   
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'tagline',
    'label'    => __( 'Show site Tagline', 'remedial_pro' ), 
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' )
    ),
    'default'  => 'on',
) );  

// home panel //

Remedial_Kirki::add_panel( 'home_options', array(     
    'title'       => __( 'Home', 'remedial_pro' ),
    'description' => __( 'Home Page Related Options', 'remedial_pro' ),     
) );  


// home page type section

 Remedial_Kirki::add_section( 'home-remedial', array(
    'title'          => __( 'PRO Home - General Settings','remedial_pro' ),
    'description'    => __( 'Home Page options', 'remedial_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'enable_home_default_content',
    'label'    => __( 'Enable Home Page Default Content', 'remedial_pro' ),
    'section'  => 'home-remedial',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Use pagebuilder to built pro home page (or) Use prebuilt layout','remedial_pro'),
) );  


// Slider section   

Remedial_Kirki::add_section( 'slider-section', array(
    'title'          => __( 'Slider Section','remedial_pro' ),
    'description'    => __( 'Home Page Slider Related Options', 'remedial_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );
Remedial_Kirki::add_field( 'remedial_pro', array(  
    'settings' => 'slider_field',  
    'label'    => __( 'Enable Slider Post ( Section )', 'remedial_pro' ),
    'section'  => 'slider-section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Slider Post in home page','remedial_pro'),
) );
 
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'slider_cat',
    'label'    => __( 'Slider Posts category', 'remedial_pro' ),
    'section'  => 'slider-section',
    'type'     => 'select',
    'choices' => Kirki_Helper::get_terms( 'category' ),
    'active_callback' => array(
        array(
            'setting'  => 'slider_field', 
            'operator' => '==',
            'value'    => true, 
        ),
    ),
    'tooltip' => __('Create post ( Goto Dashboard => Post => Add New ) and Post Featured Image ( Preferred size is 1200 x 450 pixels ) as taken as slider image and Post Content as taken as Flexcaption.','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'slider_count',
    'label'    => __( 'No. of Sliders', 'remedial_pro' ),
    'section'  => 'slider-section',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 999,
        'step' => 1,
    ),
    'default'  => 2,
    'active_callback' => array(
        array(
            'setting'  => 'slider_field',
            'operator' => '==',
            'value'    => true,
        ),                                                                             
    ),
    'tooltip' => __('Enter number of slides you want to display under your selected Category','remedial_pro'),
) );

// service section 

Remedial_Kirki::add_section( 'service_section', array(
    'title'          => __( 'Service Section','remedial_pro' ),
    'description'    => __( 'Home Page - Service Related Options', 'remedial_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Remedial_Kirki::add_field( 'remedial_pro', array(  
    'settings' => 'service_section_status',  
    'label'    => __( 'Enable Service Section', 'remedial_pro' ),
    'section'  => 'service_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Service section in home page','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'service_section_title',
    'label'    => __( 'Service Section Title & Description', 'remedial_pro' ),
    'section'  => 'service_section',
    'type'     => 'dropdown-pages', 
    'active_callback' => array(
        array(
            'setting'  => 'service_section_status',
            'operator' => '==',
            'value'    => true,
        ),                                                                       
    ),
) );

for ( $i = 1 ; $i <= 6 ; $i++ ) {
    //Create the settings Once, and Loop through it.
    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'service_section_icon_'.$i,
        'label'    => sprintf(__( 'Service Section Icons #%1$s', 'remedial_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'text',
        'description' => sprintf(__( '%1$s (fa fa-apple) ', 'remedial_pro' ), '<a href="http://fontawesome.io/icons/">Type FontAwesome icons</a>' ),          
        'active_callback' => array(
            array(
                'setting'  => 'service_section_status',
                'operator' => '==',
                'value'    => true,
            ),                                                                       
        ),
    ) ); 

    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'service_section_'.$i,
        'label'    => sprintf(__( 'Service Section #%1$s', 'remedial_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'dropdown-pages', 
        'active_callback' => array(
            array(
                'setting'  => 'service_section_status',
                'operator' => '==',
                'value'    => true,
            ),          
        ),    
    ) );
    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'service_color_'.$i,
        'label'    => sprintf(__( 'Choose Service Section Icons #%1$s', 'remedial_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'color', 
        'active_callback' => array(
            array(
                'setting'  => 'service_section_status',
                'operator' => '==',
                'value'    => true,
            ),                                                                        
        ),        
    ) );
}
 
// Image section 

Remedial_Kirki::add_section( 'about-us-section', array(
    'title'          => __( 'About Us Section','remedial_pro' ),
    'description'    => __( 'Home Page - Related Options', 'remedial_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Remedial_Kirki::add_field( 'remedial_pro', array(  
    'settings' => 'aboutus_section_status',  
    'label'    => __( 'Enable this Section to show', 'remedial_pro' ),
    'section'  => 'about-us-section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable About Us section in home page','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'aboutus_section_title',
    'label'    => __( 'About Us Section Title & Description', 'remedial_pro' ),
    'section'  => 'about-us-section',
    'type'     => 'dropdown-pages', 
    'active_callback' => array(
        array(
            'setting'  => 'aboutus_section_status',
            'operator' => '==',
            'value'    => true,
        ),          
    ),    
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'aboutus_section_form',
    'label'    => __( 'AboutUs Form', 'remedial_pro' ),
    'description' => __('Copy and paste the shortcode of the form from the contact form 7', 'remedial_pro'),
    'section'  => 'about-us-section',
    'type'     => 'text', 
    'sanitize_callback' => 'wp_kses_post',
    'active_callback' => array(
        array(
            'setting'  => 'aboutus_section_status',
            'operator' => '==',
            'value'    => true,
        ),          
    ),
) );

// latest blog section 

Remedial_Kirki::add_section( 'latest_blog_section', array(
    'title'          => __( 'Latest Blog Section','remedial_pro' ),
    'description'    => __( 'Home Page - Latest Blog Options', 'remedial_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'enable_recent_post_service',
    'label'    => __( 'Enable Recent Post Section', 'remedial_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),

    'default'  => 'on',
    'tooltip' => __('Enable recent post section in home page','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'recent_post_section_title',
    'label'    => __( 'Recent Post Section Title & Description', 'remedial_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'dropdown-pages', 
    'active_callback' => array(
        array(
            'setting'  => 'enable_recent_post_service',
            'operator' => '==',
            'value'    => true,
        ),

    ),
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'recent_posts_count',
    'label'    => __( 'No. of Recent Posts', 'remedial_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'number',
    'choices' => array(
        'min' => 2,
        'max' => 99,
        'step' => 2,
    ),
    'default'  =>3,
    'active_callback' => array(
        array(
            'setting'  => 'enable_recent_post_service',
            'operator' => '==',
            'value'    => true,
        ),

    ),
) );


// general panel      

Remedial_Kirki::add_panel( 'general_panel', array(   
    'title'       => __( 'General Settings', 'remedial_pro' ),  
    'description' => __( 'general settings', 'remedial_pro' ),         
) );
//  Page title bar section // 

Remedial_Kirki::add_section( 'header-pagetitle-bar', array(   
    'title'          => __( 'Page Title Bar & Breadcrumb','remedial_pro' ),
    'description'    => __( 'Page Title bar related options', 'remedial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) ); 
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'global_page_title_bar',
    'label'    => __( 'Check the box if you want to use a global page title bar settings. This option overrides the page options', 'remedial_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'checkbox',
    'default' => '0',
) );   

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'page_titlebar',  
    'label'    => __( 'Page Title Bar', 'remedial_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( 'Show Bar and Content', 'remedial_pro' ),
        2 => __('Hide','remedial_pro'),
    ),
    'default' => 1,
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'page_titlebar_text',  
    'label'    => __( 'Page Title Bar Text', 'remedial_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        0 => __( 'Show', 'remedial_pro' ),
        1 => __( 'Hide', 'remedial_pro' ), 
    ),
    'default' => 0,
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'breadcrumb',  
    'label'    => __( 'Hide Breadcrumb', 'remedial_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'checkbox',
    'default'  => 0,
) ); 

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'breadcrumb_char',
    'label'    => __( 'Breadcrumb Character', 'remedial_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( ' >> ', 'remedial_pro' ),
        2 => __( ' / ', 'remedial_pro' ),
        3 => __( ' > ', 'remedial_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'breadcrumb',
            'operator' => '==',
            'value'    => 0,
        ),
    ),
    //'sanitize_callback' => 'allow_htmlentities'
) );

//  pagination section // 

Remedial_Kirki::add_section( 'general-pagination', array(   
    'title'          => __( 'Pagination','remedial_pro' ),
    'description'    => __( 'Pagination related options', 'remedial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'numeric_pagination',
    'label'    => __( 'Numeric Pagination', 'remedial_pro' ),   
    'section'  => 'general-pagination',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Numbered', 'remedial_pro' ),
        'off' => esc_attr__( 'Next/Previous', 'remedial_pro' )
    ),
    'default'  => 'on',
) );

// skin color panel 

Remedial_Kirki::add_panel( 'skin_color_panel', array(   
    'title'       => __( 'Skin Color', 'remedial_pro' ),  
    'description' => __( 'Color Settings', 'remedial_pro' ),         
) );
// color scheme section 

Remedial_Kirki::add_section( 'multiple_color_section', array(
    'title'          => __( 'Color Scheme','remedial_pro' ),
    'description'    => __( 'Select your color scheme', 'remedial_pro'),
    'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 9,
) );  

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'color_scheme',
    'label'    => __( 'Select your color scheme', 'remedial_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'palette',
    'choices'     => array( 
        '1' => array( 
            '#2591fd',
        ),
        '2' => array(
            '#00aea3',
        ),
        '3' => array(
            '#ec008f',
        ),
        '4' => array(
            '#00ca56',
        ),
        '5' => array(
            '#8f39a9',
        ),
        '6' => array(
            '#F4A106',
        ),
    ),
    'default' => '1',
//'default'  => 'on',
) );

//custom color stylesheet 

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'enable_custom_color_scheme',
    'label'    => __( 'Enable Custom color scheme', 'remedial_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' )
    ),
    'default'  => 'off',
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'custom_color_scheme',
    'label'    => __( 'Select custom color scheme', 'remedial_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'color',
    'default'  => '#2591fd',
    'alpha'  => false,
    'active_callback' => array(
        array (
            'setting'  => 'enable_custom_color_scheme',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) ); 

/* pagebuilder style override */
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'enable_so_custom_color',
    'label'    => __( 'Enable this Option to change color choosen by pagebuilder', 'remedial_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' )
    ),
    'default'  => 'off',
    'tooltip' => __('while change the color scheme this option is also change the pagebuilder row and widget related option color in order to match color scheme','remedial_pro'),

) );

// typography panel //  

Remedial_Kirki::add_panel( 'typography', array( 
    'title'       => __( 'Typography', 'remedial_pro' ),
    'description' => __( 'Typography and Link Color Settings', 'remedial_pro' ),
) );
   
    Remedial_Kirki::add_section( 'typography_section', array(
        'title'          => __( 'General Settings','remedial_pro' ),
        'description'    => __( 'General Settings', 'remedial_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );
        

    Remedial_Kirki::add_section( 'body_font', array(
        'title'          => __( 'Body Font','remedial_pro' ), 
        'description'    => __( 'Specify the body font properties', 'remedial_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) ); 

    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'body_typography',
        'label'    => __( 'Enable Custom body Settings', 'remedial_pro' ),
        'section'  => 'body_font',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
            'off' => esc_attr__( 'Disable', 'remedial_pro' )
        ),
        'tooltip' => __('Turn on to body typography and turn off for default typography','remedial_pro'),
        'default'  => 'off',
    ) );


    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'body',
        'label'    => __( 'Body Settings', 'remedial_pro' ),
        'section'  => 'body_font', 
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Open Sans', 
            'variant'        => 'regular',
            'font-size'      => '16px',  
            'line-height'    => '1.5',
            'letter-spacing' => '0',
            'color'          => '#222222', 
        ),
        'output'      => array(
            array(
                'element' => 'body',
                //'suffix' => '!important',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'body_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );


    Remedial_Kirki::add_section( 'heading_section', array(
        'title'          => __( 'Heading Font','remedial_pro' ),
        'description'    => __( 'Specify typography of H1, H2, H3, H4, H5, H6', 'remedial_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'heading_one_typography',
        'label'    => __( 'Enable Custom H1 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
            'off' => esc_attr__( 'Disable', 'remedial_pro' )
        ),
        'tooltip' => __('Turn on to H1 typography and turn off for default typography','remedial_pro'),
        'default'  => 'off',
    ) );

 
    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'h1',  
        'label'    => __( 'H1 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Bitter',
            'variant'        => '700',
            'font-size'      => '48px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h1',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_one_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );
    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'heading_two_typography',
        'label'    => __( 'Enable Custom H2 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
            'off' => esc_attr__( 'Disable', 'remedial_pro' )
        ),
        'tooltip' => __('Turn on to H2 typography and turn off for default typography','remedial_pro'),
        'default'  => 'off',
    ) );


    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'h2',
        'label'    => __( 'H2 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Bitter',
            'variant'        => '700',
            'font-size'      => '36px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h2',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_two_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'heading_three_typography',
        'label'    => __( 'Enable Custom H3 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
            'off' => esc_attr__( 'Disable', 'remedial_pro' )
        ),
        'tooltip' => __('Turn on to H3 typography and turn off for default typography','remedial_pro'),
        'default'  => 'off',
    ) );


    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'h3',
        'label'    => __( 'H3 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default' => array(
            'font-family'    => 'Bitter',
            'variant'        => '700',
            'font-size'      => '30px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h3',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_three_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'heading_four_typography',
        'label'    => __( 'Enable Custom H4 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
            'off' => esc_attr__( 'Disable', 'remedial_pro' )
        ),
        'tooltip' => __('Turn on to H4 typography and turn off for default typography','remedial_pro'),
        'default'  => 'off',
    ) );


    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'h4',
        'label'    => __( 'H4 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Bitter',
            'variant'        => '700',
            'font-size'      => '24px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h4',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_four_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'heading_five_typography',
        'label'    => __( 'Enable Custom H5 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
            'off' => esc_attr__( 'Disable', 'remedial_pro' )
        ),
        'tooltip' => __('Turn on to H5 typography and turn off for default typography','remedial_pro'),
        'default'  => 'off',
    ) );



    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'h5',
        'label'    => __( 'H5 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Bitter',
            'variant'        => '700',
            'font-size'      => '18px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h5',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_five_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );

    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'heading_six_typography',
        'label'    => __( 'Enable Custom H6 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
            'off' => esc_attr__( 'Disable', 'remedial_pro' )
        ),
        'tooltip' => __('Turn on to H6 typography and turn off for default typography','remedial_pro'),
        'default'  => 'off',
    ) );



    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'h6',
        'label'    => __( 'H6 Settings', 'remedial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Bitter', 
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h6',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_six_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    // navigation font 
    Remedial_Kirki::add_section( 'navigation_section', array(
        'title'          => __( 'Navigation Font','remedial_pro' ),
        'description'    => __( 'Specify Navigation font properties', 'remedial_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'navigation_font_status',
        'label'    => __( 'Enable Navigation Font Settings', 'remedial_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
            'off' => esc_attr__( 'Disable', 'remedial_pro' )
        ),
        'tooltip' => __('Turn on to Navigation Font typography and turn off for default typography','remedial_pro'),
        'default'  => 'off',
    ) );

    Remedial_Kirki::add_field( 'remedial_pro', array(
        'settings' => 'navigation_font',
        'label'    => __( 'Navigation Font Settings', 'remedial_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Open Sans',
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8', 
            'letter-spacing' => '0',
            'color'          => '#ffffff',
        ),
        'output'      => array(
            array(
                'element' => '.main-navigation a',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'navigation_font_status',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );



// header panel //  

Remedial_Kirki::add_panel( 'header_panel', array(     
    'title'       => __( 'Header', 'remedial_pro' ),
    'description' => __( 'Header Related Options', 'remedial_pro' ), 
) );  

/* STICKY HEADER section */     
  
Remedial_Kirki::add_section( 'stricky_header', array(
    'title'          => __( 'Sticky Menu','remedial_pro' ),
    'description'    => __( 'sticky header', 'remedial_pro'),
    'panel'          => 'header_panel', // Not typically needed.
) );
Remedial_Kirki::add_field( 'remedial_pro', array(    
    'settings' => 'sticky_header',
    'label'    => __( 'Enable Sticky Header', 'remedial_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' )
    ),
    'default'  => 'on',
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'sticky_header_position',
    'label'    => __( 'Enable Sticky Header Position', 'remedial_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'top'  => esc_attr__( 'Top', 'remedial_pro' ),
        'bottom' => esc_attr__( 'Bottom', 'remedial_pro' )
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'sticky_header',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'top',
) );


/*
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'header_top_margin',
    'label'    => __( 'Header Top Margin', 'remedial_pro' ),
    'description' => __('Select the top margin of header in pixels','remedial_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'header_bottom_margin',
    'label'    => __( 'Header Bottom Margin', 'remedial_pro' ),
    'description' => __('Select the bottom margin of header in pixels','remedial_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );*/

Remedial_Kirki::add_section( 'header_image', array(
    'title'          => __( 'Header Background Video & Image','remedial_pro' ),
    'description'    => __( 'Custom Header Video & Image options', 'remedial_pro'),
    'panel'          => 'header_panel', // Not typically needed.  
) );

Remedial_Kirki::add_field( 'remedial_pro', array(   
    'settings' => 'header_bg_size',
    'label'    => __( 'Header Background Size', 'remedial_pro' ),
    'section'  => 'header_image',
    'type'     => 'radio-buttonset', 
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'remedial_pro' ),
        'contain' => esc_attr__( 'Contain', 'remedial_pro' ),
        'auto'  => esc_attr__( 'Auto', 'remedial_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'remedial_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Header Background Image Size','remedial_pro'),
) );

/*Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'header_height',
    'label'    => __( 'Header Background Image Height', 'remedial_pro' ),
    'section'  => 'header_image',
    'type'     => 'number',
    'choices' => array(
        'min' => 100,
        'max' => 600,
        'step' => 1,
    ),
    'default'  => '213',
) ); */
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'header_bg_repeat',
    'label'    => __( 'Header Background Repeat', 'remedial_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'remedial_pro'),
        'repeat' => esc_attr__('Repeat', 'remedial_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','remedial_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'repeat',  
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'header_bg_position', 
    'label'    => __( 'Header Background Position', 'remedial_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'remedial_pro'),
        'center center' => esc_attr__('Center Center', 'remedial_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'remedial_pro'),
        'left top' => esc_attr__('Left Top', 'remedial_pro'),
        'left center' => esc_attr__('Left Center', 'remedial_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'remedial_pro'),
        'right top' => esc_attr__('Right Top', 'remedial_pro'),
        'right center' => esc_attr__('Right Center', 'remedial_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'center center',  
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'header_bg_attachment',
    'label'    => __( 'Header Background Attachment', 'remedial_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'remedial_pro'),
        'fixed' => esc_attr__('Fixed', 'remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'scroll',  
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'header_overlay',
    'label'    => __( 'Enable Header( Background ) Overlay', 'remedial_pro' ),
    'section'  => 'header_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' )
    ),
    'default'  => 'off',
) );
  
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'header_overlay_color',
    'label'    => __( 'Header Overlay ( Background )color', 'remedial_pro' ),
    'section'  => 'header_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'output'   => array(
        array(
            'element'  => '.overlay-header',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

/*
/* e-option start */
/*
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'custon_favicon',
    'label'    => __( 'Custom Favicon', 'remedial_pro' ),
    'section'  => 'header',
    'type'     => 'upload',
    'default'  => '',
) ); */
/* e-option start */ 
/* Blog page section */


/* Blog panel */

Remedial_Kirki::add_panel( 'blog_panel', array(     
    'title'       => __( 'Blog', 'remedial_pro' ),
    'description' => __( 'Blog Related Options', 'remedial_pro' ),     
) ); 
Remedial_Kirki::add_section( 'blog', array(
    'title'          => __( 'Blog Page','remedial_pro' ),
    'description'    => __( 'Blog Related Options', 'remedial_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
  
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'blog_layout',
    'label'    => __( 'Select Blog Page Layout you prefer', 'remedial_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1  => esc_attr__( 'Default ( One Column )', 'remedial_pro' ),
        2 => esc_attr__( 'Two Columns ', 'remedial_pro' ),
        3 => esc_attr__( 'Three Columns ( Without Sidebar ) ', 'remedial_pro' ),
        4 => esc_attr__( 'Two Columns With Masonry', 'remedial_pro' ),
        5 => esc_attr__( 'Three Columns With Masonry ( Without Sidebar ) ', 'remedial_pro' ),
        6 => esc_attr__( 'Blog FullWidth', 'remedial_pro' ),
    ),
    'default'  => 1,
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'featured_image',
    'label'    => __( 'Enable Featured Image', 'remedial_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for blog page','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'more_text',
    'label'    => __( 'More Text', 'remedial_pro' ),
    'section'  => 'blog',
    'type'     => 'text',
    'description' => __('Text to display in case of text too long','remedial_pro'),
    'default' => __('Read More','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'featured_image_size',
    'label'    => __( 'Choose the Featured Image Size for Blog Page', 'remedial_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1 => esc_attr__( 'Large Featured Image', 'remedial_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'remedial_pro' ),
        3 => esc_attr__( 'Original Size', 'remedial_pro' ),
        4 => esc_attr__( 'Medium', 'remedial_pro' ),
        5 => esc_attr__( 'Large', 'remedial_pro' ), 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Set large and medium image size: Goto Dashboard => Settings => Media', 'remedial_pro') ,
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'enable_single_post_top_meta',
    'label'    => __( 'Enable to display top post meta data', 'remedial_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'single_post_top_meta',
    'label'    => __( 'Activate and Arrange the Order of Top Post Meta elements', 'remedial_pro' ),
    'section'  => 'blog',
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'remedial_pro' ),
        2 => esc_attr__( 'author', 'remedial_pro' ),
        3 => esc_attr__( 'comment', 'remedial_pro' ),
        4 => esc_attr__( 'category', 'remedial_pro' ),
        5 => esc_attr__( 'tags', 'remedial_pro' ),
        6 => esc_attr__( 'edit', 'remedial_pro' ),
    ),
    'default'  => array(1, 2, 3,6),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_top_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','remedial_pro'),

) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'enable_single_post_bottom_meta',
    'label'    => __( 'Enable to display bottom post meta data', 'remedial_pro' ),
    'section'  => 'blog', 
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','remedial_pro'),
    'default'  => 'on',
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'single_post_bottom_meta',
    'label'    => __( 'Activate and arrange the Order of Bottom Post Meta elements', 'remedial_pro' ),
    'section'  => 'blog',    
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'remedial_pro' ),
        2 => esc_attr__( 'author', 'remedial_pro' ),
        3 => esc_attr__( 'comment', 'remedial_pro' ),
        4 => esc_attr__( 'category', 'remedial_pro' ),
        5 => esc_attr__( 'tags', 'remedial_pro' ),
        6 => esc_attr__( 'edit', 'remedial_pro' ),
    ),
    'default'  => array(4,5),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_bottom_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','remedial_pro'),
) );


/* Single Blog page section */

Remedial_Kirki::add_section( 'single_blog', array(
    'title'          => __( 'Single Blog Page','remedial_pro' ),
    'description'    => __( 'Single Blog Page Related Options', 'remedial_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'single_featured_image',
    'label'    => __( 'Enable Single Post Featured Image', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for Single Post Page','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'single_featured_image_size',
    'label'    => __( 'Choose the featured image display type for Single Post Page', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Large Featured Image', 'remedial_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'remedial_pro' ),
        3 => esc_attr__( 'FullWidth Featured Image', 'remedial_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'author_bio_box',
    'label'    => __( 'Enable Author Bio Box below single post', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'off',
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'related_posts',
    'label'    => __( 'Show Related Posts', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Show the Related Post for Single Blog Page','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'related_posts_hierarchy',
    'label'    => __( 'Related Posts Must Be Shown As:', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Related Posts By Tags', 'remedial_pro' ),
        2 => esc_attr__( 'Related Posts By Categories', 'remedial_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'related_posts',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Select the Hierarchy','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'comments',
    'label'    => __( ' Show Comments', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Show the Comments for Single Blog Page','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'social_sharing_box',
    'label'    => __( 'Show social sharing options box below single post', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
) );

//social sharing box section

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'facebook_sb',
    'label'    => __( 'Enable facebook sharing option below single post', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'twitter_sb',
    'label'    => __( 'Enable twitter sharing option below single post', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'linkedin_sb',
    'label'    => __( 'Enable linkedin sharing option below single post', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'google-plus_sb',
    'label'    => __( 'Enable googleplus sharing option below single post', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'email_sb',
    'label'    => __( 'Enable email sharing option below single post', 'remedial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
/* FOOTER SECTION 
footer panel */

Remedial_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'remedial_pro' ),
    'description' => __( 'Footer Related Options', 'remedial_pro' ),     
) );  

Remedial_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','remedial_pro' ),
    'description'    => __( 'Footer related options', 'remedial_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'remedial_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','remedial_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'remedial_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'remedial_pro' ),
        2  => esc_attr__( '2', 'remedial_pro' ),
        3  => esc_attr__( '3', 'remedial_pro' ),
        4  => esc_attr__( '4', 'remedial_pro' ),
    ),
    'default'  => 3,
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'remedial_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'remedial_pro' ),
    'description' => __('Select the top margin of footer in pixels','remedial_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Remedial_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','remedial_pro' ),
    'description'    => __( 'Custom Footer Image options', 'remedial_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'remedial_pro' ),
        'contain' => esc_attr__( 'Contain', 'remedial_pro' ),
        'auto'  => esc_attr__( 'Auto', 'remedial_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'remedial_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'remedial_pro'),
        'repeat' => esc_attr__('Repeat', 'remedial_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','remedial_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',   
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'remedial_pro'),
        'center center' => esc_attr__('Center Center', 'remedial_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'remedial_pro'),
        'left top' => esc_attr__('Left Top', 'remedial_pro'),
        'left center' => esc_attr__('Left Center', 'remedial_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'remedial_pro'),
        'right top' => esc_attr__('Right Top', 'remedial_pro'),
        'right center' => esc_attr__('Right Center', 'remedial_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'remedial_pro'),
        'fixed' => esc_attr__('Fixed', 'remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' )
    ),
    'default'  => 'off',
) );
  
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer_image',
            'property' => 'background-color',
        ),
    ),
) );


// single page section //

Remedial_Kirki::add_section( 'single_page', array(
    'title'          => __( 'Single Page','remedial_pro' ),
    'description'    => __( 'Single Page Related Options', 'remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'single_page_featured_image',
    'label'    => __( 'Enable Single Page Featured Image', 'remedial_pro' ),
    'section'  => 'single_page',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'single_page_featured_image_size',
    'label'    => __( 'Single Page Featured Image Size', 'remedial_pro' ),
    'section'  => 'single_page',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( 'Normal', 'remedial_pro' ),
        2 => esc_attr__( 'FullWidth', 'remedial_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_page_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

// Layout section //

Remedial_Kirki::add_section( 'layout', array( 
    'title'          => __( 'Layout','remedial_pro' ),
    'description'    => __( 'Layout Related Options', 'remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'site-style',
    'label'    => __( 'Site Style', 'remedial_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'wide' =>  esc_attr__('Wide', 'remedial_pro'),
        'boxed' =>  esc_attr__('Boxed', 'remedial_pro'),
        'fluid' =>  esc_attr__('Fluid', 'remedial_pro'),  
        //'static' =>  esc_attr__('Static ( Non Responsive )', 'remedial_pro'),
    ),
    'default'  => 'wide',
    'tooltip' => __('Choose the default site layout.','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'global_sidebar_layout',
    'label'    => __( 'Check the box if you want to use a global sidebar on all pages. This option overrides the page options', 'remedial_pro' ),
    'section'  => 'layout',
    'type'     => 'checkbox',
    'default' => '0',
) );


Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'sidebar_position',
    'label'    => __( 'Main Layout', 'remedial_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-image',   
    'description' => __('Select main content and sidebar arrangement.','remedial_pro'),
    'choices' => array(
        'left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cl.png',
        'right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cr.png',
        'two-sidebar' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cm.png',  
        'two-sidebar-left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cl.png',
        'two-sidebar-right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cr.png',
        'fullwidth' =>  get_template_directory_uri() . '/admin/kirki/assets/images/1c.png',
        'no-sidebar' =>  get_template_directory_uri() . '/images/no-sidebar.png',
    ),
    'default'  => 'right', 
    'tooltip' => __('global sidebar on all pages. This option overrides the page layout sidebar options','remedial_pro'),
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'body_top_margin',
    'label'    => __( 'Body Top Margin', 'remedial_pro' ),
    'description' => __('Select the top margin of body element in pixels','remedial_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-top',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'body_bottom_margin',
    'label'    => __( 'Body Bottom Margin', 'remedial_pro' ),
    'description' => __('Select the bottom margin of body element in pixels','remedial_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-bottom',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );

/* LAYOUT SECTION  */
/*
Remedial_Kirki::add_section( 'layout', array(
    'title'          => __( 'Layout','remedial_pro' ),   
    'description'    => __( 'Layout settings that affects overall site', 'remedial_pro'),
    'panel'          => 'remedial_pro_options', // Not typically needed.
) );



Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'primary_sidebar_width',
    'label'    => __( 'Primary Sidebar Width', 'remedial_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'remedial_pro' ),
        '2' => __( 'Two Column', 'remedial_pro' ),
        '3' => __( 'Three Column', 'remedial_pro' ),
        '4' => __( 'Four Column', 'remedial_pro' ),
        '5' => __( 'Five Column ', 'remedial_pro' ),
    ),
    'default'  => '5',  
    'tooltip' => __('Select the width of the Primary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'secondary_sidebar_width',
    'label'    => __( 'Secondary Sidebar Width', 'remedial_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'remedial_pro' ),
        '2' => __( 'Two Column', 'remedial_pro' ),
        '3' => __( 'Three Column', 'remedial_pro' ),
        '4' => __( 'Four Column', 'remedial_pro' ),
        '5' => __( 'Five Column ', 'remedial_pro' ),
    ),            
    'default'  => '5',  
    'tooltip' => __('Select the width of the Secondary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','remedial_pro'),
) ); 

*/

/* FOOTER SECTION 
footer panel */

Remedial_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'remedial_pro' ),
    'description' => __( 'Footer Related Options', 'remedial_pro' ),     
) );  

Remedial_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','remedial_pro' ),
    'description'    => __( 'Footer related options', 'remedial_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'remedial_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','remedial_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'remedial_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'remedial_pro' ),
        2  => esc_attr__( '2', 'remedial_pro' ),
        3  => esc_attr__( '3', 'remedial_pro' ),
        4  => esc_attr__( '4', 'remedial_pro' ),
    ),
    'default'  => 4,
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'remedial_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'remedial_pro' ),
    'description' => __('Select the top margin of footer in pixels','remedial_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Remedial_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','remedial_pro' ),
    'description'    => __( 'Custom Footer Image options', 'remedial_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'remedial_pro' ),
        'contain' => esc_attr__( 'Contain', 'remedial_pro' ),
        'auto'  => esc_attr__( 'Auto', 'remedial_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'remedial_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'remedial_pro'),
        'repeat' => esc_attr__('Repeat', 'remedial_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','remedial_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'remedial_pro'),
        'center center' => esc_attr__('Center Center', 'remedial_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'remedial_pro'),
        'left top' => esc_attr__('Left Top', 'remedial_pro'),
        'left center' => esc_attr__('Left Center', 'remedial_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'remedial_pro'),
        'right top' => esc_attr__('Right Top', 'remedial_pro'),
        'right center' => esc_attr__('Right Center', 'remedial_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'remedial_pro'),
        'fixed' => esc_attr__('Fixed', 'remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' )
    ),
    'default'  => 'off',
) );
  
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'remedial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.overlay-footer',
            'property' => 'background-color',
        ),
    ),
) );


 if( class_exists( 'WooCommerce' ) ) {
    Remedial_Kirki::add_section( 'woocommerce_section', array(
        'title'          => __( 'WooCommerce','remedial_pro' ),
        'description'    => __( 'Theme options related to woocommerce', 'remedial_pro'),
        'priority'       => 11, 
        'theme_supports' => '', // Rarely needed.
    ) );
    Remedial_Kirki::add_field( 'woocommerce', array(
        'settings' => 'woocommerce_sidebar',
        'label'    => __( 'Enable Woocommerce Sidebar', 'remedial_pro' ),
        'description' => __('Enable Sidebar for shop page','remedial_pro'),
        'section'  => 'woocommerce_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
            'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
        ),

        'default'  => 'on',
    ) );
}
    
// background color ( rename )

Remedial_Kirki::add_section( 'colors', array(
    'title'          => __( 'Background Color','remedial_pro' ),
    'description'    => __( 'This will affect overall site background color', 'remedial_pro'),
    //'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 11,
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'general_background_color',
    'label'    => __( 'General Background Color', 'remedial_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-color',
        ),
    ),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'content_background_color',
    'label'    => __( 'Content Background Color', 'remedial_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'description' => __('when you are select boxed layout content background color will reflect the grid area','remedial_pro'), 
    'alpha' => true, 
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'general_background_image',
    'label'    => __( 'General Background Image', 'remedial_pro' ),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-image',
        ),
    ),
) );

// background image ( general & boxed layout ) //


Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'general_background_repeat',
    'label'    => __( 'General Background Repeat', 'remedial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'remedial_pro'),
        'repeat' => esc_attr__('Repeat', 'remedial_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','remedial_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'general_background_size',
    'label'    => __( 'General Background Size', 'remedial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'remedial_pro' ),
        'contain' => esc_attr__( 'Contain', 'remedial_pro' ),
        'auto'  => esc_attr__( 'Auto', 'remedial_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'remedial_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'general_background_attachment',
    'label'    => __( 'General Background Attachment', 'remedial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'remedial_pro'),
        'fixed' => esc_attr__('Fixed', 'remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'general_background_position',
    'label'    => __( 'General Background Position', 'remedial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'remedial_pro'),
        'center center' => esc_attr__('Center Center', 'remedial_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'remedial_pro'),
        'left top' => esc_attr__('Left Top', 'remedial_pro'),
        'left center' => esc_attr__('Left Center', 'remedial_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'remedial_pro'),
        'right top' => esc_attr__('Right Top', 'remedial_pro'),
        'right center' => esc_attr__('Right Center', 'remedial_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );


/* CONTENT BACKGROUND ( boxed background image )*/

Remedial_Kirki::add_field( 'remedial_pro', array(  
    'settings' => 'content_background_image',
    'label'    => __( 'Content Background Image', 'remedial_pro' ),
    'description' => __('when you are select boxed layout content background image will reflect the grid area','remedial_pro'),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-image',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'content_background_repeat',
    'label'    => __( 'Content Background Repeat', 'remedial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'remedial_pro'),
        'repeat' => esc_attr__('Repeat', 'remedial_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','remedial_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'content_background_size',
    'label'    => __( 'Content Background Size', 'remedial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'remedial_pro' ),
        'contain' => esc_attr__( 'Contain', 'remedial_pro' ),
        'auto'  => esc_attr__( 'Auto', 'remedial_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'remedial_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'content_background_attachment',
    'label'    => __( 'Content Background Attachment', 'remedial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'remedial_pro'),
        'fixed' => esc_attr__('Fixed', 'remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'content_background_position',
    'label'    => __( 'Content Background Position', 'remedial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'remedial_pro'),
        'center center' => esc_attr__('Center Center', 'remedial_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'remedial_pro'),
        'left top' => esc_attr__('Left Top', 'remedial_pro'),
        'left center' => esc_attr__('Left Center', 'remedial_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'remedial_pro'),
        'right top' => esc_attr__('Right Top', 'remedial_pro'),
        'right center' => esc_attr__('Right Center', 'remedial_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'remedial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );

/* pro theme options */

//  animation section 

Remedial_Kirki::add_section( 'animation_section', array(
    'title'          => __( 'Animation','remedial_pro' ),
    'description'    => __( 'Animation that affects overall site', 'remedial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );    

Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'animation_effect',
    'label'    => __( 'Enable Animation Effect', 'remedial_pro' ),   
    'section'  => 'animation_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'remedial_pro' ),
        'off' => esc_attr__( 'Disable', 'remedial_pro' ) 
    ),
    'default'  => 'on',
) );

// custom JS section

Remedial_Kirki::add_section( 'custom_js_section', array(
    'title'          => __( 'Custom JS','remedial_pro' ),
    'description'    => __( 'Custom JS', 'remedial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
 Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'custom_js',
    'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'remedial_pro' ),
    'section'  => 'custom_js_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
) ); 


// Tracking section 

Remedial_Kirki::add_section( 'analytics_section', array(
    'title'          => __( 'Tracking Code','remedial_pro' ),
    'description'    => __( 'Tracking Code', 'remedial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'analytics',
    'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'remedial_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
    'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'analytics_place',
    'label'    => __( 'Enable to Load Tracking Code in Footer', 'remedial_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'remedial_pro' ),
        '2' => esc_attr__( 'Disable', 'remedial_pro' )
    ),
    'default'  => '2',
    'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','remedial_pro'),
) );


//  lightbox section //

Remedial_Kirki::add_section( 'light_box', array(
    'title'          => __( 'Light Box','remedial_pro' ),
    'description'    => __( 'Light Box Settings', 'remedial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'lightbox_theme',
    'label'    => __( 'Lightbox Theme', 'remedial_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => esc_attr__( 'pp_default', 'remedial_pro' ),
        '2' => esc_attr__( 'light-rounded', 'remedial_pro' ),
        '3' => esc_attr__( 'dark-rounded', 'remedial_pro' ),
        '4' => esc_attr__( 'light-square', 'remedial_pro' ),
        '5' => esc_attr__( 'dark-square', 'remedial_pro' ),
        '6' => esc_attr__( 'facebook', 'remedial_pro' ),
    ),
    'default'  => '1',
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'lightbox_animation_speed',
    'label'    => __( 'Animation Speed', 'remedial_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'fast' => esc_attr__( 'Fast', 'remedial_pro' ),
        'slow' => esc_attr__( 'Slow', 'remedial_pro' ),
        'normal' => esc_attr__( 'Normal', 'remedial_pro' ),
    ),
    'default'  => 'fast',
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'lightbox_slideshow',
    'label'    => __( 'Autoplay Gallery Speed', 'remedial_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 100,
        'step' => 10,
    ),
    'default'  => 50,
    'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'lightbox_autoplay_slideshow',
    'label'    => __( 'Enable Autoplay Gallery', 'remedial_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'remedial_pro' ),
        '2' => esc_attr__( 'Disable', 'remedial_pro' )
    ),
    'default'  => '2',
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'lightbox_opacity',
    'label'    => __( 'Select Background Opacity', 'remedial_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 1,
        'step' => 0.1,
    ),
    'default'  => 0.5,
    'tooltip' => __('Enter 0.1 to 1.0','remedial_pro'),
) );
Remedial_Kirki::add_field( 'remedial_pro', array(
    'settings' => 'lightbox_overlay_gallery',
    'label'    => __( 'Show Gallery Thumbnails', 'remedial_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array( 
        '1'  => esc_attr__( 'Enable', 'remedial_pro' ),
        '2' => esc_attr__( 'Disable', 'remedial_pro' )
    ),
    'default'  => '1',
) );


 

         
do_action('remedial_pro_child_customizer_options');
