=== Nuptial ===
Contributors: Webulous
Tags: blog, e-commerce, photography, one-column, two-columns, right-sidebar, left-sidebar, featured-images, custom-header, custom-background, custom-menu, custom-logo, footer-widgets,   full-width-template, sticky-post, theme-options, threaded-comments, translation-ready, rtl-language-support
Requires at least: 4.0 
Tested up to: 4.8.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Nuptial is best suited for all types of site and uses Theme Customizer.
  
== Description ==   
NuptialPro is an elegant, responsive WordPress theme designed for wedding websites. It is an attractive, modern, easy to use and colorful design and stunning flexibility. However, due to its flexibility and easiness it can be used to create any types of sites. this Theme build in customizer it is very easy to use and user friendly. Theme includes lots of features.

== Frequently Asked Questions ==
= Installation =
1. Download and unzip `nuptialpro` theme
2. Upload the `nuptialpro` folder to the `/wp-content/themes/` directory
3. Activate the Theme through the 'Themes' menu in WordPress

= Setting Up Front Page =
1. By default, your front page looks like a blog. However, you can make it look like screenshot by following these steps.
2. Go to Dashboard => Appearance => Customize
3. Click on 'Static Front Page'
4. Select 'A static page' radio option
5. Select a static page for 'Front Page' and another page for 'Posts Page'


= How to Use Customizer options =

Go to Dashboard => Appearance => Customize.
Use customizer options   


== Changelog ==   

= 1.0.0 =
	* Initial Release

== Upgrade Notice == 

= 1.0.0 =
	* Initial Release

== Resources ==
* {_s}, GPLv2
* {Skeleton}, MIT
* {Flexslider} © 2015 Woo Themes, GPLv2
* {FontAwesome} © Dave Gandy, SIL OFL 1.1 and MIT   
