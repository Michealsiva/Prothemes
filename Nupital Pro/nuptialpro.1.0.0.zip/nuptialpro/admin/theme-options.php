<?php  
/**
 * Created by PhpStorm.
 * User: venkat
 * Date: 2/5/16
 * Time: 4:32 PM        
 */    
           
include_once( get_template_directory() . '/admin/kirki/kirki.php' );   
include_once( get_template_directory() . '/admin/kirki-helpers/class-theme-kirki.php' ); 
     
 
Nuptial_Kirki::add_config( 'nuptial_pro', array(     
    'capability'    => 'edit_theme_options',                  
    'option_type'   => 'theme_mod',          
) );               
     
// Flat option start //   

//  site identity section // 

Nuptial_Kirki::add_section( 'title_tagline', array(
    'title'          => __( 'Site Identity','nuptial_pro' ),
    'description'    => __( 'Site Header Options', 'nuptial_pro'),       
    'priority'       => 8,                                                                                                                
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'logo_title',
    'label'    => __( 'Enable Logo as Title', 'nuptial_pro' ),
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'priority' => 5,
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' )
    ),
    'default'  => 'off',   
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'tagline',
    'label'    => __( 'Show site Tagline', 'nuptial_pro' ), 
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' )
    ),
    'default'  => 'off',
) );  

// home panel //

Nuptial_Kirki::add_panel( 'home_options', array(     
    'title'       => __( 'Home', 'nuptial_pro' ),
    'description' => __( 'Home Page Related Options', 'nuptial_pro' ),     
) );  


// home page type section

 Nuptial_Kirki::add_section( 'home-nuptial', array(
    'title'          => __( 'PRO Home - General Settings','nuptial_pro' ),
    'description'    => __( 'Home Page options', 'nuptial_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array( 
    'settings' => 'enable_home_default_content',
    'label'    => __( 'Enable Home Page Default Content', 'nuptial_pro' ),
    'section'  => 'home-nuptial',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Use pagebuilder to built pro home page (or) Use prebuilt layout','nuptial_pro'),
) );  


// Slider section   

Nuptial_Kirki::add_section( 'slider-section', array(
    'title'          => __( 'Slider Section','nuptial_pro' ),
    'description'    => __( 'Home Page Slider Related Options', 'nuptial_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(  
    'settings' => 'slider_field',  
    'label'    => __( 'Enable Slider Post ( Section )', 'nuptial_pro' ),
    'section'  => 'slider-section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Slider Post in home page','nuptial_pro'),
) );
 
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'slider_cat',
    'label'    => __( 'Slider Posts category', 'nuptial_pro' ),
    'section'  => 'slider-section',
    'type'     => 'select',
    'choices' => Kirki_Helper::get_terms( 'category' ),
    'active_callback' => array(
        array(
            'setting'  => 'slider_field', 
            'operator' => '==',
            'value'    => true, 
        ),
    ),
    'tooltip' => __('Create post ( Goto Dashboard => Post => Add New ) and Post Featured Image ( Preferred size is 1200 x 450 pixels ) as taken as slider image and Post Content as taken as Flexcaption.','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'slider_count',
    'label'    => __( 'No. of Sliders', 'nuptial_pro' ),
    'section'  => 'slider-section',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 999,
        'step' => 1,
    ),
    'default'  => 2,
    'active_callback' => array(
        array(
            'setting'  => 'slider_field',
            'operator' => '==',
            'value'    => true,
        ),                                                                             
    ),
    'tooltip' => __('Enter number of slides you want to display under your selected Category','nuptial_pro'),
) );

// service section 

Nuptial_Kirki::add_section( 'service_section', array(
    'title'          => __( 'Service Section','nuptial_pro' ),
    'description'    => __( 'Home Page - Service Related Options', 'nuptial_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(  
    'settings' => 'service_field',  
    'label'    => __( 'Enable Service Section', 'nuptial_pro' ),
    'section'  => 'service_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Service section in home page','nuptial_pro'),
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'service_title',
    'label'    => __( 'Service Title', 'nuptial_pro' ),
    'section'  => 'service_section',
    'type'     => 'dropdown-pages',
    'active_callback' => array(
        array(
            'setting'  => 'service_field',
            'operator' => '==',
            'value'    => true,
        ),          
    ), 
) );


for ( $i = 1 ; $i <= 3 ; $i++ ) {
    //Create the settings Once, and Loop through it.

    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'service_'.$i,
        'label'    => sprintf(__( 'Service Section #%1$s', 'nuptial_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'dropdown-pages', 
        'active_callback' => array(
            array(
                'setting'  => 'service_field',
                'operator' => '==',
                'value'    => true,
            ),          
        ),    
    ) );
}
 

// latest blog section 

Nuptial_Kirki::add_section( 'latest_blog_section', array(
    'title'          => __( 'Latest Blog Section','nuptial_pro' ),
    'description'    => __( 'Home Page - Latest Blog Options', 'nuptial_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'enable_recent_post_service',
    'label'    => __( 'Enable Recent Post Section', 'nuptial_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),

    'default'  => 'on',
    'tooltip' => __('Enable recent post section in home page','nuptial_pro'),
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'recent_post_title',
    'label'    => __( 'Recent Post Title', 'nuptial_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'dropdown-pages',
    'active_callback' => array(
        array(
            'setting'  => 'enable_recent_post_service',
            'operator' => '==',
            'value'    => true,
        ),          
    ), 
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'recent_posts_count',
    'label'    => __( 'No. of Recent Posts', 'nuptial_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'number',
    'choices' => array(
        'min' => 2,
        'max' => 99,
        'step' => 2,
    ),
    'default'  => 2,
    'active_callback' => array(
        array(
            'setting'  => 'enable_recent_post_service',
            'operator' => '==',
            'value'    => true,
        ),

    ),
) );


// general panel      

Nuptial_Kirki::add_panel( 'general_panel', array(   
    'title'       => __( 'General Settings', 'nuptial_pro' ),  
    'description' => __( 'general settings', 'nuptial_pro' ),         
) );
//  Page title bar section // 

Nuptial_Kirki::add_section( 'header-pagetitle-bar', array(   
    'title'          => __( 'Page Title Bar & Breadcrumb','nuptial_pro' ),
    'description'    => __( 'Page Title bar related options', 'nuptial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) ); 
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'global_page_title_bar',
    'label'    => __( 'Check the box if you want to use a global page title bar settings. This option overrides the page options', 'nuptial_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'checkbox',
    'default' => '0',
) );   

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'page_titlebar',  
    'label'    => __( 'Page Title Bar', 'nuptial_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( 'Show Bar and Content', 'nuptial_pro' ),
        2 => __('Hide','nuptial_pro'),
    ),
    'default' => 1,
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'page_titlebar_text',  
    'label'    => __( 'Page Title Bar Text', 'nuptial_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        0 => __( 'Show', 'nuptial_pro' ),
        1 => __( 'Hide', 'nuptial_pro' ), 
    ),
    'default' => 0,
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'breadcrumb',  
    'label'    => __( 'Hide Breadcrumb', 'nuptial_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'checkbox',
    'default'  => 0,
) ); 

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'breadcrumb_char',
    'label'    => __( 'Breadcrumb Character', 'nuptial_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( ' >> ', 'nuptial_pro' ),
        2 => __( ' / ', 'nuptial_pro' ),
        3 => __( ' > ', 'nuptial_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'breadcrumb',
            'operator' => '==',
            'value'    => 0,
        ),
    ),
    //'sanitize_callback' => 'allow_htmlentities'
) );

//  pagination section // 

Nuptial_Kirki::add_section( 'general-pagination', array(   
    'title'          => __( 'Pagination','nuptial_pro' ),
    'description'    => __( 'Pagination related options', 'nuptial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'numeric_pagination',
    'label'    => __( 'Numeric Pagination', 'nuptial_pro' ),   
    'section'  => 'general-pagination',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Numbered', 'nuptial_pro' ),
        'off' => esc_attr__( 'Next/Previous', 'nuptial_pro' )
    ),
    'default'  => 'on',
) );

// skin color panel 

Nuptial_Kirki::add_panel( 'skin_color_panel', array(   
    'title'       => __( 'Skin Color', 'nuptial_pro' ),  
    'description' => __( 'Color Settings', 'nuptial_pro' ),         
) );
// color scheme section 

Nuptial_Kirki::add_section( 'multiple_color_section', array(
    'title'          => __( 'Color Scheme','nuptial_pro' ),
    'description'    => __( 'Select your color scheme', 'nuptial_pro'),
    'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 9,
) );  

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'color_scheme',
    'label'    => __( 'Select your color scheme', 'nuptial_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'palette',
    'choices'     => array( 
        '1' => array( 
            '#d44646',
        ),
        '2' => array(
            '#ee9e27',
        ),
        '3' => array(
            '#af52a0',
        ),
        '4' => array(
            '#37ad50',
        ),
        '5' => array(
            '#547cd5',
        ),
        '6' => array(
            '#00929c',
        ),
    ),
    'default' => '1',
//'default'  => 'on',
) );

/* custom color stylesheet */

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'enable_custom_color_scheme',
    'label'    => __( 'Enable Custom color scheme', 'nuptial_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' )
    ),
    'default'  => 'off',
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'custom_color_scheme',
    'label'    => __( 'Select custom color scheme', 'nuptial_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'color',
    'default'  => '#d44646',
    'alpha'  => false,
    'active_callback' => array(
        array (
            'setting'  => 'enable_custom_color_scheme',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );


/* pagebuilder style override */
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'enable_so_custom_color',
    'label'    => __( 'Enable this Option to change color choosen by pagebuilder', 'nuptial_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' )
    ),
    'default'  => 'off',
    'tooltip' => __('while change the color scheme this option is also change the pagebuilder row and widget related option color in order to match color scheme','nuptial_pro'),

) );

// typography panel //  

Nuptial_Kirki::add_panel( 'typography', array( 
    'title'       => __( 'Typography', 'nuptial_pro' ),
    'description' => __( 'Typography and Link Color Settings', 'nuptial_pro' ),
) );
   
    Nuptial_Kirki::add_section( 'typography_section', array(
        'title'          => __( 'General Settings','nuptial_pro' ),
        'description'    => __( 'General Settings', 'nuptial_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );
        

    Nuptial_Kirki::add_section( 'body_font', array(
        'title'          => __( 'Body Font','nuptial_pro' ), 
        'description'    => __( 'Specify the body font properties', 'nuptial_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) ); 

    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'body_typography',
        'label'    => __( 'Enable Custom body Settings', 'nuptial_pro' ),
        'section'  => 'body_font',
        'type'     => 'switch', 
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
            'off' => esc_attr__( 'Disable', 'nuptial_pro' )
        ),
        'tooltip' => __('Turn on to body typography and turn off for default typography','nuptial_pro'),
        'default'  => 'off',
    ) );


    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'body',
        'label'    => __( 'Body Settings', 'nuptial_pro' ),
        'section'  => 'body_font', 
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto', 
            'variant'        => 'regular',
            'font-size'      => '16px',   
            'line-height'    => '1.5',
            'letter-spacing' => '0',
            'color'          => '#8f8f8f', 
        ),
        'output'      => array(
            array(
                'element' => 'body',
                //'suffix' => '!important',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'body_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );


    Nuptial_Kirki::add_section( 'heading_section', array(
        'title'          => __( 'Heading Font','nuptial_pro' ),
        'description'    => __( 'Specify typography of H1, H2, H3, H4, H5, H6', 'nuptial_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'heading_one_typography',
        'label'    => __( 'Enable Custom H1 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
            'off' => esc_attr__( 'Disable', 'nuptial_pro' )
        ),
        'tooltip' => __('Turn on to H1 typography and turn off for default typography','nuptial_pro'),
        'default'  => 'off',
    ) );


    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'h1',  
        'label'    => __( 'H1 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '48px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h1',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_one_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );
    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'heading_two_typography',
        'label'    => __( 'Enable Custom H2 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
            'off' => esc_attr__( 'Disable', 'nuptial_pro' )
        ),
        'tooltip' => __('Turn on to H2 typography and turn off for default typography','nuptial_pro'),
        'default'  => 'off',
    ) );


    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'h2',
        'label'    => __( 'H2 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '36px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h2',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_two_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'heading_three_typography',
        'label'    => __( 'Enable Custom H3 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
            'off' => esc_attr__( 'Disable', 'nuptial_pro' )
        ),
        'tooltip' => __('Turn on to H3 typography and turn off for default typography','nuptial_pro'),
        'default'  => 'off',
    ) );


    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'h3',
        'label'    => __( 'H3 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default' => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '30px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h3',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_three_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'heading_four_typography',
        'label'    => __( 'Enable Custom H4 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
            'off' => esc_attr__( 'Disable', 'nuptial_pro' )
        ),
        'tooltip' => __('Turn on to H4 typography and turn off for default typography','nuptial_pro'),
        'default'  => 'off',
    ) );


    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'h4',
        'label'    => __( 'H4 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '24px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h4',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_four_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'heading_five_typography',
        'label'    => __( 'Enable Custom H5 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
            'off' => esc_attr__( 'Disable', 'nuptial_pro' )
        ),
        'tooltip' => __('Turn on to H5 typography and turn off for default typography','nuptial_pro'),
        'default'  => 'off',
    ) );



    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'h5',
        'label'    => __( 'H5 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '18px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h5',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_five_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );

    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'heading_six_typography',
        'label'    => __( 'Enable Custom H6 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
            'off' => esc_attr__( 'Disable', 'nuptial_pro' )
        ),
        'tooltip' => __('Turn on to H6 typography and turn off for default typography','nuptial_pro'),
        'default'  => 'off',
    ) );



    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'h6',
        'label'    => __( 'H6 Settings', 'nuptial_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway', 
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#222222',
        ),
        'output'      => array(
            array(
                'element' => 'h6',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_six_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
         
    ) );

    // navigation font 
    Nuptial_Kirki::add_section( 'navigation_section', array(
        'title'          => __( 'Navigation Font','nuptial_pro' ),
        'description'    => __( 'Specify Navigation font properties', 'nuptial_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'navigation_font_status',
        'label'    => __( 'Enable Navigation Font Settings', 'nuptial_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
            'off' => esc_attr__( 'Disable', 'nuptial_pro' )
        ),
        'tooltip' => __('Turn on to Navigation Font typography and turn off for default typography','nuptial_pro'),
        'default'  => 'off',
    ) );

    Nuptial_Kirki::add_field( 'nuptial_pro', array(
        'settings' => 'navigation_font',
        'label'    => __( 'Navigation Font Settings', 'nuptial_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '400',
            'font-size'      => '16px',
            'line-height'    => '1.8', 
            'letter-spacing' => '0',
            'color'          => '#ffffff',
        ),
        'output'      => array(
            array(
                'element' => '.main-navigation a',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'navigation_font_status',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );



// header panel //  

Nuptial_Kirki::add_panel( 'header_panel', array(     
    'title'       => __( 'Header', 'nuptial_pro' ),
    'description' => __( 'Header Related Options', 'nuptial_pro' ), 
) );  

/* STICKY HEADER section */     
  
Nuptial_Kirki::add_section( 'stricky_header', array(
    'title'          => __( 'Sticky Menu','nuptial_pro' ),
    'description'    => __( 'sticky header', 'nuptial_pro'),
    'panel'          => 'header_panel', // Not typically needed.
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(    
    'settings' => 'sticky_header',
    'label'    => __( 'Enable Sticky Header', 'nuptial_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' )
    ),
    'default'  => 'on',
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'sticky_header_position',
    'label'    => __( 'Enable Sticky Header Position', 'nuptial_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'radio-buttonset', 
    'choices' => array(
        'top'  => esc_attr__( 'Top', 'nuptial_pro' ),
        'bottom' => esc_attr__( 'Bottom', 'nuptial_pro' )
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'sticky_header',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'top',
) );


/*
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'header_top_margin',
    'label'    => __( 'Header Top Margin', 'nuptial_pro' ),
    'description' => __('Select the top margin of header in pixels','nuptial_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'header_bottom_margin',
    'label'    => __( 'Header Bottom Margin', 'nuptial_pro' ),
    'description' => __('Select the bottom margin of header in pixels','nuptial_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );*/

Nuptial_Kirki::add_section( 'header_image', array(
    'title'          => __( 'Header Background Video & Image','nuptial_pro' ),
    'description'    => __( 'Custom Header Video & Image options', 'nuptial_pro'),
    'panel'          => 'header_panel', // Not typically needed.  
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(   
    'settings' => 'header_bg_size',
    'label'    => __( 'Header Background Size', 'nuptial_pro' ),
    'section'  => 'header_image',
    'type'     => 'radio-buttonset', 
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'nuptial_pro' ),
        'contain' => esc_attr__( 'Contain', 'nuptial_pro' ),
        'auto'  => esc_attr__( 'Auto', 'nuptial_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'nuptial_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Header Background Image Size','nuptial_pro'),
) );

/*Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'header_height',
    'label'    => __( 'Header Background Image Height', 'nuptial_pro' ),
    'section'  => 'header_image',
    'type'     => 'number',
    'choices' => array(
        'min' => 100,
        'max' => 600,
        'step' => 1,
    ),
    'default'  => '213',
) ); */
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'header_bg_repeat',
    'label'    => __( 'Header Background Repeat', 'nuptial_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'nuptial_pro'),
        'repeat' => esc_attr__('Repeat', 'nuptial_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','nuptial_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'repeat',  
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'header_bg_position', 
    'label'    => __( 'Header Background Position', 'nuptial_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'nuptial_pro'),
        'center center' => esc_attr__('Center Center', 'nuptial_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'nuptial_pro'),
        'left top' => esc_attr__('Left Top', 'nuptial_pro'),
        'left center' => esc_attr__('Left Center', 'nuptial_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'nuptial_pro'),
        'right top' => esc_attr__('Right Top', 'nuptial_pro'),
        'right center' => esc_attr__('Right Center', 'nuptial_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'center center',  
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'header_bg_attachment',
    'label'    => __( 'Header Background Attachment', 'nuptial_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'nuptial_pro'),
        'fixed' => esc_attr__('Fixed', 'nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'scroll',  
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'header_overlay',
    'label'    => __( 'Enable Header( Background ) Overlay', 'nuptial_pro' ),
    'section'  => 'header_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' )
    ),
    'default'  => 'off',
) );
  
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'header_overlay_color',
    'label'    => __( 'Header Overlay ( Background )color', 'nuptial_pro' ),
    'section'  => 'header_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'output'   => array(
        array(
            'element'  => '.overlay-header',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

/*
/* e-option start */
/*
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'custon_favicon',
    'label'    => __( 'Custom Favicon', 'nuptial_pro' ),
    'section'  => 'header',
    'type'     => 'upload',
    'default'  => '',
) ); */
/* e-option start */ 
/* Blog page section */


/* Blog panel */

Nuptial_Kirki::add_panel( 'blog_panel', array(     
    'title'       => __( 'Blog', 'nuptial_pro' ),
    'description' => __( 'Blog Related Options', 'nuptial_pro' ),     
) ); 
Nuptial_Kirki::add_section( 'blog', array(
    'title'          => __( 'Blog Page','nuptial_pro' ),
    'description'    => __( 'Blog Related Options', 'nuptial_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
  
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'blog_layout',
    'label'    => __( 'Select Blog Page Layout you prefer', 'nuptial_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1  => esc_attr__( 'Default ( One Column )', 'nuptial_pro' ),
        2 => esc_attr__( 'Two Columns ', 'nuptial_pro' ),
        3 => esc_attr__( 'Three Columns ( Without Sidebar ) ', 'nuptial_pro' ),
        4 => esc_attr__( 'Two Columns With Masonry', 'nuptial_pro' ),
        5 => esc_attr__( 'Three Columns With Masonry ( Without Sidebar ) ', 'nuptial_pro' ),
        6 => esc_attr__( 'Blog FullWidth', 'nuptial_pro' ),
    ),
    'default'  => 1,
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'featured_image',
    'label'    => __( 'Enable Featured Image', 'nuptial_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for blog page','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'more_text',
    'label'    => __( 'More Text', 'nuptial_pro' ),
    'section'  => 'blog',
    'type'     => 'text',
    'description' => __('Text to display in case of text too long','nuptial_pro'),
    'default' => __('Read More','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'featured_image_size',
    'label'    => __( 'Choose the Featured Image Size for Blog Page', 'nuptial_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1 => esc_attr__( 'Large Featured Image', 'nuptial_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'nuptial_pro' ),
        3 => esc_attr__( 'Original Size', 'nuptial_pro' ),
        4 => esc_attr__( 'Medium', 'nuptial_pro' ),
        5 => esc_attr__( 'Large', 'nuptial_pro' ), 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Set large and medium image size: Goto Dashboard => Settings => Media', 'nuptial_pro') ,
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'enable_single_post_top_meta',
    'label'    => __( 'Enable to display top post meta data', 'nuptial_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'single_post_top_meta',
    'label'    => __( 'Activate and Arrange the Order of Top Post Meta elements', 'nuptial_pro' ),
    'section'  => 'blog',
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'nuptial_pro' ),
        2 => esc_attr__( 'author', 'nuptial_pro' ),
        3 => esc_attr__( 'comment', 'nuptial_pro' ),
        4 => esc_attr__( 'category', 'nuptial_pro' ),
        5 => esc_attr__( 'tags', 'nuptial_pro' ),
        6 => esc_attr__( 'edit', 'nuptial_pro' ),
    ),
    'default'  => array(1, 2, 3,6),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_top_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','nuptial_pro'),

) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'enable_single_post_bottom_meta',
    'label'    => __( 'Enable to display bottom post meta data', 'nuptial_pro' ),
    'section'  => 'blog', 
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','nuptial_pro'),
    'default'  => 'on',
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'single_post_bottom_meta',
    'label'    => __( 'Activate and arrange the Order of Bottom Post Meta elements', 'nuptial_pro' ),
    'section'  => 'blog',     
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'nuptial_pro' ),
        2 => esc_attr__( 'author', 'nuptial_pro' ),
        3 => esc_attr__( 'comment', 'nuptial_pro' ),
        4 => esc_attr__( 'category', 'nuptial_pro' ),
        5 => esc_attr__( 'tags', 'nuptial_pro' ),
        6 => esc_attr__( 'edit', 'nuptial_pro' ),
    ),
    'default'  => array(4,5),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_bottom_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','nuptial_pro'),
) );


/* Single Blog page section */

Nuptial_Kirki::add_section( 'single_blog', array(
    'title'          => __( 'Single Blog Page','nuptial_pro' ),
    'description'    => __( 'Single Blog Page Related Options', 'nuptial_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'single_featured_image',
    'label'    => __( 'Enable Single Post Featured Image', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for Single Post Page','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'single_featured_image_size',
    'label'    => __( 'Choose the featured image display type for Single Post Page', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Large Featured Image', 'nuptial_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'nuptial_pro' ),
        3 => esc_attr__( 'FullWidth Featured Image', 'nuptial_pro' ),
    ),
    'default'  => '1',
    'active_callback' => array(
        array(
            'setting'  => 'single_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'author_bio_box',
    'label'    => __( 'Enable Author Bio Box below single post', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'off',
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'related_posts',
    'label'    => __( 'Show Related Posts', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Show the Related Post for Single Blog Page','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'related_posts_hierarchy',
    'label'    => __( 'Related Posts Must Be Shown As:', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Related Posts By Tags', 'nuptial_pro' ),
        2 => esc_attr__( 'Related Posts By Categories', 'nuptial_pro' ) 
    ),
    'default'  => '1',
    'active_callback' => array(
        array(
            'setting'  => 'related_posts',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Select the Hierarchy','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'comments',
    'label'    => __( ' Show Comments', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Show the Comments for Single Blog Page','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'social_sharing_box',
    'label'    => __( 'Show social sharing options box below single post', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
) );

//social sharing box section

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'facebook_sb',
    'label'    => __( 'Enable facebook sharing option below single post', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'twitter_sb',
    'label'    => __( 'Enable twitter sharing option below single post', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'linkedin_sb',
    'label'    => __( 'Enable linkedin sharing option below single post', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'google-plus_sb',
    'label'    => __( 'Enable googleplus sharing option below single post', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'email_sb',
    'label'    => __( 'Enable email sharing option below single post', 'nuptial_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );


// single page section //

Nuptial_Kirki::add_section( 'single_page', array(
    'title'          => __( 'Single Page','nuptial_pro' ),
    'description'    => __( 'Single Page Related Options', 'nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'single_page_featured_image',
    'label'    => __( 'Enable Single Page Featured Image', 'nuptial_pro' ),
    'section'  => 'single_page',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'single_page_featured_image_size',
    'label'    => __( 'Single Page Featured Image Size', 'nuptial_pro' ),
    'section'  => 'single_page',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( 'Normal', 'nuptial_pro' ),
        2 => esc_attr__( 'FullWidth', 'nuptial_pro' ) 
    ),
    'default'  => '1',
    'active_callback' => array(
        array(
            'setting'  => 'single_page_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

// Layout section //

Nuptial_Kirki::add_section( 'layout', array( 
    'title'          => __( 'Layout','nuptial_pro' ),
    'description'    => __( 'Layout Related Options', 'nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'site-style',
    'label'    => __( 'Site Style', 'nuptial_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'wide' =>  esc_attr__('Wide', 'nuptial_pro'),
        'boxed' =>  esc_attr__('Boxed', 'nuptial_pro'),
        'fluid' =>  esc_attr__('Fluid', 'nuptial_pro'),  
        //'static' =>  esc_attr__('Static ( Non Responsive )', 'nuptial_pro'),
    ),
    'default'  => 'wide',
    'tooltip' => __('Choose the default site layout.','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'global_sidebar_layout',
    'label'    => __( 'Check the box if you want to use a global sidebar on all pages. This option overrides the page options', 'nuptial_pro' ),
    'section'  => 'layout',
    'type'     => 'checkbox',
    'default' => '0',
) );


Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'sidebar_position',
    'label'    => __( 'Main Layout', 'nuptial_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-image',   
    'description' => __('Select main content and sidebar arrangement.','nuptial_pro'),
    'choices' => array(
        'left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cl.png',
        'right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cr.png',
        'two-sidebar' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cm.png',  
        'two-sidebar-left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cl.png',
        'two-sidebar-right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cr.png',
        'fullwidth' =>  get_template_directory_uri() . '/admin/kirki/assets/images/1c.png',
        'no-sidebar' =>  get_template_directory_uri() . '/images/no-sidebar.png',
    ),
    'default'  => 'right', 
    'tooltip' => __('global sidebar on all pages. This option overrides the page layout sidebar options','nuptial_pro'),
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'body_top_margin',
    'label'    => __( 'Body Top Margin', 'nuptial_pro' ),
    'description' => __('Select the top margin of body element in pixels','nuptial_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-top',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'body_bottom_margin',
    'label'    => __( 'Body Bottom Margin', 'nuptial_pro' ),
    'description' => __('Select the bottom margin of body element in pixels','nuptial_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-bottom',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );

/* LAYOUT SECTION  */
/*
Nuptial_Kirki::add_section( 'layout', array(
    'title'          => __( 'Layout','nuptial_pro' ),   
    'description'    => __( 'Layout settings that affects overall site', 'nuptial_pro'),
    'panel'          => 'nuptial_pro_options', // Not typically needed.
) );



Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'primary_sidebar_width',
    'label'    => __( 'Primary Sidebar Width', 'nuptial_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'nuptial_pro' ),
        '2' => __( 'Two Column', 'nuptial_pro' ),
        '3' => __( 'Three Column', 'nuptial_pro' ),
        '4' => __( 'Four Column', 'nuptial_pro' ),
        '5' => __( 'Five Column ', 'nuptial_pro' ),
    ),
    'default'  => '5',  
    'tooltip' => __('Select the width of the Primary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'secondary_sidebar_width',
    'label'    => __( 'Secondary Sidebar Width', 'nuptial_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'nuptial_pro' ),
        '2' => __( 'Two Column', 'nuptial_pro' ),
        '3' => __( 'Three Column', 'nuptial_pro' ),
        '4' => __( 'Four Column', 'nuptial_pro' ),
        '5' => __( 'Five Column ', 'nuptial_pro' ),
    ),            
    'default'  => '5',  
    'tooltip' => __('Select the width of the Secondary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','nuptial_pro'),
) ); 

*/

/* FOOTER SECTION 
footer panel */

Nuptial_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'nuptial_pro' ),
    'description' => __( 'Footer Related Options', 'nuptial_pro' ),     
) );  

Nuptial_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','nuptial_pro' ),
    'description'    => __( 'Footer related options', 'nuptial_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'nuptial_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','nuptial_pro'),admin_url('customize.php') ),
    'section'  => 'footer', 
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
) );

/* Choose No.Of Footer area */
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'nuptial_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'nuptial_pro' ),
        2  => esc_attr__( '2', 'nuptial_pro' ),
        3  => esc_attr__( '3', 'nuptial_pro' ),
        4  => esc_attr__( '4', 'nuptial_pro' ),
    ),
    'default'  => '3',
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'nuptial_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'nuptial_pro' ),
    'description' => __('Select the top margin of footer in pixels','nuptial_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Nuptial_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','nuptial_pro' ),
    'description'    => __( 'Custom Footer Image options', 'nuptial_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'nuptial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'nuptial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'nuptial_pro' ),
        'contain' => esc_attr__( 'Contain', 'nuptial_pro' ),
        'auto'  => esc_attr__( 'Auto', 'nuptial_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'nuptial_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'nuptial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'nuptial_pro'),
        'repeat' => esc_attr__('Repeat', 'nuptial_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','nuptial_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'nuptial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'nuptial_pro'),
        'center center' => esc_attr__('Center Center', 'nuptial_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'nuptial_pro'),
        'left top' => esc_attr__('Left Top', 'nuptial_pro'),
        'left center' => esc_attr__('Left Center', 'nuptial_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'nuptial_pro'),
        'right top' => esc_attr__('Right Top', 'nuptial_pro'),
        'right center' => esc_attr__('Right Center', 'nuptial_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'nuptial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'nuptial_pro'),
        'fixed' => esc_attr__('Fixed', 'nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'nuptial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' )
    ),
    'default'  => 'off',
) );
  
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'nuptial_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.overlay-footer',
            'property' => 'background-color',
        ),
    ),
) );


 if( class_exists( 'WooCommerce' ) ) {
    Nuptial_Kirki::add_section( 'woocommerce_section', array(
        'title'          => __( 'WooCommerce','nuptial_pro' ),
        'description'    => __( 'Theme options related to woocommerce', 'nuptial_pro'),
        'priority'       => 11, 
        'theme_supports' => '', // Rarely needed.
    ) );
    Nuptial_Kirki::add_field( 'woocommerce', array(
        'settings' => 'woocommerce_sidebar',
        'label'    => __( 'Enable Woocommerce Sidebar', 'nuptial_pro' ),
        'description' => __('Enable Sidebar for shop page','nuptial_pro'),
        'section'  => 'woocommerce_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
            'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
        ),

        'default'  => 'on',
    ) );
}
    
// background color ( rename )

Nuptial_Kirki::add_section( 'colors', array(
    'title'          => __( 'Background Color','nuptial_pro' ),
    'description'    => __( 'This will affect overall site background color', 'nuptial_pro'),
    //'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 11,
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'general_background_color',
    'label'    => __( 'General Background Color', 'nuptial_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-color',
        ),
    ),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'content_background_color',
    'label'    => __( 'Content Background Color', 'nuptial_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'description' => __('when you are select boxed layout content background color will reflect the grid area','nuptial_pro'), 
    'alpha' => true, 
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'general_background_image',
    'label'    => __( 'General Background Image', 'nuptial_pro' ),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-image',
        ),
    ),
) );

// background image ( general & boxed layout ) //


Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'general_background_repeat',
    'label'    => __( 'General Background Repeat', 'nuptial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'nuptial_pro'),
        'repeat' => esc_attr__('Repeat', 'nuptial_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','nuptial_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'general_background_size',
    'label'    => __( 'General Background Size', 'nuptial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'nuptial_pro' ),
        'contain' => esc_attr__( 'Contain', 'nuptial_pro' ),
        'auto'  => esc_attr__( 'Auto', 'nuptial_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'nuptial_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'general_background_attachment',
    'label'    => __( 'General Background Attachment', 'nuptial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'nuptial_pro'),
        'fixed' => esc_attr__('Fixed', 'nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'general_background_position',
    'label'    => __( 'General Background Position', 'nuptial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'nuptial_pro'),
        'center center' => esc_attr__('Center Center', 'nuptial_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'nuptial_pro'),
        'left top' => esc_attr__('Left Top', 'nuptial_pro'),
        'left center' => esc_attr__('Left Center', 'nuptial_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'nuptial_pro'),
        'right top' => esc_attr__('Right Top', 'nuptial_pro'),
        'right center' => esc_attr__('Right Center', 'nuptial_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );


/* CONTENT BACKGROUND ( boxed background image )*/

Nuptial_Kirki::add_field( 'nuptial_pro', array(  
    'settings' => 'content_background_image',
    'label'    => __( 'Content Background Image', 'nuptial_pro' ),
    'description' => __('when you are select boxed layout content background image will reflect the grid area','nuptial_pro'),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-image',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'content_background_repeat',
    'label'    => __( 'Content Background Repeat', 'nuptial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'nuptial_pro'),
        'repeat' => esc_attr__('Repeat', 'nuptial_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','nuptial_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'content_background_size',
    'label'    => __( 'Content Background Size', 'nuptial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'nuptial_pro' ),
        'contain' => esc_attr__( 'Contain', 'nuptial_pro' ),
        'auto'  => esc_attr__( 'Auto', 'nuptial_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'nuptial_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'content_background_attachment',
    'label'    => __( 'Content Background Attachment', 'nuptial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'nuptial_pro'),
        'fixed' => esc_attr__('Fixed', 'nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'content_background_position',
    'label'    => __( 'Content Background Position', 'nuptial_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'nuptial_pro'),
        'center center' => esc_attr__('Center Center', 'nuptial_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'nuptial_pro'),
        'left top' => esc_attr__('Left Top', 'nuptial_pro'),
        'left center' => esc_attr__('Left Center', 'nuptial_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'nuptial_pro'),
        'right top' => esc_attr__('Right Top', 'nuptial_pro'),
        'right center' => esc_attr__('Right Center', 'nuptial_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'nuptial_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );

/* pro theme options */

//  animation section 

Nuptial_Kirki::add_section( 'animation_section', array(
    'title'          => __( 'Animation','nuptial_pro' ),
    'description'    => __( 'Animation that affects overall site', 'nuptial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );    

Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'animation_effect',
    'label'    => __( 'Enable Animation Effect', 'nuptial_pro' ),   
    'section'  => 'animation_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        'off' => esc_attr__( 'Disable', 'nuptial_pro' ) 
    ),
    'default'  => 'on',
) );

// custom JS section

Nuptial_Kirki::add_section( 'custom_js_section', array(
    'title'          => __( 'Custom JS','nuptial_pro' ),
    'description'    => __( 'Custom JS', 'nuptial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
 Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'custom_js',
    'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'nuptial_pro' ),
    'section'  => 'custom_js_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
) ); 


// Tracking section 

Nuptial_Kirki::add_section( 'analytics_section', array(
    'title'          => __( 'Tracking Code','nuptial_pro' ),
    'description'    => __( 'Tracking Code', 'nuptial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'analytics',
    'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'nuptial_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
    'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'analytics_place',
    'label'    => __( 'Enable to Load Tracking Code in Footer', 'nuptial_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        '2' => esc_attr__( 'Disable', 'nuptial_pro' )
    ),
    'default'  => '2',
    'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','nuptial_pro'),
) );


//  lightbox section //

Nuptial_Kirki::add_section( 'light_box', array(
    'title'          => __( 'Light Box','nuptial_pro' ),
    'description'    => __( 'Light Box Settings', 'nuptial_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'lightbox_theme',
    'label'    => __( 'Lightbox Theme', 'nuptial_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => esc_attr__( 'pp_default', 'nuptial_pro' ),
        '2' => esc_attr__( 'light-rounded', 'nuptial_pro' ),
        '3' => esc_attr__( 'dark-rounded', 'nuptial_pro' ),
        '4' => esc_attr__( 'light-square', 'nuptial_pro' ),
        '5' => esc_attr__( 'dark-square', 'nuptial_pro' ),
        '6' => esc_attr__( 'facebook', 'nuptial_pro' ),
    ),
    'default'  => '1',
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'lightbox_animation_speed',
    'label'    => __( 'Animation Speed', 'nuptial_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'fast' => esc_attr__( 'Fast', 'nuptial_pro' ),
        'slow' => esc_attr__( 'Slow', 'nuptial_pro' ),
        'normal' => esc_attr__( 'Normal', 'nuptial_pro' ),
    ),
    'default'  => 'fast',
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'lightbox_slideshow',
    'label'    => __( 'Autoplay Gallery Speed', 'nuptial_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 100,
        'step' => 10,
    ),
    'default'  => 50,
    'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'lightbox_autoplay_slideshow',
    'label'    => __( 'Enable Autoplay Gallery', 'nuptial_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        '2' => esc_attr__( 'Disable', 'nuptial_pro' )
    ),
    'default'  => '2',
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'lightbox_opacity',
    'label'    => __( 'Select Background Opacity', 'nuptial_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 1,
        'step' => 0.1,
    ),
    'default'  => 0.5,
    'tooltip' => __('Enter 0.1 to 1.0','nuptial_pro'),
) );
Nuptial_Kirki::add_field( 'nuptial_pro', array(
    'settings' => 'lightbox_overlay_gallery',
    'label'    => __( 'Show Gallery Thumbnails', 'nuptial_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array( 
        '1'  => esc_attr__( 'Enable', 'nuptial_pro' ),
        '2' => esc_attr__( 'Disable', 'nuptial_pro' )
    ),
    'default'  => '1',
) );


 

         
do_action('nuptial_pro_child_customizer_options');
