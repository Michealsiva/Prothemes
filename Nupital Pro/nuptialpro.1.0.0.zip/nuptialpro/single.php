<?php
/**
 * The template for displaying all single posts.
 *
 * @package NuptialPro
 */

global $post;
$post_fullwidth = get_post_meta( $post->ID, '_gx_full_width_post', true );
if ( $post_fullwidth && $post->post_type == 'post' ){
    get_template_part('single-post-fullwidth');
}else{
get_header(); 
get_template_part('template-parts/breadcrumb');
do_action('nuptial_pro_content_before');  		
do_action('nuptial_pro_single_flexslider_featured_image'); ?>

	<div id="content" class="site-content">
		<div class="container">	

	<?php do_action('nuptial_pro_two_sidebar_left'); ?>	

    <div id="primary" class="content-area <?php nuptial_pro_layout_class();?> columns">

		<main id="main" class="site-main blog-content" role="main">

		<?php while ( have_posts() ) : the_post(); ?>

			<?php get_template_part( 'template-parts/content', 'single' ); ?>

			<?php do_action('nuptial_pro_after_single_content'); ?>
				<?php if( get_theme_mod ('author_bio_box')): ?>
				<section class="author-bio clearfix">
					<div class="author-info">
						<div class="avatar">
							<?php echo get_avatar( get_the_author_meta( 'email' ), '72' ); ?>
						</div>
						<div class="description">
							<h5><?php echo __( 'About Author:', 'nuptial_pro' ); ?> <?php the_author_posts_link(); ?></h5>
							<?php the_author_meta('description');?>
						</div>
					</div>
				</section>
				<?php endif; ?> 

				<?php if( get_theme_mod('related_posts') && function_exists( 'nuptial_pro_related_posts' ) ) : ?>
					<section class="related-posts clearfix">
						<?php nuptial_pro_related_posts(); ?>
					</section>  
				<?php endif;  ?>   				
 
			<?php
				if( get_theme_mod ('comments',true) ) :
					nuptial_pro_comments_template();
				endif;
			?>

		<?php endwhile; // end of the loop. ?>

		</main><!-- #main -->
	</div><!-- #primary -->
	<?php do_action('nuptial_pro_two_sidebar_right'); 
	
get_footer();
}