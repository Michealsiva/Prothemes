<?php
	require_once Fw_DIR . 'admin/post-types/class-fw-flexslider.php';
	require_once Fw_DIR . 'admin/post-types/class-fw-elastic-slider.php';
	require_once Fw_DIR . 'admin/post-types/class-fw-faq.php';
	require_once Fw_DIR . 'admin/post-types/class-fw-portfolio.php';