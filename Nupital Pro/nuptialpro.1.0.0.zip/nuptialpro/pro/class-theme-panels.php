<?php


/**
 * Integrates this theme with SiteOrigin Page Builder.
 *
 * @package nuptial Pro
 * @since 1.0
 * @license GPL 2.0   
 */
    

/**    
 * Adds default page layouts
 *
 * Adds default page layouts to SiteOrigin Page Builder prebuilt layout section
 *
 * @param $layouts        
 */
if ( ! class_exists('Nuptial_Pro_Prebuilt_Layouts')) { 

    class Nuptial_Pro_Prebuilt_Layouts { 
        public function layouts($layouts) {     
           $layouts['default-home'] = array ( 
				'name' => __('Nuptial Pro Home', 'nuptial_pro'),
				'description' => __('Pre Built Layout for  home page', 'nuptial_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/home.json',

			);

			$layouts['about-us'] = array(
				'name' => __('About Us Page', 'nuptial_pro'),
				'description' => __( 'Pre Built layout for about us page', 'nuptial_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/about-us.json',
			);

			$layouts['contact-us'] = array(
				'name' => __('Contact Us Page', 'nuptial_pro'),
				'description' => __( 'Pre Built layout for contact us page', 'nuptial_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/contact-us.json',
			);

			$layouts['faq'] = array (
				'name' => __('FAQ Page', 'nuptial_pro'),
				'description' => __('Pre Built Layout for faq page', 'nuptial_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/faq.json',
			);
    		return $layouts; 
        }     

    }

}


