<?php
/**
 * @var $title
 * @var $select_product_type
 * @var $latest_product_type
 * @var $latest_product_count
 * @var $order_by
 * @var $order
 */
?> 

<?php 
if ( ! empty( $title ) ) {
	echo '<div class="entry-header"><h1 class="entry-title"><span>' . esc_html( $title ) . '</span></h1></div>'; 
}

	//WP Query args

	$query_args=array (
		'posts_per_page' => $latest_product_count,
		'post_status'    => 'publish',
		'post_type'      => 'product',
		'no_found_rows'  => 1,
		'order'          => $order,
		'tax_query'      => array(
			'relation' => 'AND',
		),
	);
	if($select_product_type == 'latest_product') {
		$query_args['tax_query'][] = array (
			'stock' =>1,
		);
	}

	switch ( $order_by ) {
		case 'price' :
			$query_args['meta_key'] = '_price';
			$query_args['orderby']  = 'meta_value_num';
			break;
		case 'random' :
			$query_args['orderby']  = 'rand';
			break; 
		case 'sales' :
			$query_args['meta_key'] = 'total_sales';
			$query_args['orderby']  = 'meta_value_num';
			break;
		default :
			$query_args['orderby']  = 'date';
	}

	// The Query
	$latest_query = new WP_Query( apply_filters( 'latest_query_args', $query_args) );
	
	switch( $latest_product_type ) {
		case 'normal':
			echo '<div class="latest-product-normal">';
			break;
		case 'carousel' :
			echo  '<div class="latest-product-carousel">';
			break;
		default:
			echo '<div class="latest-product-normal">';
			break;
	} ?>
		<ul class="slides clearfix">
			<?php 
				if ( $latest_query->have_posts() ) {
					while ( $latest_query->have_posts() ) : $latest_query->the_post();
					if($latest_product_type == 'normal') { ?>
						<div class="four columns">
							<div class="product-lists">
								<?php echo '<a href="' . get_the_permalink() . '" class="woocommerce-LoopProduct-link">';
								wc_get_template( 'loop/sale-flash.php' );
								echo woocommerce_get_product_thumbnail('style_outlet_pro_product_img');
								echo '</a>';
								echo '<div class="product-content">';
									echo '<h4 class="woocommerce-loop-product__title">' . get_the_title() . '</h4>';
									echo '<div class="product-bottom">';
									wc_get_template( 'loop/price.php' );
									woocommerce_template_loop_add_to_cart();
									echo '</div>';
								echo '</div>';?>
							</div>
						</div>
					<?php } 
					else { ?>	
	
						<li> 
							<div class="product-lists">
								<?php echo '<a href="' . get_the_permalink() . '" class="woocommerce-LoopProduct-link">';
								wc_get_template( 'loop/sale-flash.php' );
								echo woocommerce_get_product_thumbnail('style_outlet_pro_product_img');
								echo '</a>';
								echo '<div class="product-content">';
									echo '<h4 class="woocommerce-loop-product__title">' . get_the_title() . '</h4>';
									echo '<div class="product-bottom">';
									wc_get_template( 'loop/price.php' );
									woocommerce_template_loop_add_to_cart();
									echo '</div>';
								echo '</div>';?>
							</div>
						</li>
				<?php }
					endwhile;
				} else {
					echo __( 'No products found' );
				}
				wp_reset_postdata();
			?>
		</ul><!--/.products-->
	</div>