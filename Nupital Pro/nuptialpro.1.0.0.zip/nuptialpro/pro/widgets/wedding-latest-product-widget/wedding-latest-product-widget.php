<?php
/*
Widget Name: Latest Product
Description: Creates latest woocommerce product content section
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class Wedding_Latest_Product extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'wedding-latest-product-widget',

			// The name of the widget for display purposes.
			__('Latest Product', 'nuptial_pro'),

			array(
				'description' => __('Display Woocommerce Latest Products', 'nuptial_pro'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/latest-product',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

	function initialize_form() {
		return array(
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Title', 'nuptial_pro' )
			),
			
			'select_product_type' => array(
				'type' => 'select',
				'label' => __('Select Product Type', 'nuptial_pro'),
				'default' => 'all_product',
				'options' => array(
					'all_product' => __('All Product', 'nuptial_pro'),
					'latest_product' => __('Latest Products', 'nuptial_pro'),
				),
			),
			'latest_product_type' => array(
				'type' => 'select',
				'label' => __('Latest Product Type', 'nuptial_pro'),
				'default' => 'normal',
				'options' => array(
					'normal' => __( 'Normal', 'nuptial_pro' ),
					'carousel' => __( 'Carousel', 'nuptial_pro' ),
				),
			),
			'latest_product_count' => array(
				'type' => 'number',
				'label' => __('Number of Latest Products to be Display', 'nuptial_pro'),
			),

			'order_by' => array(
				'type' => 'select',
				'label' => __('Order By', 'nuptial_pro'),
				'default' => 'date',
				'options' => array(
					'date' => __( 'Date', 'nuptial_pro' ),
					'price' => __( 'Price', 'nuptial_pro' ),
					'sales' => __( 'Sales', 'nuptial_pro' ),
					'random' => __( 'Random', 'nuptial_pro' ),
				),
			),
			'order' => array(
				'type' => 'select',
				'label' => __('Order', 'nuptial_pro'),
				'default' => 'desc',
				'options' => array(
					'asc' => __( 'ASC', 'nuptial_pro' ),
					'desc' => __( 'DESC', 'nuptial_pro' ),
				),
			),
		);
	}
	function get_template_variables( $instance, $args ) {  
		return array(
			'title'           => ! empty( $instance['title'] ) ? $instance['title'] : '',
			'select_product_type'    => ! empty( $instance['select_product_type'] ) ? $instance['select_product_type'] : '',
			'latest_product_type'          => ! empty( $instance['latest_product_type'] ) ? $instance['latest_product_type'] : '',
			'latest_product_count' => $instance['latest_product_count'],
			'order_by'=> $instance['order_by'],
			'order' => $instance['order'],
		);
	}
	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class Wedding_Latest_Product

siteorigin_widget_register('wedding-latest-product-widget', __FILE__, 'Wedding_Latest_Product');