<?php
/**
 * Internationalization helper.
 *
 * @package     Kirki
 * @category    Core
 * @author      Aristeides Stathopoulos
 * @copyright   Copyright (c) 2016, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/https://opensource.org/licenses/MIT
 * @since       1.0
 */

if ( ! class_exists( 'Kirki_l10n' ) ) {

	/**
	 * Handles translations
	 */
	class Kirki_l10n {

		/**
		 * The plugin textdomain
		 *
		 * @access protected
		 * @var string
		 */
		protected $textdomain = 'picolog_pro';

		/**
		 * The class constructor.
		 * Adds actions & filters to handle the rest of the methods.
		 *
		 * @access public
		 */
		public function __construct() {

			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		}

		/**
		 * Load the plugin textdomain
		 *
		 * @access public
		 */
		public function load_textdomain() {

			if ( null !== $this->get_path() ) {
				load_textdomain( $this->textdomain, $this->get_path() );
			}
			load_plugin_textdomain( $this->textdomain, false, Kirki::$path . '/languages' );

		}

		/**
		 * Gets the path to a translation file.
		 *
		 * @access protected
		 * @return string Absolute path to the translation file.
		 */
		protected function get_path() {
			$path_found = false;
			$found_path = null;
			foreach ( $this->get_paths() as $path ) {
				if ( $path_found ) {
					continue;
				}
				$path = wp_normalize_path( $path );
				if ( file_exists( $path ) ) {
					$path_found = true;
					$found_path = $path;
				}
			}

			return $found_path;

		}

		/**
		 * Returns an array of paths where translation files may be located.
		 *
		 * @access protected
		 * @return array
		 */
		protected function get_paths() {

			return array(
				WP_LANG_DIR . '/' . $this->textdomain . '-' . get_locale() . '.mo',
				Kirki::$path . '/languages/' . $this->textdomain . '-' . get_locale() . '.mo',
			);

		}

		/**
		 * Shortcut method to get the translation strings
		 *
		 * @static
		 * @access public
		 * @param string $config_id The config ID. See Kirki_Config.
		 * @return array
		 */
		public static function get_strings( $config_id = 'global' ) {

			$translation_strings = array(
				'background-color'      => esc_attr__( 'Background Color', 'picolog_pro' ),
				'background-image'      => esc_attr__( 'Background Image', 'picolog_pro' ),
				'no-repeat'             => esc_attr__( 'No Repeat', 'picolog_pro' ),
				'repeat-all'            => esc_attr__( 'Repeat All', 'picolog_pro' ),
				'repeat-x'              => esc_attr__( 'Repeat Horizontally', 'picolog_pro' ),
				'repeat-y'              => esc_attr__( 'Repeat Vertically', 'picolog_pro' ),
				'inherit'               => esc_attr__( 'Inherit', 'picolog_pro' ),
				'background-repeat'     => esc_attr__( 'Background Repeat', 'picolog_pro' ),
				'cover'                 => esc_attr__( 'Cover', 'picolog_pro' ),
				'contain'               => esc_attr__( 'Contain', 'picolog_pro' ),
				'background-size'       => esc_attr__( 'Background Size', 'picolog_pro' ),
				'fixed'                 => esc_attr__( 'Fixed', 'picolog_pro' ),
				'scroll'                => esc_attr__( 'Scroll', 'picolog_pro' ),
				'background-attachment' => esc_attr__( 'Background Attachment', 'picolog_pro' ),
				'left-top'              => esc_attr__( 'Left Top', 'picolog_pro' ),
				'left-center'           => esc_attr__( 'Left Center', 'picolog_pro' ),
				'left-bottom'           => esc_attr__( 'Left Bottom', 'picolog_pro' ),
				'right-top'             => esc_attr__( 'Right Top', 'picolog_pro' ),
				'right-center'          => esc_attr__( 'Right Center', 'picolog_pro' ),
				'right-bottom'          => esc_attr__( 'Right Bottom', 'picolog_pro' ),
				'center-top'            => esc_attr__( 'Center Top', 'picolog_pro' ),
				'center-center'         => esc_attr__( 'Center Center', 'picolog_pro' ),
				'center-bottom'         => esc_attr__( 'Center Bottom', 'picolog_pro' ),
				'background-position'   => esc_attr__( 'Background Position', 'picolog_pro' ),
				'background-opacity'    => esc_attr__( 'Background Opacity', 'picolog_pro' ),
				'on'                    => esc_attr__( 'ON', 'picolog_pro' ),
				'off'                   => esc_attr__( 'OFF', 'picolog_pro' ),
				'all'                   => esc_attr__( 'All', 'picolog_pro' ),
				'cyrillic'              => esc_attr__( 'Cyrillic', 'picolog_pro' ),
				'cyrillic-ext'          => esc_attr__( 'Cyrillic Extended', 'picolog_pro' ),
				'devanagari'            => esc_attr__( 'Devanagari', 'picolog_pro' ),
				'greek'                 => esc_attr__( 'Greek', 'picolog_pro' ),
				'greek-ext'             => esc_attr__( 'Greek Extended', 'picolog_pro' ),
				'khmer'                 => esc_attr__( 'Khmer', 'picolog_pro' ),
				'latin'                 => esc_attr__( 'Latin', 'picolog_pro' ),
				'latin-ext'             => esc_attr__( 'Latin Extended', 'picolog_pro' ),
				'vietnamese'            => esc_attr__( 'Vietnamese', 'picolog_pro' ),
				'hebrew'                => esc_attr__( 'Hebrew', 'picolog_pro' ),
				'arabic'                => esc_attr__( 'Arabic', 'picolog_pro' ),
				'bengali'               => esc_attr__( 'Bengali', 'picolog_pro' ),
				'gujarati'              => esc_attr__( 'Gujarati', 'picolog_pro' ),
				'tamil'                 => esc_attr__( 'Tamil', 'picolog_pro' ),
				'telugu'                => esc_attr__( 'Telugu', 'picolog_pro' ),
				'thai'                  => esc_attr__( 'Thai', 'picolog_pro' ),
				'serif'                 => _x( 'Serif', 'font style', 'picolog_pro' ),
				'sans-serif'            => _x( 'Sans Serif', 'font style', 'picolog_pro' ),
				'monospace'             => _x( 'Monospace', 'font style', 'picolog_pro' ),
				'font-family'           => esc_attr__( 'Font Family', 'picolog_pro' ),
				'font-size'             => esc_attr__( 'Font Size', 'picolog_pro' ),
				'font-weight'           => esc_attr__( 'Font Weight', 'picolog_pro' ),
				'line-height'           => esc_attr__( 'Line Height', 'picolog_pro' ),
				'font-style'            => esc_attr__( 'Font Style', 'picolog_pro' ),
				'letter-spacing'        => esc_attr__( 'Letter Spacing', 'picolog_pro' ),
				'top'                   => esc_attr__( 'Top', 'picolog_pro' ),
				'bottom'                => esc_attr__( 'Bottom', 'picolog_pro' ),
				'left'                  => esc_attr__( 'Left', 'picolog_pro' ),
				'right'                 => esc_attr__( 'Right', 'picolog_pro' ),
				'center'                => esc_attr__( 'Center', 'picolog_pro' ),
				'justify'               => esc_attr__( 'Justify', 'picolog_pro' ),
				'color'                 => esc_attr__( 'Color', 'picolog_pro' ),
				'add-image'             => esc_attr__( 'Add Image', 'picolog_pro' ),
				'change-image'          => esc_attr__( 'Change Image', 'picolog_pro' ),
				'no-image-selected'     => esc_attr__( 'No Image Selected', 'picolog_pro' ),
				'add-file'              => esc_attr__( 'Add File', 'picolog_pro' ),
				'change-file'           => esc_attr__( 'Change File', 'picolog_pro' ),
				'no-file-selected'      => esc_attr__( 'No File Selected', 'picolog_pro' ),
				'remove'                => esc_attr__( 'Remove', 'picolog_pro' ),
				'select-font-family'    => esc_attr__( 'Select a font-family', 'picolog_pro' ),
				'variant'               => esc_attr__( 'Variant', 'picolog_pro' ),
				'subsets'               => esc_attr__( 'Subset', 'picolog_pro' ),
				'size'                  => esc_attr__( 'Size', 'picolog_pro' ),
				'height'                => esc_attr__( 'Height', 'picolog_pro' ),
				'spacing'               => esc_attr__( 'Spacing', 'picolog_pro' ),
				'ultra-light'           => esc_attr__( 'Ultra-Light 100', 'picolog_pro' ),
				'ultra-light-italic'    => esc_attr__( 'Ultra-Light 100 Italic', 'picolog_pro' ),
				'light'                 => esc_attr__( 'Light 200', 'picolog_pro' ),
				'light-italic'          => esc_attr__( 'Light 200 Italic', 'picolog_pro' ),
				'book'                  => esc_attr__( 'Book 300', 'picolog_pro' ),
				'book-italic'           => esc_attr__( 'Book 300 Italic', 'picolog_pro' ),
				'regular'               => esc_attr__( 'Normal 400', 'picolog_pro' ),
				'italic'                => esc_attr__( 'Normal 400 Italic', 'picolog_pro' ),
				'medium'                => esc_attr__( 'Medium 500', 'picolog_pro' ),
				'medium-italic'         => esc_attr__( 'Medium 500 Italic', 'picolog_pro' ),
				'semi-bold'             => esc_attr__( 'Semi-Bold 600', 'picolog_pro' ),
				'semi-bold-italic'      => esc_attr__( 'Semi-Bold 600 Italic', 'picolog_pro' ),
				'bold'                  => esc_attr__( 'Bold 700', 'picolog_pro' ),
				'bold-italic'           => esc_attr__( 'Bold 700 Italic', 'picolog_pro' ),
				'extra-bold'            => esc_attr__( 'Extra-Bold 800', 'picolog_pro' ),
				'extra-bold-italic'     => esc_attr__( 'Extra-Bold 800 Italic', 'picolog_pro' ),
				'ultra-bold'            => esc_attr__( 'Ultra-Bold 900', 'picolog_pro' ),
				'ultra-bold-italic'     => esc_attr__( 'Ultra-Bold 900 Italic', 'picolog_pro' ),
				'invalid-value'         => esc_attr__( 'Invalid Value', 'picolog_pro' ),
				'add-new'           	=> esc_attr__( 'Add new', 'picolog_pro' ),
				'row'           		=> esc_attr__( 'row', 'picolog_pro' ),
				'limit-rows'            => esc_attr__( 'Limit: %s rows', 'picolog_pro' ),
				'open-section'          => esc_attr__( 'Press return or enter to open this section', 'picolog_pro' ),
				'back'                  => esc_attr__( 'Back', 'picolog_pro' ),
				'reset-with-icon'       => sprintf( esc_attr__( '%s Reset', 'picolog_pro' ), '<span class="dashicons dashicons-image-rotate"></span>' ),
				'text-align'            => esc_attr__( 'Text Align', 'picolog_pro' ),
				'text-transform'        => esc_attr__( 'Text Transform', 'picolog_pro' ),
				'none'                  => esc_attr__( 'None', 'picolog_pro' ),
				'capitalize'            => esc_attr__( 'Capitalize', 'picolog_pro' ),
				'uppercase'             => esc_attr__( 'Uppercase', 'picolog_pro' ),
				'lowercase'             => esc_attr__( 'Lowercase', 'picolog_pro' ),
				'initial'               => esc_attr__( 'Initial', 'picolog_pro' ),
				'select-page'           => esc_attr__( 'Select a Page', 'picolog_pro' ),
				'open-editor'           => esc_attr__( 'Open Editor', 'picolog_pro' ),
				'close-editor'          => esc_attr__( 'Close Editor', 'picolog_pro' ),
				'switch-editor'         => esc_attr__( 'Switch Editor', 'picolog_pro' ),
				'hex-value'             => esc_attr__( 'Hex Value', 'picolog_pro' ),
			);

			// Apply global changes from the kirki/config filter.
			// This is generally to be avoided.
			// It is ONLY provided here for backwards-compatibility reasons.
			// Please use the kirki/{$config_id}/l10n filter instead.
			$config = apply_filters( 'kirki/config', array() );
			if ( isset( $config['i18n'] ) ) {
				$translation_strings = wp_parse_args( $config['i18n'], $translation_strings );
			}

			// Apply l10n changes using the kirki/{$config_id}/l10n filter.
			return apply_filters( 'kirki/' . $config_id . '/l10n', $translation_strings );

		}
	}
}
