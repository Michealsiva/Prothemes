
<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package PicologPro
 */ 
?><!DOCTYPE html>    
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11"><?php
if ( is_singular() && pings_open() ) { ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>"><?php
} ?>
<?php wp_head(); ?>  
</head>

<body <?php body_class(); ?>>    
<div id="page" class="hfeed site <?php echo picolog_pro_site_style_class(); ?>">
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'picolog_pro' ); ?></a>
	<?php do_action('picolog_pro_before_header'); ?>
   <header id="masthead" class="site-header header-wrap <?php echo picolog_pro_site_style_header_class(); ?>" role="banner">
	<?php  if(is_active_sidebar( 'top-left' ) || is_active_sidebar( 'top-right' )): ?>
	    <div class="top-nav">
			<div class="container">		
				<div class="eight columns">
					<div class="cart-left">
						<?php dynamic_sidebar('top-left' ); ?>
					</div>
				</div>

				<div class="eight columns">
					<div class="cart-right">
						<?php dynamic_sidebar('top-right' ); ?>  
					</div>
				</div>
			</div>
		</div> <!-- .top-nav -->
    <?php endif; 
    $style_option = get_theme_mod('style-options');?>
<?php if( $style_option == 'style1' ){ ?>
    <?php do_action('picolog_pro_header_navigation_before'); ?>

	    <div class="branding header-image">
	        <?php if ( get_theme_mod ('header_overlay',false ) ) { 
			   echo '<div class="overlay overlay-header"></div>';     
			} ?>
			<div class="nav-wrap">    	
				<div class="container">
				   <div class="four columns">    
	                   <div class="site-branding"><?php  
						   // $header_text = get_theme_mod( 'header_text' );
							$logo_title = get_theme_mod( 'logo_title' );
							$logo = get_theme_mod( 'logo', '' ); 
							$enable_home_page_logo = get_theme_mod('enable_home_page_logo');
							$tagline = get_theme_mod( 'tagline',true);
							if( $logo_title && function_exists( 'the_custom_logo' ) &&  $enable_home_page_logo ) {
	                            the_custom_logo();     
					        }elseif( $logo != '' && $logo_title ) { ?>
							   <h1 class="site-title img-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url($logo) ?>"></a></h1><?php
							}else { ?>
								<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1><?php
							} 
						    if( $tagline ) : ?>
								<p class="site-description"><?php bloginfo( 'description' ); ?></p><?php
						    endif; ?>
	                    </div><!-- .site-branding -->
	                </div>
	                <div class="twelve columns">
						<nav id="site-navigation" class="main-navigation" role="navigation">
							<button class="menu-toggle" aria-controls="menu" aria-expanded="false"><?php echo apply_filters('picolog_pro_responsive_menu_title', __('Primary Menu','picolog_pro') ); ?></button>
							<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
						</nav><!-- #site-navigation -->	
					</div>
					<?php do_action('picolog_pro_header_navigation_after'); ?>
				</div>
				<?php do_action('picolog_pro_after_primary_nav'); ?>
			</div>
		</div>
	
			<?php do_action('picolog_pro_header_navigation_end'); 
	} 
	else { ?>
			<div class="menu-push">
				<a id="showLeftPush" class="fa fa-times fa-bars"></a>
				<nav id="site-navigation" class="nav-menu-slide menu-vertical menu-left clearfix" role="navigation">
					<h3 id = "hideLeftPush"> Menu <i class="fa fa-arrow-right"></i></h3>
					<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
				</nav>
				
			</div>
			<div class="archive-header">
				<div class="container">
					<div class="site-branding">
						<?php 
							$logo_title = get_theme_mod( 'logo_title' );   
							$tagline = get_theme_mod( 'tagline',true); 
							$home_page_logo = get_theme_mod('enable_home_page_logo',true);
							$other_page_logo = get_theme_mod('enable_other_page_logo',true);
							
							if( $logo_title && function_exists( 'the_custom_logo' ) ) :
								if ( (is_front_page() && $home_page_logo ) || (!is_front_page() && $other_page_logo ) )
                                the_custom_logo(); ?>
                  				<h3 class="cover-heading"><a style="color: #<?php header_textcolor(); ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h3> 
                            
                           	<?php else : ?>
                               		<h3 class="cover-heading"><a style="color: #<?php header_textcolor(); ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h3> 
                              
						<?php endif; ?>
						<?php if( $tagline ) : ?>
								<p class="lead" style="color: #<?php header_textcolor(); ?>"><?php bloginfo( 'description' ); ?></p>
						<?php endif; 
						if  ( is_front_page() && 'posts' != get_option('show_on_front') ){ ?> 
							<div class="arrow"><i class="fa fa-arrow-circle-down"></i></a>
						<?php } ?>
					</div><!-- .site-branding -->
				</div>
			</div>
		<?php do_action('picolog_pro_header_end'); 
	}?>

    </header><!-- #masthead -->
	<?php do_action('picolog_pro_header_after');