<?php
/*
Widget Name: Cleanse Pro: Team Member 2
Description: Creates Team Members
Author: N. Venkat Raj 
Author URI: https://www.genexthemes.com
Widget URI: todo
Video URI: todo
*/
class ThemePro_Icon_Widget extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'themepro-icon-widget',

			// The name of the widget for display purposes.
			__('Theme Pro Icon Widget', 'framework'),

			array(
				'description' => __('Display Icons', 'framework'),
				'help'        => 'https://www.genexthemes.com/docs/widgets/best-sale-product',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

    function initialize_form() {
    	return array(
			'title' => array(
				'type' => 'text',
				'label' => __( 'Title', 'framework' ),
			),
			'icon' => array(
				'type' => 'icon',
				'label' => __('Select an icon', 'framework'),
			),
			'icon_color' => array(
				'type' => 'color',
				'label' => __( 'Icon Color.', 'framework' ),
			),
			'icon_border_color' => array(
				'type' => 'color',
				'label' => __( 'Icon Border Color.', 'framework' ),
			),
			'icon_background' => array(
				'type' => 'color',
				'label' => __( 'Icon Background.', 'framework' ),
			),
			'icon_hover_background' => array(
				'type' => 'color',
				'label' => __( 'Icon Hover Background.', 'framework' ),
			),
			'icon_hover_color' => array(
				'type' => 'color',
				'label' => __( 'Icon Hover Background.', 'framework' ),
			),
			'icon_size' => array(
				'type'  => 'measurement',
				'label' => __( 'Size', 'so-widgets-bundle' ),
			),
			'more_url' => array( 
				'type' => 'link',
				'label' => __('Read More URL', 'framework'),
			),
			'new_window' => array(
				'type' => 'checkbox',
				'label' => __('Open in new window?', 'framework'),
			),
		);
	}


	function get_template_variables( $instance, $args ) {
		$icon_styles = array();
		if( ! empty( $instance['icon_size'] ) ) :
			$icon_styles[] = 'font-size: ' .  $instance['icon_size'];
		endif;
		return array(
			'title' =>$instance['title'],
			'more_url' => $instance['more_url'],
			'icon' => $instance['icon'], 
			'icon_styles' => $icon_styles,
			'icon_border_color' => $instance['icon_border_color'],
			'new_window' => $instance['new_window'],
			'icon_background' => $instance['icon_background'],
			'icon_hover_background' => $instance['icon_hover_background']
		);
	}
	function get_less_variables($instance) {
		return array(     
			'icon_background' => isset($instance['icon_background']) ? $instance['icon_background']:'',
			'icon_color' => isset($instance['icon_color']) ? $instance['icon_color']:'',
		    'icon_hover_background' => isset($instance['icon_hover_background']) ? $instance['icon_hover_background']:'',
		    'icon_hover_color' => isset($instance['icon_hover_color']) ? $instance['icon_hover_color']:'',
		);
	}
	function get_template_name($instance) {
		return 'default';
	}
	function get_style_name($instance) {
		return 'default';
	}

} // class ThemePro_Icon_Widget

siteorigin_widget_register('themepro-icon-widget', __FILE__, 'ThemePro_Icon_Widget');