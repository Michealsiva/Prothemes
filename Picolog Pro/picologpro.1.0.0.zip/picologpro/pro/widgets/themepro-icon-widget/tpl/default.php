<?php 
$icon_border_color = ! empty($icon_border_color) ? 'border-color: ' . $icon_border_color .';' : ''; ?>
 
<div class="icon-widget">
	<div class="icon-wrapper" >

		<?php if( ! empty( $more_url) ) : ?>
			<a href="<?php echo sow_esc_url($more_url) ?>" class="link-icon" <?php if ( ! empty( $new_window ) ) echo 'target="_blank"'; ?> style="<?php echo $icon_border_color; ?>" >
			<?php endif; 
				echo siteorigin_widget_get_icon( $icon, $icon_styles ); 
			?>  

		<?php if( ! empty( $more_url)) : ?>
			</a>
		<?php endif; ?>
		<?php if( ! empty( $title ) ) : ?>
			<span class="icon-title"><?php echo $title; ?></span>
		<?php endif; ?>
	</div>
</div>