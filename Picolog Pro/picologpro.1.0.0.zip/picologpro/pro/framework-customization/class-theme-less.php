<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Picolog_Pro_Theme_Less_File' ) ) {  
	class Picolog_Pro_Theme_Less_File {
    
      /*  public function picolog_pro_recent_work_less_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/less/file-name.less';  
        } */
		 
        
	}
}
