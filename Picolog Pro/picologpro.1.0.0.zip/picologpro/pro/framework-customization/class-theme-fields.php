<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Picolog_Pro_Theme_fields' ) ) {  
	class Picolog_Pro_Theme_fields {
	
      	
        /* Add Or Override the widegt fields */ 
        public function picolog_pro_extend_testimonial_form($form_options, $widget) {  
			  $form_options['bg_color'] = array(
			  	'type' => 'color',
		        'label' => __( 'Choose Testimonial Background Color', 'picolog_pro' ),
		        'default' => '' 
			  ); 
			  
			  return $form_options; 

        } 
        public function picolog_pro_extend_recent_work_form($form_options, $widget) {  
        	  $form_options['title'] = array (
			  	'type'  => 'checkbox',
			  	'label' =>__('Enable Caption','picolog_pro'),
			  	'default' => true,
			  );
			  $form_options['bg_color'] = array(
			  	'type' => 'color',
		        'label' => __( 'Choose Recent work Caption Background Color', 'picolog_pro' ),
		        'default' => '#ffffff' 
			  ); 
			  
			  return $form_options; 

        } 

    }
}

