<?php
/**
 * Internationalization helper.
 *
 * @package     Kirki
 * @category    Core
 * @author      Aristeides Stathopoulos
 * @copyright   Copyright (c) 2016, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/https://opensource.org/licenses/MIT
 * @since       1.0
 */

if ( ! class_exists( 'Kirki_l10n' ) ) {

	/**
	 * Handles translations
	 */
	class Kirki_l10n {

		/**
		 * The plugin textdomain
		 *
		 * @access protected
		 * @var string
		 */
		protected $textdomain = 'structural_pro';

		/**
		 * The class constructor.
		 * Adds actions & filters to handle the rest of the methods.
		 *
		 * @access public
		 */
		public function __construct() {

			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		}

		/**
		 * Load the plugin textdomain
		 *
		 * @access public
		 */
		public function load_textdomain() {

			if ( null !== $this->get_path() ) {
				load_textdomain( $this->textdomain, $this->get_path() );
			}
			load_plugin_textdomain( $this->textdomain, false, Kirki::$path . '/languages' );

		}

		/**
		 * Gets the path to a translation file.
		 *
		 * @access protected
		 * @return string Absolute path to the translation file.
		 */
		protected function get_path() {
			$path_found = false;
			$found_path = null;
			foreach ( $this->get_paths() as $path ) {
				if ( $path_found ) {
					continue;
				}
				$path = wp_normalize_path( $path );
				if ( file_exists( $path ) ) {
					$path_found = true;
					$found_path = $path;
				}
			}

			return $found_path;

		}

		/**
		 * Returns an array of paths where translation files may be located.
		 *
		 * @access protected
		 * @return array
		 */
		protected function get_paths() {

			return array(
				WP_LANG_DIR . '/' . $this->textdomain . '-' . get_locale() . '.mo',
				Kirki::$path . '/languages/' . $this->textdomain . '-' . get_locale() . '.mo',
			);

		}

		/**
		 * Shortcut method to get the translation strings
		 *
		 * @static
		 * @access public
		 * @param string $config_id The config ID. See Kirki_Config.
		 * @return array
		 */
		public static function get_strings( $config_id = 'global' ) {

			$translation_strings = array(
				'background-color'      => esc_attr__( 'Background Color', 'structural_pro' ),
				'background-image'      => esc_attr__( 'Background Image', 'structural_pro' ),
				'no-repeat'             => esc_attr__( 'No Repeat', 'structural_pro' ),
				'repeat-all'            => esc_attr__( 'Repeat All', 'structural_pro' ),
				'repeat-x'              => esc_attr__( 'Repeat Horizontally', 'structural_pro' ),
				'repeat-y'              => esc_attr__( 'Repeat Vertically', 'structural_pro' ),
				'inherit'               => esc_attr__( 'Inherit', 'structural_pro' ),
				'background-repeat'     => esc_attr__( 'Background Repeat', 'structural_pro' ),
				'cover'                 => esc_attr__( 'Cover', 'structural_pro' ),
				'contain'               => esc_attr__( 'Contain', 'structural_pro' ),
				'background-size'       => esc_attr__( 'Background Size', 'structural_pro' ),
				'fixed'                 => esc_attr__( 'Fixed', 'structural_pro' ),
				'scroll'                => esc_attr__( 'Scroll', 'structural_pro' ),
				'background-attachment' => esc_attr__( 'Background Attachment', 'structural_pro' ),
				'left-top'              => esc_attr__( 'Left Top', 'structural_pro' ),
				'left-center'           => esc_attr__( 'Left Center', 'structural_pro' ),
				'left-bottom'           => esc_attr__( 'Left Bottom', 'structural_pro' ),
				'right-top'             => esc_attr__( 'Right Top', 'structural_pro' ),
				'right-center'          => esc_attr__( 'Right Center', 'structural_pro' ),
				'right-bottom'          => esc_attr__( 'Right Bottom', 'structural_pro' ),
				'center-top'            => esc_attr__( 'Center Top', 'structural_pro' ),
				'center-center'         => esc_attr__( 'Center Center', 'structural_pro' ),
				'center-bottom'         => esc_attr__( 'Center Bottom', 'structural_pro' ),
				'background-position'   => esc_attr__( 'Background Position', 'structural_pro' ),
				'background-opacity'    => esc_attr__( 'Background Opacity', 'structural_pro' ),
				'on'                    => esc_attr__( 'ON', 'structural_pro' ),
				'off'                   => esc_attr__( 'OFF', 'structural_pro' ),
				'all'                   => esc_attr__( 'All', 'structural_pro' ),
				'cyrillic'              => esc_attr__( 'Cyrillic', 'structural_pro' ),
				'cyrillic-ext'          => esc_attr__( 'Cyrillic Extended', 'structural_pro' ),
				'devanagari'            => esc_attr__( 'Devanagari', 'structural_pro' ),
				'greek'                 => esc_attr__( 'Greek', 'structural_pro' ),
				'greek-ext'             => esc_attr__( 'Greek Extended', 'structural_pro' ),
				'khmer'                 => esc_attr__( 'Khmer', 'structural_pro' ),
				'latin'                 => esc_attr__( 'Latin', 'structural_pro' ),
				'latin-ext'             => esc_attr__( 'Latin Extended', 'structural_pro' ),
				'vietnamese'            => esc_attr__( 'Vietnamese', 'structural_pro' ),
				'hebrew'                => esc_attr__( 'Hebrew', 'structural_pro' ),
				'arabic'                => esc_attr__( 'Arabic', 'structural_pro' ),
				'bengali'               => esc_attr__( 'Bengali', 'structural_pro' ),
				'gujarati'              => esc_attr__( 'Gujarati', 'structural_pro' ),
				'tamil'                 => esc_attr__( 'Tamil', 'structural_pro' ),
				'telugu'                => esc_attr__( 'Telugu', 'structural_pro' ),
				'thai'                  => esc_attr__( 'Thai', 'structural_pro' ),
				'serif'                 => _x( 'Serif', 'font style', 'structural_pro' ),
				'sans-serif'            => _x( 'Sans Serif', 'font style', 'structural_pro' ),
				'monospace'             => _x( 'Monospace', 'font style', 'structural_pro' ),
				'font-family'           => esc_attr__( 'Font Family', 'structural_pro' ),
				'font-size'             => esc_attr__( 'Font Size', 'structural_pro' ),
				'font-weight'           => esc_attr__( 'Font Weight', 'structural_pro' ),
				'line-height'           => esc_attr__( 'Line Height', 'structural_pro' ),
				'font-style'            => esc_attr__( 'Font Style', 'structural_pro' ),
				'letter-spacing'        => esc_attr__( 'Letter Spacing', 'structural_pro' ),
				'top'                   => esc_attr__( 'Top', 'structural_pro' ),
				'bottom'                => esc_attr__( 'Bottom', 'structural_pro' ),
				'left'                  => esc_attr__( 'Left', 'structural_pro' ),
				'right'                 => esc_attr__( 'Right', 'structural_pro' ),
				'center'                => esc_attr__( 'Center', 'structural_pro' ),
				'justify'               => esc_attr__( 'Justify', 'structural_pro' ),
				'color'                 => esc_attr__( 'Color', 'structural_pro' ),
				'add-image'             => esc_attr__( 'Add Image', 'structural_pro' ),
				'change-image'          => esc_attr__( 'Change Image', 'structural_pro' ),
				'no-image-selected'     => esc_attr__( 'No Image Selected', 'structural_pro' ),
				'add-file'              => esc_attr__( 'Add File', 'structural_pro' ),
				'change-file'           => esc_attr__( 'Change File', 'structural_pro' ),
				'no-file-selected'      => esc_attr__( 'No File Selected', 'structural_pro' ),
				'remove'                => esc_attr__( 'Remove', 'structural_pro' ),
				'select-font-family'    => esc_attr__( 'Select a font-family', 'structural_pro' ),
				'variant'               => esc_attr__( 'Variant', 'structural_pro' ),
				'subsets'               => esc_attr__( 'Subset', 'structural_pro' ),
				'size'                  => esc_attr__( 'Size', 'structural_pro' ),
				'height'                => esc_attr__( 'Height', 'structural_pro' ),
				'spacing'               => esc_attr__( 'Spacing', 'structural_pro' ),
				'ultra-light'           => esc_attr__( 'Ultra-Light 100', 'structural_pro' ),
				'ultra-light-italic'    => esc_attr__( 'Ultra-Light 100 Italic', 'structural_pro' ),
				'light'                 => esc_attr__( 'Light 200', 'structural_pro' ),
				'light-italic'          => esc_attr__( 'Light 200 Italic', 'structural_pro' ),
				'book'                  => esc_attr__( 'Book 300', 'structural_pro' ),
				'book-italic'           => esc_attr__( 'Book 300 Italic', 'structural_pro' ),
				'regular'               => esc_attr__( 'Normal 400', 'structural_pro' ),
				'italic'                => esc_attr__( 'Normal 400 Italic', 'structural_pro' ),
				'medium'                => esc_attr__( 'Medium 500', 'structural_pro' ),
				'medium-italic'         => esc_attr__( 'Medium 500 Italic', 'structural_pro' ),
				'semi-bold'             => esc_attr__( 'Semi-Bold 600', 'structural_pro' ),
				'semi-bold-italic'      => esc_attr__( 'Semi-Bold 600 Italic', 'structural_pro' ),
				'bold'                  => esc_attr__( 'Bold 700', 'structural_pro' ),
				'bold-italic'           => esc_attr__( 'Bold 700 Italic', 'structural_pro' ),
				'extra-bold'            => esc_attr__( 'Extra-Bold 800', 'structural_pro' ),
				'extra-bold-italic'     => esc_attr__( 'Extra-Bold 800 Italic', 'structural_pro' ),
				'ultra-bold'            => esc_attr__( 'Ultra-Bold 900', 'structural_pro' ),
				'ultra-bold-italic'     => esc_attr__( 'Ultra-Bold 900 Italic', 'structural_pro' ),
				'invalid-value'         => esc_attr__( 'Invalid Value', 'structural_pro' ),
				'add-new'           	=> esc_attr__( 'Add new', 'structural_pro' ),
				'row'           		=> esc_attr__( 'row', 'structural_pro' ),
				'limit-rows'            => esc_attr__( 'Limit: %s rows', 'structural_pro' ),
				'open-section'          => esc_attr__( 'Press return or enter to open this section', 'structural_pro' ),
				'back'                  => esc_attr__( 'Back', 'structural_pro' ),
				'reset-with-icon'       => sprintf( esc_attr__( '%s Reset', 'structural_pro' ), '<span class="dashicons dashicons-image-rotate"></span>' ),
				'text-align'            => esc_attr__( 'Text Align', 'structural_pro' ),
				'text-transform'        => esc_attr__( 'Text Transform', 'structural_pro' ),
				'none'                  => esc_attr__( 'None', 'structural_pro' ),
				'capitalize'            => esc_attr__( 'Capitalize', 'structural_pro' ),
				'uppercase'             => esc_attr__( 'Uppercase', 'structural_pro' ),
				'lowercase'             => esc_attr__( 'Lowercase', 'structural_pro' ),
				'initial'               => esc_attr__( 'Initial', 'structural_pro' ),
				'select-page'           => esc_attr__( 'Select a Page', 'structural_pro' ),
				'open-editor'           => esc_attr__( 'Open Editor', 'structural_pro' ),
				'close-editor'          => esc_attr__( 'Close Editor', 'structural_pro' ),
				'switch-editor'         => esc_attr__( 'Switch Editor', 'structural_pro' ),
				'hex-value'             => esc_attr__( 'Hex Value', 'structural_pro' ),
			);

			// Apply global changes from the kirki/config filter.
			// This is generally to be avoided.
			// It is ONLY provided here for backwards-compatibility reasons.
			// Please use the kirki/{$config_id}/l10n filter instead.
			$config = apply_filters( 'kirki/config', array() );
			if ( isset( $config['i18n'] ) ) {
				$translation_strings = wp_parse_args( $config['i18n'], $translation_strings );
			}

			// Apply l10n changes using the kirki/{$config_id}/l10n filter.
			return apply_filters( 'kirki/' . $config_id . '/l10n', $translation_strings );

		}
	}
}
