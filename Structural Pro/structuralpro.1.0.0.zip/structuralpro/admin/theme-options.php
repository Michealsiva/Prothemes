<?php  
/**
 * Created by PhpStorm.
 * User: venkat
 * Date: 2/5/16
 * Time: 4:32 PM        
 */    
           
include_once( get_template_directory() . '/admin/kirki/kirki.php' );   
include_once( get_template_directory() . '/admin/kirki-helpers/class-theme-kirki.php' ); 
     

Structural_Kirki::add_config( 'structural_pro', array(     
    'capability'    => 'edit_theme_options',                  
    'option_type'   => 'theme_mod',          
) );               
     
// Flat option start //   

//  site identity section // 

Structural_Kirki::add_section( 'title_tagline', array(
    'title'          => __( 'Site Identity','structural_pro' ),
    'description'    => __( 'Site Header Options', 'structural_pro'),       
    'priority'       => 8,                                                                                                                
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'logo_title',
    'label'    => __( 'Enable Logo as Title', 'structural_pro' ),
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'priority' => 5,
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' )
    ),
    'default'  => 'off',   
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'tagline',
    'label'    => __( 'Show site Tagline', 'structural_pro' ), 
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' )
    ),
    'default'  => 'on',
) );  

// home panel //

Structural_Kirki::add_panel( 'home_options', array(     
    'title'       => __( 'Home', 'structural_pro' ),
    'description' => __( 'Home Page Related Options', 'structural_pro' ),     
) );  


// home page type section

 Structural_Kirki::add_section( 'home-structural', array(
    'title'          => __( 'PRO Home - General Settings','structural_pro' ),
    'description'    => __( 'Home Page options', 'structural_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'enable_home_default_content',
    'label'    => __( 'Enable Home Page Default Content', 'structural_pro' ),
    'section'  => 'home-structural',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Use pagebuilder to built pro home page (or) Use prebuilt layout','structural_pro'),
) );  


// Slider section   

Structural_Kirki::add_section( 'slider-section', array(
    'title'          => __( 'Slider Section','structural_pro' ),
    'description'    => __( 'Home Page Slider Related Options', 'structural_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );
Structural_Kirki::add_field( 'structural_pro', array(  
    'settings' => 'slider_field',  
    'label'    => __( 'Enable Slider Post ( Section )', 'structural_pro' ),
    'section'  => 'slider-section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Slider Post in home page','structural_pro'),
) );
 
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'slider_cat',
    'label'    => __( 'Slider Posts category', 'structural_pro' ),
    'section'  => 'slider-section',
    'type'     => 'select',
    'choices' => Kirki_Helper::get_terms( 'category' ),
    'active_callback' => array(
        array(
            'setting'  => 'slider_field', 
            'operator' => '==',
            'value'    => true, 
        ),
    ),
    'tooltip' => __('Create post ( Goto Dashboard => Post => Add New ) and Post Featured Image ( Preferred size is 1200 x 450 pixels ) as taken as slider image and Post Content as taken as Flexcaption.','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'slider_count',
    'label'    => __( 'No. of Sliders', 'structural_pro' ),
    'section'  => 'slider-section',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 999,
        'step' => 1,
    ),
    'default'  => 2,
    'active_callback' => array(
        array(
            'setting'  => 'slider_field',
            'operator' => '==',
            'value'    => true,
        ),                                                                             
    ),
    'tooltip' => __('Enter number of slides you want to display under your selected Category','structural_pro'),
) );

// service section 

Structural_Kirki::add_section( 'service_section', array(
    'title'          => __( 'Service Section','structural_pro' ),
    'description'    => __( 'Home Page - Service Related Options', 'structural_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Structural_Kirki::add_field( 'structural_pro', array(  
    'settings' => 'service_section_status',  
    'label'    => __( 'Enable Service Section', 'structural_pro' ),
    'section'  => 'service_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Service section in home page','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'service_section_title',
    'label'    => __( 'Service Section Title & Description', 'structural_pro' ),
    'section'  => 'service_section',
    'type'     => 'dropdown-pages', 
    'active_callback' => array(
        array(
            'setting'  => 'service_section_status',
            'operator' => '==',
            'value'    => true,
        ),                                                                       
    ),
) );

for ( $i = 1 ; $i <= 3 ; $i++ ) {
    //Create the settings Once, and Loop through it.
    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'service_section_icon_'.$i,
        'label'    => sprintf(__( 'Service Section Icons #%1$s', 'structural_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'text',
        'description' => sprintf(__( '%1$s (fa fa-apple) ', 'structural_pro' ), '<a href="http://fontawesome.io/icons/">Type FontAwesome icons</a>' ),          
        'active_callback' => array(
            array(
                'setting'  => 'service_section_status',
                'operator' => '==',
                'value'    => true,
            ),                                                                       
        ),
    ) );

    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'service_section_'.$i,
        'label'    => sprintf(__( 'Service Section #%1$s', 'structural_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'dropdown-pages', 
        'active_callback' => array(
            array(
                'setting'  => 'service_section_status',
                'operator' => '==',
                'value'    => true,
            ),          
        ),    
    ) );
    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'service_color_'.$i,
        'label'    => sprintf(__( 'Choose Service Section Icons #%1$s', 'structural_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'color', 
        'active_callback' => array(
            array(
                'setting'  => 'service_section_status',
                'operator' => '==',
                'value'    => true,
            ),                                                                        
        ),        
    ) );
}
 
// Image section 

Structural_Kirki::add_section( 'image-content-section', array(
    'title'          => __( 'Image Content Section','structural_pro' ),
    'description'    => __( 'Home Page - Related Options', 'structural_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Structural_Kirki::add_field( 'structural_pro', array(  
    'settings' => 'image_content_section_status',  
    'label'    => __( 'Enable Image content Section', 'structural_pro' ),
    'section'  => 'image-content-section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Image content section in home page','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'image_content_section_title',
    'label'    => __( 'Image Section Title & Description', 'structural_pro' ),
    'section'  => 'image-content-section',
    'type'     => 'dropdown-pages', 
    'active_callback' => array(
        array(
            'setting'  => 'image_content_section_status',
            'operator' => '==',
            'value'    => true,
        ),          
    ),    
) );

for ( $i = 1 ; $i <= 2 ; $i++ ) {
    //Create the settings Once, and Loop through it.
    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'image_content_section_'.$i,
        'label'    => sprintf(__( 'Image Contenr Section #%1$s', 'structural_pro' ), $i ),
        'section'  => 'image-content-section',
        'type'     => 'dropdown-pages', 
        'active_callback' => array(
            array(
                'setting'  => 'image_content_section_status',
                'operator' => '==',
                'value'    => true,
            ),          
        ),    
    ) );
}


// latest blog section 

Structural_Kirki::add_section( 'latest_blog_section', array(
    'title'          => __( 'Latest Blog Section','structural_pro' ),
    'description'    => __( 'Home Page - Latest Blog Options', 'structural_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'enable_recent_post_service',
    'label'    => __( 'Enable Recent Post Section', 'structural_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),

    'default'  => 'on',
    'tooltip' => __('Enable recent post section in home page','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'recent_post_section_title',
    'label'    => __( 'Recent Post Section Title & Description', 'structural_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'dropdown-pages', 
    'active_callback' => array(
        array(
            'setting'  => 'enable_recent_post_service',
            'operator' => '==',
            'value'    => true,
        ),

    ),
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'recent_posts_count',
    'label'    => __( 'No. of Recent Posts', 'structural_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'number',
    'choices' => array(
        'min' => 2,
        'max' => 99,
        'step' => 2,
    ),
    'default'  =>3,
    'active_callback' => array(
        array(
            'setting'  => 'enable_recent_post_service',
            'operator' => '==',
            'value'    => true,
        ),

    ),
) );


// general panel      

Structural_Kirki::add_panel( 'general_panel', array(   
    'title'       => __( 'General Settings', 'structural_pro' ),  
    'description' => __( 'general settings', 'structural_pro' ),         
) );
//  Page title bar section // 

Structural_Kirki::add_section( 'header-pagetitle-bar', array(   
    'title'          => __( 'Page Title Bar & Breadcrumb','structural_pro' ),
    'description'    => __( 'Page Title bar related options', 'structural_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) ); 
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'global_page_title_bar',
    'label'    => __( 'Check the box if you want to use a global page title bar settings. This option overrides the page options', 'structural_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'checkbox',
    'default' => '0',
) );   

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'page_titlebar',  
    'label'    => __( 'Page Title Bar', 'structural_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( 'Show Bar and Content', 'structural_pro' ),
        2 => __('Hide','structural_pro'),
    ),
    'default' => 1,
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'page_titlebar_text',  
    'label'    => __( 'Page Title Bar Text', 'structural_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        0 => __( 'Show', 'structural_pro' ),
        1 => __( 'Hide', 'structural_pro' ), 
    ),
    'default' => 0,
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'breadcrumb',  
    'label'    => __( 'Hide Breadcrumb', 'structural_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'checkbox',
    'default'  => 0,
) ); 

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'breadcrumb_char',
    'label'    => __( 'Breadcrumb Character', 'structural_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( ' >> ', 'structural_pro' ),
        2 => __( ' / ', 'structural_pro' ),
        3 => __( ' > ', 'structural_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'breadcrumb',
            'operator' => '==',
            'value'    => 0,
        ),
    ),
    //'sanitize_callback' => 'allow_htmlentities'
) );

//  pagination section // 

Structural_Kirki::add_section( 'general-pagination', array(   
    'title'          => __( 'Pagination','structural_pro' ),
    'description'    => __( 'Pagination related options', 'structural_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'numeric_pagination',
    'label'    => __( 'Numeric Pagination', 'structural_pro' ),   
    'section'  => 'general-pagination',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Numbered', 'structural_pro' ),
        'off' => esc_attr__( 'Next/Previous', 'structural_pro' )
    ),
    'default'  => 'on',
) );

// skin color panel 

Structural_Kirki::add_panel( 'skin_color_panel', array(   
    'title'       => __( 'Skin Color', 'structural_pro' ),  
    'description' => __( 'Color Settings', 'structural_pro' ),         
) );
// color scheme section 

Structural_Kirki::add_section( 'multiple_color_section', array(
    'title'          => __( 'Color Scheme','structural_pro' ),
    'description'    => __( 'Select your color scheme', 'structural_pro'),
    'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 9,
) );  

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'color_scheme',
    'label'    => __( 'Select your color scheme', 'structural_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'palette',
    'choices'     => array( 
        '1' => array( 
            '#ffb500',
        ),
        '2' => array(
            '#00aea3',
        ),
        '3' => array(
            '#ec008f',
        ),
        '4' => array(
            '#00ca56',
        ),
        '5' => array(
            '#8f39a9',
        ),
        '6' => array(
            '#ea403d',
        ),
    ),
    'default' => '1',
//'default'  => 'on',
) );

/* custom color stylesheet 

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'enable_custom_color_scheme',
    'label'    => __( 'Enable Custom color scheme', 'structural_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' )
    ),
    'default'  => 'off',
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'custom_color_scheme',
    'label'    => __( 'Select custom color scheme', 'structural_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'color',
    'default'  => '#ffb500',
    'alpha'  => false,
    'active_callback' => array(
        array (
            'setting'  => 'enable_custom_color_scheme',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
*/
// typography panel //  

Structural_Kirki::add_panel( 'typography', array( 
    'title'       => __( 'Typography', 'structural_pro' ),
    'description' => __( 'Typography and Link Color Settings', 'structural_pro' ),
) );
   
    Structural_Kirki::add_section( 'typography_section', array(
        'title'          => __( 'General Settings','structural_pro' ),
        'description'    => __( 'General Settings', 'structural_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );
        

    Structural_Kirki::add_section( 'body_font', array(
        'title'          => __( 'Body Font','structural_pro' ), 
        'description'    => __( 'Specify the body font properties', 'structural_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) ); 

    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'body_typography',
        'label'    => __( 'Enable Custom body Settings', 'structural_pro' ),
        'section'  => 'body_font',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'structural_pro' ),
            'off' => esc_attr__( 'Disable', 'structural_pro' )
        ),
        'tooltip' => __('Turn on to body typography and turn off for default typography','structural_pro'),
        'default'  => 'off',
    ) );


    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'body',
        'label'    => __( 'Body Settings', 'structural_pro' ),
        'section'  => 'body_font', 
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Open Sans', 
            'variant'        => 'regular',
            'font-size'      => '16px',  
            'line-height'    => '1.5',
            'letter-spacing' => '0',
            'color'          => '#202020', 
        ),
        'output'      => array(
            array(
                'element' => 'body',
                //'suffix' => '!important',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'body_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );


    Structural_Kirki::add_section( 'heading_section', array(
        'title'          => __( 'Heading Font','structural_pro' ),
        'description'    => __( 'Specify typography of H1, H2, H3, H4, H5, H6', 'structural_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'heading_one_typography',
        'label'    => __( 'Enable Custom H1 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'structural_pro' ),
            'off' => esc_attr__( 'Disable', 'structural_pro' )
        ),
        'tooltip' => __('Turn on to H1 typography and turn off for default typography','structural_pro'),
        'default'  => 'off',
    ) );


    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'h1',  
        'label'    => __( 'H1 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '48px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h1',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_one_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );
    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'heading_two_typography',
        'label'    => __( 'Enable Custom H2 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'structural_pro' ),
            'off' => esc_attr__( 'Disable', 'structural_pro' )
        ),
        'tooltip' => __('Turn on to H2 typography and turn off for default typography','structural_pro'),
        'default'  => 'off',
    ) );


    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'h2',
        'label'    => __( 'H2 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '36px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h2',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_two_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'heading_three_typography',
        'label'    => __( 'Enable Custom H3 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'structural_pro' ),
            'off' => esc_attr__( 'Disable', 'structural_pro' )
        ),
        'tooltip' => __('Turn on to H3 typography and turn off for default typography','structural_pro'),
        'default'  => 'off',
    ) );


    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'h3',
        'label'    => __( 'H3 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default' => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '30px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h3',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_three_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'heading_four_typography',
        'label'    => __( 'Enable Custom H4 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'structural_pro' ),
            'off' => esc_attr__( 'Disable', 'structural_pro' )
        ),
        'tooltip' => __('Turn on to H4 typography and turn off for default typography','structural_pro'),
        'default'  => 'off',
    ) );


    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'h4',
        'label'    => __( 'H4 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '24px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h4',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_four_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'heading_five_typography',
        'label'    => __( 'Enable Custom H5 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'structural_pro' ),
            'off' => esc_attr__( 'Disable', 'structural_pro' )
        ),
        'tooltip' => __('Turn on to H5 typography and turn off for default typography','structural_pro'),
        'default'  => 'off',
    ) );



    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'h5',
        'label'    => __( 'H5 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway',
            'variant'        => '700',
            'font-size'      => '18px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h5',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_five_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );

    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'heading_six_typography',
        'label'    => __( 'Enable Custom H6 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'structural_pro' ),
            'off' => esc_attr__( 'Disable', 'structural_pro' )
        ),
        'tooltip' => __('Turn on to H6 typography and turn off for default typography','structural_pro'),
        'default'  => 'off',
    ) );



    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'h6',
        'label'    => __( 'H6 Settings', 'structural_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Raleway', 
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#202020',
        ),
        'output'      => array(
            array(
                'element' => 'h6',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_six_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    // navigation font 
    Structural_Kirki::add_section( 'navigation_section', array(
        'title'          => __( 'Navigation Font','structural_pro' ),
        'description'    => __( 'Specify Navigation font properties', 'structural_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'navigation_font_status',
        'label'    => __( 'Enable Navigation Font Settings', 'structural_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'structural_pro' ),
            'off' => esc_attr__( 'Disable', 'structural_pro' )
        ),
        'tooltip' => __('Turn on to Navigation Font typography and turn off for default typography','structural_pro'),
        'default'  => 'off',
    ) );

    Structural_Kirki::add_field( 'structural_pro', array(
        'settings' => 'navigation_font',
        'label'    => __( 'Navigation Font Settings', 'structural_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Open Sans',
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8', 
            'letter-spacing' => '0',
            'color'          => '#ffffff',
        ),
        'output'      => array(
            array(
                'element' => '.main-navigation a',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'navigation_font_status',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );



// header panel //  

Structural_Kirki::add_panel( 'header_panel', array(     
    'title'       => __( 'Header', 'structural_pro' ),
    'description' => __( 'Header Related Options', 'structural_pro' ), 
) );  

/* STICKY HEADER section */     
  
Structural_Kirki::add_section( 'stricky_header', array(
    'title'          => __( 'Sticky Menu','structural_pro' ),
    'description'    => __( 'sticky header', 'structural_pro'),
    'panel'          => 'header_panel', // Not typically needed.
) );
Structural_Kirki::add_field( 'structural_pro', array(    
    'settings' => 'sticky_header',
    'label'    => __( 'Enable Sticky Header', 'structural_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' )
    ),
    'default'  => 'on',
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'sticky_header_position',
    'label'    => __( 'Enable Sticky Header Position', 'structural_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'top'  => esc_attr__( 'Top', 'structural_pro' ),
        'bottom' => esc_attr__( 'Bottom', 'structural_pro' )
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'sticky_header',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'top',
) );


/*
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'header_top_margin',
    'label'    => __( 'Header Top Margin', 'structural_pro' ),
    'description' => __('Select the top margin of header in pixels','structural_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'header_bottom_margin',
    'label'    => __( 'Header Bottom Margin', 'structural_pro' ),
    'description' => __('Select the bottom margin of header in pixels','structural_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );*/

Structural_Kirki::add_section( 'header_image', array(
    'title'          => __( 'Header Background Image','structural_pro' ),
    'description'    => __( 'Custom Header Image options', 'structural_pro'),
    'panel'          => 'header_panel', // Not typically needed.  
) );

Structural_Kirki::add_field( 'structural_pro', array(   
    'settings' => 'header_bg_size',
    'label'    => __( 'Header Background Size', 'structural_pro' ),
    'section'  => 'header_image',
    'type'     => 'radio-buttonset', 
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'structural_pro' ),
        'contain' => esc_attr__( 'Contain', 'structural_pro' ),
        'auto'  => esc_attr__( 'Auto', 'structural_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'structural_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Header Background Image Size','structural_pro'),
) );

/*Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'header_height',
    'label'    => __( 'Header Background Image Height', 'structural_pro' ),
    'section'  => 'header_image',
    'type'     => 'number',
    'choices' => array(
        'min' => 100,
        'max' => 600,
        'step' => 1,
    ),
    'default'  => '213',
) ); */
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'header_bg_repeat',
    'label'    => __( 'Header Background Repeat', 'structural_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'structural_pro'),
        'repeat' => esc_attr__('Repeat', 'structural_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','structural_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'repeat',  
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'header_bg_position', 
    'label'    => __( 'Header Background Position', 'structural_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'structural_pro'),
        'center center' => esc_attr__('Center Center', 'structural_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'structural_pro'),
        'left top' => esc_attr__('Left Top', 'structural_pro'),
        'left center' => esc_attr__('Left Center', 'structural_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'structural_pro'),
        'right top' => esc_attr__('Right Top', 'structural_pro'),
        'right center' => esc_attr__('Right Center', 'structural_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'center center',  
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'header_bg_attachment',
    'label'    => __( 'Header Background Attachment', 'structural_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'structural_pro'),
        'fixed' => esc_attr__('Fixed', 'structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'scroll',  
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'header_overlay',
    'label'    => __( 'Enable Header( Background ) Overlay', 'structural_pro' ),
    'section'  => 'header_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' )
    ),
    'default'  => 'off',
) );
  
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'header_overlay_color',
    'label'    => __( 'Header Overlay ( Background )color', 'structural_pro' ),
    'section'  => 'header_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'output'   => array(
        array(
            'element'  => '.overlay-header',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

/*
/* e-option start */
/*
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'custon_favicon',
    'label'    => __( 'Custom Favicon', 'structural_pro' ),
    'section'  => 'header',
    'type'     => 'upload',
    'default'  => '',
) ); */
/* e-option start */ 
/* Blog page section */


/* Blog panel */

Structural_Kirki::add_panel( 'blog_panel', array(     
    'title'       => __( 'Blog', 'structural_pro' ),
    'description' => __( 'Blog Related Options', 'structural_pro' ),     
) ); 
Structural_Kirki::add_section( 'blog', array(
    'title'          => __( 'Blog Page','structural_pro' ),
    'description'    => __( 'Blog Related Options', 'structural_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
  
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'blog_layout',
    'label'    => __( 'Select Blog Page Layout you prefer', 'structural_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1  => esc_attr__( 'Default ( One Column )', 'structural_pro' ),
        2 => esc_attr__( 'Two Columns ', 'structural_pro' ),
        3 => esc_attr__( 'Three Columns ( Without Sidebar ) ', 'structural_pro' ),
        4 => esc_attr__( 'Two Columns With Masonry', 'structural_pro' ),
        5 => esc_attr__( 'Three Columns With Masonry ( Without Sidebar ) ', 'structural_pro' ),
        6 => esc_attr__( 'Blog FullWidth', 'structural_pro' ),
    ),
    'default'  => 1,
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'featured_image',
    'label'    => __( 'Enable Featured Image', 'structural_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for blog page','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'more_text',
    'label'    => __( 'More Text', 'structural_pro' ),
    'section'  => 'blog',
    'type'     => 'text',
    'description' => __('Text to display in case of text too long','structural_pro'),
    'default' => __('Read More','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'featured_image_size',
    'label'    => __( 'Choose the Featured Image Size for Blog Page', 'structural_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1 => esc_attr__( 'Large Featured Image', 'structural_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'structural_pro' ),
        3 => esc_attr__( 'Original Size', 'structural_pro' ),
        4 => esc_attr__( 'Medium', 'structural_pro' ),
        5 => esc_attr__( 'Large', 'structural_pro' ), 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Set large and medium image size: Goto Dashboard => Settings => Media', 'structural_pro') ,
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'enable_single_post_top_meta',
    'label'    => __( 'Enable to display top post meta data', 'structural_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'single_post_top_meta',
    'label'    => __( 'Activate and Arrange the Order of Top Post Meta elements', 'structural_pro' ),
    'section'  => 'blog',
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'structural_pro' ),
        2 => esc_attr__( 'author', 'structural_pro' ),
        3 => esc_attr__( 'comment', 'structural_pro' ),
        4 => esc_attr__( 'category', 'structural_pro' ),
        5 => esc_attr__( 'tags', 'structural_pro' ),
        6 => esc_attr__( 'edit', 'structural_pro' ),
    ),
    'default'  => array(1, 2, 3,6),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_top_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','structural_pro'),

) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'enable_single_post_bottom_meta',
    'label'    => __( 'Enable to display bottom post meta data', 'structural_pro' ),
    'section'  => 'blog', 
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','structural_pro'),
    'default'  => 'on',
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'single_post_bottom_meta',
    'label'    => __( 'Activate and arrange the Order of Bottom Post Meta elements', 'structural_pro' ),
    'section'  => 'blog',    
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'structural_pro' ),
        2 => esc_attr__( 'author', 'structural_pro' ),
        3 => esc_attr__( 'comment', 'structural_pro' ),
        4 => esc_attr__( 'category', 'structural_pro' ),
        5 => esc_attr__( 'tags', 'structural_pro' ),
        6 => esc_attr__( 'edit', 'structural_pro' ),
    ),
    'default'  => array(4,5),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_bottom_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','structural_pro'),
) );


/* Single Blog page section */

Structural_Kirki::add_section( 'single_blog', array(
    'title'          => __( 'Single Blog Page','structural_pro' ),
    'description'    => __( 'Single Blog Page Related Options', 'structural_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'single_featured_image',
    'label'    => __( 'Enable Single Post Featured Image', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for Single Post Page','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'single_featured_image_size',
    'label'    => __( 'Choose the featured image display type for Single Post Page', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Large Featured Image', 'structural_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'structural_pro' ),
        3 => esc_attr__( 'FullWidth Featured Image', 'structural_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'author_bio_box',
    'label'    => __( 'Enable Author Bio Box below single post', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'off',
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'related_posts',
    'label'    => __( 'Show Related Posts', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Show the Related Post for Single Blog Page','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'related_posts_hierarchy',
    'label'    => __( 'Related Posts Must Be Shown As:', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Related Posts By Tags', 'structural_pro' ),
        2 => esc_attr__( 'Related Posts By Categories', 'structural_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'related_posts',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Select the Hierarchy','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'comments',
    'label'    => __( ' Show Comments', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Show the Comments for Single Blog Page','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'social_sharing_box',
    'label'    => __( 'Show social sharing options box below single post', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
) );

//social sharing box section

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'facebook_sb',
    'label'    => __( 'Enable facebook sharing option below single post', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'twitter_sb',
    'label'    => __( 'Enable twitter sharing option below single post', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'linkedin_sb',
    'label'    => __( 'Enable linkedin sharing option below single post', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'google-plus_sb',
    'label'    => __( 'Enable googleplus sharing option below single post', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'email_sb',
    'label'    => __( 'Enable email sharing option below single post', 'structural_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
/* FOOTER SECTION 
footer panel */

Structural_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'structural_pro' ),
    'description' => __( 'Footer Related Options', 'structural_pro' ),     
) );  

Structural_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','structural_pro' ),
    'description'    => __( 'Footer related options', 'structural_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'structural_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','structural_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'structural_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'structural_pro' ),
        2  => esc_attr__( '2', 'structural_pro' ),
        3  => esc_attr__( '3', 'structural_pro' ),
        4  => esc_attr__( '4', 'structural_pro' ),
    ),
    'default'  => 3,
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'structural_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'structural_pro' ),
    'description' => __('Select the top margin of footer in pixels','structural_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Structural_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','structural_pro' ),
    'description'    => __( 'Custom Footer Image options', 'structural_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'structural_pro' ),
        'contain' => esc_attr__( 'Contain', 'structural_pro' ),
        'auto'  => esc_attr__( 'Auto', 'structural_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'structural_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'structural_pro'),
        'repeat' => esc_attr__('Repeat', 'structural_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','structural_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',   
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'structural_pro'),
        'center center' => esc_attr__('Center Center', 'structural_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'structural_pro'),
        'left top' => esc_attr__('Left Top', 'structural_pro'),
        'left center' => esc_attr__('Left Center', 'structural_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'structural_pro'),
        'right top' => esc_attr__('Right Top', 'structural_pro'),
        'right center' => esc_attr__('Right Center', 'structural_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'structural_pro'),
        'fixed' => esc_attr__('Fixed', 'structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' )
    ),
    'default'  => 'off',
) );
  
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer_image',
            'property' => 'background-color',
        ),
    ),
) );


// single page section //

Structural_Kirki::add_section( 'single_page', array(
    'title'          => __( 'Single Page','structural_pro' ),
    'description'    => __( 'Single Page Related Options', 'structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'single_page_featured_image',
    'label'    => __( 'Enable Single Page Featured Image', 'structural_pro' ),
    'section'  => 'single_page',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'single_page_featured_image_size',
    'label'    => __( 'Single Page Featured Image Size', 'structural_pro' ),
    'section'  => 'single_page',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( 'Normal', 'structural_pro' ),
        2 => esc_attr__( 'FullWidth', 'structural_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_page_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

// Layout section //

Structural_Kirki::add_section( 'layout', array( 
    'title'          => __( 'Layout','structural_pro' ),
    'description'    => __( 'Layout Related Options', 'structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'site-style',
    'label'    => __( 'Site Style', 'structural_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'wide' =>  esc_attr__('Wide', 'structural_pro'),
        'boxed' =>  esc_attr__('Boxed', 'structural_pro'),
        'fluid' =>  esc_attr__('Fluid', 'structural_pro'),  
        //'static' =>  esc_attr__('Static ( Non Responsive )', 'structural_pro'),
    ),
    'default'  => 'wide',
    'tooltip' => __('Choose the default site layout.','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'global_sidebar_layout',
    'label'    => __( 'Check the box if you want to use a global sidebar on all pages. This option overrides the page options', 'structural_pro' ),
    'section'  => 'layout',
    'type'     => 'checkbox',
    'default' => '0',
) );


Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'sidebar_position',
    'label'    => __( 'Main Layout', 'structural_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-image',   
    'description' => __('Select main content and sidebar arrangement.','structural_pro'),
    'choices' => array(
        'left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cl.png',
        'right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cr.png',
        'two-sidebar' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cm.png',  
        'two-sidebar-left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cl.png',
        'two-sidebar-right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cr.png',
        'fullwidth' =>  get_template_directory_uri() . '/admin/kirki/assets/images/1c.png',
        'no-sidebar' =>  get_template_directory_uri() . '/images/no-sidebar.png',
    ),
    'default'  => 'right', 
    'tooltip' => __('global sidebar on all pages. This option overrides the page layout sidebar options','structural_pro'),
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'body_top_margin',
    'label'    => __( 'Body Top Margin', 'structural_pro' ),
    'description' => __('Select the top margin of body element in pixels','structural_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-top',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'body_bottom_margin',
    'label'    => __( 'Body Bottom Margin', 'structural_pro' ),
    'description' => __('Select the bottom margin of body element in pixels','structural_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-bottom',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );

/* LAYOUT SECTION  */
/*
Structural_Kirki::add_section( 'layout', array(
    'title'          => __( 'Layout','structural_pro' ),   
    'description'    => __( 'Layout settings that affects overall site', 'structural_pro'),
    'panel'          => 'structural_pro_options', // Not typically needed.
) );



Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'primary_sidebar_width',
    'label'    => __( 'Primary Sidebar Width', 'structural_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'structural_pro' ),
        '2' => __( 'Two Column', 'structural_pro' ),
        '3' => __( 'Three Column', 'structural_pro' ),
        '4' => __( 'Four Column', 'structural_pro' ),
        '5' => __( 'Five Column ', 'structural_pro' ),
    ),
    'default'  => '5',  
    'tooltip' => __('Select the width of the Primary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'secondary_sidebar_width',
    'label'    => __( 'Secondary Sidebar Width', 'structural_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'structural_pro' ),
        '2' => __( 'Two Column', 'structural_pro' ),
        '3' => __( 'Three Column', 'structural_pro' ),
        '4' => __( 'Four Column', 'structural_pro' ),
        '5' => __( 'Five Column ', 'structural_pro' ),
    ),            
    'default'  => '5',  
    'tooltip' => __('Select the width of the Secondary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','structural_pro'),
) ); 

*/

/* FOOTER SECTION 
footer panel */

Structural_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'structural_pro' ),
    'description' => __( 'Footer Related Options', 'structural_pro' ),     
) );  

Structural_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','structural_pro' ),
    'description'    => __( 'Footer related options', 'structural_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'structural_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','structural_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'structural_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'structural_pro' ),
        2  => esc_attr__( '2', 'structural_pro' ),
        3  => esc_attr__( '3', 'structural_pro' ),
        4  => esc_attr__( '4', 'structural_pro' ),
    ),
    'default'  => 4,
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'structural_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'structural_pro' ),
    'description' => __('Select the top margin of footer in pixels','structural_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Structural_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','structural_pro' ),
    'description'    => __( 'Custom Footer Image options', 'structural_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'structural_pro' ),
        'contain' => esc_attr__( 'Contain', 'structural_pro' ),
        'auto'  => esc_attr__( 'Auto', 'structural_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'structural_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'structural_pro'),
        'repeat' => esc_attr__('Repeat', 'structural_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','structural_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'structural_pro'),
        'center center' => esc_attr__('Center Center', 'structural_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'structural_pro'),
        'left top' => esc_attr__('Left Top', 'structural_pro'),
        'left center' => esc_attr__('Left Center', 'structural_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'structural_pro'),
        'right top' => esc_attr__('Right Top', 'structural_pro'),
        'right center' => esc_attr__('Right Center', 'structural_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'structural_pro'),
        'fixed' => esc_attr__('Fixed', 'structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' )
    ),
    'default'  => 'off',
) );
  
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'structural_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.overlay-footer',
            'property' => 'background-color',
        ),
    ),
) );


 if( class_exists( 'WooCommerce' ) ) {
    Structural_Kirki::add_section( 'woocommerce_section', array(
        'title'          => __( 'WooCommerce','structural_pro' ),
        'description'    => __( 'Theme options related to woocommerce', 'structural_pro'),
        'priority'       => 11, 
        'theme_supports' => '', // Rarely needed.
    ) );
    Structural_Kirki::add_field( 'woocommerce', array(
        'settings' => 'woocommerce_sidebar',
        'label'    => __( 'Enable Woocommerce Sidebar', 'structural_pro' ),
        'description' => __('Enable Sidebar for shop page','structural_pro'),
        'section'  => 'woocommerce_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'structural_pro' ),
            'off' => esc_attr__( 'Disable', 'structural_pro' ) 
        ),

        'default'  => 'on',
    ) );
}
    
// background color ( rename )

Structural_Kirki::add_section( 'colors', array(
    'title'          => __( 'Background Color','structural_pro' ),
    'description'    => __( 'This will affect overall site background color', 'structural_pro'),
    //'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 11,
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'general_background_color',
    'label'    => __( 'General Background Color', 'structural_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-color',
        ),
    ),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'content_background_color',
    'label'    => __( 'Content Background Color', 'structural_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'description' => __('when you are select boxed layout content background color will reflect the grid area','structural_pro'), 
    'alpha' => true, 
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'general_background_image',
    'label'    => __( 'General Background Image', 'structural_pro' ),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-image',
        ),
    ),
) );

// background image ( general & boxed layout ) //


Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'general_background_repeat',
    'label'    => __( 'General Background Repeat', 'structural_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'structural_pro'),
        'repeat' => esc_attr__('Repeat', 'structural_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','structural_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'general_background_size',
    'label'    => __( 'General Background Size', 'structural_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'structural_pro' ),
        'contain' => esc_attr__( 'Contain', 'structural_pro' ),
        'auto'  => esc_attr__( 'Auto', 'structural_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'structural_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'general_background_attachment',
    'label'    => __( 'General Background Attachment', 'structural_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'structural_pro'),
        'fixed' => esc_attr__('Fixed', 'structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'general_background_position',
    'label'    => __( 'General Background Position', 'structural_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'structural_pro'),
        'center center' => esc_attr__('Center Center', 'structural_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'structural_pro'),
        'left top' => esc_attr__('Left Top', 'structural_pro'),
        'left center' => esc_attr__('Left Center', 'structural_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'structural_pro'),
        'right top' => esc_attr__('Right Top', 'structural_pro'),
        'right center' => esc_attr__('Right Center', 'structural_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );


/* CONTENT BACKGROUND ( boxed background image )*/

Structural_Kirki::add_field( 'structural_pro', array(  
    'settings' => 'content_background_image',
    'label'    => __( 'Content Background Image', 'structural_pro' ),
    'description' => __('when you are select boxed layout content background image will reflect the grid area','structural_pro'),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-image',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'content_background_repeat',
    'label'    => __( 'Content Background Repeat', 'structural_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'structural_pro'),
        'repeat' => esc_attr__('Repeat', 'structural_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','structural_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'content_background_size',
    'label'    => __( 'Content Background Size', 'structural_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'structural_pro' ),
        'contain' => esc_attr__( 'Contain', 'structural_pro' ),
        'auto'  => esc_attr__( 'Auto', 'structural_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'structural_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'content_background_attachment',
    'label'    => __( 'Content Background Attachment', 'structural_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'structural_pro'),
        'fixed' => esc_attr__('Fixed', 'structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'content_background_position',
    'label'    => __( 'Content Background Position', 'structural_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'structural_pro'),
        'center center' => esc_attr__('Center Center', 'structural_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'structural_pro'),
        'left top' => esc_attr__('Left Top', 'structural_pro'),
        'left center' => esc_attr__('Left Center', 'structural_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'structural_pro'),
        'right top' => esc_attr__('Right Top', 'structural_pro'),
        'right center' => esc_attr__('Right Center', 'structural_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'structural_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );

/* pro theme options */

//  animation section 

Structural_Kirki::add_section( 'animation_section', array(
    'title'          => __( 'Animation','structural_pro' ),
    'description'    => __( 'Animation that affects overall site', 'structural_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );    

Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'animation_effect',
    'label'    => __( 'Enable Animation Effect', 'structural_pro' ),   
    'section'  => 'animation_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'structural_pro' ),
        'off' => esc_attr__( 'Disable', 'structural_pro' ) 
    ),
    'default'  => 'on',
) );

// custom JS section

Structural_Kirki::add_section( 'custom_js_section', array(
    'title'          => __( 'Custom JS','structural_pro' ),
    'description'    => __( 'Custom JS', 'structural_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
 Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'custom_js',
    'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'structural_pro' ),
    'section'  => 'custom_js_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
) ); 


// Tracking section 

Structural_Kirki::add_section( 'analytics_section', array(
    'title'          => __( 'Tracking Code','structural_pro' ),
    'description'    => __( 'Tracking Code', 'structural_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'analytics',
    'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'structural_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
    'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'analytics_place',
    'label'    => __( 'Enable to Load Tracking Code in Footer', 'structural_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'structural_pro' ),
        '2' => esc_attr__( 'Disable', 'structural_pro' )
    ),
    'default'  => '2',
    'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','structural_pro'),
) );


//  lightbox section //

Structural_Kirki::add_section( 'light_box', array(
    'title'          => __( 'Light Box','structural_pro' ),
    'description'    => __( 'Light Box Settings', 'structural_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'lightbox_theme',
    'label'    => __( 'Lightbox Theme', 'structural_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => esc_attr__( 'pp_default', 'structural_pro' ),
        '2' => esc_attr__( 'light-rounded', 'structural_pro' ),
        '3' => esc_attr__( 'dark-rounded', 'structural_pro' ),
        '4' => esc_attr__( 'light-square', 'structural_pro' ),
        '5' => esc_attr__( 'dark-square', 'structural_pro' ),
        '6' => esc_attr__( 'facebook', 'structural_pro' ),
    ),
    'default'  => '1',
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'lightbox_animation_speed',
    'label'    => __( 'Animation Speed', 'structural_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'fast' => esc_attr__( 'Fast', 'structural_pro' ),
        'slow' => esc_attr__( 'Slow', 'structural_pro' ),
        'normal' => esc_attr__( 'Normal', 'structural_pro' ),
    ),
    'default'  => 'fast',
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'lightbox_slideshow',
    'label'    => __( 'Autoplay Gallery Speed', 'structural_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 100,
        'step' => 10,
    ),
    'default'  => 50,
    'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'lightbox_autoplay_slideshow',
    'label'    => __( 'Enable Autoplay Gallery', 'structural_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'structural_pro' ),
        '2' => esc_attr__( 'Disable', 'structural_pro' )
    ),
    'default'  => '2',
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'lightbox_opacity',
    'label'    => __( 'Select Background Opacity', 'structural_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 1,
        'step' => 0.1,
    ),
    'default'  => 0.5,
    'tooltip' => __('Enter 0.1 to 1.0','structural_pro'),
) );
Structural_Kirki::add_field( 'structural_pro', array(
    'settings' => 'lightbox_overlay_gallery',
    'label'    => __( 'Show Gallery Thumbnails', 'structural_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array( 
        '1'  => esc_attr__( 'Enable', 'structural_pro' ),
        '2' => esc_attr__( 'Disable', 'structural_pro' )
    ),
    'default'  => '1',
) );


 

         
do_action('structural_pro_child_customizer_options');
