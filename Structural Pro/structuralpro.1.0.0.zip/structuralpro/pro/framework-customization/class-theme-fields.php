<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Structural_Pro_Theme_fields' ) ) {  
	class Structural_Pro_Theme_fields {
	
      	
        /* Add Or Override the widegt fields */ 


     
	}
}

