<?php
	echo do_shortcode( '[elastic_slider id='.$slider.']' );