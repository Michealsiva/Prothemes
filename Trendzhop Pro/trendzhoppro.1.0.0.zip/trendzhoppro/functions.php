<?php
/**
 * TrendzhopPro functions and definitions
 *
 * @package TrendzhopPro
 */

if ( ! function_exists( 'trendzhop_pro_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function trendzhop_pro_setup() {

	/**
	 * Set the content width based on the theme's design and stylesheet.
	 */
	if ( ! isset( $content_width ) ) {
		$content_width = 780; /* pixels */
	}
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on style_outlet, use a find and replace
	 * to change 'trendzhop_pro' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'trendzhop_pro', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );
	add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'trendzhop_pro_product_img', 300,350, true );
	add_image_size( 'trendzhop_pro_service_img', 200,250, true );
	add_image_size( 'trendzhop_pro_blog_full_width', 380,350, true );
	add_image_size( 'trendzhop_pro_small_featured_image_width', 450,300, true );
	add_image_size( 'trendzhop_pro_blog_large_width', 800,300, true );  
	add_image_size( 'trendzhop_pro_full_width', 1200,350, true );


	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'menu-1' => esc_html__( 'Primary', 'trendzhop_pro' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

/*
	 * Enable support for Post Formats.
	 * See http://codex.wordpress.org/Post_Formats 
	 */
	add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'quote', 'link', 'gallery',  
	) );

	add_theme_support( 'custom-background' );

	add_theme_support( 'custom-logo' );

	/* License key - EDD update file */
	
	require_once get_template_directory() . '/pro/updater/theme-updater.php';

	
}
endif;
add_action( 'after_setup_theme', 'trendzhop_pro_setup' );

/**
 * Register sidebars for this for this theme.
 */
require get_template_directory() . '/pro/class-theme-sidebars.php';


$theme_sidebars = Theme_Sidebars::getInstance();


/**
 * Load TGM plugin 
 */
require get_template_directory() . '/pro/class-tgm-plugin-activation.php';

/**
* Custom template tags for this theme.
*/

require get_template_directory() . '/includes/template-tags.php';


/**
* Custom functions that act independently of the theme templates.
*/

require get_template_directory() . '/includes/extras.php';

/**
* Implement the Custom Header feature.
*/

require get_template_directory() . '/includes/custom-header.php';

/**
* Customizer additions.
*/

require get_template_directory() . '/includes/customizer.php';

/**
* Load Jetpack compatibility file.
*/

require get_template_directory() . '/includes/jetpack.php';




/**
*TrendzhopPro Widgets file
*/
//require get_template_directory() . '/includes/widgets/widgets.php';

/**
 * Inline style ( Theme Options )
 */
require get_template_directory() . '/includes/styles.php';

/**
 * Load Filter and Hook functions
 */
require get_template_directory() . '/includes/hooks-filters.php';

/**
* Load Theme Options Panel
*/

//require get_template_directory() . '/includes/theme-options.php';


include_once( get_template_directory() . '/admin/theme-options.php' ); 

/* Webulous Framework add */

require get_template_directory() . '/framework/framework.php'; 

/**
 * The core plugin class that is used to load dependencies, define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
if( !class_exists('genex_Theme') ) {
   require get_template_directory() . '/pro/class-theme.php'; 		
}

    
/* Woocommerce support */ 

add_theme_support('woocommerce');

remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper');
add_action('woocommerce_before_main_content', 'trendzhop_pro_output_content_wrapper');


function trendzhop_pro_output_content_wrapper() {
	$woocommerce_sidebar = get_theme_mod('woocommerce_sidebar',true ) ;
	if( $woocommerce_sidebar ) {
        $woocommerce_sidebar_column = 'eleven';
    }else {
        $woocommerce_sidebar_column = 'sixteen';
        remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar');
    }
    $page_breadcrumb = get_theme_mod('breadcrumb'); 
    if( empty($page_breadcrumb) && function_exists('woocommerce_breadcrumb') && (!is_front_page())) {
        echo '<div class="breadcrumb woocommerce-breadcrumb-class" style="margin-bottom: 30px;"><div class="container">';
        	//if(!is_front_page()) {
	        	echo '<div class="breadcrumb-left eight columns">';?>
	        		<h4><?php woocommerce_page_title();?></h4>
	 			<?php echo '</div>';
		//	}
			
		  	
	  		echo '<div class="breadcrumb-right eight columns">';
				 woocommerce_breadcrumb();
			echo '</div>';
		  
		 echo '</div></div>';
    }
	echo '<div class="site-content container" id="content"><div id="primary" class="content-area '. $woocommerce_sidebar_column .' columns">';	
}

remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end' );
add_action( 'woocommerce_after_main_content', 'trendzhop_pro_output_content_wrapper_end' );

function trendzhop_pro_output_content_wrapper_end () {
	echo "</div>";
}

add_action( 'init', 'trendzhop_pro_remove_wc_breadcrumbs' );  
function trendzhop_pro_remove_wc_breadcrumbs() {
   	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}

/* Header Add To cart Count code */

add_filter('add_to_cart_fragments', 'woocommerce_header_add_to_cart_fragment');
function woocommerce_header_add_to_cart_fragment( $fragments ) {
	global $woocommerce; 
	ob_start(); ?>
	<a class="cart-contents" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'trendzhop_pro'); ?>"><?php echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'trendzhop_pro'), $woocommerce->cart->cart_contents_count);?> - <?php echo $woocommerce->cart->get_cart_total(); ?></a>

    <?php $fragments['a.cart-contents'] = ob_get_clean();
	return $fragments; 
}

/**
* Begins execution of the theme.
*
* Since everything within the theme is registered via hooks,
* then kicking off the theme from this point in the file does
* not affect the page life cycle.
*
* @since    1.0.0
*/
function run_trendzhop_pro() {

	$theme = new Trendzhop_Pro_Theme( 'trendzhop_pro', '1.0.0' );
	$theme->run(); 

}

run_trendzhop_pro();


/* SVG Support */
function genex_svg_mime_support($mimes) {
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter('upload_mimes', 'genex_svg_mime_support');


/* Recommended plugin using TGM */
add_action( 'tgmpa_register', 'trendzhop_pro_register_plugins');
if( !function_exists('trendzhop_pro_register_plugins') ) {
	function trendzhop_pro_register_plugins() {
       /**
		 * Array of plugin arrays. Required keys are name and slug.
		 * If the source is NOT from the .org repo, then source is also required.
		 */
		$plugins = array(

			array(
				'name'     => 'WooCommerce', // The plugin name.
				'slug'     => 'woocommerce', // The plugin slug (typically the folder name).
				'required' => false, // If false, the plugin is only 'recommended' instead of required.
			),
			array(
				'name'     => 'YITH WooCommerce Wishlist', // The plugin name.
				'slug'     => 'yith-woocommerce-wishlist', // The plugin slug (typically the folder name).
				'required' => false, // If false, the plugin is only 'recommended' instead of required.
			),
		);
		/*
		 * Array of configuration settings. Amend each line as needed.
		 *
		 * TGMPA will start providing localized text strings soon. If you already have translations of our standard
		 * strings available, please help us make TGMPA even better by giving us access to these translations or by
		 * sending in a pull-request with .po file(s) with the translations.
		 *
		 * Only uncomment the strings in the config array if you want to customize the strings.
		 */
		$config = array(
			'id'           => 'tgmpa',
			// Unique ID for hashing notices for multiple instances of TGMPA.
			'default_path' => '',
			// Default absolute path to bundled plugins.
			'menu'         => 'tgmpa-install-plugins',
			// Menu slug.
			'parent_slug'  => 'themes.php',
			// Parent menu slug.
			'capability'   => 'edit_theme_options',
			// Capability needed to view plugin install page, should be a capability associated with the parent menu used.
			'has_notices'  => true,
			// Show admin notices or not.
			'dismissable'  => true,
			// If false, a user cannot dismiss the nag message.
			'dismiss_msg'  => '',
			// If 'dismissable' is false, this message will be output at top of nag.
			'is_automatic' => false,
			// Automatically activate plugins after installation or not.
			'message'      => '',
			// Message to output right before the plugins table.
		);

		tgmpa( $plugins, $config );
	}
}

