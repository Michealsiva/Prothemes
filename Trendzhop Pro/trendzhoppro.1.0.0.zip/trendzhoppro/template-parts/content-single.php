<?php
/**
 * @package TrendzhopPro
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header"> 
		<?php the_title( '<h1 class="entry-title"><span>', '</span></h1>' ); ?>
		<?php if ( 'post' == get_post_type() ) : ?>
				<div class="entry-meta">
					<?php if(function_exists('trendzhop_pro_entry_top_meta') ) {
						trendzhop_pro_entry_top_meta(); 
					} ?> 
				</div><!-- .entry-meta -->
				<?php endif; ?> 

			<br class="clear">
	</header><!-- .entry-header -->
<?php
		$single_featured_image = get_theme_mod( 'single_featured_image',true );
		$single_featured_image_size = get_theme_mod ('single_featured_image_size',1);
		if (isset($single_featured_image_size) && $single_featured_image_size != 3  && $single_featured_image ) { ?>
		    <div class="post-thumb blog-thumb"><?php
			    if( has_post_thumbnail() && ! post_password_required() ) : 
			        if ( $single_featured_image_size == 1 ) : 
						the_post_thumbnail('trendzhop_pro_blog_large_width');  
				    else: 
						the_post_thumbnail('trendzhop_pro_small_featured_image_width');		
					endif;
			    endif;?>
		    </div><?php
		} ?>



	<div class="entry-content">
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages: ', 'trendzhop_pro' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->



	<?php trendzhop_pro_post_nav(); ?>
</article><!-- #post-## -->
