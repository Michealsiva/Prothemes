<?php
/**
 * Template part for displaying posts.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package TrendzhopPro 
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="entry-content">  
		<?php 

	$featured_image = get_theme_mod( 'featured_image',true );
	if( $featured_image ) : ?>
		<div class="post-thumb blog-thumb"><?php
			if( function_exists( 'trendzhop_pro_featured_image' ) ) :
				trendzhop_pro_featured_image();
			endif; ?>
	    </div><?php 
	endif; ?> 

	<?php do_action('trendzhop_pro_entry_header_before'); ?>  

		<header class="entry-header">  
			<div class="title-meta">
				<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
				<?php if ( get_theme_mod('enable_single_post_top_meta', true ) ): ?>
				<div class="entry-meta">
					<?php if(function_exists('trendzhop_pro_entry_top_meta') ) {
						    trendzhop_pro_entry_top_meta(); 
						} ?> 
				</div><!-- .entry-meta -->
				<?php endif; ?>
			</div>
			<br class="clear">
	   </header><!-- .entry-header -->


	<?php do_action('trendzhop_pro_entry_header_after'); ?>
	
	<div class="entry-content">
		<?php
			/* translators: %s: Name of current post */
			the_content();
		?>

		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'trendzhop_pro' ),
				'after'  => '</div>',
			) );
		?>
	    <br class="clear" />
	</div><!-- .entry-content -->

	<?php do_action('trendzhop_pro_entry_footer_before'); ?>

		<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
			<footer class="entry-footer">
				<?php if(function_exists('trendzhop_pro_entry_bottom_meta') ) {
				     trendzhop_pro_entry_bottom_meta();
				} ?>
			</footer><!-- .entry-footer -->
		<?php endif;?>
		
	<?php do_action('trendzhop_pro_entry_footer_after'); ?>

</article><!-- #post-## -->