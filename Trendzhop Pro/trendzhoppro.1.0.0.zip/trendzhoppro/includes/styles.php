<?php

function trendzhop_pro_custom_styles($custom) {
$custom = '';  
    $sticky_header_position = get_theme_mod('sticky_header_position') ;
    if( $sticky_header_position == 'bottom') {
      $custom .= ".nav-wrap.sticky-nav {  top: auto!important;
        bottom:0%; }"."\n"; 
      $custom .= ".nav-wrap.sticky-nav .nav-menu .sub-menu {  top: auto;
        bottom:100%; }"."\n"; 
    }

  /* Heder background image */

    
if( get_theme_mod('header_image')  ) {        

        $bg_size = get_theme_mod('header_bg_size','auto');
        $bg_repeat = get_theme_mod('header_bg_repeat','repeat'); 
        $bg_attachment =  get_theme_mod('header_bg_attachment','scroll'); 
        $bg_position =   get_theme_mod('header_bg_position','left top'); 
        $bg_height = get_theme_mod('header_bg_height','150');  

        $custom .= ".branding {  background-position: ". $bg_position. ";
            background-repeat: ". $bg_repeat . ";  
            background-size: ". $bg_size ." ;
            min-height: ". $bg_height ."px;  
            background-attachment : ". $bg_attachment .";
            position: relative; }"."\n";
   }
 



	//Output all the styles
	wp_add_inline_style( 'trendzhop-header', $custom );	
}



add_action( 'wp_enqueue_scripts', 'trendzhop_pro_custom_styles',11 );  
