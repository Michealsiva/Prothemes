<?php
/**
 * TrendzhopPro Theme Customizer
 *
 * @package TrendzhopPro
 */ 

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function trendzhop_pro_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
}
add_action( 'customize_register', 'trendzhop_pro_customize_register' );

/** 
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function trendzhop_pro_customize_preview_js() {
	wp_enqueue_script( 'trendzhop_pro_customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'trendzhop_pro_customize_preview_js' );


if( get_theme_mod('enable_primary_color',false) ) {

	add_action( 'wp_head','cleanse_pro_customizer_primary_custom_css' );

		function cleanse_pro_customizer_primary_custom_css() {
			$primary_color = get_theme_mod( 'primary_color','#e84c3d'); ?>

	        <style type="text/css"> 
				.main-navigation {
					background-image: none!important;
				}
				.comment-form textarea, .comment-form input[type="text"], .comment-form input[type="email"],.single-post #respond .comment-form-url #url,.woocommerce table.shop_table tbody,.woocommerce #customer_login .u-column1 form.login, .woocommerce #customer_login .u-column1 form.register, .woocommerce #customer_login .u-column2 form.login, .woocommerce #customer_login .u-column2 form.register,.woocommerce #order_review tfoot,.woocommerce #order_review #payment,.woocommerce .checkout_coupon,.woocommerce .login' {
					opacity: 0.045;
				}
				.so-widget-trendzhop-pro-product-discount-widget .product-discount-wrapper:before,  .so-widget-trendzhop-pro-product-discount-widget .product-discount-wrapper:after, .widget_recent-posts-widget .recent-posts-slider:hover .flex-direction-nav a.flex-prev:hover,  .widget_recent-posts-widget .recent-posts-slider:hover .flex-direction-nav a.flex-next:hover {
					opacity:0.7;
				}
				.portfolioeffects .overlay_icon, .portfolioeffects:hover .overlay_icon, .flexslider:hover .flex-direction-nav a.flex-prev:hover,.flexslider:hover .flex-direction-nav a.flex-next:hover {
					opacity:0.5;
				}
			</style>
<?php
	}
}