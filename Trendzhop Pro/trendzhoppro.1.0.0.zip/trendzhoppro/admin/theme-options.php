<?php
/**
 * Created by PhpStorm.
 * User: venkat
 * Date: 2/5/16
 * Time: 4:32 PM         
 */   
     
include_once( get_template_directory() . '/admin/kirki/kirki.php' );   
include_once( get_template_directory() . '/admin/kirki-helpers/class-theme-kirki.php' ); 


Trendzhop_Kirki::add_config( 'trendzhop_pro', array(     
    'capability'    => 'edit_theme_options',                  
    'option_type'   => 'theme_mod',          
) );             
     
// trendzhop_pro option start //   

//  site identity section // 

Trendzhop_Kirki::add_section( 'title_tagline', array(
    'title'          => __( 'Site Identity','trendzhop_pro' ),
    'description'    => __( 'Site Header Options', 'trendzhop_pro'),       
    'priority'       => 8,                                                                  
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'logo_title',
    'label'    => __( 'Enable Logo as Title', 'trendzhop_pro' ),
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'priority' => 5,
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => 'off',   
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'tagline',
    'label'    => __( 'Show site Tagline', 'trendzhop_pro' ), 
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => 'on',
) );

// general panel      

Trendzhop_Kirki::add_panel( 'general_panel', array(   
    'title'       => __( 'General Settings', 'trendzhop_pro' ),  
    'description' => __( 'general settings', 'trendzhop_pro' ),         
) );

//  Page title bar section // 

Trendzhop_Kirki::add_section( 'header-pagetitle-bar', array(   
    'title'          => __( 'Page Title Bar & Breadcrumb','trendzhop_pro' ),
    'description'    => __( 'Page Title bar related options', 'trendzhop_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) ); 
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'global_page_title_bar',
    'label'    => __( 'Check the box if you want to use a global page title bar settings. This option overrides the page options', 'trendzhop_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'checkbox',
    'default' => '0',
) );   

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'page_titlebar',  
    'label'    => __( 'Page Title Bar', 'trendzhop_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( 'Show Bar and Content', 'trendzhop_pro' ),
        2 => __('Hide','trendzhop_pro'),
    ),
    'default' => 1,
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'page_titlebar_text',  
    'label'    => __( 'Page Title Bar Text', 'trendzhop_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        0 => __( 'Show', 'trendzhop_pro' ),
        1 => __( 'Hide', 'trendzhop_pro' ), 
    ),
    'default' => 0,
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'breadcrumb',  
    'label'    => __( 'Hide Breadcrumb', 'trendzhop_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'checkbox',
    'default'  => 0,
) ); 

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'breadcrumb_char',
    'label'    => __( 'Breadcrumb Character', 'trendzhop_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( ' >> ', 'trendzhop_pro' ),
        2 => __( ' // ', 'trendzhop_pro' ),
        3 => __( ' > ', 'trendzhop_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'breadcrumb',
            'operator' => '==',
            'value'    => 0,
        ),
    ),
    //'sanitize_callback' => 'allow_htmlentities'
) );


//  pagination section // 

Trendzhop_Kirki::add_section( 'general-pagination', array(   
    'title'          => __( 'Pagination','trendzhop_pro' ),
    'description'    => __( 'Pagination related options', 'trendzhop_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'numeric_pagination',
    'label'    => __( 'Numeric Pagination', 'trendzhop_pro' ),   
    'section'  => 'general-pagination',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Numbered', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Next/Previous', 'trendzhop_pro' )
    ),
    'default'  => 'on',
) );

/*Home Section.
Trendzhop_Kirki::add_panel( 'home_options', array(   
    'title'       => __( 'Home', 'trendzhop_pro' ),  
    'description' => __( 'home', 'trendzhop_pro' ),         
) );

Trendzhop_Kirki::add_section( 'pro_home_section', array(
    'title'          => __( 'Pro: Use Page Builder','trendzhop_pro' ),
    'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'trendzhop_pro'),
    'panel'          => 'home_options', // Not typically needed. 
    'priority'     => 9,
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'page-builder',
    'label'    => __( 'Use Page Builder', 'trendzhop_pro' ),
    'section'  => 'pro_home_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','trendzhop_pro'),
    'default'  => 'off',
) );


// home page type section

Trendzhop_Kirki::add_section( 'home_type_section', array(
    'title'          => __( 'Home - General Settings','trendzhop_pro' ),
    'description'    => __( 'Home Page options', 'trendzhop_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'enable_home_default_content',
    'label'    => __( 'Enable Home Page Default Content', 'trendzhop_pro' ),
    'section'  => 'home_type_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    
    'default'  => 'off',
    'tooltip' => __('Enable home page default content ( home page content )','trendzhop_pro'),
) );

  

// Slider section

Trendzhop_Kirki::add_section( 'slider_section', array(
    'title'          => __( 'Slider Section','trendzhop_pro' ),
    'description'    => __( 'Home Page Slider Related Options', 'trendzhop_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(  
    'settings' => 'enable_slider',
    'label'    => __( 'Enable Slider Post ( Section )', 'trendzhop_pro' ),
    'section'  => 'slider_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ),
    ),
    'default'  => 'on',
    
    'tooltip' => __('Enable Slider Post in home page','trendzhop_pro'),
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'slider_cat',
    'label'    => __( 'Slider Posts category', 'trendzhop_pro' ),
    'section'  => 'slider_section',
    'type'     => 'select',
    'choices' => Kirki_Helper::get_terms( 'category' ),
    'active_callback' => array(
        array(
            'setting'  => 'enable_slider',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Create post ( Goto Dashboard => Post => Add New ) and Post Featured Image ( Preferred size is 1200 x 450 pixels ) as taken as slider image and Post Content as taken as Flexcaption.','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'slider_count',
    'label'    => __( 'No. of Sliders', 'trendzhop_pro' ),
    'section'  => 'slider_section',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 999,
        'step' => 1,
    ),
    'default'  => 2,
    'active_callback' => array(
        array(
            'setting'  => 'enable_slider',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Enter number of slides you want to display under your selected Category','trendzhop_pro'),
) );
     
// service section 

Trendzhop_Kirki::add_section( 'service_section', array(
    'title'          => __( 'Service Section','trendzhop_pro' ),
    'description'    => __( 'Home Page - Service Related Options', 'trendzhop_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array( 
    'settings' => 'enable_service_section',
    'label'    => __( 'Enable Service Section', 'trendzhop_pro' ),
    'section'  => 'service_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),

    'default'  => 'on',
    'tooltip' => __('Enable service section in home page','trendzhop_pro'),
) ); 

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'service-1',
    'label'    => __( 'Service Section #1', 'trendzhop_pro' ), 
    'section'  => 'service_section',
    'type'     => 'dropdown-pages', 
    //'tooltip' => __('Create Page ( Goto Dashboard => Page =>Add New ) and Page Featured Image ( Preferred size is 100 x 100 pixels )','trendzhop_pro'),
    'active_callback' => array(
        array(
            'setting'  => 'enable_service_section',
            'operator' => '==',
            'value'    => true,
        ),
    ),

) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'service-2',
    'label'    => __( 'Service Section #2', 'trendzhop_pro' ), 
    'section'  => 'service_section',
    'type'     => 'dropdown-pages', 
    //'tooltip' => __('Create Page ( Goto Dashboard => Page =>Add New ) and Page Featured Image ( Preferred size is 100 x 100 pixels )','trendzhop_pro'),
    'active_callback' => array(
        array(
            'setting'  => 'enable_service_section',
            'operator' => '==',
            'value'    => true,
        ),
    ),

) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'service-3',
    'label'    => __( 'Service Section #3', 'trendzhop_pro' ), 
    'section'  => 'service_section',
    'type'     => 'dropdown-pages', 
    //'tooltip' => __('Create Page ( Goto Dashboard => Page =>Add New ) and Page Featured Image ( Preferred size is 100 x 100 pixels )','trendzhop_pro'),
    'active_callback' => array(
        array(
            'setting'  => 'enable_service_section',
            'operator' => '==',
            'value'    => true,
        ),
    ),

) );

*/



// skin color panel 

Trendzhop_Kirki::add_panel( 'skin_color_panel', array(   
    'title'       => __( 'Skin Color', 'trendzhop_pro' ),  
    'description' => __( 'Color Settings', 'trendzhop_pro' ),         
) );
// color scheme section 

Trendzhop_Kirki::add_section( 'multiple_color_section', array(
    'title'          => __( 'Color Scheme','trendzhop_pro' ),
    'description'    => __( 'Select your color scheme', 'trendzhop_pro'),
    'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 9,
) );  

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'color_scheme',
    'label'    => __( 'Select your color scheme', 'trendzhop_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'palette',
    'choices'     => array(
        '1' => array(
            '#e84c3d', 
        ),
        '2' => array(
            '#7067D2', 
        ), 
        '3' => array(
            '#00cf52',
        ),
        '4' => array(
            ' #FF6000',
        ),
        '5' => array(
            '#FF299B',
        ),
        '6' => array(
            '#C5BA00',   
        ),
        
    ),
    'default' => '1',
    //'default'  => 'on',
) );


// Change Color Options

Trendzhop_Kirki::add_section( 'primary_color_field', array(
    'title'          => __( 'Change Color Options','trendzhop_pro' ),
    'description'    => __( 'This will reflect in links, buttons,Navigation and many others. Choose a color to match your site.', 'trendzhop_pro'),
    'panel'          => 'skin_color_panel', // Not typically needed.
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'enable_primary_color',
    'label'    => __( 'Enable Custom Primary color', 'trendzhop_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => 'off',
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'primary_color',
    'label'    => __( 'Primary color', 'trendzhop_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => ' #e84c3d',
    'alpha'  => true,
    'active_callback' => array(
        array (
            'setting'  => 'enable_primary_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array(
        array(
            'element'  => '.woocommerce div.product .woocommerce-tabs ul.tabs li,  .page-template-portfolio-2col .entry-title:before, .page-template-portfolio-2col_text .entry-title:before, .page-template-portfolio-2col_sidebar .entry-title:before, .page-template-portfolio-3col .entry-title:before, .page-template-portfolio-3col_text .entry-title:before, .page-template-portfolio-3col_sidebar .entry-title:before, .page-template-portfolio-4col .entry-title:before, .page-template-portfolio-4col_text .entry-title:before, .page-template-portfolio .entry-title:before,.ui-accordion h3 span,.so-widget-image-widget .img-border img,.tabs.normal ul li a, .tabs ul li a,input[type="text"]:focus,
                input[type="email"]:focus,
                input[type="url"]:focus,
                input[type="password"]:focus,
                input[type="search"]:focus,
                textarea:focus ',
            'property' => 'border-color',
        ),
        array(
            'element'  => 'button,input[type="button"],
                    input[type="reset"],
                    input[type="submit"], .navigation a:hover,
                    .comment-navigation a:hover, .nav-links .meta-nav,
                    .more-link .meta-nav, .comment-navigation .meta-nav,.nav-links .nav-previous:hover a,
                    .more-link .nav-previous:hover a, .comment-navigation .nav-previous:hover a ,.nav-links .nav-next:hover a,
                    .more-link .nav-next:hover a, .comment-navigation .nav-next:hover a,a.more-link,.navigation.pagination .page-numbers,.branding .cart-item, .share-box ul li a:hover,.comment-form .form-submit input[type="submit"],.hentry.sticky,.hentry.sticky .entry-footer span,.page-links,.post .latest-content a.more-link:hover,.woocommerce table.shop_table thead th, .woocommerce table.shop_table tbody td.actions .coupon input.button,  .woocommerce #customer_login .u-column2 form.login,  .woocommerce #customer_login .u-column1 form.login input.button, .woocommerce #customer_login .u-column1 form.register input.button, .woocommerce #customer_login .u-column2 form.login input.button, .woocommerce #customer_login .u-column2 form.register input.button,  .woocommerce .checkout_coupon .form-row-last .button,.woocommerce nav.woocommerce-pagination ul li, .title-divider:before,.row #primary .page-title span ,.entry-header h1 span, .entry-header h1 span, .woocommerce #content nav.woocommerce-pagination ul li a:focus,
                    .woocommerce #content nav.woocommerce-pagination ul li a:hover,
                    .woocommerce #content nav.woocommerce-pagination ul li span.current,
                    .woocommerce nav.woocommerce-pagination ul li a:focus,
                    .woocommerce nav.woocommerce-pagination ul li a:hover,
                    .woocommerce nav.woocommerce-pagination ul li span.current,
                    .woocommerce-page #content nav.woocommerce-pagination ul li a:focus,
                    .woocommerce-page #content nav.woocommerce-pagination ul li a:hover,
                    .woocommerce-page #content nav.woocommerce-pagination ul li span.current,
                    .woocommerce-page nav.woocommerce-pagination ul li a:focus,
                    .woocommerce-page nav.woocommerce-pagination ul li a:hover,
                    .woocommerce-page nav.woocommerce-pagination ul li span.current,.woocommerce a.remove ,.woocommerce .cart button.single_add_to_cart_button,  .woocommerce ul.products li.product:hover .button.product_type_simple, .woocommerce-page ul.products li.product:hover .button.product_type_simple,  .woocommerce ul.products li.product:hover .button.product_type_variable, .woocommerce-page ul.products li.product:hover .button.product_type_variable,  .woocommerce ul.products li.product a.added_to_cart, .woocommerce-page ul.products li.product a.added_to_cart,.woocommerce .widget_price_filter .price_slider_amount .button,.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,.woocommerce #content div.product .woocommerce-tabs ul.tabs li, .woocommerce div.product .woocommerce-tabs ul.tabs li, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li, .woocommercece-page div.product .woocommerce-tabs ul.tabs li,    .portfolioeffects:hover .overlay_icon, .portfolio-excerpt .more-link,  .page-template-portfolio-2col .entry-title:after, .page-template-portfolio-2col_text .entry-title:after, .page-template-portfolio-2col_sidebar .entry-title:after, .page-template-portfolio-3col .entry-title:after, .page-template-portfolio-3col_text .entry-title:after, .page-template-portfolio-3col_sidebar .entry-title:after, .page-template-portfolio-4col .entry-title:after, .page-template-portfolio-4col_text .entry-title:after, .page-template-portfolio .entry-title:after,
                    .so-widget-gx-flexslider-widget .flexcarousel .flex-direction-nav a:hover, .so-widget-gx-recent-posts-widget .flexcarousel .flex-direction-nav a:hover,
                    .ui-accordion .ui-accordion-header-active,.btn, .widget_button-widget .btn,  .so-widget-trendzhop_pro-best-sale-product-widget ul .four.columns:hover .button.product_type_simple, .so-widget-trendzhop_pro-best-sale-product-widget ul li:hover .button.product_type_simple,  .so-widget-trendzhop_pro-best-sale-product-widget ul .four.columns:hover .button.product_type_variable, .so-widget-trendzhop_pro-best-sale-product-widget ul li:hover .button.product_type_variable,  .so-widget-trendzhop_pro-best-sale-product-widget ul a.added_to_cart,#secondary .left-sidebar .callout-widget,.dropcap-circle,
                    .dropcap-box ,.dropcap-book,.left-sidebar .dropcap-circle,
                    .left-sidebar .dropcap-box ,.widget .ei-slider-thumbs li.ei-slider-element,
                    ul.ei-slider-thumbs li.ei-slider-element,.flexslider:hover .flex-direction-nav a.flex-prev:hover,   .so-widget-trendzhop_pro-featured-product-widget ul .four.columns:hover .button.product_type_simple, .so-widget-trendzhop_pro-featured-product-widget ul li:hover .button.product_type_simple,  .so-widget-trendzhop_pro-featured-product-widget ul .four.columns:hover .button.product_type_variable, .so-widget-trendzhop_pro-featured-product-widget ul li:hover .button.product_type_variable,  .so-widget-trendzhop_pro-featured-product-widget ul a.added_to_cart,.icon-box a.more-button:hover,.gx-pricing-table:hover .btn-normal,  ul.filter-options li a:hover, ul.filter-options li .selected,  .site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
                    .site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,
                    .left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
                    .left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,.so-widget-skills-widget .skill-container .skill .skill-percentage, .site-footer .widget.widget_skill-widget .skill-container .skill-percentage,.left-sidebar .widget.widget_skill-widget .skill-container .skill-percentage, .share-box ul li a:hover, .theme-social-network .sow-social-media-button .sow-icon-fontawesome:hover,.service-wrapper .service-content p a:hover, .tabs.normal ul li a:hover, .tabs ul li a:hover,.tabs.normal ul li .tabulous_active, .tabs ul li .tabulous_active,  .so-widget-trendzhop_pro-onsale-product-widget ul .four.columns:hover .button.product_type_simple, .so-widget-trendzhop_pro-onsale-product-widget ul li:hover .button.product_type_simple,  .so-widget-trendzhop_pro-onsale-product-widget ul .four.columns:hover .button.product_type_variable, .so-widget-trendzhop_pro-onsale-product-widget ul li:hover .button.product_type_variable,  .so-widget-trendzhop_pro-onsale-product-widget ul a.added_to_cart,  .so-widget-trendzhop_pro-top-rated-product-widget ul .four.columns:hover .button.product_type_simple, .so-widget-trendzhop_pro-top-rated-product-widget ul li:hover .button.product_type_simple,  .so-widget-trendzhop_pro-top-rated-product-widget ul .four.columns:hover .button.product_type_variable, .so-widget-trendzhop_pro-top-rated-product-widget ul li:hover .button.product_type_variable,.so-widget-trendzhop_pro-top-rated-product-widget ul a.added_to_cart,.so-widget-team-member-widget .our-team,.toggle .toggle-title,  .so-widget-trendzhop_pro-latest-product-widget ul .four.columns:hover .button.product_type_simple, .so-widget-trendzhop_pro-latest-product-widget ul li:hover .button.product_type_simple,  .so-widget-trendzhop_pro-latest-product-widget ul .four.columns:hover .button.product_type_variable, .so-widget-trendzhop_pro-latest-product-widget ul li:hover .button.product_type_variable,  .so-widget-trendzhop_pro-latest-product-widget ul a.added_to_cart,.widget_calendar table caption,.widget_search .search-form input[type="submit"],.widget_tag_cloud a:hover,.site-footer .footer-widgets .widget_calendar table caption,.site-footer .scroll-to-top ,.main-navigation button.menu-toggle:hover,button,
input[type="button"],
input[type="reset"],
input[type="submit"],.menu-toggle ul li a:hover,
    .main-navigation.toggled ul.menu.nav-menu ul li a:hover,
    .slicknav_menu ul li a:hover,.slicknav_menu,.slicknav_nav .slicknav_row:hover,.slicknav_btn:hover,.navigation a:hover,
  .comment-navigation a:hover .nav-links .meta-nav,
  .more-link .meta-nav, .comment-navigation .meta-nav,.nav-links .nav-previous:hover a,
  .more-link .nav-previous:hover a, .comment-navigation .nav-previous:hover a,.nav-links .nav-next:hover a,
  .more-link .nav-next:hover a, .comment-navigation .nav-next:hover a,a.more-link,.navigation.pagination .page-numbers, .branding .header-search-box .search-form .customSelect,.branding .header-search-box .search-form select,.branding .cart-item,.share-box ul li a:hover,.hentry.sticky,.hentry.sticky .entry-footer span,.page-links,.post .latest-content a.more-link ,.post .latest-content a.more-link:hover,.woocommerce table.shop_table thead th,  .woocommerce #customer_login .u-column1 form.login input.button, .woocommerce #customer_login .u-column1 form.register input.button, .woocommerce #customer_login .u-column2 form.login input.button, .woocommerce #customer_login .u-column2 form.register input.button,

.woocommerce nav.woocommerce-pagination ul li,.title-divider:before,.service-wrapper .service-content p a:hover,.row #primary .page-title span,.entry-header h1 span,.woocommerce #content nav.woocommerce-pagination ul li a:focus,
.woocommerce #content nav.woocommerce-pagination ul li a:hover,
.woocommerce #content nav.woocommerce-pagination ul li span.current,
.woocommerce nav.woocommerce-pagination ul li a:focus,
.woocommerce nav.woocommerce-pagination ul li a:hover,
.woocommerce nav.woocommerce-pagination ul li span.current,
.woocommerce-page #content nav.woocommerce-pagination ul li a:focus,
.woocommerce-page #content nav.woocommerce-pagination ul li a:hover,
.woocommerce-page #content nav.woocommerce-pagination ul li span.current,
.woocommerce-page nav.woocommerce-pagination ul li a:focus,
.woocommerce-page nav.woocommerce-pagination ul li a:hover,
.woocommerce-page nav.woocommerce-pagination ul li span.current,.woocommerce a.remove,  .woocommerce ul.products li.product:hover .button.product_type_simple, .woocommerce-page ul.products li.product:hover .button.product_type_simple,  .woocommerce ul.products li.product:hover .button.product_type_variable, .woocommerce-page ul.products li.product:hover .button.product_type_variable,  .woocommerce ul.products li.product a.added_to_cart, .woocommerce-page ul.products li.product a.added_to_cart,.woocommerce .widget_price_filter .price_slider_amount .button,.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,.woocommerce #content div.product .woocommerce-tabs ul.tabs li, .woocommerce div.product .woocommerce-tabs ul.tabs li, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li, .woocommerce-page div.product .woocommerce-tabs ul.tabs li,.widget_calendar table caption,.widget_search .search-form input[type="submit"], .widget_tag_cloud a:hover,.nav-wrap,.so-widget-trendzhop-pro-best-sale-product-widget .flex-direction-nav .flex-disabled,.so-widget-trendzhop-pro-best-sale-product-widget ul .four.columns:hover .button.product_type_simple, .so-widget-trendzhop-pro-best-sale-product-widget ul li:hover .button.product_type_simple,.so-widget-trendzhop-pro-best-sale-product-widget ul .four.columns:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist, .so-widget-trendzhop-pro-best-sale-product-widget ul li:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist,.so-widget-trendzhop-pro-best-sale-product-widget .flex-direction-nav a:hover,.so-widget-trendzhop-pro-best-sale-product-widget ul .yith-wcwl-wishlistexistsbrowse.show a::before, .so-widget-trendzhop-pro-best-sale-product-widget ul .yith-wcwl-wishlistaddedbrowse.show a::before,.so-widget-trendzhop-pro-best-sale-product-widget ul a.added_to_cart::before, .so-widget-trendzhop-pro-featured-product-widget .flex-direction-nav .flex-disabled,.so-widget-trendzhop-pro-featured-product-widget ul .four.columns:hover .button.product_type_simple, .so-widget-trendzhop-pro-featured-product-widget ul li:hover .button.product_type_simple,.so-widget-trendzhop-pro-featured-product-widget ul .four.columns:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist, .so-widget-trendzhop-pro-featured-product-widget ul li:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist,.so-widget-trendzhop-pro-featured-product-widget .flex-direction-nav a:hover,.so-widget-trendzhop-pro-featured-product-widget ul .yith-wcwl-wishlistexistsbrowse.show a::before, .so-widget-trendzhop-pro-featured-product-widget ul .yith-wcwl-wishlistaddedbrowse.show a::before,.so-widget-trendzhop-pro-featured-product-widget ul a.added_to_cart::before,.so-widget-trendzhop-pro-latest-product-widget .flex-direction-nav .flex-disabled,.so-widget-trendzhop-pro-latest-product-widget ul .four.columns:hover .button.product_type_simple, .so-widget-trendzhop-pro-latest-product-widget ul li:hover .button.product_type_simple,.so-widget-trendzhop-pro-latest-product-widget ul .four.columns:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist, .so-widget-trendzhop-pro-latest-product-widget ul li:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist,.so-widget-trendzhop-pro-latest-product-widget .flex-direction-nav a:hover,.so-widget-trendzhop-pro-latest-product-widget ul .yith-wcwl-wishlistexistsbrowse.show a::before, .so-widget-trendzhop-pro-latest-product-widget ul .yith-wcwl-wishlistaddedbrowse.show a::before,.so-widget-trendzhop-pro-latest-product-widget ul a.added_to_cart::before, .so-widget-trendzhop-pro-onsale-product-widget .flex-direction-nav .flex-disabled,.so-widget-trendzhop-pro-onsale-product-widget ul .four.columns:hover .button.product_type_simple, .so-widget-trendzhop-pro-onsale-product-widget ul li:hover .button.product_type_simple,.so-widget-trendzhop-pro-onsale-product-widget ul .four.columns:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist, .so-widget-trendzhop-pro-onsale-product-widget ul li:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist,.so-widget-trendzhop-pro-onsale-product-widget .flex-direction-nav a:hover,.so-widget-trendzhop-pro-onsale-product-widget ul .yith-wcwl-wishlistexistsbrowse.show a::before, .so-widget-trendzhop-pro-onsale-product-widget ul .yith-wcwl-wishlistaddedbrowse.show a::before,.so-widget-trendzhop-pro-onsale-product-widget ul a.added_to_cart::before, .so-widget-trendzhop-pro-top-rated-product-widget .flex-direction-nav .flex-disabled,.so-widget-trendzhop-pro-top-rated-product-widget ul .four.columns:hover .button.product_type_simple, .so-widget-trendzhop-pro-top-rated-product-widget ul li:hover .button.product_type_simple,.so-widget-trendzhop-pro-top-rated-product-widget ul .four.columns:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist, .so-widget-trendzhop-pro-top-rated-product-widget ul li:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist,.so-widget-trendzhop-pro-top-rated-product-widget .flex-direction-nav a:hover,.so-widget-trendzhop-pro-top-rated-product-widget ul .yith-wcwl-wishlistexistsbrowse.show a::before, .so-widget-trendzhop-pro-top-rated-product-widget ul .yith-wcwl-wishlistaddedbrowse.show a::before,.so-widget-trendzhop-pro-top-rated-product-widget ul a.added_to_cart::before,.widget_recent-posts-widget .recent-posts-carousel .flex-direction-nav .flex-disabled,.widget_recent-posts-widget .recent-posts-carousel .flex-direction-nav a:hover,.woocommerce ul.products li.product:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist, .woocommerce-page ul.products li.product:hover .yith-wcwl-add-to-wishlist .yith-wcwl-add-button .add_to_wishlist,.woocommerce ul.products li.product .yith-wcwl-wishlistexistsbrowse.show a::before, .woocommerce ul.products li.product .yith-wcwl-wishlistaddedbrowse.show a::before, .woocommerce-page ul.products li.product .yith-wcwl-wishlistexistsbrowse.show a::before, .woocommerce-page ul.products li.product .yith-wcwl-wishlistaddedbrowse.show a::before,.woocommerce ul.products li.product a.added_to_cart::before, .woocommerce-page ul.products li.product a.added_to_cart::before',
            'property' => 'background-color', 
        ),

          array(
            'element'  => '.tabs.normal ul li .tabulous_active, .tabs ul li .tabulous_active,.woocommerce #content input.button:hover,
                .woocommerce #respond input#submit:hover,
                .woocommerce a.button:hover,
                .woocommerce button.button:hover,
                .woocommerce input.button:hover,
                .woocommerce-page #content input.button:hover,
                .woocommerce-page #respond input#submit:hover,
                .woocommerce-page a.button:hover,
                .woocommerce-page button.button:hover,
                .woocommerce-page input.button:hover,.woocommerce table.shop_table tbody td.actions .coupon input.button,.woocommerce table.shop_table tbody td.actions .button,.woocommerce .wc-proceed-to-checkout .checkout-button.button.alt, .woocommerce #order_review #payment .place-order input,.woocommerce .checkout_coupon .form-row-last .button, .woocommerce .login .button,.woocommerce .cart button.single_add_to_cart_button,.site-footer .widget.widget_skill-widget .skill-container .skill-percentage,.left-sidebar .widget.widget_skill-widget .skill-container .skill-percentage,  .comment-form .form-submit input[type="submit"],.single-product .yith-wcwl-add-to-wishlist .yith-wcwl-add-button.show a,.flexslider .flex-caption p a,.site-info,.two.columns.add-to-cart .cart-item:hover',
            'property' => 'background-color',
            'suffix' => '!important',
        ),

        array(
            'element'  => '.nav-wrap .nav-left:hover ul ul.children li a,.nav-wrap .nav-left:hover ul li.cat-parent a:hover,
 .nav-wrap .nav-left:hover ul li.cat-parent a:hover:after,.top-nav ul li:hover a,ol.comment-list .reply:before,.comment-author .fn a,ol.comment-list article .fn,.comment-metadata a:hover,.comment-form .comment-form-email, .comment-form .comment-form-author,.comment-form .comment-form-comment,.hentry.post h1 a:hover,.entry-header .entry-title a:hover,.entry-meta .dd,.entry-meta span, .entry-footer span ,.entry-meta span i, .entry-footer span i,
.entry-meta span a, .entry-footer span a,
.entry-meta span:after, .entry-footer span:after,.single-post #respond .comment-form-url label,.woocommerce #customer_login .u-column1 h2, .woocommerce #customer_login .u-column2 h2,.woocommerce #customer_details h3,.woocommerce #order_review_heading,.woocommerce-info:before,
.order-total .amount,
.cart-subtotal .amount,.woocommerce #content table.cart a.remove,
.woocommerce table.cart a.remove,
.woocommerce-page #content table.cart a.remove,
.woocommerce-page table.cart a.remove,.woocommerce .woocommerce-breadcrumb a:hover,
.woocommerce-page .woocommerce-breadcrumb a:hover,.woocommerce-message:before,
.woocommerce .star-rating span,
.woocommerce .star-rating::before,.portfolioeffects .content-details h3 a:hover,.portfolioeffects .overlay_icon a:hover i,ul#portfolio li h3 a:hover,  .page-template-portfolio-2col .entry-title:before, .page-template-portfolio-2col_text .entry-title:before, .page-template-portfolio-2col_sidebar .entry-title:before, .page-template-portfolio-3col .entry-title:before, .page-template-portfolio-3col_text .entry-title:before, .page-template-portfolio-3col_sidebar .entry-title:before, .page-template-portfolio-4col .entry-title:before, .page-template-portfolio-4col_text .entry-title:before, .page-template-portfolio .entry-title:before,.recent-work-container .recent_work_overlay a:hover i,.breadcrumb a:hover,.ui-accordion h3 span,.dropcap,.left-sidebar .dropcap,
.left-sidebar .dropcap-circle,
.left-sidebar .dropcap-box,.icon-box .icon-wrapper span,.so-widget-list-widget .sow-icon-fontawesome, .so-widget-list-widget .list-image,.pullright:before,
  .pullleft:before,
  .pullnone:before, .widget_recent-posts-widget .recent-posts .latest-post-details h3 a:hover, .widget_recent-posts-widget .recent-posts-carousel .latest-post-details h3 a:hover,    .widget_recent-posts-widget .recent-posts .latest-post-details .btn-readmore, .widget_recent-posts-widget .recent-posts-carousel .latest-post-details .btn-readmore,.left-sidebar .widget_recent-posts-widget .flex-recent-posts li a,.so-widget-gx-recent-work-widget .portfolioeffects .content-details h3 a:hover, .so-widget-gx-recent-work-widget .work .content-details h3 a:hover,.portfolioeffects .content-details h3 a:hover, .work .content-details h3 a:hover,.left-sidebar .widget_social-networks-widget ul li a:hover i, .service-wrapper .service-content h4 a:hover,.site-footer .widget.widget_ourteam-widget:hover .team-content h4,#secondary .left-sidebar .widget.widget_ourteam-widget .team-content h4,.site-footer .widget_testimonial-widget ul li .client,.so-widget-tooltip-widget a, #secondary #recentcomments a:hover,.widget_calendar table th a:hover, .widget_calendar table td a:hover,.widget_calendar table tfoot td a,
.site-footer .widget_calendar table a,.widget-area .widget_rss span,
 .widget-area .widget_rss a:hover,.site-footer .footer-widgets .calendar_wrap a:hover,.site-footer .footer-widgets a:hover,.site-info .left-sidebar .textwidget ul li a:hover,.portfolio-excerpt h4 a,.single-product .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistaddedbrowse.show a, .single-product .yith-wcwl-add-to-wishlist .yith-wcwl-wishlistexistsbrowse a',

            'property' => 'color',
        ),
        
        array(
            'element' => ' .main-navigation ul ul.sub-menu li:hover > a,.nav-wrap .nav-left:hover ul ul.children li:hover > a ,.woocommerce div.product .woocommerce-tabs ul.tabs::before,.hr_fancy_with_color,.tabs.normal ul, .tabs ul,.entry-header h1',
            'property' => 'border-bottom-color',
        ),
        array(
            'element' => '.pullright,.pullleft,.pullnone,',
            'property' => 'border-left-color',
        ),
        array(
            'element'  => ' .gx-pricing-table:hover .gx-table-header',
            'property' => 'border-top-color',
        ),
        
    ),
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'enable_nav_bg_color',
    'label'    => __( 'Enable Navigation Bar BG Color', 'trendzhop_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => 'off',
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'nav_bg_color',
    'label'    => __( 'Navigation Bar BG Color', 'trendzhop_pro' ),
    'section'  => 'primary_color_field',
    'type'     => 'color',
    'default'  => '#03a9f4',
    'alpha'  => true,
    'active_callback' => array(
        array(
            'setting'  => 'enable_nav_bg_color',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output' => array(
        array(
            'element' => '.nav-wrap',
            'property' => 'background-color',
        ),
        array(
            'element' => '.nav-wrap',
            'property' => 'background-color',
            'media_query' => '@media(max-width: 600px)',
        ),
    ),
) );
   
// typography panel //

Trendzhop_Kirki::add_panel( 'typography', array( 
    'title'       => __( 'Typography', 'trendzhop_pro' ),
    'description' => __( 'Typography and Link Color Settings', 'trendzhop_pro' ),
) );
   
    Trendzhop_Kirki::add_section( 'typography_section', array(
        'title'          => __( 'General Settings','trendzhop_pro' ),
        'description'    => __( 'General Settings', 'trendzhop_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

        

    Trendzhop_Kirki::add_section( 'body_font', array(
        'title'          => __( 'Body Font','trendzhop_pro' ),
        'description'    => __( 'Specify the body font properties', 'trendzhop_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) ); 

    Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'body_typography',
        'label'    => __( 'Enable Custom body Settings', 'trendzhop_pro' ),
        'section'  => 'body_font',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
            'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
        ),
        'tooltip' => __('Turn on to body typography and turn off for default typography','trendzhop_pro'),
        'default'  => 'off',
    ) );

    Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'body',
        'label'    => __( 'Body Settings', 'trendzhop_pro' ),
        'section'  => 'body_font', 
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'sans-serif',
            'variant'        => 'regular',
            'font-size'      => '16px',
            'line-height'    => '1.5',
            'letter-spacing' => '0',
            'color'          => '#33363a',
        ),
        'output'      => array(
            array(
                'element' => 'body',
                //'suffix' => '!important',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'body_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );


    Trendzhop_Kirki::add_section( 'heading_section', array(
        'title'          => __( 'Heading Font','trendzhop_pro' ),
        'description'    => __( 'Specify typography of H1, H2, H3, H4, H5, H6', 'trendzhop_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );
    

      Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'heading_one_typography',
        'label'    => __( 'Enable Custom H1 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
            'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
        ),
        'tooltip' => __('Turn on to H1 typography and turn off for default typography','trendzhop_pro'),
        'default'  => 'off',
    ) );

    Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'h1',
        'label'    => __( 'H1 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '48px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#33363a',
        ),
        'output'      => array(
            array(
                'element' => 'h1',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_one_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );
    Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'heading_two_typography',
        'label'    => __( 'Enable Custom H2 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
            'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
        ),
        'tooltip' => __('Turn on to H2 typography and turn off for default typography','trendzhop_pro'),
        'default'  => 'off',
    ) );

    Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'h2',
        'label'    => __( 'H2 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '36px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#33363a',
        ),
        'output'      => array(
            array(
                'element' => 'h2',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_two_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'heading_three_typography',
        'label'    => __( 'Enable Custom H3 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
            'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
        ),
        'tooltip' => __('Turn on to H3 typography and turn off for default typography','trendzhop_pro'),
        'default'  => 'off',
    ) );


    Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'h3',
        'label'    => __( 'H3 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default' => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '30px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#33363a',
        ),
        'output'      => array(
            array(
                'element' => 'h3',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_three_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

        Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'heading_four_typography',
        'label'    => __( 'Enable Custom H4 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
            'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
        ),
        'tooltip' => __('Turn on to H4 typography and turn off for default typography','trendzhop_pro'),
        'default'  => 'off',
    ) );


    Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'h4',
        'label'    => __( 'H4 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '24px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#33363a',
        ),
        'output'      => array(
            array(
                'element' => 'h4',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_four_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

        Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'heading_five_typography',
        'label'    => __( 'Enable Custom H5 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
            'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
        ),
        'tooltip' => __('Turn on to H5 typography and turn off for default typography','trendzhop_pro'),
        'default'  => 'off',
    ) );


    Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'h5',
        'label'    => __( 'H5 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '18px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#33363a',
        ),
        'output'      => array(
            array(
                'element' => 'h5',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_five_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );

        Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'heading_six_typography',
        'label'    => __( 'Enable Custom H6 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
            'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
        ),
        'tooltip' => __('Turn on to H6 typography and turn off for default typography','trendzhop_pro'),
        'default'  => 'off',
    ) );



    Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'h6',
        'label'    => __( 'H6 Settings', 'trendzhop_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#33363a',
        ),
        'output'      => array(
            array(
                'element' => 'h6',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_six_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    // navigation font 
    Trendzhop_Kirki::add_section( 'navigation_section', array(
        'title'          => __( 'Navigation Font','trendzhop_pro' ),
        'description'    => __( 'Specify Navigation font properties', 'trendzhop_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

       Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'navigation_font_status',
        'label'    => __( 'Enable Navigation Font Settings', 'trendzhop_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
            'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
        ),
        'tooltip' => __('Turn on to Navigation Font typography and turn off for default typography','trendzhop_pro'),
        'default'  => 'off',
    ) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
        'settings' => 'navigation_font',
        'label'    => __( 'Navigation Font Settings', 'trendzhop_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '400',
            'font-size'      => '15px',
            'line-height'    => '1.8', 
            'letter-spacing' => '0',
            'color'          => '#ffffff',
        ),
        'output'      => array(
            array(
                'element' => '.main-navigation a,.main-navigation ul ul a,
                            .main-navigation a:hover, .main-navigation .current_page_item > a,
                             .main-navigation .current-menu-item > a, .main-navigation .current-menu-parent > a, 
                             .main-navigation .current_page_ancestor > a, .main-navigation .current_page_parent > a',
            ),
        ),
'active_callback' => array(
            array(
                'setting'  => 'navigation_font_status',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );



// header panel //

Trendzhop_Kirki::add_panel( 'header_panel', array(     
    'title'       => __( 'Header', 'trendzhop_pro' ),
    'description' => __( 'Header Related Options', 'trendzhop_pro' ), 
) );  

Trendzhop_Kirki::add_section( 'header', array(
    'title'          => __( 'General Header','trendzhop_pro' ),
    'description'    => __( 'Header options', 'trendzhop_pro'),
    'panel'          => 'header_panel', // Not typically needed.  
) );    


Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'header_search',
    'label'    => __( 'Enable to Show Search box in Header', 'trendzhop_pro' ), 
    'section'  => 'header',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => 'on',
) );



/* STICKY HEADER section */   

Trendzhop_Kirki::add_section( 'stricky_header', array(
    'title'          => __( 'Sticky Menu','trendzhop_pro' ),
    'description'    => __( 'sticky header', 'trendzhop_pro'),
    'panel'          => 'header_panel', // Not typically needed.
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(    
    'settings' => 'sticky_header',
    'label'    => __( 'Enable Sticky Header', 'trendzhop_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => 'off',
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'sticky_header_position',
    'label'    => __( 'Enable Sticky Header Position', 'trendzhop_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'top'  => esc_attr__( 'Top', 'trendzhop_pro' ),
        'bottom' => esc_attr__( 'Bottom', 'trendzhop_pro' )
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'sticky_header',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'top',
) );


Trendzhop_Kirki::add_section( 'header_image', array(
    'title'          => __( 'Header Background Image','trendzhop_pro' ),
    'description'    => __( 'Custom Header Image options', 'trendzhop_pro'),
    'panel'          => 'header_panel', // Not typically needed.  
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(   
    'settings' => 'header_bg_size',
    'label'    => __( 'Header Background Size', 'trendzhop_pro' ),
    'section'  => 'header_image',
    'type'     => 'radio-buttonset', 
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'trendzhop_pro' ),
        'contain' => esc_attr__( 'Contain', 'trendzhop_pro' ),
        'auto'  => esc_attr__( 'Auto', 'trendzhop_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'trendzhop_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Header Background Image Size','trendzhop_pro'),
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'header_bg_repeat',
    'label'    => __( 'Header Background Repeat', 'trendzhop_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'trendzhop_pro'),
        'repeat' => esc_attr__('Repeat', 'trendzhop_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','trendzhop_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'repeat',  
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'header_bg_position', 
    'label'    => __( 'Header Background Position', 'trendzhop_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'trendzhop_pro'),
        'center center' => esc_attr__('Center Center', 'trendzhop_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'trendzhop_pro'),
        'left top' => esc_attr__('Left Top', 'trendzhop_pro'),
        'left center' => esc_attr__('Left Center', 'trendzhop_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'trendzhop_pro'),
        'right top' => esc_attr__('Right Top', 'trendzhop_pro'),
        'right center' => esc_attr__('Right Center', 'trendzhop_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'center center',  
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'header_bg_attachment',
    'label'    => __( 'Header Background Attachment', 'trendzhop_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'trendzhop_pro'),
        'fixed' => esc_attr__('Fixed', 'trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'scroll',  
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'header_overlay',
    'label'    => __( 'Enable Header( Background ) Overlay', 'trendzhop_pro' ),
    'section'  => 'header_image',
    'type'     => 'switch',    
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => 'off',
) );
  
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'header_overlay_color',
    'label'    => __( 'Header Overlay ( Background )color', 'trendzhop_pro' ),
    'section'  => 'header_image',
    'type'     => 'color',  
    'alpha' => true,
    'default'  => '#ffffff', 
    'output'   => array(
        array(
            'element'  => '.overlay-header',
            'property' => 'background-color',
        ),
    ), 
    'active_callback' => array(
        array(
            'setting'  => 'header_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

/* Blog panel */

Trendzhop_Kirki::add_panel( 'blog_panel', array(     
    'title'       => __( 'Blog', 'trendzhop_pro' ),
    'description' => __( 'Blog Related Options', 'trendzhop_pro' ),     
) ); 
Trendzhop_Kirki::add_section( 'blog', array(
    'title'          => __( 'Blog Page','trendzhop_pro' ),
    'description'    => __( 'Blog Related Options', 'trendzhop_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
  
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'blog_layout',
    'label'    => __( 'Select Blog Page Layout you prefer', 'trendzhop_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1  => esc_attr__( 'Default ( One Column )', 'trendzhop_pro' ),
        2 => esc_attr__( 'Two Columns ', 'trendzhop_pro' ),
        3 => esc_attr__( 'Three Columns ( Without Sidebar ) ', 'trendzhop_pro' ),
        4 => esc_attr__( 'Two Columns With Masonry', 'trendzhop_pro' ),
        5 => esc_attr__( 'Three Columns With Masonry ( Without Sidebar ) ', 'trendzhop_pro' ),
        6 => esc_attr__( 'Blog FullWidth', 'trendzhop_pro' ),
    ),
    'default'  => 1,
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'featured_image',
    'label'    => __( 'Enable Featured Image', 'trendzhop_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for blog page','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'more_text',
    'label'    => __( 'More Text', 'trendzhop_pro' ),
    'section'  => 'blog',
    'type'     => 'text',
    'description' => __('Text to display in case of text too long','trendzhop_pro'),
    'default' => __('Read More','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'featured_image_size',
    'label'    => __( 'Choose the Featured Image Size for Blog Page', 'trendzhop_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1 => esc_attr__( 'Large Featured Image', 'trendzhop_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'trendzhop_pro' ),
        3 => esc_attr__( 'Original Size', 'trendzhop_pro' ),
        4 => esc_attr__( 'Medium', 'trendzhop_pro' ),
        5 => esc_attr__( 'Large', 'trendzhop_pro' ), 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Set large and medium image size: Goto Dashboard => Settings => Media', 'trendzhop_pro') ,
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'enable_single_post_top_meta',
    'label'    => __( 'Enable to display top post meta data', 'trendzhop_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'single_post_top_meta',
    'label'    => __( 'Activate and Arrange the Order of Top Post Meta elements', 'trendzhop_pro' ),
    'section'  => 'blog',
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'trendzhop_pro' ),
        2 => esc_attr__( 'author', 'trendzhop_pro' ),
        3 => esc_attr__( 'comment', 'trendzhop_pro' ),
        4 => esc_attr__( 'category', 'trendzhop_pro' ),
        5 => esc_attr__( 'tags', 'trendzhop_pro' ),
        6 => esc_attr__( 'edit', 'trendzhop_pro' ),
    ),
    'default'  => array(1, 2, 6),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_top_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','trendzhop_pro'),

) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'enable_single_post_bottom_meta',
    'label'    => __( 'Enable to display bottom post meta data', 'trendzhop_pro' ),
    'section'  => 'blog', 
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','trendzhop_pro'),
    'default'  => 'on',
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'single_post_bottom_meta',
    'label'    => __( 'Activate and arrange the Order of Bottom Post Meta elements', 'trendzhop_pro' ),
    'section'  => 'blog',
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'trendzhop_pro' ),
        2 => esc_attr__( 'author', 'trendzhop_pro' ),
        3 => esc_attr__( 'comment', 'trendzhop_pro' ),
        4 => esc_attr__( 'category', 'trendzhop_pro' ),
        5 => esc_attr__( 'tags', 'trendzhop_pro' ),
        6 => esc_attr__( 'edit', 'trendzhop_pro' ),
    ),
    'default'  => array(3,4,5),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_bottom_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','trendzhop_pro'),
) );


/* Single Blog page section */

Trendzhop_Kirki::add_section( 'single_blog', array(
    'title'          => __( 'Single Blog Page','trendzhop_pro' ),
    'description'    => __( 'Single Blog Page Related Options', 'trendzhop_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'single_featured_image',
    'label'    => __( 'Enable Single Post Featured Image', 'trendzhop_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for Single Post Page','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'single_featured_image_size',
    'label'    => __( 'Choose the featured image display type for Single Post Page', 'trendzhop_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Large Featured Image', 'trendzhop_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'trendzhop_pro' ),
        3 => esc_attr__( 'FullWidth Featured Image', 'trendzhop_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'author_bio_box',
    'label'    => __( 'Enable Author Bio Box below single post', 'trendzhop_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'off',
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'related_posts',
    'label'    => __( 'Show Related Posts', 'trendzhop_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Show the Related Post for Single Blog Page','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'related_posts_hierarchy',
    'label'    => __( 'Related Posts Must Be Shown As:', 'trendzhop_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Related Posts By Tags', 'trendzhop_pro' ),
        2 => esc_attr__( 'Related Posts By Categories', 'trendzhop_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'related_posts',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Select the Hierarchy','trendzhop_pro'),

) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'comments',
    'label'    => __( ' Show Comments', 'trendzhop_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Show the Comments for Single Blog Page','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'social_sharing_box',
    'label'    => __( 'Show social sharing options box below single post', 'genex_flat' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
) );

//social sharing box section

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'facebook_sb',
    'label'    => __( 'Enable facebook sharing option below single post', 'trendzhop_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'twitter_sb',
    'label'    => __( 'Enable twitter sharing option below single post', 'trendzhop_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'linkedin_sb',
    'label'    => __( 'Enable linkedin sharing option below single post', 'trendzhop_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'google-plus_sb',
    'label'    => __( 'Enable googleplus sharing option below single post', 'trendzhop_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'email_sb',
    'label'    => __( 'Enable email sharing option below single post', 'trendzhop_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
/* FOOTER SECTION 
footer panel */

Trendzhop_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'trendzhop_pro' ),
    'description' => __( 'Footer Related Options', 'trendzhop_pro' ),     
) );  

Trendzhop_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','trendzhop_pro' ),
    'description'    => __( 'Footer related options', 'trendzhop_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'trendzhop_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','trendzhop_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'trendzhop_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'trendzhop_pro' ),
        2  => esc_attr__( '2', 'trendzhop_pro' ),
        3  => esc_attr__( '3', 'trendzhop_pro' ),
        4  => esc_attr__( '4', 'trendzhop_pro' ),
    ),
    'default'  => 4,
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'trendzhop_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'trendzhop_pro' ),
    'description' => __('Select the top margin of footer in pixels','trendzhop_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Trendzhop_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','trendzhop_pro' ),
    'description'    => __( 'Custom Footer Image options', 'trendzhop_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'trendzhop_pro' ),
        'contain' => esc_attr__( 'Contain', 'trendzhop_pro' ),
        'auto'  => esc_attr__( 'Auto', 'trendzhop_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'trendzhop_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'trendzhop_pro'),
        'repeat' => esc_attr__('Repeat', 'trendzhop_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','trendzhop_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'trendzhop_pro'),
        'center center' => esc_attr__('Center Center', 'trendzhop_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'trendzhop_pro'),
        'left top' => esc_attr__('Left Top', 'trendzhop_pro'),
        'left center' => esc_attr__('Left Center', 'trendzhop_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'trendzhop_pro'),
        'right top' => esc_attr__('Right Top', 'trendzhop_pro'),
        'right center' => esc_attr__('Right Center', 'trendzhop_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'trendzhop_pro'),
        'fixed' => esc_attr__('Fixed', 'trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => 'off',
) );
  
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.overlay-footer',
            'property' => 'background-color',
        ),
    ),
) );


// single page section //

Trendzhop_Kirki::add_section( 'single_page', array(
    'title'          => __( 'Single Page','trendzhop_pro' ),
    'description'    => __( 'Single Page Related Options', 'trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'single_page_featured_image',
    'label'    => __( 'Enable Single Page Featured Image', 'trendzhop_pro' ),
    'section'  => 'single_page',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'single_page_featured_image_size',
    'label'    => __( 'Single Page Featured Image Size', 'trendzhop_pro' ),
    'section'  => 'single_page',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( 'Normal', 'trendzhop_pro' ),
        2 => esc_attr__( 'FullWidth', 'trendzhop_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_page_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

// Layout section //

Trendzhop_Kirki::add_section( 'layout', array(
    'title'          => __( 'Layout','trendzhop_pro' ),
    'description'    => __( 'Layout Related Options', 'trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'site-style',
    'label'    => __( 'Site Style', 'trendzhop_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'wide' =>  esc_attr__('Wide', 'trendzhop_pro'),
        'boxed' =>  esc_attr__('Boxed', 'trendzhop_pro'),
        'fluid' =>  esc_attr__('Fluid', 'trendzhop_pro'),  
        //'static' =>  esc_attr__('Static ( Non Responsive )', 'trendzhop_pro'),
    ),
    'default'  => 'wide',
    'tooltip' => __('Choose the default site layout.','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'global_sidebar_layout',
    'label'    => __( 'Check the box if you want to use a global sidebar on all pages. This option overrides the page options', 'trendzhop_pro' ),
    'section'  => 'layout',
    'type'     => 'checkbox',
    'default' => '0',
) );


Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'sidebar_position',
    'label'    => __( 'Main Layout', 'trendzhop_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-image',   
    'description' => __('Select main content and sidebar arrangements.','trendzhop_pro'),
    'choices' => array(
        'left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cl.png',
        'right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cr.png',
        'two-sidebar' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cm.png',  
        'two-sidebar-left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cl.png',
        'two-sidebar-right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cr.png',
        'fullwidth' =>  get_template_directory_uri() . '/admin/kirki/assets/images/1c.png',
        'no-sidebar' =>  get_template_directory_uri() . '/images/no-sidebar.png',
    ),
    'default'  => 'right', 
    'tooltip' => __('This Changes will be reflected in default template unless unique template is set for specific page','trendzhop_pro'),
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'body_top_margin',
    'label'    => __( 'Body Top Margin', 'trendzhop_pro' ),
    'description' => __('Select the top margin of body element in pixels','trendzhop_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-top',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'body_bottom_margin',
    'label'    => __( 'Body Bottom Margin', 'trendzhop_pro' ),
    'description' => __('Select the bottom margin of body element in pixels','trendzhop_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-bottom',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );

/* LAYOUT SECTION  */
/*
Trendzhop_Kirki::add_section( 'layout', array(
    'title'          => __( 'Layout','trendzhop_pro' ),   
    'description'    => __( 'Layout settings that affects overall site', 'trendzhop_pro'),
    'panel'          => 'style_outlet_pro_options', // Not typically needed.
) );



Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'primary_sidebar_width',
    'label'    => __( 'Primary Sidebar Width', 'trendzhop_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'trendzhop_pro' ),
        '2' => __( 'Two Column', 'trendzhop_pro' ),
        '3' => __( 'Three Column', 'trendzhop_pro' ),
        '4' => __( 'Four Column', 'trendzhop_pro' ),
        '5' => __( 'Five Column ', 'trendzhop_pro' ),
    ),
    'default'  => '5',  
    'tooltip' => __('Select the width of the Primary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'secondary_sidebar_width',
    'label'    => __( 'Secondary Sidebar Width', 'trendzhop_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'trendzhop_pro' ),
        '2' => __( 'Two Column', 'trendzhop_pro' ),
        '3' => __( 'Three Column', 'trendzhop_pro' ),
        '4' => __( 'Four Column', 'trendzhop_pro' ),
        '5' => __( 'Five Column ', 'trendzhop_pro' ),
    ),            
    'default'  => '5',  
    'tooltip' => __('Select the width of the Secondary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','trendzhop_pro'),
) ); 

*/

/* FOOTER SECTION 
footer panel */

Trendzhop_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'trendzhop_pro' ),
    'description' => __( 'Footer Related Options', 'trendzhop_pro' ),     
) );  

Trendzhop_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','trendzhop_pro' ),
    'description'    => __( 'Footer related options', 'trendzhop_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'trendzhop_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','trendzhop_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'trendzhop_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'trendzhop_pro' ),
        2  => esc_attr__( '2', 'trendzhop_pro' ),
        3  => esc_attr__( '3', 'trendzhop_pro' ),
        4  => esc_attr__( '4', 'trendzhop_pro' ),
    ),
    'default'  => 4,
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'trendzhop_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'trendzhop_pro' ),
    'description' => __('Select the top margin of footer in pixels','trendzhop_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

Trendzhop_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','trendzhop_pro' ),
    'description'    => __( 'Custom Footer Image options', 'trendzhop_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'trendzhop_pro' ),
        'contain' => esc_attr__( 'Contain', 'trendzhop_pro' ),
        'auto'  => esc_attr__( 'Auto', 'trendzhop_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'trendzhop_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'trendzhop_pro'),
        'repeat' => esc_attr__('Repeat', 'trendzhop_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','trendzhop_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'trendzhop_pro'),
        'center center' => esc_attr__('Center Center', 'trendzhop_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'trendzhop_pro'),
        'left top' => esc_attr__('Left Top', 'trendzhop_pro'),
        'left center' => esc_attr__('Left Center', 'trendzhop_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'trendzhop_pro'),
        'right top' => esc_attr__('Right Top', 'trendzhop_pro'),
        'right center' => esc_attr__('Right Center', 'trendzhop_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'trendzhop_pro'),
        'fixed' => esc_attr__('Fixed', 'trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => 'off',
) );
  
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'trendzhop_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => ' #4baf4f', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.overlay-footer',
            'property' => 'background-color',
        ),
    ),
) );


 if( class_exists( 'WooCommerce' ) ) {
    Trendzhop_Kirki::add_section( 'woocommerce_section', array(
        'title'          => __( 'WooCommerce','trendzhop_pro' ),
        'description'    => __( 'Theme options related to woocommerce', 'trendzhop_pro'),
        'priority'       => 11, 
        'theme_supports' => '', // Rarely needed.
    ) );
    Trendzhop_Kirki::add_field( 'woocommerce', array(
        'settings' => 'woocommerce_sidebar',
        'label'    => __( 'Enable Woocommerce Sidebar', 'trendzhop_pro' ),
        'description' => __('Enable Sidebar for shop page','trendzhop_pro'),
        'section'  => 'woocommerce_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
            'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
        ),

        'default'  => 'on',
    ) );
}
    
// background color ( rename )

Trendzhop_Kirki::add_section( 'colors', array(
    'title'          => __( 'Background Color','trendzhop_pro' ),
    'description'    => __( 'This will affect overall site background color', 'trendzhop_pro'),
    //'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 11,
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'general_background_color',
    'label'    => __( 'General Background Color', 'trendzhop_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-color',
        ),
    ),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'content_background_color',
    'label'    => __( 'Content Background Color', 'trendzhop_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'description' => __('when you are select boxed layout content background color will reflect the grid area','trendzhop_pro'), 
    'alpha' => true, 
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'general_background_image',
    'label'    => __( 'General Background Image', 'trendzhop_pro' ),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-image',
        ),
    ),
) );

// background image ( general & boxed layout ) //


Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'general_background_repeat',
    'label'    => __( 'General Background Repeat', 'trendzhop_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'trendzhop_pro'),
        'repeat' => esc_attr__('Repeat', 'trendzhop_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','trendzhop_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'general_background_size',
    'label'    => __( 'General Background Size', 'trendzhop_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'trendzhop_pro' ),
        'contain' => esc_attr__( 'Contain', 'trendzhop_pro' ),
        'auto'  => esc_attr__( 'Auto', 'trendzhop_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'trendzhop_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'general_background_attachment',
    'label'    => __( 'General Background Attachment', 'trendzhop_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'trendzhop_pro'),
        'fixed' => esc_attr__('Fixed', 'trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'general_background_position',
    'label'    => __( 'General Background Position', 'trendzhop_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'trendzhop_pro'),
        'center center' => esc_attr__('Center Center', 'trendzhop_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'trendzhop_pro'),
        'left top' => esc_attr__('Left Top', 'trendzhop_pro'),
        'left center' => esc_attr__('Left Center', 'trendzhop_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'trendzhop_pro'),
        'right top' => esc_attr__('Right Top', 'trendzhop_pro'),
        'right center' => esc_attr__('Right Center', 'trendzhop_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );


/* CONTENT BACKGROUND ( boxed background image )*/

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(  
    'settings' => 'content_background_image',
    'label'    => __( 'Content Background Image', 'trendzhop_pro' ),
    'description' => __('when you are select boxed layout content background image will reflect the grid area','trendzhop_pro'),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-image',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'content_background_repeat',
    'label'    => __( 'Content Background Repeat', 'trendzhop_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'trendzhop_pro'),
        'repeat' => esc_attr__('Repeat', 'trendzhop_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','trendzhop_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'content_background_size',
    'label'    => __( 'Content Background Size', 'trendzhop_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'trendzhop_pro' ),
        'contain' => esc_attr__( 'Contain', 'trendzhop_pro' ),
        'auto'  => esc_attr__( 'Auto', 'trendzhop_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'trendzhop_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'content_background_attachment',
    'label'    => __( 'Content Background Attachment', 'trendzhop_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'trendzhop_pro'),
        'fixed' => esc_attr__('Fixed', 'trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'content_background_position',
    'label'    => __( 'Content Background Position', 'trendzhop_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'trendzhop_pro'),
        'center center' => esc_attr__('Center Center', 'trendzhop_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'trendzhop_pro'),
        'left top' => esc_attr__('Left Top', 'trendzhop_pro'),
        'left center' => esc_attr__('Left Center', 'trendzhop_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'trendzhop_pro'),
        'right top' => esc_attr__('Right Top', 'trendzhop_pro'),
        'right center' => esc_attr__('Right Center', 'trendzhop_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'trendzhop_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );

/* pro theme options */

//  animation section 

Trendzhop_Kirki::add_section( 'animation_section', array(
    'title'          => __( 'Animation','trendzhop_pro' ),
    'description'    => __( 'Animation that affects overall site', 'trendzhop_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );  

Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'animation_effect',
    'label'    => __( 'Enable Animation Effect', 'trendzhop_pro' ),   
    'section'  => 'animation_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        'off' => esc_attr__( 'Disable', 'trendzhop_pro' ) 
    ),
    'default'  => 'on',
) );

// custom JS section

Trendzhop_Kirki::add_section( 'custom_js_section', array(
    'title'          => __( 'Custom JS','trendzhop_pro' ),
    'description'    => __( 'Custom JS', 'trendzhop_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
 Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'custom_js',
    'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'trendzhop_pro' ),
    'section'  => 'custom_js_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
) ); 


// Tracking section 

Trendzhop_Kirki::add_section( 'analytics_section', array(
    'title'          => __( 'Tracking Code','trendzhop_pro' ),
    'description'    => __( 'Tracking Code', 'trendzhop_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'analytics',
    'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'trendzhop_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
    'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'analytics_place',
    'label'    => __( 'Enable to Load Tracking Code in Footer', 'trendzhop_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        '2' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => '2',
    'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','trendzhop_pro'),
) );


//  lightbox section //

Trendzhop_Kirki::add_section( 'light_box', array(
    'title'          => __( 'Light Box','trendzhop_pro' ),
    'description'    => __( 'Light Box Settings', 'trendzhop_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'lightbox_theme',
    'label'    => __( 'Lightbox Theme', 'trendzhop_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => esc_attr__( 'pp_default', 'trendzhop_pro' ),
        '2' => esc_attr__( 'light-rounded', 'trendzhop_pro' ),
        '3' => esc_attr__( 'dark-rounded', 'trendzhop_pro' ),
        '4' => esc_attr__( 'light-square', 'trendzhop_pro' ),
        '5' => esc_attr__( 'dark-square', 'trendzhop_pro' ),
        '6' => esc_attr__( 'facebook', 'trendzhop_pro' ),
    ),
    'default'  => '1',
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'lightbox_animation_speed',
    'label'    => __( 'Animation Speed', 'trendzhop_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'fast' => esc_attr__( 'Fast', 'trendzhop_pro' ),
        'slow' => esc_attr__( 'Slow', 'trendzhop_pro' ),
        'normal' => esc_attr__( 'Normal', 'trendzhop_pro' ),
    ),
    'default'  => 'fast',
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'lightbox_slideshow',
    'label'    => __( 'Autoplay Gallery Speed', 'trendzhop_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 100,
        'step' => 10,
    ),
    'default'  => 50,
    'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'lightbox_autoplay_slideshow',
    'label'    => __( 'Enable Autoplay Gallery', 'trendzhop_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        '2' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => '2',
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'lightbox_opacity',
    'label'    => __( 'Select Background Opacity', 'trendzhop_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 1,
        'step' => 0.1,
    ),
    'default'  => 0.5,
    'tooltip' => __('Enter 0.1 to 1.0','trendzhop_pro'),
) );
Trendzhop_Kirki::add_field( 'trendzhop_pro', array(
    'settings' => 'lightbox_overlay_gallery',
    'label'    => __( 'Show Gallery Thumbnails', 'trendzhop_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array( 
        '1'  => esc_attr__( 'Enable', 'trendzhop_pro' ),
        '2' => esc_attr__( 'Disable', 'trendzhop_pro' )
    ),
    'default'  => '1',
) );

do_action('trendzhop_pro_child_customizer_options');
