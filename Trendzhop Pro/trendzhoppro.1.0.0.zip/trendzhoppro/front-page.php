<?php
/**
 * The front page template file.
 *
 *
 * @package Trendzhop Pro
 */
$page_sidebar_layout = get_post_meta( $post->ID, '_gx_pagesidebar_layout', true ); 
	if( 'posts' == get_option('show_on_front') ) {  
		get_template_part('home');
	}else{ 
        get_header();   
        	//if ( get_theme_mod('page-builder',true ) ) {     
				do_action('trendzhop_pro_content_before'); ?>

		<div id="content" class="site-content"> 
			<div class="container"><?php

			do_action('trendzhop_pro_primary_before'); ?> 

				<div id="primary" class="content-area <?php trendzhop_pro_primary_class(); ?> columns">

				   <main id="main" class="site-main" role="main"><?php
						while ( have_posts() ) : the_post();
							the_content();    
						endwhile; ?>
			        </main><!-- #main --> 

			    </div><!-- #primary --><?php	

            do_action('trendzhop_pro_primary_after'); ?>

			<?php	

            
			get_footer();  

 }