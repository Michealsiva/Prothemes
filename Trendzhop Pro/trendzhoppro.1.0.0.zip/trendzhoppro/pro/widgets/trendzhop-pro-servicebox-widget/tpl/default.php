<?php
/**
 * @var $title
 * @var $sub-title
 * @var $text_position
 * @var $text_align
 * @var $image 
 * @var $image_fallback
 * @var $alt
 * @var $url
 * @var $new_window
 */
?><?php 

    switch ($text_align) {
		case 'right':
			$text_alignment = 'text-align: right;';
			break;  
		case 'center':
			$text_alignment = 'text-align: center;';
			break;
		default:
			$text_alignment = 'text-align: left;';    
			break;
	}
?>

	<div class="service-wrapper <?php echo $text_align; ?> clearfix" >
<?php
	$src = siteorigin_widgets_get_attachment_image_src(
		$image,
		$size,
		$image_fallback   
	);

	$attr = array();
	if( !empty($src) ) {
		$attr = array(
			'src' => $src[0],
		);

		if(!empty($src[1])) $attr['width'] = $src[1];
		if(!empty($src[2])) $attr['height'] = $src[2];
		if (function_exists('wp_get_attachment_image_srcset')) {
			$attr['srcset'] = wp_get_attachment_image_srcset( $image,'full');
	 	}
	}  
	$attr = apply_filters( 'siteorigin_widgets_image_attr', $attr, $instance, $this );
	$classes = array('so-widget-image'); 
	?>
			<?php 
				if(!empty($title)) $attr['title'] = $title;
				if(!empty($sub_title)) $attr['sub_title'] = $sub_title;
				if(!empty($alt)) $attr['alt'] = $alt; 
			?>
		<div class="service-content <?php echo $text_position;?>">
			 	<h4><?php if(!empty($url)) : ?><a href="<?php echo sow_esc_url($url) ?>" <?php if($new_window) echo 'target="_blank"' ?>><?php endif; ?><?php echo $title;?></a></h4>
			 	<h6> <?php echo $sub_title; ?> </h6>
			 	<p><?php if(!empty($url)) : ?><a href="<?php echo sow_esc_url($url) ?>" <?php if($new_window) echo 'target="_blank"' ?>><?php endif; ?>
			 	<?php echo $alt;?></a></p>
		 	</div>
		
				<img <?php foreach($attr as $n => $v) echo $n.'="' . esc_attr($v) . '" ' ?> class="<?php echo esc_attr( implode(' ', $classes) ) ?>"/>
			
		
		
	</div>