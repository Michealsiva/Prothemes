<?php
/*
Widget Name: Trendzhop Pro: Service Offer Box
Description: Creates featured-product content section
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class TrendzhopPro_ServiceBox_Widget extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'trendzhop-pro-servicebox-widget',

			// The name of the widget for display purposes.
			__('Trendzhop Pro: Service Offer Box', 'framework'),

			array(
				'description' => __('Creates Service Offer Box section', 'framework'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/featured-product',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

	function initialize_form() {
		return array(
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Title.', 'framework' )
			),
			'sub_title' => array(
				'type'  => 'text',
				'label' => __( 'Sub Title.', 'framework' )
			),
			'image' => array( 
				'type' => 'media',
				'label' => __( 'Icon image', 'framework' ),
				'library' => 'image'
			),
			
			'text_align' => array(
				'type' => 'select',
				'label' => __('Text alignment', 'framework'),
				'default' => 'right',
				'options' => array(
					'left' => __('Left', 'framework'),
					'right' => __('Right', 'framework'),
					'center' => __('Center', 'framework'),
				),
			),
			'text_position' => array(
				'type' => 'select',
				'label' => __('Text position', 'framework'),
				'default' => 'bottom',
				'options' => array(
					'bottom' => __( 'Bottom', 'framework' ),
					'top' => __( 'Top', 'framework' ),
					'center'=>__( 'Center','framework'),
				),
			),
			'alt' => array(
				'type' => 'text',
				'label' => __('Discount Text', 'framework'),
			),

			'url' => array(
				'type' => 'link',
				'label' => __('Destination URL', 'framework'),
			),
			'new_window' => array(
				'type' => 'checkbox',
				'default' => false,
				'label' => __('Open in new window', 'framework'),
			),
		);
	}
	function get_template_variables( $instance, $args ) {  
		return array(
			'title'           => ! empty( $instance['title'] ) ? $instance['title'] : '',
			'sub_title'    => ! empty( $instance['sub_title'] ) ? $instance['sub_title'] : '',
			'image'          => ! empty( $instance['image'] ) ? $instance['image'] : '',
			'text_position' => $instance['text_position'],
			'text_align'=> $instance['text_align'],
			'alt' => $instance['alt'],
			'url' => $instance['url'],
			'new_window' => $instance['new_window'],
		);
	}
	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class TrendzhopPro_ServiceBox_Widget

siteorigin_widget_register('trendzhop-pro-servicebox-widget', __FILE__, 'TrendzhopPro_ServiceBox_Widget');