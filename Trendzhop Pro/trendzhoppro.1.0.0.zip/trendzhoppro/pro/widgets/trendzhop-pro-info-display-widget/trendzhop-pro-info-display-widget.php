<?php
/*
Widget Name: Trendzhop Pro: Info Display Widget
Description: Creates info-display content section
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class TrendzhopPro_Info_Display extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'trendzhop-pro-info-display-widget',

			// The name of the widget for display purposes.
			__('Trendzhop Pro: Info Display', 'framework'),

			array(
				'description' => __('Display Information about sites', 'framework'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/info-display',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

	function initialize_form() {
		return array(
			
			'info_data' => array(
				'type' => 'text',
				'label' => __('Information need to Display', 'framework'),
			),
			'background_color' => array(
				'type' => 'color',
				'label' => __('Background color of Information content', 'framework'),
			),
			'icon_section' => array(
				'type' => 'section',
				'label' => __( 'Icon fields.' , 'framework' ),
				'hide' => false,
				'fields' => array(
					'info_icon' => array(
						'type' => 'icon',
						'label' => __( 'Stat icon', 'framework' )
					),
					'icon_color' => array(
						'type' => 'color',
						'label' => __( 'Icon Color.', 'framework' ),
					),
					'icon_size' => array(
						'type'  => 'measurement',
						'label' => __( 'Size', 'framework' ),
					),
				),
			),
			'info_image' => array(
				'type' => 'media',
				'label' => __( 'Image for Information', 'framework' ),
				'library' => 'image'
			),
		);
	}
	function get_template_variables( $instance, $args ) {  
		$icon_styles = array();
		if( ! empty( $instance['icon_section']['icon_size'] ) ) :
			$icon_styles[] = 'font-size: ' . $instance['icon_section']['icon_size'] . ';';
		endif;
		if( ! empty( $instance['icon_section']['icon_color'] ) ) :
			$icon_styles[] = 'color:' . $instance['icon_section']['icon_color'] . ';';
		endif;

		return array(
			'info_data'    => ! empty( $instance['info_data'] ) ? $instance['info_data'] : '',
			'background' => $instance['background_color'],
			'icon' => ! empty( $instance['icon_section']['info_icon'] ) ? $instance['icon_section']['info_icon'] : '',
			'icon_styles' => $icon_styles,

			'image' => ! empty( $instance['info_image'] ) ? $instance['info_image'] : '',
		);
	}
	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class TrendzhopPro_Info_Display

siteorigin_widget_register('trendzhop-pro-info-display-widget', __FILE__, 'TrendzhopPro_Info_Display');