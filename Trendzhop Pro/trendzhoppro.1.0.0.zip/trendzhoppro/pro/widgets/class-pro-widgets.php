<?php

if ( ! class_exists( 'Trendzhop_Pro_Widgets' ) ) {

	class Trendzhop_Pro_Widgets {

	    /* Inclue All Widget folders */
	    public function Trendzhop_Pro_get_widgets_folder( $folders ) {
	    	$sow_path = WP_PLUGIN_DIR . '/so-widgets-bundle/widgets/';
			$current_settings = get_option( 'siteorigin_panels_settings', array() );
			/* if( empty($current_settings['widget_bundle_widgets']) ) {
				if( $sow_path === $folders[0] ) {
				   unset($folders[0]);    
			    }   
			} */   
			 
			$folders[] = get_template_directory() . '/pro/widgets/';
			return $folders;
		} 

	    /* Site Origin Widget Bundle Webulous widgets Group & Tab */
		public function Trendzhop_Pro_add_widgets_group($widgets) {
				$trendzhop_pro_widgets = array(
				    'TrendzhopPro_ServiceBox_Widget',
					'TrendzhopPro_Featured_Product',
					'TrendzhopPro_Latest_Product',
					'TrendzhopPro_Info_Display',
					'TrendzhopPro_BestSale_Product',
					'TrendzhopPro_Top_Rated_Product',
					'TrendzhopPro_OnSale_Product',
					'TrendzhopPro_Product_Discount'
				);
				foreach($trendzhop_pro_widgets as $trendzhop_pro_widget) {
					if( isset( $widgets[$trendzhop_pro_widget] ) ) {
						$widgets[$trendzhop_pro_widget]['groups'] = array('theme');
					}
				} 
				return $widgets;
		}   
  

		public function Trendzhop_Pro_filter_active_widgets($active){
			$active_widgets = array(
				'trendzhop-pro-servicebox-widget',
				'trendzhop-pro-featured-product-widget',
				'trendzhop-pro-latest-product-widget',
				'trendzhop-pro-top-rated-product-widget',
				'trendzhop-pro-onsale-product-widget',
				'trendzhop-pro-product-discount-widget',
				'trendzhop-pro-best-sale-product-widget',
				'trendzhop-pro-info-display-widget'
			);
			
			foreach ($active_widgets as $value ) {
			   $active[$value] = true;
			} 
		   
		   
		    return $active;
		}   

	}
	
}


