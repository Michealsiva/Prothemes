<?php
/*
Widget Name: Trendzhop Pro: Latest Product
Description: Creates latest-product content section
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class TrendzhopPro_Latest_Product extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'trendzhop-pro-latest-product-widget',

			// The name of the widget for display purposes.
			__('Trendzhop Pro: Latest Product', 'framework'),

			array(
				'description' => __('Display Latest Products', 'framework'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/latest-product',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

	function initialize_form() {
		return array(
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Title', 'framework' )
			),
			
			'select_product_type' => array(
				'type' => 'select',
				'label' => __('Select Product Type', 'framework'),
				'default' => 'all_product',
				'options' => array(
					'all_product' => __('All Product', 'framework'),
					'latest_product' => __('Latest Products', 'framework'),
				),
			),
			'latest_product_type' => array(
				'type' => 'select',
				'label' => __('Latest Product Type', 'framework'),
				'default' => 'normal',
				'options' => array(
					'normal' => __( 'Normal', 'framework' ),
					'carousel' => __( 'Carousel', 'framework' ),
				),
			),
			'latest_product_count' => array(
				'type' => 'number',
				'label' => __('Number of Latest Products to be Display', 'framework'),
			),

			'order_by' => array(
				'type' => 'select',
				'label' => __('Order By', 'framework'),
				'default' => 'date',
				'options' => array(
					'date' => __( 'Date', 'framework' ),
					'price' => __( 'Price', 'framework' ),
					'sales' => __( 'Sales', 'framework' ),
					'random' => __( 'Random', 'framework' ),
				),
			),
			'order' => array(
				'type' => 'select',
				'label' => __('Order', 'framework'),
				'default' => 'desc',
				'options' => array(
					'asc' => __( 'ASC', 'framework' ),
					'desc' => __( 'DESC', 'framework' ),
				),
			),
		);
	}
	function get_template_variables( $instance, $args ) {  
		return array(
			'title'           => ! empty( $instance['title'] ) ? $instance['title'] : '',
			'select_product_type'    => ! empty( $instance['select_product_type'] ) ? $instance['select_product_type'] : '',
			'latest_product_type'          => ! empty( $instance['latest_product_type'] ) ? $instance['latest_product_type'] : '',
			'latest_product_count' => $instance['latest_product_count'],
			'order_by'=> $instance['order_by'],
			'order' => $instance['order'],
		);
	}
	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class TrendzhopPro_Latest_Product

siteorigin_widget_register('trendzhop-pro-latest-product-widget', __FILE__, 'TrendzhopPro_Latest_Product');