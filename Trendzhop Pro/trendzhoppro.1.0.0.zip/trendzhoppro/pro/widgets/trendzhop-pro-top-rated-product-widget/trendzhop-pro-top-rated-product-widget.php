<?php
/*
Widget Name: Trendzhop Pro: Top Rated Product
Description: Creates top-rated-product content section
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class TrendzhopPro_Top_Rated_Product extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'trendzhop-pro-top-rated-product-widget',

			// The name of the widget for display purposes.
			__('Trendzhop Pro: Top Rated Product', 'framework'),

			array(
				'description' => __('Display Top Rated Products', 'framework'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/top-rated-product',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

	function initialize_form() {
		return array(
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Title', 'framework' )
			),
			'top_rated_product_type' => array(
				'type' => 'select',
				'label' => __('Top Rated Product Type', 'framework'),
				'default' => 'normal',
				'options' => array(
					'normal' => __( 'Normal', 'framework' ),
					'carousel' => __( 'Carousel', 'framework' ),
				),
			),
			'top_rated_product_count' => array(
				'type' => 'number',
				'label' => __('Number of Top Rated Products to be Display', 'framework'),
			),

			'order_by' => array(
				'type' => 'select',
				'label' => __('Order By', 'framework'),
				'default' => 'date',
				'options' => array(
					'date' => __( 'Date', 'framework' ),
					'price' => __( 'Price', 'framework' ),
					'random' => __( 'Random', 'framework' ),
				),
			),
			'order' => array(
				'type' => 'select',
				'label' => __('Order', 'framework'),
				'default' => 'desc',
				'options' => array(
					'asc' => __( 'ASC', 'framework' ),
					'desc' => __( 'DESC', 'framework' ),
				),
			),
		);
	}
	function get_template_variables( $instance, $args ) {  
		return array(
			'title'           => ! empty( $instance['title'] ) ? $instance['title'] : '',
			'top_rated_product_type'          => ! empty( $instance['top_rated_product_type'] ) ? $instance['top_rated_product_type'] : '',
			'top_rated_product_count' => $instance['top_rated_product_count'],
			'order_by'=> $instance['order_by'],
			'order' => $instance['order'],
		);
	}
	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class TrendzhopPro_Top_Rated_Product

siteorigin_widget_register('trendzhop-pro-top-rated-product-widget', __FILE__, 'TrendzhopPro_Top_Rated_Product');