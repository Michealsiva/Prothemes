<?php
/**
 * @var $title
 * @var $top_rated_product_type
 * @var $top_rated_product_count
 * @var $order_by
 * @var $order
 */ 
?> 

<?php 
if ( ! empty( $title ) ) {
	echo '<div class="entry-header"><h1 class="entry-title"><span>' . esc_html( $title ) . '</span></h1></div>'; 
}

	//WP Query args

	$query_args = array(
		'posts_per_page' => $top_rated_product_count,
		'no_found_rows'  => 1,
		'post_status'    => 'publish',
		'post_type'      => 'product',
		'meta_key'       => '_wc_average_rating',
		'meta_query'     => WC()->query->get_meta_query(),
		'tax_query'      => WC()->query->get_tax_query(),
	);
	
	
	switch ( $order_by ) {
		case 'price' :
			$query_args['meta_key'] = '_price';
			$query_args['orderby']  = 'meta_value_num';
			break;
		case 'random' :
			$query_args['orderby']  = 'rand';
			break; 
		default :
			$query_args['orderby']  = 'date';
	}

	// The Query
	$rated_query = new WP_Query( apply_filters( 'rated_query_args', $query_args) );
	switch( $top_rated_product_type ) {
		case 'normal':
			echo '<div class="top-rated-product-normal">';
			break;
		case 'carousel' :
			echo  '<div class="top-rated-product-carousel">';
			break;
		default:
			echo '<div class="top-rated-product-normal">';
			break;
	}
	
	//if ($featured_query->have_posts()) : ?>
		<ul class="slides clearfix">
			<?php 
				if ( $rated_query->have_posts() ) {
					while ( $rated_query->have_posts() ) : $rated_query->the_post();
					if($top_rated_product_type == 'normal') { ?>
						<div class="four columns">
							<div class="product-lists">
								<?php echo '<a href="' . get_the_permalink() . '" class="woocommerce-LoopProduct-link">';
								wc_get_template( 'loop/sale-flash.php' );
								echo woocommerce_get_product_thumbnail('trendzhop_pro_product_img');
								echo '</a>';
								echo '<div class="product-content">';
									echo '<h2 class="woocommerce-loop-product__title">' . get_the_title() . '</h2>';
									
									wc_get_template( 'loop/price.php' );
									woocommerce_template_loop_add_to_cart();
									echo do_shortcode( "[yith_wcwl_add_to_wishlist]" );
								echo '</div>';?>
							</div>
						</div>
					<?php } 
					else { ?>
						<li> 
							<div class="product-lists">
								<?php echo '<a href="' . get_the_permalink() . '" class="woocommerce-LoopProduct-link">';
								wc_get_template( 'loop/sale-flash.php' );
								echo woocommerce_get_product_thumbnail('trendzhop_pro_product_img');
								echo '</a>';
								echo '<div class="product-content">';
									echo '<h2 class="woocommerce-loop-product__title">' . get_the_title() . '</h2>';
									
									wc_get_template( 'loop/price.php' );
									woocommerce_template_loop_add_to_cart();
									echo do_shortcode( "[yith_wcwl_add_to_wishlist]" );
								echo '</div>';?>
							</div>
						</li>
				<?php }
					endwhile;
				} else {
					echo __( 'No products found' );
				}
				wp_reset_postdata();
			?>
		</ul><!--/.products-->
	</div>