<?php
/*
Widget Name: Trendzhop Pro: Best Sale Product
Description: Creates best-sale-product content section
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class TrendzhopPro_BestSale_Product extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'trendzhop-pro-best-sale-product-widget',

			// The name of the widget for display purposes.
			__('Trendzhop Pro: Best Sale Product', 'framework'),

			array(
				'description' => __('Display Best Sale Products', 'framework'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/best-sale-product',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

	function initialize_form() {
		return array(
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Title', 'framework' )
			),
			
			'sale_product_type' => array(
				'type' => 'select',
				'label' => __('Best Sale Product Type', 'framework'),
				'default' => 'normal',
				'options' => array(
					'normal' => __( 'Normal', 'framework' ),
					'carousel' => __( 'Carousel', 'framework' ),
				),
			),
			'sale_product_count' => array(
				'type' => 'number',
				'label' => __('Number of Products to be Display', 'framework'),
			),

			'order_by' => array(
				'type' => 'select',
				'label' => __('Order By', 'framework'),
				'default' => 'date',
				'options' => array(
					'date' => __( 'Date', 'framework' ),
					'price' => __( 'Price', 'framework' ),
					'sales' => __( 'Sales', 'framework' ),
					'random' => __( 'Random', 'framework' ),
				),
			),
			'order' => array(
				'type' => 'select',
				'label' => __('Order', 'framework'),
				'default' => 'desc',
				'options' => array(
					'asc' => __( 'ASC', 'framework' ),
					'desc' => __( 'DESC', 'framework' ),
				),
			),
		);
	}
	function get_template_variables( $instance, $args ) {  
		return array(
			'title'           => ! empty( $instance['title'] ) ? $instance['title'] : '',
			
			'sale_product_type'          => ! empty( $instance['sale_product_type'] ) ? $instance['sale_product_type'] : '',
			'sale_product_count' => $instance['sale_product_count'],
			'order_by'=> $instance['order_by'],
			'order' => $instance['order'],
		);
	}
	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class TrendzhopPro_BestSale_Product

siteorigin_widget_register('trendzhop-pro-best-sale-product-widget', __FILE__, 'TrendzhopPro_BestSale_Product');