<?php
/**
 * @var $title

 * @var $sale_product_type
 * @var $sale_product_count
 * @var $order_by
 * @var $order
 */ 
?> 

<?php 
if ( ! empty( $title ) ) {
	echo '<div class="entry-header"><h1 class="entry-title"><span>' . esc_html( $title ) . '</span></h1></div>'; 
}

	$product_visibility_term_ids = wc_get_product_visibility_term_ids();
	//WP Query args

	$query_args=array (
		'posts_per_page' => $sale_product_count,
		'post_status'    => 'publish',
		'post_type'      => 'product',
		'no_found_rows'  => 1,
		'order'          => $order,
		'meta_key' => 'total_sales',
    	'orderby' => 'meta_value_num',
    
	);

	

	switch ( $order_by ) {
		case 'price' :
			$query_args['meta_key'] = '_price';
			$query_args['orderby']  = 'meta_value_num';
			break;
		case 'random' :
			$query_args['orderby']  = 'rand';
			break; 
		case 'sales' :
			$query_args['meta_key'] = 'total_sales';
			$query_args['orderby']  = 'meta_value_num';
			break;
		default :
			$query_args['orderby']  = 'date';
	}

	// The Query
	$sale_query = new WP_Query( apply_filters( 'sale_query_args', $query_args) );
	switch( $sale_product_type ) {
		case 'normal':
			echo '<div class="sale-product-normal">';
			break;
		case 'carousel' :
			echo  '<div class="sale-product-carousel">';
			break;
		default:
			echo '<div class="sale-product-normal">';
			break;
	}
	
	//if ($sale_query->have_posts()) : ?>
		<ul class="slides clearfix">
			<?php 
				if ( $sale_query->have_posts() ) {
					while ( $sale_query->have_posts() ) : $sale_query->the_post();
					if($sale_product_type == 'normal') { ?>
						<div class="four columns">
							<div class="product-lists">
								<?php echo '<a href="' . get_the_permalink() . '" class="woocommerce-LoopProduct-link">';
								wc_get_template( 'loop/sale-flash.php' );
								echo woocommerce_get_product_thumbnail('trendzhop_pro_product_img');
								
								echo '<div class="product-content">';
									echo '<h2 class="woocommerce-loop-product__title">' . get_the_title() . '</h2>';
									
									wc_get_template( 'loop/price.php' );
									woocommerce_template_loop_add_to_cart();
									echo do_shortcode( "[yith_wcwl_add_to_wishlist]" );
								echo '</div>';
								echo '</a>';?>
							</div>
						</div>
					<?php } 
					else { ?>
						<li> 
							<div class="product-lists">
								<?php echo '<a href="' . get_the_permalink() . '" class="woocommerce-LoopProduct-link">';
								wc_get_template( 'loop/sale-flash.php' );
								echo woocommerce_get_product_thumbnail('trendzhop_pro_product_img');
								
								echo '<div class="product-content">';
									echo '<h2 class="woocommerce-loop-product__title">' . get_the_title() . '</h2>';
									
									wc_get_template( 'loop/price.php' );
									woocommerce_template_loop_add_to_cart();
									echo do_shortcode( "[yith_wcwl_add_to_wishlist]" );
								echo '</div>';
								echo '</a>';?>
							</div>
						</li>
				<?php }
					endwhile;
				} else {
					echo __( 'No products found' );
				}
				wp_reset_postdata();
			?>
		</ul><!--/.products-->
	</div>