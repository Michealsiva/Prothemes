<?php
/*
Widget Name: Trendzhop Pro: Product Discount Widget
Description: Creates product-discount content section
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class TrendzhopPro_Product_Discount extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'trendzhop-pro-product-discount-widget',

			// The name of the widget for display purposes.
			__('Trendzhop Pro: Product Discount Widget', 'framework'),

			array(
				'description' => __('Display Product Discount Widgets', 'framework'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/product-discount',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			)
         	
		);
	}
 
	function get_widget_form() {
		return $form_options = array(
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Title', 'framework' ),
			),
			'image' => array( 
				'type' => 'media',
				'label' => __( 'Discount Featured Image', 'framework' ),
				'library' => 'image',
			),
			'discount_text' => array(
				'type' => 'number',
				'label' => __('Enter the Product discount', 'framework'),
				//'options' => $this->get_aaa(),
			),
			'discount_caption' => array (
				'type' => 'text',
				'label' => __('Discount Caption','framework'), 
			),
			'discount' => array(
				'type' =>'text',
				'label' => __('Enter the word that displays after Discount Percentage','framework'),
			),
			'image_hover_color' => array(
				'type' =>'color',
				'label' => __('Image Hover Background color','framework'),
			)
		);

	}

	function get_aaa() {
		$sliders = array();
		$args    = array(
			'post_type'     => 'product',
			'posts_per_page' =>'-1',
		);
		$query   = new WP_Query( $args );
		if ( $query->have_posts() ) {   
			while ( $query->have_posts() ) {
				$query->the_post();
				$sliders[ $query->post->ID ] = $query->post->post_title;
			}
		}

 
		return $sliders;
	}

	function get_template_variables( $instance, $args ) {  
		return array(
			'title'           => ! empty( $instance['title'] ) ? $instance['title'] : '',
			'image'          => ! empty( $instance['image'] ) ? $instance['image'] : '',
			'discount_text' => ! empty( $instance['discount_text'] ) ? $instance['discount_text'] : '',
			'discount_caption' =>! empty( $instance['discount_caption'] ) ? $instance['discount_caption'] : '',
			'discount' => ! empty( $instance['discount'] ) ? $instance['discount'] : '',
			'image_hover_color' => ! empty( $instance['image_hover_color'] ) ? $instance['image_hover_color'] : '',
		);
	}
	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class TrendzhopPro_Product_Discount

siteorigin_widget_register('trendzhop-pro-product-discount-widget', __FILE__, 'TrendzhopPro_Product_Discount');