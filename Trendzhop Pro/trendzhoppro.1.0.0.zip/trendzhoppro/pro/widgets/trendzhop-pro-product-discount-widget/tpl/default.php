<?php
/**
 * @var $title
 * @var $image
 * @var $product_items
 * @var $product_items_featured
 * @var $discount_caption
 * @var $discount
 * @var $image_hover_color
 */
?>

<?php 
if ( ! empty( $title ) ) {
	echo '<div class="entry-header"><h1 class="entry-title"><span>' . esc_html( $title ) . '</span></h1></div>'; 
}
?>

<div class="product-discount-wrapper" style="background-color:<?php echo $image_hover_color;?>" >
<?php
	$src = siteorigin_widgets_get_attachment_image_src(
		$image,
		array(800,300),
		$image_fallback   
	);

	$attr = array();
	if( !empty($src) ) {
		$attr = array(
			'src' => $src[0],
		);

		if(!empty($src[1])) $attr['width'] = $src[1];
		if(!empty($src[2])) $attr['height'] = $src[2];
		if (function_exists('wp_get_attachment_image_srcset')) {
			$attr['srcset'] = wp_get_attachment_image_srcset( $image,'trendzhop_propro_blog_large_width');
	 	}
	}  
	$attr = apply_filters( 'siteorigin_widgets_image_attr', $attr, $instance, $this );
	$classes = array('so-widget-image'); 
	
	if ( !($product_items_featured ) ) { ?>
		<img <?php foreach($attr as $n => $v) echo $n.'="' . esc_attr($v) . '" ' ?> class="<?php echo esc_attr( implode(' ', $classes) ) ?>"/>
	<?php }

	else { ?>
		<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $product_items ),'trendzhop_propro_product_img' );?>
		
   		<img src="<?php  echo $image[0]; ?>">
	<?php } ?>
	<?php $product = wc_get_product( $product_items );?>


		<div class="image-cross-hover">
	        <div class="inside">
				<div class="caption-text"> <?php echo $discount_caption;?></div>
	       		
	            <?php $percentage = round( ( ( $product->regular_price - $product->sale_price ) / $product->regular_price ) * 100 ); ?>
	            <div class="inside-text">
					<span class="discount-price"><?php echo $discount_text; ?> </span>
					<span class="percentage"> % </span>
					<span class="discount-text"> <?php echo $discount;?></span>
				</div>
				
	        </div>
		</div><!-- end callout -->
	
</div>

