<?php
/*
Widget Name: Trendzhop Pro: OnSale Product
Description: Creates onsale-product content section
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class TrendzhopPro_OnSale_Product extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'trendzhop-pro-onsale-product-widget',

			// The name of the widget for display purposes.
			__('Trendzhop Pro: OnSale Product', 'framework'),

			array(
				'description' => __('Display OnSale Products', 'framework'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/onsale-product',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

	function initialize_form() {
		return array(
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Title', 'framework' )
			),
			
			'select_product_type' => array(
				'type' => 'select',
				'label' => __('Select Product Type', 'framework'),
				'default' => 'all_product',
				'options' => array(
					'all_product' => __('All Product', 'framework'),
					'onsale_product' => __('On-Sale Products', 'framework'),
				),
			),
			'onsale_product_type' => array(
				'type' => 'select',
				'label' => __('OnSale Product Type', 'framework'),
				'default' => 'normal',
				'options' => array(
					'normal' => __( 'Normal', 'framework' ),
					'carousel' => __( 'Carousel', 'framework' ),
				),
			),
			'onsale_product_count' => array(
				'type' => 'number',
				'label' => __('Number of OnSale Products to be Display', 'framework'),
			),

			'order_by' => array(
				'type' => 'select',
				'label' => __('Order By', 'framework'),
				'default' => 'date',
				'options' => array(
					'date' => __( 'Date', 'framework' ),
					'price' => __( 'Price', 'framework' ),
					'sales' => __( 'Sales', 'framework' ),
					'random' => __( 'Random', 'framework' ),
				),
			),
			'order' => array(
				'type' => 'select',
				'label' => __('Order', 'framework'),
				'default' => 'desc',
				'options' => array(
					'asc' => __( 'ASC', 'framework' ),
					'desc' => __( 'DESC', 'framework' ),
				),
			),
		);
	}
	function get_template_variables( $instance, $args ) {  
		return array(
			'title'           => ! empty( $instance['title'] ) ? $instance['title'] : '',
			'select_product_type'    => ! empty( $instance['select_product_type'] ) ? $instance['select_product_type'] : '',
			'onsale_product_type'          => ! empty( $instance['onsale_product_type'] ) ? $instance['onsale_product_type'] : '',
			'onsale_product_count' => $instance['onsale_product_count'],
			'order_by'=> $instance['order_by'],
			'order' => $instance['order'],
		);
	}
	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class TrendzhopPro_OnSale_Product

siteorigin_widget_register('trendzhop-pro-onsale-product-widget', __FILE__, 'TrendzhopPro_OnSale_Product');