<?php

/**
 * Created by venkat on 2/11/16
 */
if ( ! class_exists('Theme_Sidebars')) { 
	class Theme_Sidebars {

		protected $sidebars;

		public static $instance = null;     

		/**
		 * Theme_Sidebars constructor. 
		 */
		public function __construct() {
			$this->sidebars = array(
				'sidebar-1'    => array(
					'name'        => __( 'Sidebar', 'trendzhop_pro' ),
					'description' => __( 'Primary sidebar', 'trendzhop_pro' ),
				),
				'sidebar-left' => array(
					'name'        => __( 'Sidebar Left', 'trendzhop_pro' ),
					'description' => __( 'Left Sidebar', 'trendzhop_pro' ),
				),
				'header-menu-left' => array(
					'name'        => __( 'Menu Product List', 'trendzhop_pro' ),
					'description' => __( 'Display the Product Categories Dropdown', 'trendzhop_pro' ),
				),
				
				'top-right'    => array(
					'name'        => __( 'Top Right', 'trendzhop_pro' ),
					'description' => __( 'Widget area at top right side of the header', 'trendzhop_pro' ),
				),
				'top-left'     => array(
					'name'        => __( 'Top Left', 'trendzhop_pro' ),
					'description' => __( 'Widget area at top left side of the header', 'trendzhop_pro' ),
				),
				'footer-nav'   => array(
					'name'        => __( 'Footer Nav', 'trendzhop_pro' ),
					'description' => __( 'Widget area in bottom right side of Footer', 'trendzhop_pro' ),
				),
				'footer'       => array(
					'name'        => __( 'Footer %d', 'trendzhop_pro' ),
					'description' => __( 'One of 4 Column Footer widget area', 'trendzhop_pro' ),
					'multiple'    => true,
					'items'       => 4,
				),
			);

			add_action( 'widgets_init', array( $this, 'register' ) );  
			add_action( 'init', array($this, 'get') );
		}

		/**
		 * Get an instance of this class
		 */

		public static function getInstance() { 
			if ( self::$instance === null ) {
				self::$instance = new Theme_Sidebars();   
			}

			return self::$instance;
		}

		/**
		 * Register widget area.
		 *
		 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
		 */
		public function register() {
			foreach ( $this->sidebars as $id => $sidebar ) {
				$multiple = isset($sidebar['multiple']) ? $sidebar['multiple'] : false;
				$items =  isset($sidebar['items']) ? $sidebar['items'] : 1;
				if ( ! $multiple ) {
					register_sidebar( array(
						'name'          => $sidebar['name'],
						'id'            => $id,
						'description'   => $sidebar['description'],
						'before_widget' => '<aside id="%1$s" class="widget %2$s">',
						'after_widget'  => '</aside>',
						'before_title'  => '<h4 class="widget-title">',
						'after_title'   => '</h4>',
					) );
				} else {
					register_sidebars( $sidebar['items'], array(
						'name'          => $sidebar['name'],
						'id'            => $id,
						'description'   => $sidebar['description'],
						'before_widget' => '<aside id="%1$s" class="widget %2$s">',
						'after_widget'  => '</aside>',
						'before_title'  => '<h4 class="widget-title">',
						'after_title'   => '</h4>',
					) );
				}
			}
		}

		public static function get() {
			$default_sidebars = array();
			foreach ($GLOBALS['wp_registered_sidebars'] as $sidebar) {
				$default_sidebars[$sidebar['id']] = $sidebar['name'];
			}
			return $default_sidebars;
		}
	}
}