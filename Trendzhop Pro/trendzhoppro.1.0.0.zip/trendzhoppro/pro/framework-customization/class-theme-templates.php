<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Theme_templates' ) ) {  
	class Theme_templates {

        
	   	public function trendzhop_pro_team_member_template_file( $filename, $instance, $widget  ) {
			return get_stylesheet_directory() . '/pro/framework-customization/widgets/team-member.php';   
		}
		public function trendzhop_pro_testimonial_template_file( $filename, $instance, $widget  ) {
			return get_stylesheet_directory() . '/pro/framework-customization/widgets/testimonial.php';   
		}
		public function trendzhop_pro_recent_post_template_file( $filename, $instance, $widget  ) {
			return get_stylesheet_directory() . '/pro/framework-customization/widgets/recent-post.php';   
		}
		public function trendzhop_pro_cta_template_file( $filename, $instance, $widget  ) {
			return get_stylesheet_directory() . '/pro/framework-customization/widgets/cta.php';   
		}    
		public function trendzhop_pro_heading_template_file( $filename, $instance, $widget  ) {
			return get_stylesheet_directory() . '/pro/framework-customization/widgets/heading.php';   
		} 
		public function trendzhop_pro_icon_box_template_file( $filename, $instance, $widget  ) {
			return get_stylesheet_directory() . '/pro/framework-customization/widgets/icon-box.php';   
		} 
	}
}

         
