<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Theme_Less_File' ) ) {  
	class Theme_Less_File {
    
   /* public function trendzhop_propro_product_discount_less_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/less/product-discount.less';  
        } */
		

             
        
	}
}
