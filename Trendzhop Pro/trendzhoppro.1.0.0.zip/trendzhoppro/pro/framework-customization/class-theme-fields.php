<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'Theme_fields' ) ) {  
	class Theme_fields {
		
        /* Add Or Override the widegt fields */
        public function trendzhop_pro_extend_heading_form($form_options, $widget) {
		  $form_options['style'] = array(
		  	'type' => 'checkbox',
	        'label' => __( 'Enable Theme Default Heading Style', 'trendzhop_pro' ),
	        'default' => false
		  );  
		  return $form_options;

        } 

        public function trendzhop_pro_extend_icon_box_form($form_options, $widget) {
		  $form_options['icon_box_style2'] = array(
		  	'type' => 'checkbox',
	        'label' => __( 'Enable Theme Style2 ', 'trendzhop_pro' ),
	        'default' => false
		  );  
		  return $form_options;

        }    

	}
}

