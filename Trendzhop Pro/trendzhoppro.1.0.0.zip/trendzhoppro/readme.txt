=== TrendzhopPro ===
Contributors: Webulous
Tags: custom-menu, featured-images, post-formats, right-sidebar, left-sidebar, sticky-post, threaded-comments, translation-ready, three-columns, two-columns, one-column, flexible-header, custom-background, custom-header, custom-colors, editor-style, full-width-template, rtl-language-support, theme-options, translation-ready
Requires at least: 4.0
Tested up to: 4.8
Stable tag: 1.0.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

TrendzhopPro is a simple e-commerce WordPress Theme.
TrendzhopPro is best suited for all types of shoping sites. 

== Description == 
TrendzhopPro comes with modern, stylish and responsive design. It uses skeleton framework for grids which keeps minimal css. Stylesheet is generated using SASS and so stays DRY.
TrendzhopPro is best suited for shoping sites with added features. You can select the pages that displayed in Home with Shop special offers.and which allows your users to browse your product catalogs in easyway, add items to their shopping carts intuitively, and proceed to checkout and make payments, all right off your website. 
  
== Frequently Asked Questions == 
= Installation =
1. Download and unzip `TrendzhopPro` theme
2. Upload the `style outlet pro' folder to the `/wp-content/themes/` directory
3. Activate the Theme through the 'Themes' menu in WordPress

= Setting Up Front Page =

1. By default, your front page looks like a blog. However, you can make it look like screenshot by following these steps.
2. Goto Dashboard => Apperance => Customize
3. Click on 'Static Front Page'
4. Select 'A static page' radio option
5. Select a static page for 'Front Page' and another page for 'Posts Page'.

= How to control featured images visibility =

Goto Dashboard => Apperance => Customize. 
Use customizer options   

== Changelog ==

= 1.0.0 =
* Initial Release

== Upgrade Notice ==

= 1.0.0 =
* Initial Release

== Resources ==
* {_s}, GPLv2
* {Skeleton}, MIT
* {Flexslider} © 2015 Woo Themes, GPLv2
* {FontAwesome} © Dave Gandy, SIL OFL 1.1 and MIT   
