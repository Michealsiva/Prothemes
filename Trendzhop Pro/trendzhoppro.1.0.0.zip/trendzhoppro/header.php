<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package TrendzhopPro
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>> 
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<?php if ( is_singular() && pings_open() ) { ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>"><?php
} ?>
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>    

<div id="page" class="hfeed site <?php echo trendzhop_pro_site_style_class(); ?>">
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'trendzhop_pro' ); ?></a>
	<?php do_action('trendzhop_pro_before_header'); ?>
	<header id="masthead" class="site-header <?php echo trendzhop_pro_site_style_header_class(); ?>" role="banner">
		<?php do_action('trendzhop_pro_header_start'); ?>
		<div class="header-image">
			<?php 
			    if ( get_theme_mod ('header_overlay',false ) ) { 
					echo '<div class="overlay overlay-header"></div>';      
				} ?>
				<?php if( is_active_sidebar('top-left')  || is_active_sidebar('top-right') ) :?>
					<div class="top-nav">
						<div class="container">		
							<div class="eight columns">
								<div class="cart-left">
									<?php dynamic_sidebar('top-left' ); ?>
								</div>
							</div>

							<div class="eight columns">
								<div class="cart-right">
									<?php dynamic_sidebar('top-right' ); ?>  
								</div>
							</div>

						</div>
					</div> <!-- .top-nav -->
				<?php endif;?>
				<?php do_action('trendzhop_pro_header_navigation_before'); ?>
		<div class="branding"> 
			<div class="container">
			<?php if ( get_theme_mod ('header_search',true) ){  ?>
				<div class="eight columns">
					<div class="site-branding">
						<?php 
							$logo_title = get_theme_mod( 'logo_title' ); 
							$logo = get_theme_mod( 'logo', '' );  
							$tagline = get_theme_mod( 'tagline',true);
							if( $logo_title && function_exists( 'the_custom_logo' ) ) {
	                               the_custom_logo();  
							}elseif( $logo != '' && $logo_title ) { ?>
							   <h1 class="site-title img-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url($logo) ?>"></a></h1>
					<?php	}else { ?>
								<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
							<?php } ?>
						<?php if( $tagline ) : ?>
							<p class="site-description"><?php bloginfo( 'description' ); ?></p>
						<?php endif; ?>
					</div><!-- .site-branding -->
				</div> 
				
				<div class="eight columns header-search-box">
					<form role="search" method="get" class="search-form clearfix" action="<?php echo home_url( '/' ); ?>">
			            <span class="screen-reader-text">Search For</span>
			            <input type="search" class="search-field" placeholder="Search..." value="<?php echo esc_attr( get_search_query() ); ?>" name="s" title="Search for:" />
			            <input type="submit" class="search-submit" value="Search" />
	            
			            <?php
				            $args = array(
			                  'show_option_all'  => __( 'Any Category' ),
			                  'posts_per_page' => -1,
			                  'post_status'    => 'publish',
			                  'post_type'      => 'product',
			                  'taxonomy'      =>'product_cat',
			                  //'name'          => 'All Categories',
			                );
			             	wc_product_dropdown_categories( $args );
			            ?>
		          	</form>

				    <?php wc_enqueue_js( "
				        jQuery( '.dropdown_product_cat' ).change( function() {
				          if ( jQuery(this).val() != '' ) {
				            var this_page = '';
				            var home_url  = '" . esc_js( home_url( '/' ) ) . "';
				            if ( home_url.indexOf( '?' ) > 0 ) {
				              this_page = home_url + '&product_cat=' + jQuery(this).val();
				            } else {
				              this_page = home_url + '?product_cat=' + jQuery(this).val();
				            }
				            location.href = this_page;
				          }
				        });	
				      " );?>
				</div>

				
			<?php } else { ?> 
				<div class="sixteen columns">
					<div class="site-branding">
						<?php 
							$logo_title = get_theme_mod( 'logo_title' ); 
							$logo = get_theme_mod( 'logo', '' );  
							$tagline = get_theme_mod( 'tagline',true);
							if( $logo_title && function_exists( 'the_custom_logo' ) ) {
	                               the_custom_logo();  
							}elseif( $logo != '' && $logo_title ) { ?>
							   <h1 class="site-title img-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url($logo) ?>"></a></h1>
					<?php	}else { ?>
								<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
							<?php } ?>
						<?php if( $tagline ) : ?>
							<p class="site-description"><?php bloginfo( 'description' ); ?></p>
						<?php endif; ?>
					</div><!-- .site-branding -->
				</div> 

				
				<?php 
			} ?>
			</div>
			</div>
			</div>
			<div class="nav-wrap">
				<div class="container">
					<?php if( is_active_sidebar('header-menu-left') ){ ?>
						<div class="four columns">
							<div class="nav-left">	
								<div class="product-menu">
									<div class="product-menu-bar">
										<?php dynamic_sidebar('header-menu-left' ); ?>
									</div>
								</div>
							</div>
						</div>
						<nav id="site-navigation" class="main-navigation ten columns" role="navigation">
							<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><i class="fa fa-align-justify fa-2x" aria-hidden="true"></i></button>
							<?php wp_nav_menu( array( 'theme_location' => 'menu-1', 'menu_id' => 'primary-menu' ) ); ?>
						</nav><!-- #site-navigation -->
						<?php if ( class_exists( 'WooCommerce' ) ) : ?>
							<div class="two columns add-to-cart">
								<div class="cart-item">
									<?php global $woocommerce; ?>
									<a href="<?php echo $woocommerce->cart->get_cart_url();?>"><i class="fa fa-shopping-cart"></i></a>
									 <a class="cart-customlocation" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>">(<?php echo sprintf ( _n( '%d', '%d', WC()->cart->get_cart_contents_count() ), WC()->cart->get_cart_contents_count() ); ?> )</a>	
								</div>
							</div>
						<?php endif;?>
					<?php } else { ?>
						<nav id="site-navigation" class="main-navigation fourteen columns" role="navigation">
							<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><i class="fa fa-align-justify fa-2x" aria-hidden="true"></i></button>
							<?php wp_nav_menu( array( 'theme_location' => 'menu-1', 'menu_id' => 'primary-menu' ) ); ?>
						</nav><!-- #site-navigation -->
						<?php if ( class_exists( 'WooCommerce' ) ) : ?>
							<div class="two columns add-to-cart">
								<div class="cart-item">
									<?php global $woocommerce; ?>
									<a href="<?php echo $woocommerce->cart->get_cart_url();?>"><i class="fa fa-shopping-cart"></i></a>
									 <a class="cart-customlocation" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>">(<?php echo sprintf ( _n( '%d', '%d', WC()->cart->get_cart_contents_count() ), WC()->cart->get_cart_contents_count() ); ?> )</a>	
								</div>
							</div>
						<?php endif;?>
					<?php }?>
				</div>
			</div>
	</header><!-- #masthead -->


