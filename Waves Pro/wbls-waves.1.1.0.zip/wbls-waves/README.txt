=== Webulous Waves Pro ===
Contributors: webulous
Donate link: http://www.webulousthemes.com/
Tags: comments, spam
Requires at least: 4.0.0
Tested up to: 4.7
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin converts free version of Waves theme into pro version.

== Description ==

This plugin converts free version of Waves theme into pro version.


== Installation ==

1. Upload `wbls-waves` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. This is a screen shot

== Changelog == 
= 1.1.0 =
* Merge Custom css option to WP option


= 1.0.9 =
 * Fix Sidebar text widget issue

= 1.0.8 =
* Fix Tracking code bug
* Fix single clock demo content bug
* Compatible with site origin widget bundle

= 1.0.7 =
 * Fix readmore button style issue

= 1.0.6 =
 * Fix header-logo bug

= 1.0.5 =
 * Added More options
 * Customizer Changed to kirki 

= 1.0.4 =
* Fix License activation issue

= 1.0.3 =
* Change Update file & Enable License Key Activation 

= 1.0.2 =
* Fix Responsive style bug

= 1.0.1 =
* Added `scroll to top` button
* Change Documentation link

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.1.0 =
* Merge Custom css option to WP option