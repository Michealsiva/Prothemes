<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 4:55 PM
	 */ 
if( ! class_exists( 'Wbls_Theme_Hooks' )) {
	class Wbls_Theme_Hooks {

		public function full_width_slider(){  
			global $post; 
			remove_action('waves_before_content','waves_before_content_free',10);   
			$slider_shortcode = get_post_meta( $post->ID, '_wbls_slider_shortcode', true );
			if( $slider_shortcode != '' ) {
			 get_header('blank'); ?>
			 <div class="home-header"> 
					<?php 
					echo do_shortcode( $slider_shortcode );		
					 $breadcrumb = get_theme_mod( 'breadcrumb' ); ?>    
			      <?php if( $breadcrumb ) : ?>    
						<?php $header_bread = 'header-bread'; 
				      else:   $header_bread = '';   
				   endif;?>	
					<header id="masthead" class="site-header flex-header" role="banner">
						<div class="header-wrapper <?php echo $header_bread; ?>">
							<?php if ( get_theme_mod ('header_overlay',false ) ) { 
								   echo '<div class="overlay overlay-header"></div>';     
							} ?>
							<?php if( is_active_sidebar( 'top-left' )  || is_active_sidebar( 'top-left' ) ): ?>
								<div class="top-nav">
									<div class="container">		
									<?php if( is_active_sidebar( 'top-left' ) ) : ?>     
										<div class="ten columns">
											<div class="cart">
												<?php dynamic_sidebar('top-left' ); ?>
											</div>
										</div>
									<?php endif; ?>
									<?php if( is_active_sidebar('top-right' ) ) : ?>
										<div class="columns six">
											<div class="social">
												<?php dynamic_sidebar('top-right' ); ?>  
											</div>
										</div>
									<?php endif; ?>
									</div>
								</div> <!-- .top-nav -->
						    <?php endif;?>
						
							<div class="branding">
								<div class="container">
									<div class="six columns">    
										<nav id="site-navigation" class="main-navigation navigation-left clearfix" role="navigation">
											<h1 class="menu-toggle"><?php _e( 'Menu', 'wbls-waves' ); ?></h1>
											<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'wbls-waves' ); ?></a>
											<?php wp_nav_menu( array( 'theme_location' => 'primary-left' ) ); ?>   
										</nav><!-- #site-navigation -->
									</div>
									<div class="four columns">
										<div class="site-branding">
											<?php 
												$logo_title = get_theme_mod( 'logo_title' );
												$logo = get_theme_mod( 'logo', '' );
												$tagline = get_theme_mod( 'tagline',true);
												if( $logo_title && function_exists( 'the_custom_logo' ) ) {
						                                the_custom_logo();     
											        }elseif( $logo != '' && $logo_title ) { ?>
													   <h1 class="site-title img-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url($logo) ?>"></a></h1>
											<?php	}else { ?>
														<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
												    <?php } ?>
											<?php if( $tagline ) : ?>
													<h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
											<?php endif; ?>
										</div><!-- .site-branding -->
										
									</div>
									<div class="six columns">    
										<nav id="site-navigation-right" class="main-navigation avigation-right clearfix" role="navigation">
											<h1 class="menu-toggle"><?php _e( 'Menu', 'wbls-waves' ); ?></h1>
											<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'wbls-waves' ); ?></a>
											<?php wp_nav_menu( array( 'theme_location' => 'primary-right' ) ); ?>   
										</nav><!-- #site-navigation -->
									</div>
								</div>
							</div><!-- .branding -->
				        </div>
						<?php $breadcrumb = get_theme_mod( 'breadcrumb' ); ?>    
						<?php if( $breadcrumb ) : ?>
							<div class="breadcrumb">
								<div class="container">
									<div class="breadcrumb-left eight columns">
										<?php the_title('<h4>','</h4>');?>			
									</div>
									<div class="breadcrumb-right eight columns">
										<?php  if( function_exists('wbls_waves_breadcrumbs') ) { 
										    wbls_waves_breadcrumbs(); 
										} ?>
									</div>
								</div>
							</div>	
					    <?php endif; ?>
					</header><!-- #masthead -->
		     </div>
		   <?php
			}
			else{
				get_header();
			}
		} 
		
		public function single_portfolio($single_template){
		    global $post;
			if( $post->post_type == 'portfolio') {
				$single_template = WBLS_THEME_DIR . 'public/views/single-portfolio.php';
				if( file_exists($single_template) && is_file($single_template) ) {
					 $single_template;
				} else {
					if( defined( 'WBLS_FW_DIR' ) ) {
						$single_template = WBLS_FW_DIR . 'public/views/single-portfolio.php';	
						if( is_file($single_template) && file_exists( $single_template ) ) {
                            $single_template;
						}
					}
					
				}
			}
			return $single_template;
		}
			
		public function single_post($single_template){    
		    global $post;
		    $post_fullwidth = get_post_meta( $post->ID, '_wbls_full_width_post', true );
			if( $post->post_type == 'post') {
				if ( $post_fullwidth ){
					$single_template = WBLS_THEME_DIR . 'public/views/single-post-fullwidth.php';
				    if( file_exists($single_template) && is_file($single_template) ) {
					    $single_template;
				    } 
				}
			}
			return $single_template;
		}


		public function portfolio_views($file){        
			global $post;
		    $file = WBLS_THEME_DIR . 'public/views/' . get_post_meta( $post->ID, '_wp_page_template', true );
			return $file;
		}

		public function customizer_options($free_options) {   
			$pro_options = array(
	            // typography start //
	            'typography' => array(   
	                'priority'       => 10,
	                'title'          => __('Typography', 'wbls-waves'),
	                'description'    => __('Typography and Link Color Settings', 'wbls-waves'),
	                'sections' => array(
	                    'typography_section' => array(
	                        'title' => __('General Settings', 'wbls-waves'),
	                        'description' => __('','wbls-waves'),
	                        'fields' => array(
	                            'custom_typography' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Custom Typography', 'wbls-waves'),
	                                'description' => __('Turn on to customize typography and turn off for default typography.', 'wbls-waves'),
	                                'default' => 0,
	                            ),

	                        ),    
	                    ),

	                    'body_font' => array(
	                        'title' => __('Body Font','wbls-waves'),
	                        'description' => __('Specify the body font properties.','wbls-waves'),
	                        'fields' => array (
	                            'body' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                            ),
	                            'body_color' => array(
	                                'type' => 'color',
	                                'label' => __('Body Color', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#333'
	                            ),
	                        ),
	                    ),
	                    'h1_property' => array(
	                        'title' => __('H1 Font Properties','wbls-waves'),
	                        'description' => __('Specify the h1 font properties.','wbls-waves'),
	                        'fields' => array (
	                            'h1' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                            ),
	                            'h1_color' => array(
	                                'type' => 'color',
	                                'label' => __('H1 Color', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#333'
	                            ),
	                        ),
	                    ),
	                    'h2_property' => array(
	                        'title' => __('H2 Font Properties','wbls-waves'),
	                        'description' => __('Specify the h2 font properties.','wbls-waves'),
	                        'fields' => array (
	                                'h2' => array(
	                                    'type' => 'typography',
	                                    'label' => __('', 'wbls-waves'),
	                                    'description' => __('', 'wbls-waves'),
	                                ),
	                                'h2_color' => array(
	                                    'type' => 'color',
	                                    'label' => __('H2 Color', 'wbls-waves'),
	                                    'description' => __('', 'wbls-waves'),
	                                    'sanitize_callback' => 'sanitize_hex_color',
	                                    'transport' => 'postMessage',
	                                    'default' => '#333'
	                                )
	                        ),
	                    ),
	                    'h3_property' => array(
	                        'title' => __('H3 Font Properties','wbls-waves'),
	                        'description' => __('Specify the h3 font properties.','wbls-waves'),
	                        'fields' => array (
	                                'h3' => array(
	                                    'type' => 'typography',
	                                    'label' => __('', 'wbls-waves'),
	                                    'description' => __('', 'wbls-waves'),
	                                ),
	                                'h3_color' => array(
	                                    'type' => 'color',
	                                    'label' => __('H3 Color', 'wbls-waves'),
	                                    'description' => __('', 'wbls-waves'),
	                                    'sanitize_callback' => 'sanitize_hex_color',
	                                    'transport' => 'postMessage',
	                                    'default' => '#333'     
	                                )
	                        ),
	                    ),
	                    'h4_property' => array(
	                        'title' => __('H4 Font Properties','wbls-waves'),
	                        'description' => __('Specify the h4 font properties.','wbls-waves'),
	                        'fields' => array (
	                            'h4' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                            ),
	                            'h4_color' => array(
	                                'type' => 'color',
	                                'label' => __('H4 Color', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#333'
	                            )
	                        ),
	                    ),
	                    'h5_property' => array(
	                        'title' => __('H5 Font Properties','wbls-waves'),
	                        'description' => __('Specify the h5 font properties.','wbls-waves'),
	                        'fields' => array (
	                            'h5' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                            ),
	                            'h5_color' => array(
	                                'type' => 'color',
	                                'label' => __('H5 Color', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#333'
	                            )
	                        ),
	                    ),
	                    'h6_property' => array(
	                        'title' => __('H6 Font Properties','wbls-waves'),
	                        'description' => __('Specify the h6 font properties.','wbls-waves'),
	                        'fields' => array (
	                            'h6' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                            ),
	                            'h6_color' => array(
	                                'type' => 'color',
	                                'label' => __('H6 Color', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#333'
	                            )
	                        ),
	                    ),
	                ),
	            ), // typography panel end //

				'pro_panel' => array(
	                'priority'       => 9,
	                'title'          => __('Pro Options', 'wbls-waves'),
	                'description'    => __('Pro Options', 'wbls-waves'),
	                'sections' => array(
	                    'multiple_color_section' => array(
	                        'title' => __('Color Scheme ', 'wbls-waves'),
	                        'description' => __('Select your color scheme','wbls-waves'),
	                        'fields' => array(
	                            'color_scheme' => array(        
	                                'type' => 'select',
	                                'label' => __('Select your color scheme.', 'wbls-waves'),
	                                'description' => __(' ', 'wbls-waves'),
	                                'choices' => array(
	                                    '1' => __('Default', 'wbls-waves'),       
	                                    '2' => __('Blue', 'wbls-waves'),
	                                    '3' => __('Green', 'wbls-waves'),    
	                                    '4' => __('Pink', 'wbls-waves'),
	                                    '5' => __('Purple', 'wbls-waves'),   
	                                    '6' => __('Red', 'wbls-waves'),
	                                    '7' => __('Yellow', 'wbls-waves'),	                                 
	                                ),
	                                'default' => 1,  
                            	),                     
	                        ),
	                    ),
                       'social_network' => array(
                        'title' => __('Social Networks', 'wbls-waves'),
                        'description' => __(' Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-waves'),
                        'fields' => array(
                            'digg' => array(
                                'type' => 'text',
                                'label' => __('Digg', 'wbls-waves'), 
                                'description' => __('Your Digg link ', 'wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'dribbble' => array(
                                'type' => 'text',
                                'label' => __('Dribbble', 'wbls-waves'),
                                'description' => __('Your Dribbble link ', 'wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'facebook' => array(
                                'type' => 'text',
                                'label' => __('Facebook', 'wbls-waves'),
                                'description' => __('Your Facebook link', 'wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'twitter' => array(
                                'type' => 'text',
                                'label' => __('Twitter', 'wbls-waves'),
                                'description' => __('Your Twitter link', 'wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'google_plus' => array(
                                'type' => 'text',
                                'label' => __('Google +', 'wbls-waves'),
                                'description' => __('Your Google Plus', 'wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',

                            ),
                            'linkedin' => array(
                                'type' => 'text',
                                'label' => __('LinkedIn', 'wbls-waves'),
                                'description' => __('Your LinkedIn link', 'wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'instagram' => array(
                                'type' => 'text',
                                'label' => __('Instagram', 'wbls-waves'),
                                'description' => __('Your Instagram link ', 'wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'flickr' => array(
                                'type' => 'text',
                                'label' => __('Flickr', 'wbls-waves'),
                                'description' => __('Your Flickr link', 'wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'youtube' => array(
                                'type' => 'text',
                                'label' => __('YouTube', 'wbls-waves'),
                                'description' => __('Your YouTube link', 'wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'vimeo' => array(
                                'type' => 'text',
                                'label' => __('Vimeo', 'wbls-waves'),
                                'description' => __('Your Vimeo link', 'wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'pinterest' => array(
                                'type' => 'text',
                                'label' => __('Pinterest', 'wbls-waves'),
                                'description' => __('Your Pinterest link','wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'rss' => array(
                                'type' => 'text',
                                'label' => __('RSS', 'wbls-waves'),
                                'description' => __('Your RSS link','wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'skype' => array(
                                'type' => 'text',
                                'label' => __('Skype', 'wbls-waves'),
                                'description' => __('Your Skype link','wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'tumblr' => array(
                                'type' => 'text',
                                'label' => __('Tumblr', 'wbls-waves'),
                                'description' => __('Your Tumblr link','wbls-waves'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                        ),
                    ),

						'flex_slider_section' => array(
	                        'title' => __('Flex Slider', 'wbls-waves'),
	                        'description' => __('Flex Slider Settings','wbls-waves'),
	                        'fields' => array(
	                            'animation' => array(
	                                'type' => 'select',
	                                'label' => __('Select slider animation effect', 'wbls-waves'),
	                                'description' => __('Select slider animation effect.', 'wbls-waves'),
	                                'choices' => array(
	                                    '1' => __('Fade', 'wbls-waves'),
	                                    '2' => __('Slide', 'wbls-waves'),
	                                ),
	                                'default' => 2,
	                            ),
	                            'slide_direction' => array(
	                                'type' => 'select',
	                                'label' => __('Select direction to slide ', 'wbls-waves'),
	                                'description' => __('Select direction to slide (if you are using the "Slide" animation)', 'wbls-waves'),
	                                'choices' => array(
	                                    '1' => __('Horizontal', 'wbls-waves'),
	                                    '2' => __('Vertical', 'wbls-waves'),
	                                ),
	                                'default' => 1,
	                            ),
	                            'flexslider_slideshow_speed' => array(
	                                'type' => 'range',
	                                'label' => __('Slideshow Speed', 'wbls-waves'),
	                                'description' => __('Set the delay between each slide animation (in milliseconds)', 'wbls-waves'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 1,
	                                ),
	                                'default' => 50
	                            ),
	                            'flexslider_animation_speed' => array(
	                                'type' => 'range',
	                                'label' => __('Animation Speed', 'wbls-waves'),
	                                'description' => __('Set the duration of each slide animation (in milliseconds)', 'wbls-waves'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 1,
	                                ),
	                                'default' => 50
	                            ),
	                            'flexslider_slideshow' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Animate the slideshows automatically', 'wbls-waves'),
	                                'description' => __('Enable Animate the slideshows automatically', 'wbls-waves'),
	                                'default' => 1,
	                            ),
	                            'flexslider_smooth_height' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable to Adjust the height of the slideshow to the height of the current slide', 'wbls-waves'),
	                                'description' => __('Enable Adjust the height of the slideshow to the height of the current slide', 'wbls-waves'),
	                                'default' => 0,
	                            ),
	                            'flexslider_direction_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable  Display the "Previous/Next" Buttons', 'wbls-waves'),
	                                'description' => __('Enable  Display the "Previous/Next" Buttons', 'wbls-waves'),
	                                'default' => 1,
	                            ),
	                            'flexslider_control_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Display the slideshow pagination', 'wbls-waves'),
	                                'description' => __('Enable Display the slideshow pagination', 'wbls-waves'),
	                                'default' => 1,
	                            ),
	                            'flexslider_keyboard_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Keyboard Navigation', 'wbls-waves'),
	                                'description' => __('Enable keyboard navigation', 'wbls-waves'),
	                                'default' => 1,
	                            ),
	                            'flexslider_mousewheel_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Mouse Wheel Navigation', 'wbls-waves'),
	                                'description' => __('Enable the mousewheel navigation', 'wbls-waves'),
	                                'default' => 1,
	                            ),
	                            'flexslider_pauseplay' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Pause / Play event', 'wbls-waves'),
	                                'description' => __('Enable the "Pause/Play" event', 'wbls-waves'),
	                                'default' => 0,
	                            ),
	                            'flexslider_randomize' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Random Slides', 'wbls-waves'),
	                                'description' => __('Enable to Randomize the order of slides in slideshows', 'wbls-waves'),
	                                'default' => 0,
	                            ),
	                            'flexslider_animation_loop' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Loop Slideshow animations', 'wbls-waves'),
	                                'description' => __('Enable Loop the slideshow animations', 'wbls-waves'),
	                                'default' => 0,
	                            ),
	                            'flexslider_pause_on_action' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Pause On Action while navigation', 'wbls-waves'),
	                                'description' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation', 'wbls-waves'),
	                                'default' => 1,
	                            ),
	                            'flexslider_pause_on_hover' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Pause On Action while hovering the slides', 'wbls-waves'),
	                                'description' => __('Enable to Pause the slideshow autoplay when hovering over a slide', 'wbls-waves'),
	                                'default' => 0,
	                            ),
	                            'flexslider_prev_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Previous" button', 'wbls-waves'),
	                                'description' => __(' The text to display on the "Previous" button.', 'wbls-waves'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Prev'
	                            ),
	                            'flexslider_next_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Next" button', 'wbls-waves'),
	                                'description' => __(' The text to display on the "Next" button.', 'wbls-waves'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Next'
	                            ),
	                            'flexslider_play_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Play" button', 'wbls-waves'),
	                                'description' => __(' The text to display on the "Play" button.', 'wbls-waves'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Play'
	                            ),
	                            'flexslider_pause_text' => array(
	                                'type' => 'text',
	                                'label' => __('The text to display on the "Pause" button', 'wbls-waves'),
	                                'description' => __(' The text to display on the "Pause" button.', 'wbls-waves'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Pause'
	                            ),

	                        ),
	                    ),
						'flex_carousel' => array(
	                        'title' => __('Flex Carousel Slider', 'wbls-waves'),
	                        'description' => __('Flex Carousel Settings','wbls-waves'),
	                        'fields' => array(
	                            'carousel_animation_loop' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Loop through carousel items?', 'wbls-waves'),
	                                'default' => 0,
	                            ),
	                            'carousel_item_width' => array(
	                                'type' => 'text',
	                                'label' => __('Carousel item width', 'wbls-waves'),
	                                'default' => 230,
	                                'sanitize_callback' => 'absint'
	                            ),
	                            'carousel_item_margin' => array(
	                                'type' => 'text',
	                                'label' => __('Carousel item margin', 'wbls-waves'),
	                                'default' => 5,
	                                'sanitize_callback' => 'absint'
	                            ),
	                            'carousel_pagination' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Carousel Pagination', 'wbls-waves'),
	                                'default' => 1,

	                            ),
	                        ),
                		),
						'light_box' => array(    
	                        'title' => __('Light Box', 'wbls-waves'),
	                        'description' => __('Light Box Settings ','wbls-waves'),
	                        'fields' => array(
	                            'lightbox_theme' => array(
	                                'type' => 'select',
	                                'label' => __('Lightbox Theme', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                                'choices' => array(
	                                    '1' => __('pp_default', 'wbls-waves'),
	                                    '2' => __('light-rounded', 'wbls-waves'),
	                                    '3' => __('dark-rounded', 'wbls-waves'),
	                                    '4' => __('light-square', 'wbls-waves'),
	                                    '5' => __('dark-square', 'wbls-waves'),
	                                    '6' => __('facebook', 'wbls-waves'),
	                                ),
	                                'default' => '1',
	                            ),
	                            'lightbox_animation_speed' => array(
	                                'type' => 'select',
	                                'label' => __('Animation Speed', 'wbls-waves'),
	                                'description' => __('', 'wbls-waves'),
	                                'choices' => array(
	                                    'fast' => __('Fast', 'wbls-waves'),
	                                    'slow' => __('Slow', 'wbls-waves'),
	                                    'normal' => __('Normal', 'wbls-waves'),
	                                ),
	                                'default' => 'fast',
	                            ),
	                            'lightbox_slideshow' => array( 
	                                'type' => 'range',
	                                'label' => __('Autoplay Gallery Speed', 'wbls-waves'),
	                                'description' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)', 'wbls-waves'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 10,
	                                ),
	                                'default' => 50,
	                            ),
	                            'lightbox_autoplay_slideshow' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Autoplay Gallery', 'wbls-waves'),
	                                'description' => __('Check to autoplay the lightbox gallery', 'wbls-waves'),
	                                'default' => 0,
	                            ),
	                            'lightbox_opacity' => array(
	                                'type' => 'range',
	                                'label' => __('Select Background Opacity', 'wbls-waves'),
	                                'description' => __('Enter 0.1 to 1.0', 'wbls-waves'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 1,
	                                    'step' => 0.1
	                                ),
	                                'default' => 0.5
	                            ),
	                           /* 'lightbox_show_title' => array( 
	                                'type' => 'checkbox',
	                                'label' => __('Check to show  visibility of the title', 'wbls-waves'),
	                                'description' => __('Select visibility of the title', 'wbls-waves'),
	                                'default' => 1,
	                            ),*/
	                            'lightbox_overlay_gallery' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Show Gallery Thumbnails', 'wbls-waves'),
	                                'description' => __('Check to show gallery thumbnails', 'wbls-waves'),
	                                'default' => 1,
	                            ),
	                          /*  'lightbox_social_tools' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Show social sharing icons', 'wbls-waves'),
	                                'description' => __('Check to show social sharing icons', 'wbls-waves'),
	                                'default' => 1,
	                            ),*/

	                        ),
                		),
						'analytics_section' => array(
	                        'title' => __('Tracking Code', 'wbls-waves'),
	                        'description' => __('Tracking Code','wbls-waves'),
	                        'fields' => array(
		                        'analytics' => array(
	                                'type' => 'textarea',
	                                'label' => __('Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-waves'),
	                                'description' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-waves'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                            ),
	                            'analytics_place' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable to Load Tracking Code in Footer', 'wbls-waves'),
	                                'description' => __('Check to load analytics in footer. Uncheck to load in header.', 'wbls-waves'),
	                                'default' => 0,  
	                            ),                   
	                        ),
	                    ),
                       'custom_js_section' => array(
	                        'title' => __(' Custom Js', 'wbls-waves'),
	                        'description' => __('Custom Js','wbls-waves'),
	                        'fields' => array(
		                        'custom_js' => array(
	                                'type' => 'textarea',
	                                'label' => __('Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-waves'),
	                                'description' => __('','wbls-waves'),
	                                'sanitize_callback' => 'sanitize_text_field',  
                            	),                   
	                        ),
	                    ),
	                    'custom_css_section' => array(
	                        'title' => __(' Custom CSS', 'wbls-waves'),
	                        'description' => __('Custom CSS','wbls-waves'),
	                        'fields' => array(
		                        'custom_css' => array(
	                                'type' => 'textarea',
	                                'label' => __('Custom CSS: Quickly add some CSS to your theme by adding it to this block.', 'wbls-waves'),
	                                'description' => __('','wbls-waves'),
	                                'sanitize_callback' => 'sanitize_text_field',
                                ),                   
	                        ),
	                    ),

					),
				),


    		); // pro theme option end //

			$options = array_merge($free_options, $pro_options);
			return $options;

		}
	}
}