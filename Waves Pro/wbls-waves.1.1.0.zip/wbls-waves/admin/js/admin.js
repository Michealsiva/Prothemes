(function( $ ) {

	$(function() {

		docs = $('<a class="waves-docs doc"></a>')
			.attr('href','http://www.webulousthemes.com/waves-pro/') 
			.attr('target','_blank')
			.text('Documentation');

		support = $('<a class="waves-docs question"></a>')
			.attr('href','http://www.webulousthemes.com/support-ticket/')
			.attr('target','_blank')
			.text('Ask a Question');

		$('#customize-info .preview-notice').append(docs);
		$('#customize-info .preview-notice').append(support);

		$('.waves-docs').on('click',function(e){
			e.stopPropagation();
		});
		
		
	});

})( jQuery );
