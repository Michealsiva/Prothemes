<?php
/**
 * Pro customizer options     
 */

add_action('wbls-waves_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() {    

// pro home page section 

		Waves_Kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-waves' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-waves'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) );

		Waves_Kirki::add_field( 'waves', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-waves' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch',
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
				'off' => esc_attr__( 'Disable', 'wbls-waves' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-waves'),
			'default'  => 'off',
		) );
		Waves_Kirki::add_field( 'waves', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-waves' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-waves'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-waves'),
		) );

//  animation section 

Waves_Kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-waves' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-waves'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-waves' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Waves_Kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-waves' ),
	'description'    => __( 'Custom JS', 'wbls-waves'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Waves_Kirki::add_field( 'waves', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-waves' ),
	'section'  => 'custom_js_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
) ); 



// Tracking section 

Waves_Kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-waves' ),
	'description'    => __( 'Tracking Code', 'wbls-waves'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'analytics',
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-waves' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-waves' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'2' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-waves'),
) );

// color scheme section 

Waves_Kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-waves' ),
	'description'    => __( 'Select your color scheme', 'wbls-waves'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'color_scheme',
	'label'    => __( 'Select your color scheme', 'wbls-waves' ),
	'section'  => 'multiple_color_section',
	'type'     => 'palette',
	'choices'     => array(
    '1' => array(
		'#1fb2e2',
	),
	'2' => array(
		'#4c89db',
	),
	'3' => array(
		'#7ead16',
	),
	'4' => array(
		'#db4678',
	),
	'5' => array(
		'#855bce',
	),
	'6' => array(
		'#e44647',
	),
	'7' => array(
		'#ec8e06',
	),
),
'default' => '1',
//'default'  => 'on',
) );


//Social Network URL Section
Waves_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-waves' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-waves'),
	'panel'			 => 'social_panel',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-waves' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-waves'),
) );

// flexslider section //

Waves_Kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-waves' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-waves'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-waves' ),
		'2' => esc_attr__( 'Slide', 'wbls-waves' )
	),
	'default'  => '2',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-waves' ),
		'2' => esc_attr__( 'Vertical', 'wbls-waves' )
	),
	'default'  => '1',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => 'on',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => 'on',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => 'on',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => 'on',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => 'off',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => 'off',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => 'off',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'off' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-waves' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Waves_Kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-waves' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-waves'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-waves' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'2' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => '2',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-waves' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-waves' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-waves' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'2' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => '2',
) );

//  portfolio settings //

Waves_Kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-waves' ),
) );

$post_per_page = get_option('posts_per_page');
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-waves' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-waves' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-waves' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-waves' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-waves'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-waves' ),
		2 => __( 'Show Without "All"', 'wbls-waves' ),
		3 => __( 'Hide', 'wbls-waves' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Waves_Kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-waves' ),
	'description'    => __( 'Light Box Settings', 'wbls-waves'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-waves' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-waves' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-waves' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-waves' ),
		'4' => esc_attr__( 'light-square', 'wbls-waves' ),
		'5' => esc_attr__( 'dark-square', 'wbls-waves' ),
		'6' => esc_attr__( 'facebook', 'wbls-waves' ),
	),
	'default'  => '1',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-waves' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-waves' ),
		'slow' => esc_attr__( 'Slow', 'wbls-waves' ),
		'normal' => esc_attr__( 'Normal', 'wbls-waves' ),
	),
	'default'  => 'fast',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-waves' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-waves' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'2' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => '2',
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-waves' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-waves'),
) );
Waves_Kirki::add_field( 'waves', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-waves' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-waves' ),
		'2' => esc_attr__( 'Disable', 'wbls-waves' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#1fb2e2',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'input[type="text"]:focus,ul.filter-options li a,.services-wrapper .service img,.services-wrapper .service span::after,ul.filter-options li a:hover:before, ul.filter-options li .selected:before,.nav-links .nav-previous:hover a:after,.nav-links .nav-next:hover a:after,
.more-link .nav-next:hover a:after,.flexcarousel-white .widget_flexslider-widget .flex-direction-nav a:hover:after,.portfolio-excerpt .more-link:before,.tabs-container div,.comment-navigation .nav-next:hover a:after,
.more-link .nav-previous:hover a:after,.left-sidebar .dropcap-book,blockquote:after,.tabs-container ul.tabs li a,.comment-navigation .nav-previous:hover a:after,
input[type="email"]:focus,.free-home .post-wrapper .latest-post .btn-readmore:hover:before,.flexslider .flex-caption a,.flexslider .flex-caption a:before,
input[type="url"]:focus,ol.webulous_page_navi .bpn-next-link a:after, ol.webulous_page_navi .bpn-prev-link a:after,
input[type="password"]:focus,.btn:before,.widget_recent-work-widget ul.filter-options li a:hover:before, .widget_recent-work-widget ul.filter-options li .selected:before,.widget_recent-work-widget ul.filter-options li a,.free-home .services-wrapper .service img,.tabs-container ul.tabs .ui-tabs-active a:before,
input[type="search"]:focus,.flex-direction-nav a:hover:after,.page-template-blog-fullwidth .hentry.post .entry-title:after, .page-template-blog-large .hentry.post .entry-title:after, .page-template-blog-small .hentry.post .entry-title:after, .single-post .hentry.post .entry-title:after,
textarea:focus,.free-home .services-wrapper .service span:after,.btn:before,.pullright:after,
.pullleft:after,.portfolio-excerpt .more-link::before,.toggle .toggle-content,.circle-icon-box .circle-icon-wrapper .fa-stack i:after,.icon-left .fa-stack i::after, .icon-top .fa-stack i::after, .icon-right .fa-stack i::after,
.pullnone:after,.tabs ul li a.tabulous_active::before, .tabs ul li a:hover::before,.tabs.normal .tabs_container, .tabs .tabs_container,.tabs ul li a.tabulous_,.circle-icon-box .circle-icon-wrapper .fa-stack i,.icon-polygon .circle-icon-wrapper h3.fa-stack,
.icon-polygon .circle-icon-wrapper h3.fa-stack:before,.callout-widget a:before, .icon-horizontal .fa-stack i,
.icon-vertical .fa-stack i,.tabs.normal ul li a, .tabs ul li a,.widget-area h4.widget-title::after, .widget-area h3.widget-title::after,.icon-horizontal .fa-stack i:after,.widget-area h4.widget-title:after,
.icon-vertical .fa-stack i:after,.widget_image-box-widget .image-box img,.site-footer .widget_tag_cloud a,
.icon-polygon .circle-icon-wrapper h3.fa-stack:after,.wide-pattern-black .widget_testimonial-widget .flex-direction-nav a:hover:after,
.widget_button-widget a.btn.btn-default:before,.ui-accordion .ui-accordion-content,.home.blog .hentry.post .entry-title::after, .single-post .hentry.post .entry-title::after,.post-wrapper .latest-post .btn-readmore:hover::before',
			'property' => 'border-color',
		),
		array(
			'element'  =>'.stat-white .widget_stat-widget .stat::after',
			'property' =>'border-color',
			'suffix'   =>'!important',
		),
		array(
			'element'  => '.tabs-container ul.tabs li:first-child:after,.withtip.left:after,.icon-polygon .circle-icon-wrapper h3.fa-stack',
			'property' => 'border-left-color',
		),
		array(
			'element'  => ' .tabs-container ul.tabs:after,.withtip.right:after,.icon-polygon .circle-icon-wrapper h3.fa-stack',
			'property' => 'border-right-color',
		),
		array(
			'element'  => '.sep:after,.withtip.top:after 
',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '.withtip.bottom:after,.widget-area h4.widget-title,.widget-area h4.widget-title, .widget-area h3.widget-title',
			'property' => 'border-bottom-color',
		),
		array(
			'element'  => 'a,.main-navigation ul ul a,.widget-area ul li a:hover,.site-info .widget_nav_menu a:hover,.site-info p a,.widget_calendar table th a,.widget-area .widget_rss a,.widget_calendar table td a,
#secondary #recentcomments a,.main-navigation .current_page_item,.widget_list-widget ul li .fa, .widget_list-widget ol li .fa,
.main-navigation .current-menu-item,.widget_testimonial-widget ul li p.client,.widget_recent-posts-widget .entry-meta span:hover i, .widget_recent-posts-widget .entry-meta span:hover a,
.main-navigation .current_page_ancestor,.main-navigation .current_page_item > a,.widget_recent-posts-widget .entry-meta span:hover,
.main-navigation .current-menu-item > a,.circle-icon-box:hover h4,.widget_recent-posts-widget h4 a:hover,#secondary .btn-white:hover,
#secondary .widget_button-widget .btn.white:hover,.site-footer .footer-widgets a:hover,.site-footer .widget_recent-posts-widget li .recent-post:hover h4 a,
.main-navigation .current_page_ancestor > a,.main-navigation .sub-menu .current_page_item,.site-footer .footer-bottom ul.menu li a:hover,
.main-navigation .sub-menu .current-menu-item,.woocommerce #content table.cart a.remove,.left-sidebar .widget_social-networks-widget ul li a:hover i,.contact-info .textwidget a:hover, .contact-info p a:hover,.site-footer .icon-horizontal .icon-title,
.site-footer .icon-vertical .icon-title,.site-footer .widget_list-widget ul li i,.site-footer .widget_testimonial-widget ul li .client,
.circle-icon-box:hover a.link-title,.site-footer .widget.widget_ourteam-widget:hover .team-content h4,
.main-navigation .sub-menu .current_page_ancestor,.main-navigation ul.nav-menu > li a:hover ,.site-footer .footer-widgets #calendar_wrap a,
.main-navigation .children .current_page_item,.main-navigation .sub-menu li a:hover, .main-navigation .children li a:hover,
.main-navigation .children-menu .current-menu-item,.hentry.post h1 a:hover,.entry-meta span:hover i,
.main-navigation .children-menu .current_page_ancestor,.main-navigation .sub-menu .current_page_item > a,
.main-navigation .sub-menu .current-menu-item > a,.services-wrapper .service:hover h4,.breadcrumb a,.nav-links .nav-previous:hover a .meta-nav,.entry-footer span:hover i,
.more-link .nav-previous:hover a .meta-nav, .comment-navigation .nav-previous:hover a .meta-nav,.comment-metadata a:hover,
.main-navigation .sub-menu .current_page_ancestor > a,.alert-message a:hover,.widget_recent-work-widget .portfolioeffects .content-details h3 a:hover, .widget_recent-work-widget .work .content-details h3 a:hover,.page-links a ,.free-home .post-wrapper .latest-post h3 a:hover,.top-nav .social ul li:hover a,ol.comment-list .reply:before,
.main-navigation .children .current_page_item > a,.order-total .amount,.widget.widget_ourteam-widget .team-social ul li a:hover,
.cart-subtotal .amount,.nav-links .nav-next:hover a .meta-nav,ol.comment-list article .fn ,
.more-link .nav-next:hover a .meta-nav, .comment-navigation .nav-next:hover a .meta-nav,.entry-meta span:hover a,ul#portfolio li h3 a:hover,
.main-navigation .children .current-menu-item > a,.post-wrapper .latest-post .entry-meta span:hover i, .post-wrapper .latest-post .entry-meta span:hover a,.left-sidebar .icon-horizontal .icon-title,
.left-sidebar .icon-vertical .icon-title,.left-sidebar .dropcap,#secondary .left-sidebar .widget.widget_ourteam-widget .team-content h4,.portfolioeffects .content-details h3 a:hover,.portfolioeffects .overlay_icon a:hover i ,
.entry-footer span:hover a,.branding .site-branding a:hover,.single-post .edit-link:hover,.left-sidebar .widget_recent-posts-widget .flex-recent-posts li a ,.left-sidebar .widget_list-widget ul li i,.page-template-blog-large .edit-link:hover,
.main-navigation .children .current_page_ancestor > a,.post-wrapper .latest-post .entry-meta span:hover,.post-wrapper .latest-post h3 a:hover,.free-home .post-wrapper .latest-post .entry-meta span:hover i, .free-home .post-wrapper .latest-post .entry-meta span:hover a,.free-home .post-wrapper .latest-post .entry-meta span:hover,.free-home .services-wrapper .service:hover h4',
			'property' => 'color',
		),
		/*array(
			'element'  => 'th a,
							.site-header .social .recentcomments a,
							.header-wrap .site-header .social .recentcomments a,
							.left-sidebar .recentcomments a,
							.left-sidebar .widget_rss a,
							.ei-title h3,
							#secondary .btn-white:hover,
			  				#secondary .widget_button-widget .btn.white:hover',
			'property' => 'color',
			'suffix' => '!important',
		),*/
		array(
			'element'  => '.nav-wrap,.free-home .post-wrapper .latest-post .btn-readmore:hover,.woocommerce #content input.button:hover,
.left-sidebar .dropcap-circle,.ui-accordion h3,.ui-accordion h3 span,.flexslider .flex-caption a,
.left-sidebar .dropcap-box,.left-sidebar .widget.widget_skill-widget .skill-container .skill-percentage,
.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
.left-sidebar .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,
.site-footer .icon-horizontal .fa-stack,.portfolio-excerpt .more-link,
.site-footer .icon-vertical .fa-stack,.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-prev,
.site-footer .widget.widget_recent-work-widget ul.flex-direction-nav li a.flex-next,
.pullright,.home.blog .hentry.post .entry-title::before, .single-post .hentry.post .entry-title::before,
.pullleft,.circle-icon-box .circle-icon-wrapper .fa-stack i,ul.filter-options li a:hover, ul.filter-options li .selected,
.pullnone,.circle-icon-box:hover a.more-button,.post-wrapper .latest-post .btn-readmore:hover,
.tabs-container ul.tabs li a:hover,.ui-accordion .ui-accordion-header-active,
.main-navigation ul ul li,.free-home .services-wrapper .service .demo-thumb ,.slicknav_menu a:hover,.nav-links .nav-previous:hover a,
.more-link .nav-previous:hover a,blockquote,.page-template-blog-fullwidth .hentry.post .entry-title:before, .page-template-blog-large .hentry.post .entry-title:before, .page-template-blog-small .hentry.post .entry-title:before, .single-post .hentry.post .entry-title:before ,
.page-template-blog-fullwidth .more-link,.btn,.dropcap-circle,.withtip:before,.circle-icon-box:hover .circle-icon-wrapper .fa-stack i ,
.callout-widget a,.wide-pattern-black .widget_testimonial-widget .flex-direction-nav a:hover,.contact-form input[type="submit"],
.dropcap-box,.icon-left .fa-stack i, .icon-top .fa-stack i, .icon-right .fa-stack i,.dropcap-book,.toggle .toggle-title,.toggle .toggle-title .fa,.circle-icon-box a.more-button:hover,
.widget_button-widget a.btn.btn-default,.flex-direction-nav a:hover,.flexcarousel-white .widget_flexslider-widget .flex-direction-nav a:hover,.site-footer .widget_tag_cloud a:hover,
.left-sidebar .icon-horizontal .fa-stack,.widget_tag_cloud a,.widget_recent-work-widget ul.filter-options li a:hover, .widget_recent-work-widget ul.filter-options li .selected,
.left-sidebar .icon-vertical .fa-stack,.icon-horizontal .fa-stack i,.widget.widget_skill-widget .skill-container .skill,
.icon-vertical .fa-stack i,.share-box ul li a:hover,.widget_image-box-widget a.more-button,.wide-pattern-black .widget_testimonial-widget .flex-direction-nav a:hover,.page-template-blog-large .more-link, .page-template-blog-small .more-link, .single-post .more-link,
.comment-navigation .nav-previous:hover a,.top-nav ul li:hover a,.tabs-container ul.tabs .ui-tabs-active a,.nav-links .nav-next:hover a,
.more-link .nav-next:hover a,.tabs.normal ul::before, .tabs ul::before,.hentry.sticky,ol.webulous_page_navi li.bpn-current, ol.webulous_page_navi .bpn-next-link a, ol.webulous_page_navi .bpn-prev-link a,ol.webulous_page_navi li a:hover,.comment-navigation .nav-next:hover a,a.more-link:hover,a.more-link:hover .meta-nav,
.site-footer .scroll-to-top',
			'property' => 'background-color',
		),
		array(
			'element'  => '.stat-white .widget_stat-widget .stat,.tabs ul li a.tabulous_active, .tabs ul li a:hover',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
) );

/*Waves_Kirki::add_field( 'waves', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-waves' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#222222',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.site-content .navigation a,
							.site-content .more-link,
							.site-content .comment-navigation a,
							.webulous_page_navi li.bpn-current,
							.header-wrap .social ul li a,
							.comment-list > li article .comment-meta .comment-author b:hover,
							.comment-list > li article .comment-meta .comment-author a:hover,
							.comment-list > li article .comment-meta .comment-author cite:hover,
							.comment-list > li article .reply:hover i,
							#primary .sticky .entry-meta a,
					  		#primary .sticky .entry-footer a,
					  		.latest-post-content a.btn-readmore,
					  		.related-posts ul#webulous-related-posts li:hover a,
					  		.site-footer .footer-widgets .widget_archive select,
						    .site-footer .footer-widgets .widget_categories select,
						    .site-footer .footer-widgets .textwidget select,
						    .widget.widget_ourteam-widget .team-content h4 span,
						    .widget_recent-posts-widget .recent-post .readmore a,
						    .alert-message a,
						    .icon-right .icon-title,
							.icon-left .icon-title,
							.icon-right a.link-title,
							.icon-right .icon-title,
							.icon-right .fa-stack,
							.icon-left a.link-title,
							.icon-left .icon-title,
							.icon-left .fa-stack,
							.widget_testimonial-widget ul li .client,
							.single-portfolio .one-third dd a:hover,
							.waves-process.white-bg,
			  				.waves-process.white-bg h3.widget-title,
			  				.waves-process.white-bg .textwidget h4,
			  				.not-found-inner a:hover,
			  				.cnt-address .widget_text p:nth-of-type(1),
							.cnt-address .textwidget p:nth-of-type(1),
							#secondary.sidebar .widget_testimonial-widget h3',
			'property' => 'color',
		),
		array(
			'element' => 'table tr th:hover a,
			  				.site-header .social .recentcomments a:hover	
							.header-wrap .site-header .social .recentcomments a:hover,
							#primary .sticky a:hover,
							#primary .sticky span:hover,
							#primary .sticky time:hover,
							.left-sidebar .recentcomments a:hover,
							.left-sidebar .widget_rss a:hover,
							.wide-cta .call-btn a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),
		array(
			'element' => 'button:hover,
							input[type="button"]:hover,
							input[type="reset"]:hover,
							input[type="submit"]:hover,
							.footer-widgets .textwidget .wpcf7-form input.wpcf7-submit:hover,
							#nav-wrap,
							.main-navigation ul ul li,
							.site-content .more-link:hover,
							.webulous_page_navi li a,
							.webulous_page_navi li.bpn-next-link a,
			  				.webulous_page_navi li.bpn-prev-link a,
			  				.home .flexslider .slides .flex-caption a:hover,
			      			.home .flexslider .slides .flex-caption p a:hover,
			      			.home .flexslider .flex-control-paging li a,
			      			.share-box ul li a,
			      			.site-footer .widget_social-networks-widget ul li a:hover,
			      			#secondary select,
							.footer-widgets select,
							.widget.widget_ourteam-widget ul.team-social li a,
							.widget.widget_ourteam-widget:hover .team-social ul li a:hover,
							.widget.widget_skill-widget .skill-container .skill .skill-percentage,
							.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link,
							.widget_recent-work-widget .portfolio4col .overlay_icon a,
							#filters ul.filter-options li a:hover,
						    #filters ul.filter-options li a.selected,
						    .recent-work-container .recent_work_overlay a.icon-zoom,
						    .portfolioeffects .portfolio_link_icons a,
						    .flexslider .slides .flex-caption a:hover,
			      			.flexslider .slides .flex-caption p a:hover,
			      			.flexslider .flex-control-paging li a,
			      			.widget_recent-work-widget ul.flex-direction-nav a:hover,
			      			.widget_recent-posts-widget .recent-posts-carousel ul.flex-direction-nav a:hover,
			      			.recent-posts-slider .flex-direction-nav a:hover,
			      			.widget_recent-posts-widget .recent-posts-carousel .flex-control-nav li a,
			      			.recent-posts-slider .flex-control-paging li a,
			      			.flex-control-nav li a,
			      			.wide-default .widget_flexslider-widget .flexcarousel .flex-direction-nav a:hover,
			      			.page-slider ul.ei-slider-thumbs li a,
			      			a.btn-white:hover,
			  				.widget_button-widget .btn.white:hover,
			  				.toggle .toggle-title:hover,
			  				.circle-icon-box:hover .circle-icon-wrapper,
			  				.callout-widget .call-btn a,
			  				.wide-dark-grey .callout-widget p.call-btn a:hover,
			  				.widget_wbls-image-widget .image-widget-overlay:hover i:hover,
			  				.error-404.not-found .page-header,
			  				.cnt-form .wpcf7-form input[type="submit"]:hover,
			  				.site-footer .widget_social-networks-widget ul li a,
			  				#secondary.sidebar .callout-widget p.call-btn a:hover',
			'property' => 'background-color',
		),
        array(
			'element' => '.slicknav_menu,
				          .search-form input.search-submit:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element' => '.page-numbers,
				         .waves-process.white-bg .textwidget img',  
			'property' => 'border-color',
		),
		array(
			'element' => '.site-content .nav-next a span,
							.withtip.left:after,
							.home .flexslider .slides .flex-caption a:after,
			      			.home .flexslider .slides .flex-caption p a:after,
			      			.home .flexslider .flex-direction-nav .flex-nav-next a,
			      			#filters ul.filter-options li a:hover:before,
			        		#filters ul.filter-options li a.selected:before,
			        		.flexslider .slides .flex-caption a:after,
			      			.flexslider .slides .flex-caption p a:after,
			      			.flexslider .flex-direction-nav .flex-nav-next a,
			      			.widget_button-widget .btn.white:hover:after,
			      			.callout-widget .call-btn a:after,
			      			.wide-dark-grey .callout-widget p.call-btn a:hover:after,
			      			.widget_testimonial-widget .flex-direction-nav a.flex-next:hover',
			'property' => 'border-left-color',
		),
		array(
			'element' => 'abbr,acronym,.withtip.bottom:after',
			'property' => 'border-bottom-color',
		),
        array(
			'element' => '.withtip.right:after,.page-numbers:last-child,
			      			.site-content .nav-previous a span,
			      			.home .flexslider .flex-direction-nav .flex-nav-prev a,
			      			.flexslider .flex-direction-nav .flex-nav-prev a,
			      			a.btn-white:hover:before,
			    			.widget_button-widget .btn.white:hover:before,
			    			.callout-widget .call-btn a:before,
			    			.wide-dark-grey .callout-widget p.call-btn a:hover:before,
			    			.widget_testimonial-widget .flex-direction-nav a.flex-prev:hover',
			'property' => 'border-right-color',
		),
        array(
			'element' => '.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link:after',
			'property' => 'border-top-color',
		),
		array(
			'element' => '.site-footer .widget_social-networks-widget ul li a:after',
			'property' => 'border-top-color',
			'suffix' => '!important',
		),
		
	),
) );*/

Waves_Kirki::add_field( 'waves', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'wbls-waves' ),
	'tooltip' => __('Select how far from top, Default value top = 10 ( in % )','wbls-waves'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '10',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'top',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
}

