<div class="free-home">
    <div class="services-wrapper clearfix">
         <div class="service">
            <div class="service-featured">
    	    	<?php if( has_post_thumbnail() ) : ?>
                    <span><a href="<?php echo esc_url( get_permalink() ); ?>">        <?php the_post_thumbnail('waves_recent_page_img'); ?></a></span>
    	    	<?php endif; ?>  
        	</div>
        	<div class="service-content">
        	    <?php the_title( sprintf( '<h4><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' ); ?>
    	    	<?php the_content(); ?>
        	</div>
        </div>
    </div>
</div>

