<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts
 *
 * @param $layouts
 */
if (!function_exists('wbls_waves_prebuilt_page_layouts') ) {   
function wbls_waves_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-waves'),
    'description' => __('Pre Built Layout for  home page', 'wbls-waves'),
    'widgets' =>  array(
          0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'we are creative agency',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'c083515b-d1a3-4e65-b5cf-c2b0e1178148',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'type' => 'circle',
            'title' => ' Responsive Layout',
            'text' => 'Waves  is fully Responsive and can adapt to any screen size. Resize your browser window to view it!',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '883eb6d5-f84e-4490-b0ff-b3782232046d',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'type' => 'circle',
            'title' => 'SOCIAL MEDIA',
            'text' => 'Want your users to stay in touch? No problem,Waves has Social Media icons all throughout the theme!',
            'icon' => 'fa-skype',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => 'ed954535-3153-4417-a2c4-a91602aa25ca',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'type' => 'circle',
            'title' => 'CUSTOMIZATION',
            'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
            'icon' => 'fa-cog',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '3fde51fb-7c81-4473-8a8d-f26c519b1ea9',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'src' => 'http://waves.webulous.in/wp-content/uploads/2016/09/lady.png',
            'href' => 'http://waves.webulous.in/wp-content/uploads/2016/09/lady.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => 'd63752aa-6f7f-45e9-a8a2-89581d6a7907',
              'style' => 
              array (
                'class' => 'home-image',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'head-para',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => 'home-image-row',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '0px',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '57cd43102ade5',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '0bcaf83f-c048-4f30-80fd-9dcc5cc57d9a',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'our testimonials',
            'text' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'white-head-text head-para',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Testimonials',
            'count' => '4',
            'panels_info' => 
            array (
              'class' => 'Wbls_Testimonial_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '56bd81efbc37d',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'd3ef23fa-bfbe-4e39-94cb-88c071243faf',
        'style' => 
        array (
          'class' => 'grid-margin',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'our portfolio',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'ccf9e50d-98af-46d8-b613-b7127d78f398',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Recent Work',
            'count' => '8',
            'type' => 'isotope',
            'panels_info' => 
            array (
              'class' => 'Wbls_Recent_Work_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '4741373b-bcae-43a4-88f8-292a270861a0',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'head-para',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '57cd43102ae73',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '40c1edee-8d85-4660-853a-19092ee408ca',
        'style' => 
        array (
          'class' => 'grid-margin',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '335',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '0c4b12ad-be3d-4608-9f8d-c631ed7c8294',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '334',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'af92c022-fa8c-4b75-ade3-6990a7a556b0',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '333',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => 'ab959598-be64-4070-b6f6-0223489ea3cf',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '332',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'widget_id' => '278586fe-e7c9-4b5c-8d9e-ec7cf3d4fa46',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '0px',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '57cd43102aecd',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '219d20cb-3fc9-49cf-978b-0ad3450ac1ce',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'our team ',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '11499251-b138-400a-813e-f671d06d71a0',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Sed at nisl massa. Sed bibendum nisi aliquam quam varius a posuere ex ultricies. Vestibulum efficitur a mi ac elementum. In vehicula nibh ut diam dictum quis laoreet leo suscipit.',
            'image_url' => 'http://waves.webulous.in/wp-content/uploads/2016/09/three.png',
            'title' => 'Harvey Dent',
            'designation' => 'CEO',
            'linkedin' => 'http://www.linkedin.com',
            'google' => 'http://www.google.com',
            'twitter' => 'http://www.twitter.com',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '9bf8c908-a883-406f-9dd5-fd8496b3fe0e',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Sed at nisl massa. Sed bibendum nisi aliquam quam varius a posuere ex ultricies. Vestibulum efficitur a mi ac elementum. In vehicula nibh ut diam dictum quis laoreet leo suscipit.',
            'image_url' => 'http://waves.webulous.in/wp-content/uploads/2016/09/two.png',
            'title' => 'Jessica Lee',
            'designation' => 'Manager',
            'linkedin' => 'http://www.linkedin.com',
            'google' => 'http://www.google.com',
            'twitter' => 'http://www.twitter.com',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '3c89d47e-1ef1-4310-abd9-d1ceb2453554',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Sed at nisl massa. Sed bibendum nisi aliquam quam varius a posuere ex ultricies. Vestibulum efficitur a mi ac elementum. In vehicula nibh ut diam dictum quis laoreet leo suscipit.',
            'image_url' => 'http://waves.webulous.in/wp-content/uploads/2016/09/one.png',
            'title' => 'Devid Harris',
            'designation' => 'Developer',
            'linkedin' => 'http://www.linkedin.com',
            'google' => 'http://www.google.com',
            'twitter' => 'http://www.twitter.com',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => 'b47036f3-c0aa-4459-af19-9c4c270c84fb',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'head-para',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
        ),
      ),
      'builder_id' => '57cd43102af31',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 4,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '23984830-9736-4c3b-897b-4ed0e559d1a0',
        'style' => 
        array (
          'class' => 'grid-margin',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'our skills',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '4291b887-f6f9-4e4f-a655-9b6008ff103a',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Skills',
            'panels_info' => 
            array (
              'class' => 'Wbls_Skill_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '29c21d4a-aba7-4aac-ac28-2c3df2523e55',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'head-para white-text',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'skill-white',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '57cd43102afa6',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 5,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '10a1ef60-1163-4274-b8fb-40026e303a6d',
        'style' => 
        array (
          'class' => 'grid-margin',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'about us',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '2166e3f3-3cbc-42e8-83a6-f9fefa22893a',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '<img src="http://waves.webulous.in/wp-content/uploads/2016/09/about-us.jpg"> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniamquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodoconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.  Ut enim ad minim veniamquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur. ',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '5619f4f1-66dc-4397-be14-4fe4baddb1ba',
              'style' => 
              array (
                'class' => 'about-text',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
          2 => 
          array (
            'title' => '',
            'text' => '[accordion_group][accordion title="Aliquam rutrum tortor quis ultrices ultricies."]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="Curabitur rutrum vehicula enim et pulvinar."] Sed nec massa lorem. Phasellus ut tincidunt velit, id scelerisque lorem. Nullam nisl tortor, mollis ut massa in, dapibus tincidunt libero. Ut tempus aliquam felis, quis consequat nunc hendrerit eget. Praesent sollicitudin nunc eu sollicitudin placerat. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="Pellentesque iaculis vulputate blandit."]Aliquam non lacus in lacus aliquet blandit. Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. Sed ut augue vitae augue vestibulum pulvinar. Fusce commodo ultricies volutpat. Vivamus quis nulla porta euismod sem bibendum, interdum lorem. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. [/accordion][/accordion_group]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '1290c803-d928-43c7-8f67-f71a934a6a3e',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'head-para',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '57cd43102b010',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 6,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '2ce7f16f-67e2-4099-be1c-172e879f60af',
        'style' => 
        array (
          'class' => 'grid-margin',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'slider' => 'clients',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '86c60657-c529-49a0-8e68-970a3da6cb8b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'From blog',
      'text' => 'Lorem ipsum dolor sit amet onsectetur adipisicing elit sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'dc2ccf02-fefa-4328-b647-4cedf0b47b08',
        'style' => 
        array (
          'class' => 'head-para',
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => '',
      'count' => '3',
      'type' => 'normal',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Posts_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '299d5c0e-3610-479d-99cb-839eaaba9bdf',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'grid-margin',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern wide-pattern-black waves',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'standard-width',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-black-pattern stat-white panel-row-style-full-width-layout waves ',
        'row_stretch' => 'full',
        'background_image_attachment' => 21,
        'background_display' => 'cover',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'standard-width',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout waves',
        'row_stretch' => 'full',
        'background_image_attachment' => 30,
        'background_display' => 'cover',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'standard-width',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-black-pattern panel-row-style-full-width-layout flexcarousel-white waves',
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'standard-width',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    
    ),

  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-waves'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-waves'),
    'widgets' => array(
            0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'about us',
            'text' => 'Vestibulum commodo est sit amet elit fermentum et volutpat purus rhoncus. Aliquam tempor felis eget tincidunt posuere. ',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'head-para',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.

Vestibulum commodo est sit amet elit fermentum, et volutpat purus rhoncus. Aliquam tempor felis eget tincidunt posuere. Donec in ultricies mauris. Sed maximus nulla viverra augue aliquam tempor. Vivamus quis nisi at erat tincidunt maximus et non tellus. Etiam quis arcu porta, tincidunt sem ac, lobortis arcu. Praesent vel porttitor nisi.',
            'filter' => 'on',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Skills',
            'panels_info' => 
            array (
              'class' => 'Wbls_Skill_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '56bd8d382f9f0',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '47304c8d-e752-43b0-b707-8f875bab097b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Team',
            'text' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '338fabe0-ff25-46ab-b1ac-2c02b1499f19',
              'style' => 
              array (
                'class' => 'head-para white-head-text',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Nullam ac tellus orci. Suspendisse id orci nec augue tempor tincidunt. Vestibulum a odio erat. Aenean consequat finibus Maecenas dapibus efficitur dui in euismod.',
            'image_url' => 'http://waves.webulous.in/wp-content/uploads/2016/09/one.png',
            'title' => 'Harvey Dent',
            'designation' => 'CEO',
            'linkedin' => 'http://www.Linkedin.com',
            'google' => 'http://www.google.com',
            'twitter' => 'http://www.twitter.com',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '6b1260ef-7eb3-4b66-b906-f35f29f38984',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Nullam ac tellus orci. Suspendisse id orci nec augue tempor tincidunt. Vestibulum a odio erat. Aenean consequat finibus Maecenas dapibus efficitur dui in euismod.',
            'image_url' => 'http://waves.webulous.in/wp-content/uploads/2016/09/two.png',
            'title' => 'jessica Lee',
            'designation' => 'Manager',
            'linkedin' => 'http://www.Linkedin.com',
            'google' => 'http://www.google.com',
            'twitter' => 'http://www.twitter.com',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '0fc5154c-79d5-4616-bc64-9d4544b1665f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Nullam ac tellus orci. Suspendisse id orci nec augue tempor tincidunt. Vestibulum a odio erat. Aenean consequat finibus Maecenas dapibus efficitur dui in euismod.',
            'image_url' => 'http://waves.webulous.in/wp-content/uploads/2016/09/three.png',
            'title' => 'Devid Harris ',
            'designation' => 'Developer',
            'linkedin' => 'http://www.Linkedin.com',
            'google' => 'http://www.google.com',
            'twitter' => 'http://www.twitter.com',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '8766af11-34b3-4215-962a-d552828be89c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'clr-white',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '0px',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
        ),
      ),
      'builder_id' => '57cd455862f34',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'd299e0e8-ee0b-4951-b36f-35eecd9d0b1c',
        'style' => 
        array (
          'class' => 'grid-margin',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => '335',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '88df1f9c-4965-4b7d-bc93-ebce1e4ec0fa',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => '334',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 3,
        'widget_id' => '7c98778b-1cc7-4e8c-b319-9d2e5be4b7ca',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => '333',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 4,
        'widget_id' => 'f40f0f6c-a8e7-476b-af28-4e46cb7a7889',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => '332',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 3,
        'id' => 5,
        'widget_id' => '2960bd68-5097-4566-b979-cf867e3ab1aa',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => '',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
<p><a class="btn btn-black btn-large" herf="http://www.webulousthemes.com">Get in touch</a></p>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '78a1019b-fe8e-404c-b44f-131b0146a15d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now ',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 7,
        'widget_id' => 'efdbe41b-a0e6-4fec-ab84-fa316b3ae283',
        'style' => 
        array (
          'class' => 'cta-normal',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'slider' => 'clients',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'edec9bde-79b7-4adc-96ab-dbade1f0d98a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern wide-pattern-black waves ',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-cta-pattern text-cta waves',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-black-pattern panel-row-style-full-width-layout flexcarousel-white waves',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
        ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'wbls-waves'),
      'description' => __( 'Pre Built layout for features page', 'wbls-waves'),
      'widgets' => array(
            0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our unique features',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'head-para',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'type' => 'circle',
            'title' => 'RESPONSIVE LAYOUT',
            'text' => 'Waves is fully responsive and can adapt to any screen size. Resize your browser window to view it!',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'type' => 'circle',
            'title' => 'AWESOME SLIDER ',
            'text' => 'Waves includes Flex slider. You can use Flex slider anywhere in your site.',
            'icon' => 'fa-random',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => 'circle-icon-top',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'type' => 'circle',
            'title' => 'FONT AWESOME',
            'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
            'icon' => 'fa-flag',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'style' => 
              array (
                'class' => 'circle-icon-top',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'type' => 'circle',
            'title' => 'Retina Ready',
            'text' => 'Waves is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
            'icon' => 'fa-magic',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'type' => 'circle',
            'title' => 'TYPOGRAPHY',
            'text' => 'Waves loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
            'icon' => 'fa-font',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 2,
              'cell' => 0,
              'id' => 5,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'type' => 'circle',
            'title' => 'DEMO CONTENT',
            'text' => 'Waves includes demo content files. You can quickly setup the site like our demo and get started easily!',
            'icon' => 'fa-times',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 2,
              'cell' => 1,
              'id' => 6,
              'style' => 
              array (
                'class' => 'circle-icon-bottom',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          7 => 
          array (
            'type' => 'circle',
            'title' => 'PAGE LAYOUTS',
            'text' => 'Waves offers many different page layouts so you can quickly and easily create your pages with no hassle!',
            'icon' => 'fa-copy (alias)',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 2,
              'cell' => 2,
              'id' => 7,
              'style' => 
              array (
                'class' => 'circle-icon-bottom',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          8 => 
          array (
            'type' => 'circle',
            'title' => 'PAGE BUILDER',
            'text' => 'Waves supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
            'icon' => 'fa-plus',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 2,
              'cell' => 3,
              'id' => 8,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          2 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          5 => 
          array (
            'grid' => 2,
            'weight' => 0.25,
          ),
          6 => 
          array (
            'grid' => 2,
            'weight' => 0.25,
          ),
          7 => 
          array (
            'grid' => 2,
            'weight' => 0.25,
          ),
          8 => 
          array (
            'grid' => 2,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '56bd8db88f4d8',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
      'title' => 'WEBULOUS THEME',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'class' => 'cta-white',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'height' => '30',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'type' => 'circle',
            'title' => 'CUSTOM WIDGET',
            'text' => ' We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
            'icon' => 'fa-beer',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'type' => 'circle',
            'title' => 'SHORTCODE BUILDER',
            'text' => 'Waves inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
            'icon' => 'fa-shopping-cart',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => 'circle-icon-top',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'type' => 'circle',
            'title' => 'ADVANCED ADMIN ',
            'text' => 'Waves uses advanced Redux Framework for theme options panel, you can customize any part of your site quickly and easily!',
            'icon' => 'fa-cog',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'style' => 
              array (
                'class' => 'circle-icon-top',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'type' => 'circle',
            'title' => 'EXCELLENT SUPPORT',
            'text' => ' We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
            'icon' => 'fa-thumb-tack',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'type' => 'circle',
            'title' => ' Google Map ',
            'text' => 'Waves includes Google Map as shortcode and widget. So you can use it anywhere in your site!',
            'icon' => 'fa-map-marker',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 0,
              'id' => 4,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'type' => 'circle',
            'title' => ' Social Media',
            'text' => 'Want your users to stay in touch? No problem, Waves has Social Media icons all throughout the theme!',
            'icon' => 'fa-skype',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 1,
              'id' => 5,
              'style' => 
              array (
                'class' => 'circle-icon-bottom',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'type' => 'circle',
            'title' => ' Multiple Portfolio',
            'text' => '2 Portfolio layouts, 1 Blog layouts and alternate layouts for interior pages!',
            'icon' => 'fa-list-alt',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 2,
              'id' => 6,
              'style' => 
              array (
                'class' => 'circle-icon-bottom',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          7 => 
          array (
            'type' => 'circle',
            'title' => ' Multiple Sidebar',
            'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
            'icon' => 'fa-columns',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 3,
              'id' => 7,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          5 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          6 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          7 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '56bd8e47bfa11',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
      'title' => 'WEBULOUS THEME',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 4,
        'style' => 
        array (
          'class' => 'cta-white',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'height' => '30',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 5,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'type' => 'circle',
            'title' => ' Customization  ',
            'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
            'icon' => 'fa-edit (alias)',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'type' => 'circle',
            'title' => ' Shortcode Builder',
            'text' => 'Waves inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
            'icon' => 'fa-check',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => 'circle-icon-top',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'type' => 'circle',
            'title' => 'Testimonials',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'icon' => 'fa-rocket',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'style' => 
              array (
                'class' => 'circle-icon-top',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'type' => 'circle',
            'title' => 'Improvement',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'icon' => 'fa-rss',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'more' => 'Read More',
            'more_url' => 'http://www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '56bd8e6b709ea',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 6,
        'cell' => 0,
        'id' => 6,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-black-pattern panel-row-style-full-width-layout-carousel  waves',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-black-pattern panel-row-style-full-width-layout-carousel  waves',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-waves'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-waves'),
      'widgets' => array(
            0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Contact Us',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'head-para',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '<iframe frameborder="0" scrolling="no" marginheight="0" marginwidth="0"width="1500" height="500" src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d16062173.644113218!2d69.1988817262194!3d10.623733484413826!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sIndia%2C+India!5e0!3m2!1sen!2sus!4v1451987139624"><div><small><a href="http://embedgooglemaps.com">embedgooglemaps.com</a></small></div><div><small><a href="http://premiumlinkgenerator.com/keep2share-cc">keep2share premium link generator</a></small></div></iframe>


',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => '<i class="fa fa-phone"></i> (1)123 456 789',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 2,
              'cell' => 0,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '',
            'text' => '<i class="fa fa-map-marker"></i>Place Marker',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 2,
              'cell' => 1,
              'id' => 3,
              'style' => 
              array (
                'class' => 'align-center',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '',
            'text' => '<i class="fa fa-envelope-o"></i>  <a href="mailto:information@mail.com">information@gmail.com</a>
',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 2,
              'cell' => 2,
              'id' => 4,
              'style' => 
              array (
                'class' => 'align-right',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => '',
            'text' => '[contact-form-7 id="195" title="Contact-Us-Left"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 3,
              'cell' => 0,
              'id' => 5,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'title' => '',
            'text' => '[contact-form-7 id="196" title="Contant-Us-Right"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 3,
              'cell' => 1,
              'id' => 6,
              'style' => 
              array (
                'class' => 'contact-button',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => 'full-stretched',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'cover',
              'border_color' => '',
            ),
          ),
          2 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'contact-info',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          3 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => 'contact-form',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
          2 => 
          array (
            'grid' => 2,
            'weight' => 0.33333333333332998,
          ),
          3 => 
          array (
            'grid' => 2,
            'weight' => 0.33333333333332998,
          ),
          4 => 
          array (
            'grid' => 2,
            'weight' => 0.33333333333332998,
          ),
          5 => 
          array (
            'grid' => 3,
            'weight' => 0.37975951903807997,
          ),
          6 => 
          array (
            'grid' => 3,
            'weight' => 0.62024048096191997,
          ),
        ),
      ),
      'builder_id' => '568f8959e2d2a',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-waves'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-waves'),
    'widgets' =>  array(
         0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Faq\'s',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vestibulum ante ipsum primis.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'head-para',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[accordion_group][accordion title=" Suspendisse massa odio"]Ut at lacinia erat. Aliquam lacus ex, tristique vitae quam nec, egestas scelerisque elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nunc tempor quam eu posuere porttitor. Etiam quis lectus est. Morbi ac gravida odio. Aliquam efficitur nisl orci, ac vestibulum ipsum blandit id. Aliquam lacinia eget sapien nec pulvinar. Praesent nibh erat, imperdiet non ornare euismod, rutrum ut mi. Quisque et risus in dolor porttitor iaculis.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu  Etiam semper tortor arcu, volutpat consequat est convallis eu. Nulla posuere neque quis mi laoreet volutpat.[/accordion][accordion title=" Praesent condimentum metus mauris"]In id lectus sed justo rhoncus luctus. Praesent imperdiet, massa et cursus sollicitudin, nibh tellus ullamcorper magna, eu fringilla est mi id magna. Etiam elit ex, pulvinar quis vehicula vitae, molestie eget ante. In hac habitasse platea dictumst. Duis turpis risus, ultricies sit amet libero pharetra, vestibulum imperdiet nisi. Integer sapien orci, placerat eu pretium a, faucibus eget massa. Nam gravida nisi eget felis consectetur, nec vestibulum urna malesuada.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu Integer nec faucibus sem, vitae molestie arcu. [/accordion][accordion title="Vivamus dignissim dolor fermentum."]Donec ornare scelerisque convallis. Integer at erat in dolor fringilla ornare ut vitae est. Vivamus vulputate bibendum ex ac pulvinar. Cras tincidunt lorem elementum, mollis felis ut, tristique ante. Cras mattis ante a metus dapibus, nec sollicitudin massa blandit. Sed eget augue eget leo elementum porta eu non augue. Aenean ac diam eget orci molestie eleifend id et ipsum. Quisque ac tellus ac ligula condimentum fermentum. Donec congue lorem nec pellentesque efficitur. Sed imperdiet molestie nibh efficitur feugiat. Mauris scelerisque et neque sed pellentesque. Vivamus finibus lectus ut erat bibendum bibendum. Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu[/accordion][accordion title="Mauris auctor vulputate urna"]Aenean laoreet, dolor sit amet faucibus finibus, sem sem interdum velit, et egestas libero enim sit amet libero. Maecenas nec nisi ut nibh luctus lacinia eu id magna. Duis sed arcu ipsum. Sed dictum a nisi vel pellentesque. Maecenas semper posuere rhoncus. Sed consectetur nibh felis, quis porttitor velit gravida eget. Donec lectus dolor, tincidunt finibus quam vitae, vulputate gravida ipsum. Integer blandit velit ante, eu placerat ligula mollis eget. Suspendisse elit metus, mollis at vehicula in, venenatis ut purus. Integer mollis scelerisque est, at congue nisi aliquam quis. Nulla vitae purus id nisl cursus tempor. Integer nibh risus, feugiat nec dui sed, dapibus tincidunt tortor. Pellentesque porta scelerisque lorem, sit amet porta dui. Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu [/accordion][accordion title="Praesent pulvinar pretium magna"] Sed dictum a nisi vel pellentesque. Maecenas semper posuere rhoncus. Sed consectetur nibh felis, quis porttitor velit gravida eget. Donec lectus dolor, tincidunt finibus quam vitae, vulputate gravida ipsum. Integer blandit velit ante, eu placerat ligula mollis eget. Suspendisse elit metus, mollis at vehicula in, venenatis ut purus. Integer mollis scelerisque est, at congue nisi aliquam quis. Nulla vitae purus id nisl cursus tempor. Integer nibh risus, feugiat nec dui sed, dapibus tincidunt tortor. Pellentesque porta scelerisque lorem, sit amet porta dui.Aenean laoreet, dolor sit amet faucibus finibus, sem sem interdum velit, et egestas libero enim sit amet libero. Maecenas nec nisi ut nibh luctus lacinia eu id magna. Duis sed arcu ipsum.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu  [/accordion][accordion title="Etiam eget lorem nisi Duis neque."] Maecenas nec nisi ut nibh luctus lacinia eu id magna. Duis sed arcu ipsum. Sed dictum a nisi vel pellentesque. Maecenas semper posuere rhoncus. Sed consectetur nibh felis, quis porttitor velit gravida eget. Donec lectus dolor, tincidunt finibus quam vitae, vulputate gravida ipsum. Integer blandit velit ante, eu placerat ligula mollis eget. Suspendisse elit metus, mollis at vehicula in, venenatis ut purus. Integer mollis scelerisque est, at congue nisi aliquam quis. Nulla vitae purus id nisl cursus tempor. Integer nibh risus, feugiat nec dui sed, dapibus tincidunt tortor. Pellentesque porta scelerisque lorem, sit amet porta dui.Aenean laoreet, dolor sit amet faucibus finibus, sem sem interdum velit, et egestas libero enim sit amet libero.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu  [/accordion][accordion title="Aliquam rutrum tortor quis ultrices ultricies."]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. Cras venenatis a nibh ut placerat. Vivamus a mauris non quam pretium lobortis non ac odio. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="Curabitur rutrum vehicula enim et pulvinar."] Sed nec massa lorem. Phasellus ut tincidunt velit, id scelerisque lorem. Nullam nisl tortor, mollis ut massa in, dapibus tincidunt libero. Pellentesque pretium posuere turpis eget dignissim. Curabitur sapien lorem, feugiat et velit et, vehicula aliquet urna. Vivamus pellentesque lorem at urna suscipit, at vulputate est ultricies. Aliquam ultrices nec massa sed adipiscing. Pellentesque feugiat sodales tellus. Ut tempus aliquam felis, quis consequat nunc hendrerit eget. Praesent sollicitudin nunc eu sollicitudin placerat. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="Pellentesque iaculis vulputate blandit."]Aliquam non lacus in lacus aliquet blandit. Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. Sed ut augue vitae augue vestibulum pulvinar. Fusce commodo ultricies volutpat. Vivamus quis nulla porta, faucibus metus eu, tempus dolor. Ut sed faucibus mi, ac volutpat lectus. Morbi a rhoncus erat. Mauris et metus posuere, imperdiet urna at, congue risus. Nunc at ante sed ipsum porttitor scelerisque semper non libero. Vivamus feugiat nisl sit amet mi tristique dictum. Donec id magna facilisis, euismod sem bibendum, interdum lorem. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title=" Vestibulum in mi mauris. Duis luctus dolor ante."]Fusce vehicula risus lorem, sed ultricies neque pellentesque at. Ut dapibus aliquam leo non cursus. Donec eros dui, fringilla vel lacinia id, tincidunt ac eros. Ut ultrices elit nec viverra adipiscing. Aliquam suscipit viverra luctus. Vivamus rhoncus molestie hendrerit. Aenean id lacinia odio. Nullam sit amet dui accumsan, ornare nisi at, ornare elit. Proin ut dolor risus. Cras quis pellentesque felis, at venenatis nibh. Quisque tincidunt id enim a aliquam. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][/accordion_group]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => 'faq-acc',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '560cc638a78f9',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'class' => 'cta-white',
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'waves full-width-black-pattern panel-row-style-full-width-layout-carousel ',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-waves'),
    'description' => __('Pre Built Layout for services page', 'wbls-waves'),
    'widgets' =>  array(
            0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Need Help ?',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
<li><i class="fa fa-phone"></i> 1 118 234 678</li>
<li><i class="fa fa-envelope-o"></i>  <a href="mailto:information@mail.com">information@mail.com</a></li>

',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'service-info',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'title' => 'Web Design and Development',
                  'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                  'icon' => 'fa-mobile',
                  'icon_background_color' => '',
                  'icon_size' => '2x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => true,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'Branding and Corporate Identity',
                  'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                  'icon' => 'fa-bar-chart-o',
                  'icon_background_color' => '',
                  'icon_size' => '2x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 1,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'title' => 'SEO Optimization',
                  'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                  'icon' => 'fa-search',
                  'icon_background_color' => '',
                  'icon_size' => '2x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => true,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 2,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 1,
                ),
              ),
            ),
            'builder_id' => '56067d6ec8a35',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => true,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.30018068265044001,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.69981931734956004,
          ),
        ),
      ),
      'builder_id' => '56bd8f84b3981',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'our uniq tab',
      'text' => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam feugiat vitae ultricies.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'class' => 'head-para white-head-text',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'slider' => 'small-our-services-slider',
      'type' => 'slider',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse ultricies sem vitae leo tristique, eu accumsan tortor imperdiet.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 3,
        'style' => 
        array (
          'class' => 'cta-normal',
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern wide-pattern-black flexcarousel-white round-slider waves',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'wbls_waves_prebuilt_page_layouts');


function wbls_waves_panels_row_style_fields($fields) {  

    $waves_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-waves'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-waves' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-waves' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-waves' ),
        'bounce-animation' => __('bounce-animation','wbls-waves' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-waves' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-waves' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-waves' ),
        'expandUp-animation' => __('expandUp-animation','wbls-waves' ),
        'fade-animation' => __('fade-animation','wbls-waves' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-waves' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-waves' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-waves' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-waves' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-waves' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-waves' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-waves' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-waves' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-waves' ),
        'flip-animation' => __('flip-animation','wbls-waves' ),
        'flipInX-animation' => __('flipInX-animation','wbls-waves' ),
        'flipInY-animation' => __('flipInY-animation','wbls-waves' ),
        'floating-animation' => __('floating-animation','wbls-waves' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-waves' ),
        'hatch-animation' => __('hatch-animation','wbls-waves' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-waves' ),
        'puffIn-animation' => __('puffIn-animation','wbls-waves' ),
        'pullDown-animation' => __('pullDown-animation','wbls-waves' ),
        'pullUp-animation' => __('pullUp-animation','wbls-waves' ),
        'pulse-animation' => __('pulse-animation','wbls-waves' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-waves' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-waves' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-waves' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-waves' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-waves' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-waves' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-waves' ),
        'scale-down-animation' => __('scale-down-animation','wbls-waves' ),
        'scale-up-animation' => __('scale-up-animation','wbls-waves' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-waves' ),
        'slide-left-animation' => __('slide-left-animation','wbls-waves' ),
        'slide-right-animation' => __('slide-right-animation','wbls-waves' ),
        'slide-top-animation' => __('slide-top-animation','wbls-waves' ),
        'slideDown-animation' => __('slideDown-animation','wbls-waves' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-waves' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-waves' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-waves' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-waves' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-waves' ),
        'slideRight-animation' => __('slideRight-animation','wbls-waves' ),
        'slideUp-animation' => __('slideUp-animation','wbls-waves' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-waves' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-waves' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-waves' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-waves' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-waves' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-waves' ),
        'swap-animation'  => __('swap-animation','wbls-waves' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-waves' ),
        'swing-animation'  => __('swing-animation','wbls-waves' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-waves' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-waves' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-waves' ), 
        'tossing-animation'  => __('tossing-animation','wbls-waves' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-waves' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-waves' ), 
        'wobble-animation' => __('wobble-animation','wbls-waves' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-waves' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'waves'),
            'type' => 'select',
            'options' => $waves_animation_name,
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_waves_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_waves_panels_row_style_fields');

function wbls_waves_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_waves_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_waves_panels_panels_row_style_attributes', 10, 2);

function wbls_waves_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Animation', 'wbls-waves'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_waves_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_waves_row_style_groups' );