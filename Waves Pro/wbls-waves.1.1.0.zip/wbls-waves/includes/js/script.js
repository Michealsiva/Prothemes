( function( $ ) {
	// Do Something
		
} )( jQuery );