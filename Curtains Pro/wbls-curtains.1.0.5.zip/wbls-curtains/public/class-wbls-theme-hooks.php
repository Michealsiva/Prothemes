<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 4:55 PM
	 */
if( ! class_exists( 'Wbls_Theme_Hooks' )) {
	class Wbls_Theme_Hooks {

		public function full_width_slider(){
			global $post;
			$slider_shortcode = get_post_meta( $post->ID, '_wbls_slider_shortcode', true );
			if( $slider_shortcode != '' ) {
				echo '<div class="page-slider">';
				echo do_shortcode( $slider_shortcode );
				echo '</div>';
			}
		}
		
		public function single_portfolio($single_template){
		    global $post;
			if( $post->post_type == 'portfolio') {
				$single_template = WBLS_THEME_DIR . 'public/views/single-portfolio.php';
				if( file_exists($single_template) && is_file($single_template) ) {
					 $single_template;
				} else {
					if( defined( 'WBLS_FW_DIR' ) ) {
						$single_template = WBLS_FW_DIR . 'public/views/single-portfolio.php';	
						if( is_file($single_template) && file_exists( $single_template ) ) {
                            $single_template;
						}
					}
				}
			}
			return $single_template;
		} 
		
		public function single_post($single_template){    
		    global $post;
		    $post_fullwidth = get_post_meta( $post->ID, '_wbls_full_width_post', true );
			if( $post->post_type == 'post') {
				if ( $post_fullwidth ){
					$single_template = WBLS_THEME_DIR . 'public/views/single-post-fullwidth.php';
				    if( file_exists($single_template) && is_file($single_template) ) {
					    $single_template;
				    } 
				}
			}
			return $single_template;
		}

		public function portfolio_views($file){        
			global $post;
		    $file = WBLS_THEME_DIR . 'public/views/' . get_post_meta( $post->ID, '_wp_page_template', true );
			return $file;
		}

		public function customizer_options($free_options) {   
			$pro_options = array(
	            // typography start //
	            'typography' => array(   
	                'priority'       => 10,
	                'title'          => __('Typography', 'wbls-curtains'),
	                'description'    => __('Typography and Link Color Settings', 'wbls-curtains'),
	                'sections' => array(
	                    'typography_section' => array(
	                        'title' => __('General Settings', 'wbls-curtains'),
	                        'description' => __('','wbls-curtains'),
	                        'fields' => array(
	                            'custom_typography' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Custom Typography', 'wbls-curtains'),
	                                'description' => __('Turn on to customize typography and turn off for default typography.', 'wbls-curtains'),
	                                'default' => 0,
	                            ),

	                        ),    
	                    ),

	                    'body_font' => array(
	                        'title' => __('Body Font','wbls-curtains'),
	                        'description' => __('Specify the body font properties.','wbls-curtains'),
	                        'fields' => array (
	                            'body' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                            ),
	                            'body_color' => array(
	                                'type' => 'color',
	                                'label' => __('Body Color', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#282827'
	                            ),
	                        ),
	                    ),
	                    'h1_property' => array(
	                        'title' => __('H1 Font Properties','wbls-curtains'),
	                        'description' => __('Specify the h1 font properties.','wbls-curtains'),
	                        'fields' => array (
	                            'h1' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                            ),
	                            'h1_color' => array(
	                                'type' => 'color',
	                                'label' => __('H1 Color', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#282827'
	                            ),
	                        ),
	                    ),
	                    'h2_property' => array(
	                        'title' => __('H2 Font Properties','wbls-curtains'),
	                        'description' => __('Specify the h2 font properties.','wbls-curtains'),
	                        'fields' => array (
	                                'h2' => array(
	                                    'type' => 'typography',
	                                    'label' => __('', 'wbls-curtains'),
	                                    'description' => __('', 'wbls-curtains'),
	                                ),
	                                'h2_color' => array(
	                                    'type' => 'color',
	                                    'label' => __('H2 Color', 'wbls-curtains'),
	                                    'description' => __('', 'wbls-curtains'),
	                                    'sanitize_callback' => 'sanitize_hex_color',
	                                    'transport' => 'postMessage',
	                                    'default' => '#282827'
	                                )
	                        ),
	                    ),
	                    'h3_property' => array(
	                        'title' => __('H3 Font Properties','wbls-curtains'),
	                        'description' => __('Specify the h3 font properties.','wbls-curtains'),
	                        'fields' => array (
	                                'h3' => array(
	                                    'type' => 'typography',
	                                    'label' => __('', 'wbls-curtains'),
	                                    'description' => __('', 'wbls-curtains'),
	                                ),
	                                'h3_color' => array(
	                                    'type' => 'color',
	                                    'label' => __('H3 Color', 'wbls-curtains'),
	                                    'description' => __('', 'wbls-curtains'),
	                                    'sanitize_callback' => 'sanitize_hex_color',
	                                    'transport' => 'postMessage',
	                                    'default' => '#282827'     
	                                )
	                        ),
	                    ),
	                    'h4_property' => array(
	                        'title' => __('H4 Font Properties','wbls-curtains'),
	                        'description' => __('Specify the h4 font properties.','wbls-curtains'),
	                        'fields' => array (
	                            'h4' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                            ),
	                            'h4_color' => array(
	                                'type' => 'color',
	                                'label' => __('H4 Color', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#282827'
	                            )
	                        ),
	                    ),
	                    'h5_property' => array(
	                        'title' => __('H5 Font Properties','wbls-curtains'),
	                        'description' => __('Specify the h5 font properties.','wbls-curtains'),
	                        'fields' => array (
	                            'h5' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                            ),
	                            'h5_color' => array(
	                                'type' => 'color',
	                                'label' => __('H5 Color', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#282827'
	                            )
	                        ),
	                    ),
	                    'h6_property' => array(
	                        'title' => __('H6 Font Properties','wbls-curtains'),
	                        'description' => __('Specify the h6 font properties.','wbls-curtains'),
	                        'fields' => array (
	                            'h6' => array(
	                                'type' => 'typography',
	                                'label' => __('', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                            ),
	                            'h6_color' => array(
	                                'type' => 'color',
	                                'label' => __('H6 Color', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_hex_color',
	                                'transport' => 'postMessage',
	                                'default' => '#282827'
	                            )
	                        ),
	                    ),
	                ),
	            ), // typography panel end //

				'pro_panel' => array(
	                'priority'       => 9,
	                'title'          => __('Pro Options', 'wbls-curtains'),
	                'description'    => __('Pro Options', 'wbls-curtains'),
	                'sections' => array(
	                    'multiple_color_section' => array(
	                        'title' => __('Color Scheme ', 'wbls-curtains'),
	                        'description' => __('Select your color scheme','wbls-curtains'),
	                        'fields' => array(
	                            'color_scheme' => array(   
	                                'type' => 'select',
	                                'label' => __('Select your color scheme.', 'wbls-curtains'),
	                                'description' => __(' ', 'wbls-curtains'),
	                                'choices' => array(
	                                    '1' => __('Default', 'wbls-curtains'),             
	                                    '2' => __('Green', 'wbls-curtains'),
	                                    '3' => __('Orange', 'wbls-curtains'),    
	                                    '4' => __('Red', 'wbls-curtains'),
	                                    '5' => __('Yellow', 'wbls-curtains'),
	                                    '6' => __('LightPurple', 'wbls-curtains'),
	                                    '7' => __('SaddleBrown', 'wbls-curtains'),
	                                    '8' => __('Pink', 'wbls-curtains'),
	                                ),
	                                'default' => 1,  
                            	),                     
	                        ),
	                    ),
                        'social_network' => array(
	                        'title' => __('Social Networks', 'wbls-curtains'),
	                        'description' => __(' Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-curtains'),
	                        'fields' => array(
	                            'digg' => array(
	                                'type' => 'text',
	                                'label' => __('Digg', 'wbls-curtains'), 
	                                'description' => __('Your Digg link ', 'wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'dribbble' => array(
	                                'type' => 'text',
	                                'label' => __('Dribbble', 'wbls-curtains'),
	                                'description' => __('Your Dribbble link ', 'wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'facebook' => array(
	                                'type' => 'text',
	                                'label' => __('Facebook', 'wbls-curtains'),
	                                'description' => __('Your Facebook link', 'wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'twitter' => array(
	                                'type' => 'text',
	                                'label' => __('Twitter', 'wbls-curtains'),
	                                'description' => __('Your Twitter link', 'wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'google_plus' => array(
	                                'type' => 'text',
	                                'label' => __('Google +', 'wbls-curtains'),
	                                'description' => __('Your Google Plus', 'wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',

	                            ),
	                            'linkedin' => array(
	                                'type' => 'text',
	                                'label' => __('LinkedIn', 'wbls-curtains'),
	                                'description' => __('Your LinkedIn link', 'wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'instagram' => array(
	                                'type' => 'text',
	                                'label' => __('Instagram', 'wbls-curtains'),
	                                'description' => __('Your Instagram link ', 'wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'flickr' => array(
	                                'type' => 'text',
	                                'label' => __('Flickr', 'wbls-curtains'),
	                                'description' => __('Your Flickr link', 'wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'youtube' => array(
	                                'type' => 'text',
	                                'label' => __('YouTube', 'wbls-curtains'),
	                                'description' => __('Your YouTube link', 'wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'vimeo' => array(
	                                'type' => 'text',
	                                'label' => __('Vimeo', 'wbls-curtains'),
	                                'description' => __('Your Vimeo link', 'wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'pinterest' => array(
	                                'type' => 'text',
	                                'label' => __('Pinterest', 'wbls-curtains'),
	                                'description' => __('Your Pinterest link','wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'rss' => array(
	                                'type' => 'text',
	                                'label' => __('RSS', 'wbls-curtains'),
	                                'description' => __('Your RSS link','wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'skype' => array(
	                                'type' => 'text',
	                                'label' => __('Skype', 'wbls-curtains'),
	                                'description' => __('Your Skype link','wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
	                            'tumblr' => array(
	                                'type' => 'text',
	                                'label' => __('Tumblr', 'wbls-curtains'),
	                                'description' => __('Your Tumblr link','wbls-curtains'),
	                                'sanitize_callback' => 'esc_url_raw',
	                            ),
                            ),
                        ),


						'flex_slider_section' => array(
	                        'title' => __('Flex Slider', 'wbls-curtains'),
	                        'description' => __('Flex Slider Settings','wbls-curtains'),
	                        'fields' => array(
	                            'animation' => array(
	                                'type' => 'select',
	                                'label' => __('Select slider animation effect', 'wbls-curtains'),
	                                'description' => __('Select slider animation effect.', 'wbls-curtains'),
	                                'choices' => array(
	                                    '1' => __('Fade', 'wbls-curtains'),
	                                    '2' => __('Slide', 'wbls-curtains'),
	                                ),
	                                'default' => 2,
	                            ),
	                            'slide_direction' => array(
	                                'type' => 'select',
	                                'label' => __('Select direction to slide ', 'wbls-curtains'),
	                                'description' => __('Select direction to slide (if you are using the "Slide" animation)', 'wbls-curtains'),
	                                'choices' => array(
	                                    '1' => __('Horizontal', 'wbls-curtains'),
	                                    '2' => __('Vertical', 'wbls-curtains'),
	                                ),
	                                'default' => 1,
	                            ),
	                            'flexslider_slideshow_speed' => array(
	                                'type' => 'range',
	                                'label' => __('Slideshow Speed', 'wbls-curtains'),
	                                'description' => __('Set the delay between each slide animation (in milliseconds)', 'wbls-curtains'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 1,
	                                ),
	                                'default' => 50
	                            ),
	                            'flexslider_animation_speed' => array(
	                                'type' => 'range',
	                                'label' => __('Animation Speed', 'wbls-curtains'),
	                                'description' => __('Set the duration of each slide animation (in milliseconds)', 'wbls-curtains'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 1,
	                                ),
	                                'default' => 50
	                            ),
	                            'flexslider_slideshow' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Animate the slideshows automatically', 'wbls-curtains'),
	                                'description' => __('Enable Animate the slideshows automatically', 'wbls-curtains'),
	                                'default' => 1,
	                            ),
	                            'flexslider_smooth_height' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable to Adjust the height of the slideshow to the height of the current slide', 'wbls-curtains'),
	                                'description' => __('Enable Adjust the height of the slideshow to the height of the current slide', 'wbls-curtains'),
	                                'default' => 0,
	                            ),
	                            'flexslider_direction_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable  Display the "Previous/Next" Buttons', 'wbls-curtains'),
	                                'description' => __('Enable  Display the "Previous/Next" Buttons', 'wbls-curtains'),
	                                'default' => 1,
	                            ),
	                            'flexslider_control_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Display the slideshow pagination', 'wbls-curtains'),
	                                'description' => __('Enable Display the slideshow pagination', 'wbls-curtains'),
	                                'default' => 1,
	                            ),
	                            'flexslider_keyboard_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Keyboard Navigation', 'wbls-curtains'),
	                                'description' => __('Enable keyboard navigation', 'wbls-curtains'),
	                                'default' => 1,
	                            ),
	                            'flexslider_mousewheel_nav' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Mouse Wheel Navigation', 'wbls-curtains'),
	                                'description' => __('Enable the mousewheel navigation', 'wbls-curtains'),
	                                'default' => 1,
	                            ),
	                            'flexslider_pauseplay' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Pause / Play event', 'wbls-curtains'),
	                                'description' => __('Enable the "Pause/Play" event', 'wbls-curtains'),
	                                'default' => 0,
	                            ),
	                            'flexslider_randomize' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Random Slides', 'wbls-curtains'),
	                                'description' => __('Enable to Randomize the order of slides in slideshows', 'wbls-curtains'),
	                                'default' => 0,
	                            ),
	                            'flexslider_animation_loop' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Loop Slideshow animations', 'wbls-curtains'),
	                                'description' => __('Enable Loop the slideshow animations', 'wbls-curtains'),
	                                'default' => 0,
	                            ),
	                            'flexslider_pause_on_action' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Pause On Action while navigation', 'wbls-curtains'),
	                                'description' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation', 'wbls-curtains'),
	                                'default' => 1,
	                            ),
	                            'flexslider_pause_on_hover' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Enable Pause On Action while hovering the slides', 'wbls-curtains'),
	                                'description' => __('Enable to Pause the slideshow autoplay when hovering over a slide', 'wbls-curtains'),
	                                'default' => 0,
	                            ),
	                            'flexslider_prev_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Previous" button', 'wbls-curtains'),
	                                'description' => __(' The text to display on the "Previous" button.', 'wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Prev'
	                            ),
	                            'flexslider_next_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Next" button', 'wbls-curtains'),
	                                'description' => __(' The text to display on the "Next" button.', 'wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Next'
	                            ),
	                            'flexslider_play_text' => array(
	                                'type' => 'text',
	                                'label' => __(' The text to display on the "Play" button', 'wbls-curtains'),
	                                'description' => __(' The text to display on the "Play" button.', 'wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Play'
	                            ),
	                            'flexslider_pause_text' => array(
	                                'type' => 'text',
	                                'label' => __('The text to display on the "Pause" button', 'wbls-curtains'),
	                                'description' => __(' The text to display on the "Pause" button.', 'wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                                'default' => 'Pause'
	                            ),

	                        ),
	                    ),
						'flex_carousel' => array(
	                        'title' => __('Flex Carousel Slider', 'wbls-curtains'),
	                        'description' => __('Flex Carousel Settings','wbls-curtains'),
	                        'fields' => array(
	                            'carousel_animation_loop' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Loop through carousel items?', 'wbls-curtains'),
	                                'default' => 0,
	                            ),
	                            'carousel_item_width' => array(
	                                'type' => 'text',
	                                'label' => __('Carousel item width', 'wbls-curtains'),
	                                'default' => 270,
	                                'sanitize_callback' => 'absint'
	                            ),
	                            'carousel_item_margin' => array(
	                                'type' => 'text',
	                                'label' => __('Carousel item margin', 'wbls-curtains'),
	                                'default' => 5,
	                                'sanitize_callback' => 'absint'
	                            ),
	                            'carousel_pagination' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Carousel Pagination', 'wbls-curtains'),
	                                'default' => 0,

	                            ),
	                        ),
                		),
						'light_box' => array(    
	                        'title' => __('Light Box', 'wbls-curtains'),
	                        'description' => __('Light Box Settings ','wbls-curtains'),
	                        'fields' => array(
	                            'lightbox_theme' => array(
	                                'type' => 'select',
	                                'label' => __('Lightbox Theme', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                                'choices' => array(
	                                    '1' => __('pp_default', 'wbls-curtains'),
	                                    '2' => __('light-rounded', 'wbls-curtains'),
	                                    '3' => __('dark-rounded', 'wbls-curtains'),
	                                    '4' => __('light-square', 'wbls-curtains'),
	                                    '5' => __('dark-square', 'wbls-curtains'),
	                                    '6' => __('facebook', 'wbls-curtains'),
	                                ),
	                                'default' => '1',
	                            ),
	                            'lightbox_animation_speed' => array(
	                                'type' => 'select',
	                                'label' => __('Animation Speed', 'wbls-curtains'),
	                                'description' => __('', 'wbls-curtains'),
	                                'choices' => array(
	                                    'fast' => __('Fast', 'wbls-curtains'),
	                                    'slow' => __('Slow', 'wbls-curtains'),
	                                    'normal' => __('Normal', 'wbls-curtains'),
	                                ),
	                                'default' => 'fast',
	                            ),
	                            'lightbox_slideshow' => array( 
	                                'type' => 'range',
	                                'label' => __('Autoplay Gallery Speed', 'wbls-curtains'),
	                                'description' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)', 'wbls-curtains'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 100,
	                                    'step' => 10,
	                                ),
	                                'default' => 50,
	                            ),
	                            'lightbox_autoplay_slideshow' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable Autoplay Gallery', 'wbls-curtains'),
	                                'description' => __('Check to autoplay the lightbox gallery', 'wbls-curtains'),
	                                'default' => 0,
	                            ),
	                            'lightbox_opacity' => array(
	                                'type' => 'range',
	                                'label' => __('Select Background Opacity', 'wbls-curtains'),
	                                'description' => __('Enter 0.1 to 1.0', 'wbls-curtains'),
	                                'input_attrs' => array(
	                                    'min' => 0,
	                                    'max' => 1,
	                                    'step' => 0.1
	                                ),
	                                'default' => 0.5
	                            ),
	                           /* 'lightbox_show_title' => array( 
	                                'type' => 'checkbox',
	                                'label' => __('Check to show  visibility of the title', 'wbls-curtains'),
	                                'description' => __('Select visibility of the title', 'wbls-curtains'),
	                                'default' => 1,
	                            ),*/
	                            'lightbox_overlay_gallery' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Show Gallery Thumbnails', 'wbls-curtains'),
	                                'description' => __('Check to show gallery thumbnails', 'wbls-curtains'),
	                                'default' => 1,
	                            ),
	                          /*  'lightbox_social_tools' => array(
	                                'type' => 'checkbox',
	                                'label' => __(' Show social sharing icons', 'wbls-curtains'),
	                                'description' => __('Check to show social sharing icons', 'wbls-curtains'),
	                                'default' => 1,
	                            ),*/

	                        ),
                		),
						'analytics_section' => array(
	                        'title' => __('Tracking Code', 'wbls-curtains'),
	                        'description' => __('Tracking Code','wbls-curtains'),
	                        'fields' => array(
		                        'analytics' => array(
	                                'type' => 'textarea',
	                                'label' => __('Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-curtains'),
	                                'description' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_text_field',
	                            ),
	                            'analytics_place' => array(
	                                'type' => 'checkbox',
	                                'label' => __('Enable to Load Tracking Code in Footer', 'wbls-curtains'),
	                                'description' => __('Check to load analytics in footer. Uncheck to load in header.', 'wbls-curtains'),
	                                'default' => 0,  
	                            ),                   
	                        ),
	                    ),
                        'custom_js_section' => array(
	                        'title' => __(' Custom Js', 'wbls-curtains'),
	                        'description' => __('Custom Js','wbls-curtains'),
	                        'fields' => array(
		                        'custom_js' => array(
	                                'type' => 'textarea',
	                                'label' => __('Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-curtains'),
	                                'description' => __('','wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_text_field',  
                            	),                   
	                        ),
	                    ),
	                    'custom_css_section' => array(
	                        'title' => __(' Custom CSS', 'wbls-curtains'),
	                        'description' => __('Custom CSS','wbls-curtains'),
	                        'fields' => array(
		                        'custom_css' => array(
	                                'type' => 'textarea',
	                                'label' => __('Custom CSS: Quickly add some CSS to your theme by adding it to this block.', 'wbls-curtains'),
	                                'description' => __('','wbls-curtains'),
	                                'sanitize_callback' => 'sanitize_text_field',
                                ),                   
	                        ),
	                    ),
                        	
                            

					),
				),


    		); // pro theme option end //

			$options = array_merge($free_options, $pro_options);
			return $options;

		}
	}
}