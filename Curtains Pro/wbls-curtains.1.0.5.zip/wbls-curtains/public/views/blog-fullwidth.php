<?php 
/*
	Template Name: Blog Full Width
 */
 	get_header();
?>
  	   

	<?php do_action('curtains_before_content'); ?>

	<div id="content" class="site-content">
	<div class="container">

		<div id="primary" class="content-area sixteen columns">

			<main id="main" class="site-main" role="main">
				<?php
					$query_string ="post_type=post&paged=$paged"; 
					query_posts($query_string);
					$num_of_posts = $wp_query->post_count;
				?>		
					
<?php if ( have_posts() ) : ?>
<?php /* Start the Loop */ ?>
	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<div class="entry-content">        
			<?php	$featured_image = get_theme_mod('featured_image',true); 
					$featured_image_size = get_theme_mod ('featured_image_size','1');?>
					<div class="thumb blog-thumb">
				 		<?php  if( $featured_image ) : ?>    
						
							<?php if( $featured_image_size == '1' ) :
									if( has_post_thumbnail() && ! post_password_required() ) :   
										the_post_thumbnail('wbls-curtains-blog-full-width'); 		
									else :
										echo '<img src="' . get_stylesheet_directory_uri()  . '/images/no-image-blog-full-width.png" />';						
									endif;
								else: 
									if( has_post_thumbnail() && ! post_password_required() ) :   
										the_post_thumbnail('wbls-curtains-small-featured-image-width');
									else :
										echo '<img src="' . get_stylesheet_directory_uri()  . '/images/no-image-small-featured-image-width.png" />';
									endif;
								endif;
							?>
							<span class="date-structure posted-on">	    			
								<span class="dd"><?php the_time('j'); ?></span>   
								<span class="mm"><?php the_time('M'); ?></span>
							</span>

						<?php else: ?>
							<span class="date-structure posted-on top-date">				
								<span class="dd"><?php the_time('j'); ?></span>
								<span class="mm"><?php the_time('M'); ?></span>
							</span>
						<?php endif; ?>
					</div>

		<div class="entry-body">
			<h3 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h3>
			<?php if ( get_theme_mod('enable_single_post_top_meta',true ) ): ?>
			<div class="entry-meta">
				<?php if(function_exists('wbls_curtains_entry_top_meta') ) {
							     wbls_curtains_entry_top_meta();
							} ?>
			</div><!-- .entry-meta -->						
			<?php endif; ?>			
				<?php echo the_content(); ?>
				<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
				<footer class="entry-footer">
				<?php if(function_exists('wbls_curtains_entry_bottom_meta') ) {
				     wbls_curtains_entry_bottom_meta();
				} ?>
				</footer><!-- .entry-footer -->
			<?php endif;?>	
			</div>

		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'wbls-curtains' ),
				'after'  => '</div>',
			) );
		?>
		<br class="clear" />
	</div><!-- .entry-content -->
			
</article><!-- #post-## -->
     <?php endwhile; ?>

		<?php 
			if(  get_theme_mod ('numeric_pagination',true) && function_exists( 'wbls_curtains_pagination' ) ) : 
					wbls_curtains_pagination();
				else :
					wbls_curtains_post_nav();     
				endif; 
		?>

		<?php else : ?>

			<?php get_template_part( 'content', 'none' ); ?>

		<?php endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->
	
		
<?php get_footer(); ?>