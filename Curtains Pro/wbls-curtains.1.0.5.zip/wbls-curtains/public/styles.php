<?php
$custom = '';	
	$sticky_header_position = get_theme_mod('sticky_header_position') ;
	if( $sticky_header_position == 'bottom') {
		$custom .= ".site-header-sticky #nav-wrap {  top: auto!important;
			bottom:0%; border-top: 6px solid #282828; border-bottom:0; }"."\n";	
		$custom .= ".site-header-sticky #nav-wrap  .nav-menu .sub-menu {  top: auto;
			bottom:100%;  }"."\n";    	
	}	

    $portfolio_filter = get_theme_mod('portfolio_filter',1);

	switch ($portfolio_filter) {
		case 2:
			$custom .= " #filters .filter-options li:first-child {
		       	display: none;
		    }"."\n";
			break;
		case 3:
			$custom .= " #filters .filter-options {
		       	display: none;
		    }"."\n";
			break;
	}
	$page_title_bar = get_theme_mod('page_titlebar');
     switch ($page_title_bar) {
     	case 2:
     		$custom .= ".site-header .header-bottom {
     			background-color: transparent;
                    background-image: none;
     		}"."\n";
               $custom .= ".breadcrumb-wrap .breadcrumb #crumbs span i{
                   color:#ffffff;
                    
               }"."\n";
     		break;     	
     	case 3:
     		$custom .= ".header-bottom {
     			display: none;
     		}"."\n";
     		break;		
     }

     $page_title_bar_status = get_theme_mod('page_titlebar_text');
     if( $page_title_bar_status == 2 ) {
     	    $custom .= ".header-bottom .page-title  {
     			display: none;
     		}"."\n";
     }

     /* home page header style  */
     if( get_theme_mod('enable_slider',true) ) {
          $custom .= ".home .site-header {
               background-image: none;
               position: fixed;
          }"."\n";
     }

	//Output all the styles
	wp_add_inline_style( $this->plugin_name, $custom );	  
