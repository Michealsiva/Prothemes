<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts
 *
 * @param $layouts
 */
if (!function_exists('webulous_prebuilt_page_layouts') ) {   
function webulous_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-curtains'),
    'description' => __('Pre Built Layout for  home page', 'wbls-curtains'),
    'widgets' =>  array(
             0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'src' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/home-oval.png',
            'href' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/home-oval.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '87e96dc4-c892-436b-a914-247b036471ad',
              'style' => 
              array (
                'class' => 'home-bg',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Responsive Layout',
            'text' => 'Curtain is fully Responsive and can adapt to any screen size. Resize your browser window to view it!',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'cd71a2f9-f8df-44d6-ac6e-b1dd3772b9bf',
              'style' => 
              array (
                'class' => 'home-icon-left',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Retina Ready',
            'text' => 'Curtain is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution Retina displays of all sizes!',
            'icon' => 'fa-magic',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '48879d67-b057-4e85-8850-0a51d1e10549',
              'style' => 
              array (
                'class' => 'home-icon-right',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Page Builder',
            'text' => 'Curtain supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page Builder visual editor.',
            'icon' => 'fa-plus',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 2,
              'cell' => 0,
              'id' => 3,
              'widget_id' => '25e89918-0a09-4449-816b-e88c3ee88a85',
              'style' => 
              array (
                'class' => 'home-icon-left',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Font Awesome',
            'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
            'icon' => 'fa-flag',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 2,
              'cell' => 2,
              'id' => 4,
              'widget_id' => '18944cec-b821-40b4-87d9-cf552d40a067',
              'style' => 
              array (
                'class' => 'icons-right',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => 'Typography',
            'text' => 'Curtain loves Typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
            'icon' => 'fa-font',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 3,
              'cell' => 0,
              'id' => 5,
              'widget_id' => '511e64c2-122a-4eb2-b218-bc1e3df582ee',
              'style' => 
              array (
                'class' => 'home-icon-left',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'title' => 'Social Media',
            'text' => 'Want your users to stay in touch? No problem, Curtain has Social Media icons all throughout the theme!',
            'icon' => 'fa-skype',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 3,
              'cell' => 2,
              'id' => 6,
              'widget_id' => '876e39fd-06c8-4d7b-b0dc-3cd983398aa2',
              'style' => 
              array (
                'class' => 'icons-right',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'bottom-gap',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          2 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '35px',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          3 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'bottom-gap',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.45983935742971999,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.11951815277140999,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.42064248979886998,
          ),
          4 => 
          array (
            'grid' => 2,
            'weight' => 0.36965899670828001,
          ),
          5 => 
          array (
            'grid' => 2,
            'weight' => 0.27279684946827998,
          ),
          6 => 
          array (
            'grid' => 2,
            'weight' => 0.35754415382344001,
          ),
          7 => 
          array (
            'grid' => 3,
            'weight' => 0.45412824163325999,
          ),
          8 => 
          array (
            'grid' => 3,
            'weight' => 0.12240850958309001,
          ),
          9 => 
          array (
            'grid' => 3,
            'weight' => 0.42346324878364999,
          ),
        ),
      ),
      'builder_id' => '57ceab7319369',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '4b2dde5b-5baa-4d1d-a02a-becf99ed3303',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '2',
            'type' => 'normal',
            'content' => 'Our Clients',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'feb43631-fe5a-4ec9-8559-1f631f6f5916',
              'style' => 
              array (
                'class' => 'heading-center clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Testimonials',
            'count' => '5',
            'panels_info' => 
            array (
              'class' => 'Wbls_Testimonial_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '3e51aafe-a356-4ae7-964a-7084be7b2c6c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => 'full',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '57ceab73193fd',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'b6cd28b0-4359-43f5-9e0b-b11aa92b173a',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Creative Team',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. ',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'fca42d0f-e939-405b-947c-87da24b21ade',
              'style' => 
              array (
                'class' => 'top-head',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-three.png',
            'title' => 'Alexander Solomon',
            'designation' => 'CEO',
            'linkedin' => 'http://Linkedin.com',
            'google' => 'http://Google.com',
            'twitter' => 'http://Twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '3cd01851-d02b-4e6a-80d6-df72e58f4d71',
              'style' => 
              array (
                'class' => 'team-odd',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-two.png',
            'title' => 'Kate Smith',
            'designation' => 'Designer',
            'linkedin' => 'http://Linkedin.com',
            'google' => 'http://Google.com',
            'twitter' => 'http://Twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => 'd457beb1-b997-40a3-9105-cd15eb4e0650',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-six.png',
            'title' => 'Michael Doe',
            'designation' => 'Developer',
            'linkedin' => 'http://Linkedin.com',
            'google' => 'http://Google.com',
            'twitter' => 'http://Twitter.com',
            'facebook' => 'http://Facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 2,
              'cell' => 0,
              'id' => 3,
              'widget_id' => '47847e11-3ddc-45f1-87ce-04014dbbc1d5',
              'style' => 
              array (
                'class' => 'team-odd',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-one.png',
            'title' => ' Debbie Brown',
            'designation' => 'Manager',
            'linkedin' => 'http://Linkedin.com',
            'google' => 'http://Google.com',
            'twitter' => 'http://Twitter.com',
            'facebook' => 'http://Facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 2,
              'cell' => 1,
              'id' => 4,
              'widget_id' => 'ecd5daec-1368-4bc8-9770-b21fc9a3faa9',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-five.png',
            'title' => 'David Burton',
            'designation' => 'Programmer',
            'linkedin' => 'http://linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 3,
              'cell' => 0,
              'id' => 5,
              'widget_id' => '1ad2b345-23be-49b7-a07e-15991c662572',
              'style' => 
              array (
                'class' => 'team-odd',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-four.png',
            'title' => 'Kate Smith',
            'designation' => 'Photographer',
            'linkedin' => 'http://linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 3,
              'cell' => 1,
              'id' => 6,
              'widget_id' => '7d0ac34e-52d1-497c-a257-e0a36461e574',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          2 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
          3 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          3 => 
          array (
            'grid' => 2,
            'weight' => 0.5,
          ),
          4 => 
          array (
            'grid' => 2,
            'weight' => 0.5,
          ),
          5 => 
          array (
            'grid' => 3,
            'weight' => 0.5,
          ),
          6 => 
          array (
            'grid' => 3,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '57ceab731945d',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '9c4b10c0-a0de-4349-9279-75de542e2d3a',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Recent Works',
            'text' => 'Fusce pretium turpis eu porttitor tristique. Quisque viverra fringilla lorem In hac habitasse platea dictumst.',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'top-head clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'count' => '12',
            'type' => 'isotope',
            'panels_info' => 
            array (
              'class' => 'Wbls_Recent_Work_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => 'recent-work-normal',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'like our creative works? grab this perfect theme now',
            'content' => '',
            'anchor_text' => 'Purchase Now',
            'url' => 'www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Cta_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 2,
              'style' => 
              array (
                'class' => 'cta-white top-gap',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '55cdd2b743f7d',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '4075bfae-2f6a-4f17-bbed-cbeaa518a037',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '481',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '482',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '483',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '484',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 3,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => 'full-width-darkprimary',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 0,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '5673a6cddaa89',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '063e4d53-774a-45b1-8d7f-a65bfa3ae40d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Recent Posts',
      'count' => '3',
      'type' => 'normal',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Posts_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '492a481c-4e59-424e-b8ff-f2bcef90f156',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'slider' => 'clients',
            'type' => 'carousel',
            'panels_info' => 
            array (
              'class' => 'Wbls_FlexSlider_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '56b9912a9086c',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 6,
        'widget_id' => 'fd86b26e-1c81-4a0a-ac58-34da9f2ad23d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'home-icon-wrapper standard-width animation-row1',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern wide-pattern-black animation-row2',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-blue-pattern panel-row-style-full-width-layout animation-row4',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern animation-row5',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout animation-row6',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout-carousel full-width-grey-pattern animation-row7',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    
    ),

  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-curtains'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-curtains'),
    'widgets' => array(
            0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '2',
            'type' => 'normal',
            'content' => 'about us',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '55a54d6f-01d8-4ff7-a4a2-bd6c901f1329',
              'style' => 
              array (
                'class' => 'heading-center',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/about-us.png',
            'href' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/about-us.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'c11da71d-7017-40d4-9e13-2c405e1ee87e',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'title' => 'Responsive Layout',
                  'text' => 'Curtain is fully Responsive and can adapt to any screen size. Resize your browser window to view it!',
                  'icon' => 'fa-mobile',
                  'icon_background_color' => '',
                  'icon_size' => '4x',
                  'icon_placement' => 'left',
                  'more' => 'Read',
                  'more_url' => 'www.webulousthemes.com',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => true,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'SOCIAL MEDIA',
                  'text' => 'Want your users to stay in touch? No problem, Curtain has Social Media icons all throughout the theme!',
                  'icon' => 'fa-skype',
                  'icon_background_color' => '',
                  'icon_size' => '4x',
                  'icon_placement' => 'left',
                  'more' => 'Read',
                  'more_url' => 'www.webulousthemes.com',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 1,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'title' => 'TYPOGRAPHY',
                  'text' => 'Curtain loves Typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
                  'icon' => 'fa-font',
                  'icon_background_color' => '',
                  'icon_size' => '4x',
                  'icon_placement' => 'left',
                  'more' => 'Read',
                  'more_url' => 'www.webulousthemes.com',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 2,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                3 => 
                array (
                  'btntext' => 'LEARN MORE',
                  'url' => 'www.Webulousthemes.com',
                  'target' => '_blank',
                  'size' => 'btn-large',
                  'color' => 'btn-default',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Button_Widget',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 3,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 1,
                ),
              ),
            ),
            'builder_id' => '55cc76ce91591',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '8269a163-1dd2-489c-bb0c-61fcd4c1b7f5',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '57cead13c10de',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'fbf40555-1ff8-44cc-8018-5df4877fc230',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'level' => '2',
      'type' => 'normal',
      'content' => 'Our Clients',
      'panels_info' => 
      array (
        'class' => 'Wbls_Heading_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '2bd110b1-c1d1-4400-8271-79007800ffdb',
        'style' => 
        array (
          'class' => 'heading-center clr-white',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Testimonials',
      'count' => '5',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '9cccffb2-17f9-47ea-b99c-20a718314fcf',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Creative Team',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. ',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '01947029-7209-4d28-8f88-4161ce61705c',
              'style' => 
              array (
                'class' => 'top-head',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-three.png',
            'title' => 'Alexander Solomon',
            'designation' => 'CEO',
            'linkedin' => 'http://linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '0ab84d76-f2cd-4960-b4f2-0fe132e54e99',
              'style' => 
              array (
                'class' => 'team-odd',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-two.png',
            'title' => 'Kate Smith',
            'designation' => 'Designer',
            'linkedin' => 'http://linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => 'fd58d6db-8cd2-460a-a242-2c091d0c2a48',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-six.png',
            'title' => 'Michael Doe',
            'designation' => 'Developer',
            'linkedin' => 'http://linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 2,
              'cell' => 0,
              'id' => 3,
              'widget_id' => '73d1c07f-67d6-4436-81cb-1151436e36b1',
              'style' => 
              array (
                'class' => 'team-odd',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-one.png',
            'title' => 'Debbie Brown',
            'designation' => 'Manager',
            'linkedin' => 'http://linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 2,
              'cell' => 1,
              'id' => 4,
              'widget_id' => 'e861e82e-4de0-4934-90d3-cb6a6e7cf6ea',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-five.png',
            'title' => 'David Burton',
            'designation' => 'Programmer',
            'linkedin' => 'http://linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 3,
              'cell' => 0,
              'id' => 5,
              'widget_id' => 'b94e6c91-d699-4cca-8c18-1359e8c8cd73',
              'style' => 
              array (
                'class' => 'team-odd',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus volutpat ultricies orci, in cursus eros lobortis at. Maecenas eget urna in ipsum consequat porttitor semper eu elit. Sed sit amet odio sit amet ipsum tristique suscipit. Donec semper faucibus dolor vitae eleifend. ',
            'image_url' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/ourteam-four.png',
            'title' => 'Kate Smith',
            'designation' => 'Photographer',
            'linkedin' => 'http://linkedin.com',
            'google' => 'http://google.com',
            'twitter' => 'http://twitter.com',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 3,
              'cell' => 1,
              'id' => 6,
              'widget_id' => 'a91f0502-1372-49d5-a5bc-c47e121e4d16',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          2 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
          3 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          3 => 
          array (
            'grid' => 2,
            'weight' => 0.5,
          ),
          4 => 
          array (
            'grid' => 2,
            'weight' => 0.5,
          ),
          5 => 
          array (
            'grid' => 3,
            'weight' => 0.5,
          ),
          6 => 
          array (
            'grid' => 3,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '57cead5c6a36e',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 2,
        'cell' => 0,
        'id' => 3,
        'widget_id' => 'c698a3df-c41c-4bda-b8d5-35eeaf72a4c8',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'content' => '',
      'title' => 'LIKE OUR CREATIVE WORKS? GRAB THIS PERFECT THEME NOW',
      'url' => 'www.Webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '431fbaf4-dd6d-4079-a087-ee77bd747986',
        'style' => 
        array (
          'class' => 'cta-white ',
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'bottom-gap',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern wide-pattern-black',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-blue-pattern panel-row-style-full-width-layout-carousel',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
        ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'wbls-curtains'),
      'description' => __( 'Pre Built layout for features page', 'wbls-curtains'),
      'widgets' => array(
             0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'type' => 'polygon',
            'title' => 'RESPONSIVE LAYOUT',
            'text' => 'Curtain is fully responsive and can adapt to any screen size. Resize your browser window to view it!',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'type' => 'polygon',
            'title' => 'AWESOME SLIDERS',
            'text' => 'Curtain includes Flex slider. You can use Flex slider anywhere in your site.',
            'icon' => 'fa-random',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'type' => 'polygon',
            'title' => 'FONT AWESOME',
            'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
            'icon' => 'fa-flag',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'type' => 'polygon',
            'title' => 'TYPOGRAPHY',
            'text' => 'Curtain loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
            'icon' => 'fa-font',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 3,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'type' => 'polygon',
            'title' => 'EXCELLENT SUPPORT',
            'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
            'icon' => 'fa-thumb-tack',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 4,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'type' => 'polygon',
            'title' => 'RETINA READY',
            'text' => 'Curtain is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
            'icon' => 'fa-magic',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 5,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'title' => 'LIKE OUR CREATIVE WORKS? GRAB THIS PERFECT THEME NOW',
            'content' => '',
            'anchor_text' => 'Purchase Now',
            'url' => 'www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Cta_Widget',
              'raw' => false,
              'grid' => 2,
              'cell' => 0,
              'id' => 6,
              'style' => 
              array (
                'class' => 'cta-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          7 => 
          array (
            'type' => 'polygon',
            'title' => 'ADVANCED ADMIN',
            'text' => 'Curtain uses advanced Redux Framework for theme options panel, you can customize any part of your site quickly and easily!',
            'icon' => 'fa-cog',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 3,
              'cell' => 0,
              'id' => 7,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          8 => 
          array (
            'type' => 'polygon',
            'title' => 'PAGE BUILDER',
            'text' => 'Curtain supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
            'icon' => 'fa-plus',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 3,
              'cell' => 1,
              'id' => 8,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          9 => 
          array (
            'type' => 'polygon',
            'title' => 'PAGE LAYOUTS',
            'text' => 'Curtain offers many different page layouts so you can quickly and easily create your pages with no hassle!',
            'icon' => 'fa-copy (alias)',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 3,
              'cell' => 2,
              'id' => 9,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          10 => 
          array (
            'type' => 'polygon',
            'title' => 'CUSTOM WIDGET',
            'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
            'icon' => 'fa-beer',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 4,
              'cell' => 0,
              'id' => 10,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          11 => 
          array (
            'type' => 'polygon',
            'title' => 'SHORTCODE BUILDER',
            'text' => 'Curtain inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
            'icon' => 'fa-check',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 4,
              'cell' => 1,
              'id' => 11,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          12 => 
          array (
            'type' => 'polygon',
            'title' => 'DEMO CONTENT',
            'text' => 'Curtain includes demo content files. You can quickly setup the site like our demo and get started easily!',
            'icon' => 'fa-times',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 4,
              'cell' => 2,
              'id' => 12,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          13 => 
          array (
            'title' => 'LIKE OUR CREATIVE WORKS? GRAB THIS PERFECT THEME NOW',
            'content' => '',
            'anchor_text' => 'Purchase Now',
            'url' => 'www.webulousthemes.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Cta_Widget',
              'raw' => false,
              'grid' => 5,
              'cell' => 0,
              'id' => 13,
              'style' => 
              array (
                'class' => 'cta-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          14 => 
          array (
            'type' => 'polygon',
            'title' => 'WOO COMMERCE',
            'text' => 'Curtain has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!',
            'icon' => 'fa-shopping-cart',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 6,
              'cell' => 0,
              'id' => 14,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          15 => 
          array (
            'type' => 'polygon',
            'title' => 'SOCIAL MEDIA',
            'text' => 'Want your users to stay in touch? No problem, Curtain has Social Media icons all throughout the theme!',
            'icon' => 'fa-skype',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 6,
              'cell' => 1,
              'id' => 15,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          16 => 
          array (
            'type' => 'polygon',
            'title' => 'GOOGLE MAP',
            'text' => 'Curtain includes Google Map as shortcode and widget. So, you can use it anywhere in your site!',
            'icon' => 'fa-map-marker',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 6,
              'cell' => 2,
              'id' => 16,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          17 => 
          array (
            'type' => 'polygon',
            'title' => 'MULTIPLE PORTFOLIO',
            'text' => '7 portfolio layouts, 3 blog layouts and multiple other alternate layouts for interior pages!',
            'icon' => 'fa-list-alt',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 7,
              'cell' => 0,
              'id' => 17,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          18 => 
          array (
            'type' => 'polygon',
            'title' => 'MULTIPLE SIDEBAR',
            'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
            'icon' => 'fa-columns',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 7,
              'cell' => 1,
              'id' => 18,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          19 => 
          array (
            'type' => 'polygon',
            'title' => 'CUSTOMIZATION',
            'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
            'icon' => 'fa-edit (alias)',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 7,
              'cell' => 2,
              'id' => 19,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          2 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'full-width-blue-pattern panel-row-style-full-width-layout-carousel ',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          3 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          4 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          5 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'full-width-blue-pattern panel-row-style-full-width-layout-carousel ',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          6 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          7 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33423810508316998,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33242856158349998,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          5 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          6 => 
          array (
            'grid' => 2,
            'weight' => 1,
          ),
          7 => 
          array (
            'grid' => 3,
            'weight' => 0.33333333333332998,
          ),
          8 => 
          array (
            'grid' => 3,
            'weight' => 0.33333333333332998,
          ),
          9 => 
          array (
            'grid' => 3,
            'weight' => 0.33333333333332998,
          ),
          10 => 
          array (
            'grid' => 4,
            'weight' => 0.33333333333332998,
          ),
          11 => 
          array (
            'grid' => 4,
            'weight' => 0.33333333333332998,
          ),
          12 => 
          array (
            'grid' => 4,
            'weight' => 0.33333333333332998,
          ),
          13 => 
          array (
            'grid' => 5,
            'weight' => 1,
          ),
          14 => 
          array (
            'grid' => 6,
            'weight' => 0.33333333333332998,
          ),
          15 => 
          array (
            'grid' => 6,
            'weight' => 0.33333333333332998,
          ),
          16 => 
          array (
            'grid' => 6,
            'weight' => 0.33333333333332998,
          ),
          17 => 
          array (
            'grid' => 7,
            'weight' => 0.33333333333332998,
          ),
          18 => 
          array (
            'grid' => 7,
            'weight' => 0.33333333333332998,
          ),
          19 => 
          array (
            'grid' => 7,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '569c90c6e72fc',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout-carousel full-width-black-pattern',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-curtains'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-curtains'),
      'widgets' => array(
            0 => 
    array (
      'title' => 'Contact Us',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'class' => 'contact-head tcenter',
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '[contact-form-7 id="124" title="Contact-Us-Left"]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'contact-limit',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[contact-form-7 id="125" title="Contant-Us-Right"]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Email',
            'text' => 'Info@gmail.com',
            'icon' => 'fa-envelope',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => 'contact-details',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Phone',
            'text' => '+1 (234) 56789',
            'icon' => 'fa-phone',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'style' => 
              array (
                'class' => 'contact-details',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Fax',
            'text' => '+1 (456) 45789',
            'icon' => 'fa-suitcase',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'style' => 
              array (
                'class' => 'contact-details',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => '',
            'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d6305.992774595653!2d-122.41157430890459!3d37.790124433800656!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858091edff45bd%3A0x70c4586b1202a605!2sUSA+Hostels+San+Francisco!5e0!3m2!1sen!2sin!4v1407318894507" width="1200" height="500" frameborder="0" style="border:0; box-shadow: 0px 0px 50px #606060"></iframe>',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 2,
              'cell' => 0,
              'id' => 5,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => 'contact-text standard-width',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 5,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          2 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'standard-width',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.093574297188755193,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.26434153447457054,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.28416833667335062,
          ),
          5 => 
          array (
            'grid' => 1,
            'weight' => 0.26626506024096058,
          ),
          6 => 
          array (
            'grid' => 1,
            'weight' => 0.091650771422363192,
          ),
          7 => 
          array (
            'grid' => 2,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '56b9980db5567',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'content' => '',
      'title' => 'LIKE OUR CREATIVE WORKS? GRAB THIS PERFECT THEME NOW',
      'url' => 'www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'class' => 'cta-white ',
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-blue-pattern panel-row-style-full-width-layout-carousel',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-curtains'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-curtains'),
    'widgets' =>  array(
          0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '2',
            'type' => 'normal',
            'content' => 'FAQ\'S',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'heading-center',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[accordion_group][accordion title=" Suspendisse massa odio"]Ut at lacinia erat. Aliquam lacus ex, tristique vitae quam nec, egestas scelerisque elit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nunc tempor quam eu posuere porttitor. Etiam quis lectus est. Morbi ac gravida odio. Aliquam efficitur nisl orci, ac vestibulum ipsum blandit id. Aliquam lacinia eget sapien nec pulvinar. Praesent nibh erat, imperdiet non ornare euismod, rutrum ut mi. Quisque et risus in dolor porttitor iaculis.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu  Etiam semper tortor arcu, volutpat consequat est convallis eu. Nulla posuere neque quis mi laoreet volutpat.[/accordion][accordion title=" Praesent condimentum metus mauris"]In id lectus sed justo rhoncus luctus. Praesent imperdiet, massa et cursus sollicitudin, nibh tellus ullamcorper magna, eu fringilla est mi id magna. Etiam elit ex, pulvinar quis vehicula vitae, molestie eget ante. In hac habitasse platea dictumst. Duis turpis risus, ultricies sit amet libero pharetra, vestibulum imperdiet nisi. Integer sapien orci, placerat eu pretium a, faucibus eget massa. Nam gravida nisi eget felis consectetur, nec vestibulum urna malesuada.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu Integer nec faucibus sem, vitae molestie arcu. [/accordion][accordion title="Vivamus dignissim dolor fermentum."]Donec ornare scelerisque convallis. Integer at erat in dolor fringilla ornare ut vitae est. Vivamus vulputate bibendum ex ac pulvinar. Cras tincidunt lorem elementum, mollis felis ut, tristique ante. Cras mattis ante a metus dapibus, nec sollicitudin massa blandit. Sed eget augue eget leo elementum porta eu non augue. Aenean ac diam eget orci molestie eleifend id et ipsum. Quisque ac tellus ac ligula condimentum fermentum. Donec congue lorem nec pellentesque efficitur. Sed imperdiet molestie nibh efficitur feugiat. Mauris scelerisque et neque sed pellentesque. Vivamus finibus lectus ut erat bibendum bibendum. Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu[/accordion][accordion title="Mauris auctor vulputate urna"]Aenean laoreet, dolor sit amet faucibus finibus, sem sem interdum velit, et egestas libero enim sit amet libero. Maecenas nec nisi ut nibh luctus lacinia eu id magna. Duis sed arcu ipsum. Sed dictum a nisi vel pellentesque. Maecenas semper posuere rhoncus. Sed consectetur nibh felis, quis porttitor velit gravida eget. Donec lectus dolor, tincidunt finibus quam vitae, vulputate gravida ipsum. Integer blandit velit ante, eu placerat ligula mollis eget. Suspendisse elit metus, mollis at vehicula in, venenatis ut purus. Integer mollis scelerisque est, at congue nisi aliquam quis. Nulla vitae purus id nisl cursus tempor. Integer nibh risus, feugiat nec dui sed, dapibus tincidunt tortor. Pellentesque porta scelerisque lorem, sit amet porta dui. Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu [/accordion][accordion title="Praesent pulvinar pretium magna"] Sed dictum a nisi vel pellentesque. Maecenas semper posuere rhoncus. Sed consectetur nibh felis, quis porttitor velit gravida eget. Donec lectus dolor, tincidunt finibus quam vitae, vulputate gravida ipsum. Integer blandit velit ante, eu placerat ligula mollis eget. Suspendisse elit metus, mollis at vehicula in, venenatis ut purus. Integer mollis scelerisque est, at congue nisi aliquam quis. Nulla vitae purus id nisl cursus tempor. Integer nibh risus, feugiat nec dui sed, dapibus tincidunt tortor. Pellentesque porta scelerisque lorem, sit amet porta dui.Aenean laoreet, dolor sit amet faucibus finibus, sem sem interdum velit, et egestas libero enim sit amet libero. Maecenas nec nisi ut nibh luctus lacinia eu id magna. Duis sed arcu ipsum.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu  [/accordion][accordion title="Etiam eget lorem nisi Duis neque."] Maecenas nec nisi ut nibh luctus lacinia eu id magna. Duis sed arcu ipsum. Sed dictum a nisi vel pellentesque. Maecenas semper posuere rhoncus. Sed consectetur nibh felis, quis porttitor velit gravida eget. Donec lectus dolor, tincidunt finibus quam vitae, vulputate gravida ipsum. Integer blandit velit ante, eu placerat ligula mollis eget. Suspendisse elit metus, mollis at vehicula in, venenatis ut purus. Integer mollis scelerisque est, at congue nisi aliquam quis. Nulla vitae purus id nisl cursus tempor. Integer nibh risus, feugiat nec dui sed, dapibus tincidunt tortor. Pellentesque porta scelerisque lorem, sit amet porta dui.Aenean laoreet, dolor sit amet faucibus finibus, sem sem interdum velit, et egestas libero enim sit amet libero.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. Integer nec faucibus sem, vitae molestie arcu  [/accordion][accordion title="Aliquam rutrum tortor quis ultrices ultricies."]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. Cras venenatis a nibh ut placerat. Vivamus a mauris non quam pretium lobortis non ac odio. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="Curabitur rutrum vehicula enim et pulvinar."] Sed nec massa lorem. Phasellus ut tincidunt velit, id scelerisque lorem. Nullam nisl tortor, mollis ut massa in, dapibus tincidunt libero. Pellentesque pretium posuere turpis eget dignissim. Curabitur sapien lorem, feugiat et velit et, vehicula aliquet urna. Vivamus pellentesque lorem at urna suscipit, at vulputate est ultricies. Aliquam ultrices nec massa sed adipiscing. Pellentesque feugiat sodales tellus. Ut tempus aliquam felis, quis consequat nunc hendrerit eget. Praesent sollicitudin nunc eu sollicitudin placerat. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title="Pellentesque iaculis vulputate blandit."]Aliquam non lacus in lacus aliquet blandit. Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. Sed ut augue vitae augue vestibulum pulvinar. Fusce commodo ultricies volutpat. Vivamus quis nulla porta, faucibus metus eu, tempus dolor. Ut sed faucibus mi, ac volutpat lectus. Morbi a rhoncus erat. Mauris et metus posuere, imperdiet urna at, congue risus. Nunc at ante sed ipsum porttitor scelerisque semper non libero. Vivamus feugiat nisl sit amet mi tristique dictum. Donec id magna facilisis, euismod sem bibendum, interdum lorem. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][accordion title=" Vestibulum in mi mauris. Duis luctus dolor ante."]Fusce vehicula risus lorem, sed ultricies neque pellentesque at. Ut dapibus aliquam leo non cursus. Donec eros dui, fringilla vel lacinia id, tincidunt ac eros. Ut ultrices elit nec viverra adipiscing. Aliquam suscipit viverra luctus. Vivamus rhoncus molestie hendrerit. Aenean id lacinia odio. Nullam sit amet dui accumsan, ornare nisi at, ornare elit. Proin ut dolor risus. Cras quis pellentesque felis, at venenatis nibh. Quisque tincidunt id enim a aliquam. Praesent dapibus erat turpis, sodales aliquet justo consectetur eget. Nam mattis consectetur nunc nec dapibus. Nam malesuada, diam nec imperdiet luctus, lacus turpis facilisis dui, sed lobortis sem justo vitae odio. Sed tincidunt consectetur est eget sodales. In laoreet ligula id eros convallis, nec rutrum turpis tempor. [/accordion][/accordion_group]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => 'faq-acc',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '56b9b2d43feb2',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'content' => '',
      'title' => 'LIKE OUR CREATIVE WORKS? GRAB THIS PERFECT THEME NOW',
      'url' => 'www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'class' => 'cta-white',
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '150px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-blue-pattern panel-row-style-full-width-layout-carousel',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-curtains'),
    'description' => __('Pre Built Layout for services page', 'wbls-curtains'),
    'widgets' =>  array(
           0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'src' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/our-services.png',
            'href' => 'http://curtains.webulous.in/wp-content/uploads/2015/08/our-services.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '61419b90-1f6c-4704-ad11-672251dac3ee',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => 'Donec in sem ut lorem tincidunt dictum et quis nisi. Phasellus ultricies commodo convallis. Curabitur ullamcorper orci id ex ullamcorper, mattis tincidunt ex fermentum. Aenean finibus, lectus sed feugiat porttitor, erat diam vulputate urna, vitae facilisis felis risus et dolor. Integer et sapien nisl. Duis nec ipsum diam. Sed maximus condimentum urna in aliquet.Praesent pulvinar pretium magna vel dictum. Etiam convallis imperdiet lacinia. Aliquam eget euismod lorem. 

Fusce pretium bibendum dui nec elementum. Curabitur dapibus pretium nisl eget consequat. Nam aliquam ante eu nibh molestie, a mollis augue egestas. Praesent porttitor volutpat arcu a dignissim. Sed mattis urna a consectetur placerat.Etiam eget lorem nisi. Duis neque tellus, ultricies at tortor ac, pharetra facilisis nisl. Nulla mi sapien, viverra at pharetra id, venenatis eu risus. Duis faucibus, erat vitae tincidunt venenatis, leo ex commodo urna, quis blandit ipsum metus at arcu. ',
            'filter' => 'on',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'c6463144-a353-4f3a-8dc1-45a2151c32cb',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.21385542168675001,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.78614457831325002,
          ),
        ),
      ),
      'builder_id' => '57ceadfb32aae',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'b448b858-154e-4a3e-b762-4e305defe31a',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '2',
            'type' => 'normal',
            'content' => 'Our Services',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'heading-center clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'type' => 'polygon',
            'title' => 'RESPONSIVE LAYOUT',
            'text' => 'Curtain is fully responsive and can adapt to any screen size. Resize your browser window to view it!',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => '',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'type' => 'polygon',
            'title' => 'AWESOME SLIDERS',
            'text' => 'Curtains includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
            'icon' => 'fa-random',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'type' => 'polygon',
            'title' => 'FONT AWESOME',
            'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
            'icon' => 'fa-flag',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.Webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'type' => 'polygon',
            'title' => 'TYPOGRAPHY',
            'text' => 'Curtain loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
            'icon' => 'fa-font',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'more' => 'Read',
            'more_url' => 'www.Webulousthemes.com',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_CircleIcon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'style' => 
              array (
                'class' => 'clr-white',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => 'service-default',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '56b998ea0536b',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '8874931c-721b-4a85-9a59-1772390e843f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Recent Posts',
      'count' => '3',
      'type' => 'normal',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Posts_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '9541eb3d-645f-4617-adcf-56125de4a566',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'content' => '',
      'title' => 'LIKE OUR CREATIVE WORKS? GRAB THIS PERFECT THEME NOW',
      'url' => 'www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '56023536-6dd3-4936-948e-b47cf4cdf2ef',
        'style' => 
        array (
          'class' => 'cta-white',
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'standard-width ',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'panel-row-style-full-width-layout full-width-black-pattern',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'standard-width ',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'full-width-blue-pattern panel-row-style-full-width-layout-carousel',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'webulous_prebuilt_page_layouts');


function wbls_curtains_panels_row_style_fields($fields) {  

    $curtains_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-curtains'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-curtains' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-curtains' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-curtains' ),
        'bounce-animation' => __('bounce-animation','wbls-curtains' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-curtains' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-curtains' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-curtains' ),
        'expandUp-animation' => __('expandUp-animation','wbls-curtains' ),
        'fade-animation' => __('fade-animation','wbls-curtains' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-curtains' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-curtains' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-curtains' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-curtains' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-curtains' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-curtains' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-curtains' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-curtains' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-curtains' ),
        'flip-animation' => __('flip-animation','wbls-curtains' ),
        'flipInX-animation' => __('flipInX-animation','wbls-curtains' ),
        'flipInY-animation' => __('flipInY-animation','wbls-curtains' ),
        'floating-animation' => __('floating-animation','wbls-curtains' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-curtains' ),
        'hatch-animation' => __('hatch-animation','wbls-curtains' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-curtains' ),
        'puffIn-animation' => __('puffIn-animation','wbls-curtains' ),
        'pullDown-animation' => __('pullDown-animation','wbls-curtains' ),
        'pullUp-animation' => __('pullUp-animation','wbls-curtains' ),
        'pulse-animation' => __('pulse-animation','wbls-curtains' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-curtains' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-curtains' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-curtains' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-curtains' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-curtains' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-curtains' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-curtains' ),
        'scale-down-animation' => __('scale-down-animation','wbls-curtains' ),
        'scale-up-animation' => __('scale-up-animation','wbls-curtains' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-curtains' ),
        'slide-left-animation' => __('slide-left-animation','wbls-curtains' ),
        'slide-right-animation' => __('slide-right-animation','wbls-curtains' ),
        'slide-top-animation' => __('slide-top-animation','wbls-curtains' ),
        'slideDown-animation' => __('slideDown-animation','wbls-curtains' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-curtains' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-curtains' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-curtains' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-curtains' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-curtains' ),
        'slideRight-animation' => __('slideRight-animation','wbls-curtains' ),
        'slideUp-animation' => __('slideUp-animation','wbls-curtains' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-curtains' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-curtains' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-curtains' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-curtains' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-curtains' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-curtains' ),
        'swap-animation'  => __('swap-animation','wbls-curtains' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-curtains' ),
        'swing-animation'  => __('swing-animation','wbls-curtains' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-curtains' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-curtains' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-curtains' ), 
        'tossing-animation'  => __('tossing-animation','wbls-curtains' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-curtains' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-curtains' ), 
        'wobble-animation' => __('wobble-animation','wbls-curtains' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-curtains' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'curtains'),
            'type' => 'select',
            'options' => $curtains_animation_name,
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_curtains_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_curtains_panels_row_style_fields');

function wbls_curtains_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_curtains_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_curtains_panels_panels_row_style_attributes', 10, 2);

function wbls_curtains_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Animation', 'wbls-curtains'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_curtains_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_curtains_row_style_groups' );