<div class="free-home">
    <div class="services-wrapper clearfix">
         <div class="service even">  
            <div class="page-thumb">
    	    	<?php if( has_post_thumbnail() ) : ?>
                    <a href="<?php echo esc_url( get_permalink() ); ?>">              <?php the_post_thumbnail('curtains_home_page_img'); ?></a>
    	    	<?php endif; ?>
        	</div>
        	<div class="page-content">
    	    	<?php the_content(); ?>
        	</div>    
        </div>
    </div> 
</div>     

