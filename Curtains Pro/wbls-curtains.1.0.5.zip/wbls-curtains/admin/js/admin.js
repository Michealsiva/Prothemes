(function( $ ) {

	$(function() {

		docs = $('<a class="curtains-docs doc"></a>')
			.attr('href','http://www.webulousthemes.com/curtains-pro/') 
			.attr('target','_blank')
			.text('Documentation');

		support = $('<a class="curtains-docs question"></a>')
			.attr('href','http://www.webulousthemes.com/support-ticket/')
			.attr('target','_blank')
			.text('Ask a Question');

		$('#customize-info .preview-notice').append(docs);
		$('#customize-info .preview-notice').append(support);

		$('.curtains-docs').on('click',function(e){
			e.stopPropagation();
		});
		
		
	});

})( jQuery );
