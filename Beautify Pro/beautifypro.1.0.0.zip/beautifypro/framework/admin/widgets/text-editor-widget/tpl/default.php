<div class="widget-tinymce textwidget">
	<?php echo $text ?>
</div>
