<?php
$gap = sprintf( 'style="height: %1$s;"', $gap );
printf( '<div class="gap" %1$s></div>', $gap );