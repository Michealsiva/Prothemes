=== Beautify ===
Contributors: Webulous
Tags: custom-menu, featured-images, post-formats, right-sidebar, left-sidebar, sticky-post, threaded-comments, translation-ready, three-columns, two-columns, one-column, flexible-header, custom-background, custom-header, custom-colors, editor-style, full-width-template, rtl-language-support, theme-options, translation-ready
Requires at least: 4.0 
Tested up to: 4.8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Beautify is best suited for all types of site and uses Theme Customizer.
  
== Description ==   
Beautify is a beautiful and Flexible WordPress theme. Can be used for Interior,Photography,corporate business, Cafe and Restarutant.It is an attractive, modern, easy to use and responsive WordPress theme with colorful design and stunning flexibility. There is no theme options panel, instead uses Customizer, core feature of WordPress and comes with lots of options to customize. Some of the available options are awesome slider section, header options, footer options, layout design options, widget options and lots of other available options will allow you to create unique website as you want. 

== Frequently Asked Questions ==
= Installation =
1. Download and unzip `beautifypro` theme
2. Upload the `beautifypro` folder to the `/wp-content/themes/` directory
3. Activate the Theme through the 'Themes' menu in WordPress

= Setting Up Front Page =
1. By default, your front page looks like a blog. However, you can make it look like screenshot by following these steps.
2. Go to Dashboard => Appearance => Customize
3. Click on 'Static Front Page'
4. Select 'A static page' radio option
5. Select a static page for 'Front Page' and another page for 'Posts Page'


= How to Use Customizer options =

Go to Dashboard => Appearance => Customize.
Use customizer options   


== Changelog ==   

= 1.0.0 =
	* Initial Release

== Upgrade Notice == 

= 1.0.0 =
	* Initial Release

== Resources ==
* {_s}, GPLv2
* {Skeleton}, MIT
* {Flexslider} © 2015 Woo Themes, GPLv2
* {FontAwesome} © Dave Gandy, SIL OFL 1.1 and MIT   
