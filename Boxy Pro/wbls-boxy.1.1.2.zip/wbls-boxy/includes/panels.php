<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts  
 *
 * @param $layouts  
 */
if (!function_exists('wbls_boxy_prebuilt_page_layouts') ) {   
function wbls_boxy_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-boxy'),
    'description' => __('Pre Built Layout for  home page', 'wbls-boxy'),
    'widgets' =>  array(
    0 => 
    array (
      'height' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '37794fc2-bcf4-4648-9749-9725848fcb28',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'Our Services',
      'panels_info' => 
      array (
        'class' => 'Wbls_Heading_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '11777859-72b6-4949-be0c-2e3bd0d57b90',
        'style' => 
        array (
          'class' => 'heading-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Responsive Design',
      'text' => ' Boxy is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
      'icon' => 'fa-mobile-phone',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'top',
      'more' => 'read more',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '1f0f2f41-75e1-4b09-a8cc-90bd552817ac',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Retina Ready',
      'text' => 'Boxy is Retina Ready. Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!.',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'top',
      'more' => 'read more',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 3,
        'widget_id' => 'dddc3c13-2149-43a7-ba3f-00d78382a8d9',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Font Awesome',
      'text' => 'This icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!.',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => '4x',
      'icon_placement' => 'top',
      'more' => 'read more',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 4,
        'widget_id' => '925cfac8-ec2e-4cb8-938b-1d807ca8697b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'Our Team',
      'panels_info' => 
      array (
        'class' => 'Wbls_Heading_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '7d52afe2-e5a0-43d3-9706-644d5f038b92',
        'style' => 
        array (
          'class' => 'heading-center',
          'padding' => '10px',
          'background_display' => 'tile',
          'widget_bottom_margin' => '-50px',
        ),
      ),
    ),
    6 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'image_url' => 'http://boxy.webulous.in/wp-content/uploads/2016/07/Our-Team-One.png',
            'title' => 'MITCHEL',
            'designation' => 'MANAGER',
            'linkedin' => 'http://www.linkedin.com/',
            'google' => 'http://www.google.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '40f4180e-28a8-4d5a-83a4-ae35d295247e',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'image_url' => 'http://boxy.webulous.in/wp-content/uploads/2016/07/Our-Team-Two.png',
            'title' => 'EMMA',
            'designation' => 'DESIGNER',
            'linkedin' => 'http://www.linkedin.com/',
            'google' => 'http://www.google.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '1a9e217f-5ec8-408c-9fc4-006d2b9b9d3a',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'image_url' => 'http://boxy.webulous.in/wp-content/uploads/2016/07/Our-Team-Three.png',
            'title' => 'IRISH',
            'designation' => 'DEVELOPER',
            'linkedin' => 'http://www.linkedin.com/',
            'google' => 'http://www.google.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '21d866e4-a5d4-4982-b8da-a84239fa9926',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'animation_class' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '577d03fa72e8a',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 6,
        'widget_id' => 'fe18814f-61f4-4854-90fc-6f6ecf50426c',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'Tabs and Skills',
      'panels_info' => 
      array (
        'class' => 'Wbls_Heading_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '18a55757-3b82-4ea5-8439-c2af26341f74',
        'style' => 
        array (
          'class' => 'heading-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => '',
      'text' => '[tabs_group type="normal"][tabs title="HOME"]Donec faucibus lorem nec iaculis faucibus. Pellentesque placerat nulla eu mi elementum, vitae condimentum metus tincidunt. Mauris rhoncus suscipit diam, eu varius elit. Etiam vehicula commodo erat, sed facilisis nibh dapibus sit amet. Quisque egestas posuere lacus a porta. Morbi dictum varius odio sed cursus. Cras accumsan justo nunc, et mattis ligula euismod cursus. [/tabs][tabs title="ANDROID"]Curabitur suscipit, eros vitae rhoncus blandit, enim nisl iaculis mauris, vitae sollicitudin lectus tortor ut tellus. Fusce dignissim fermentum arcu eu pharetra. Proin tincidunt elit at iaculis imperdiet. Curabitur pellentesque sodales erat eget dapibus. Nam faucibus, ipsum ut consectetur fermentum, nulla massa malesuada mauris, vitae vehicula felis mi vel velit. Mauris in suscipit tortor. Etiam a felis mattis, congue nisi id, tempus elit. Ut quis imperdiet justo. Nam suscipit tristique urna et mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Morbi vitae mollis justo. Morbi tempus molestie imperdiet. Aliquam auctor eros eu nibh molestie, eu posuere metus iaculis. Nulla facilisi. Aenean vitae urna eget nisl aliquet tristique. Curabitur ac lobortis purus, quis imperdiet libero. [/tabs][tabs title="HTML"]Vestibulum sed pharetra augue. Duis scelerisque rhoncus nunc, a eleifend elit dapibus sit amet. Sed ac porttitor turpis. Cras pretium ipsum odio, vel blandit velit porttitor sed. Duis dictum ultrices tellus, mollis posuere justo tincidunt quis. Aenean porta ex vel accumsan eleifend. Vivamus dapibus neque nec metus consequat, vel tincidunt dolor scelerisque. Duis dolor arcu, interdum in finibus ut, finibus a turpis. Nam id magna consequat, posuere tortor sed, posuere diam. [/tabs][/tabs_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'widget_id' => '8b0c7610-8fff-499f-b4ab-9826820fbb1a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_Skill_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 9,
        'widget_id' => '7b27f9eb-b39e-4d95-8299-2bc22ad349d0',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '1',
            'type' => 'separator',
            'content' => 'Fun Facts',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '3ca8e27a-f216-4222-9712-bb71c09763c9',
              'style' => 
              array (
                'class' => 'heading-center-white',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '617',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '9cab7761-e0dd-44df-a194-5cff705102fe',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '618',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => 'f287f95d-7c03-4aa0-9d80-70f47d5564eb',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '619',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => '392bd0e6-2d13-4561-b81f-21d85c83d2c8',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '620',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => '92d72dd7-28ab-44ff-a6c6-a7acd0f9ed7c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '577b8b4a8e792',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 10,
        'widget_id' => 'f7cc0278-63b3-4814-bdf1-d973004c1b38',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Our Recent Work',
      'count' => '16',
      'type' => 'isotope',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Work_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'widget_id' => '7a4f7c13-ad7a-4cf8-ad0e-e41b4532d35d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Our Testimonials',
      'count' => '4',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'widget_id' => '04b3f199-c10b-4fa6-a6a7-4b82eca4daca',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => 'Latest Posts',
      'count' => '3',
      'type' => 'normal',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Posts_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 13,
        'widget_id' => 'b9e0638a-1a35-4d93-8c05-e81acc556dbe',
        'style' => 
        array (
          'class' => 'title-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. ',
      'title' => 'Webulous Thems',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Buy Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 14,
        'widget_id' => 'f263dbe6-678f-4d00-ace6-cecd0e3b9521',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '50px',
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'class' => 'center-align',
        'bottom_margin' => '100px',
        'gutter' => '40px',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-black',
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-black',
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    9 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-primary cta-bottom',
        'bottom_margin' => '0px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 4,
      'weight' => 0.5,
    ),
    7 => 
    array (
      'grid' => 4,
      'weight' => 0.5,
    ),
    8 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    11 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    12 => 
    array (
      'grid' => 9,
      'weight' => 1,
    ),
    
    ),
  );

   $layouts['home-style2'] = array(
    'name' => __('Home Page2', 'wbls-stronghold'),
    'description' => __( 'Pre Built layout for home page2', 'wbls-stronghold'),
    'widgets' => array(
           0 => 
    array (
      'type' => 'circle',
      'title' => 'Lightning Fast',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,',
      'icon' => 'fa-bolt',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://google.com/',
      'all_linkable' => true,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '0a017ee2-c20e-440e-ba48-3a765943c4cd',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'type' => 'circle',
      'title' => 'Built With Care',
      'text' => 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
      'icon' => 'fa-heart',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://google.com/',
      'all_linkable' => true,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => 'c6adb5fe-8485-4d2f-979d-164f7fda8179',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Mobile Ready',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://google.com/',
      'all_linkable' => '1',
      'box' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 2,
        'widget_id' => '18b14cdf-58e4-4a94-a621-6ce288f52fea',
        'style' => 
        array (
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'image_url' => 'http://boxy.webulous.in/wp-content/uploads/2016/07/Our-Team-One.png',
            'title' => 'Mitchel',
            'designation' => 'Manager',
            'linkedin' => 'http://www.linkedin.com/',
            'google' => 'http://www.google.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '75df74a3-2857-40e7-9f08-4cab86ff4c27',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'widget_bottom_margin' => '',
                'padding_top_bottom' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'image_url' => 'http://boxy.webulous.in/wp-content/uploads/2016/07/Our-Team-Two.png',
            'title' => 'Emma',
            'designation' => 'Designer',
            'linkedin' => 'http://www.linkedin.com/',
            'google' => 'http://www.google.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'fefb2007-9773-449e-8223-fe9fe7b9e985',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'widget_bottom_margin' => '',
                'padding_top_bottom' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'image_url' => 'http://boxy.webulous.in/wp-content/uploads/2016/07/Our-Team-Three.png',
            'title' => 'Jessica Lee',
            'designation' => 'Developer',
            'linkedin' => 'http://www.linkedin.com/',
            'google' => 'http://www.google.com/',
            'twitter' => 'http://www.twitter.com/',
            'facebook' => 'http://www.facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '63cb1dfc-14ce-48bd-8c6c-68531a11b8cb',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'widget_bottom_margin' => '',
                'padding_top_bottom' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '57c3bfd64bffe',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '97d4d921-4d2e-4939-873f-5baf8a857250',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Skills',
      'panels_info' => 
      array (
        'class' => 'Wbls_Skill_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => 'ae1abead-bf07-453c-bb5f-5e90435e7a3d',
        'style' => 
        array (
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Accordion',
      'text' => '[accordion_group][accordion title="2013"]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Vivamus a mauris non quam pretium lobortis non ac odio. [/accordion][accordion title="2014"]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. Cras venenatis a nibh ut placerat. Vivamus a mauris non quam pretium lobortis non ac odio. [/accordion][accordion title="2015"]In sodales tellus sed arcu euismod tempor. Curabitur fringilla nibh quis lorem interdum mattis. Vivamus ornare placerat tellus ut accumsan. Fusce rutrum faucibus varius. Nunc a ipsum sit amet arcu dapibus egestas ut ut lorem. Integer sagittis mi nec nisl condimentum congue. Cras venenatis a nibh ut placerat. Vivamus a mauris non quam pretium lobortis non ac odio. [/accordion][/accordion_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 5,
        'widget_id' => '31550441-19b7-4596-8bca-ef2ffb41176e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => '',
      'text' => '<div class="whyus-left">
Why Should Be With Us
<h1>Amazing Tools to Build Awesome Website</h1>
<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
<ul>
<li>Aliquam dictum elit ac magna rhoncus, nec vestibulum sem suscipit.</li>
<li>Pellentesque convallis tortor et massa rhoncus interdum.</li>
<li>Morbi sit amet lacus porttitor, efficitur turpis eget, euismod ipsum.</li>
</ul>
</div>
',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '5a552dae-6bc9-4ea1-bd80-f9eef287a76b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => '',
      'text' => '<div class="whyus-right">
<ul>
<li><i class="fa fa-align-justify"></i>Our Company Mission</li>
<li><i class="fa fa-cloud"></i>The Boxy Philosophy</li>
<li><i class="fa fa-magnet"></i>The Boxy Promiss</li>
<li><i class="fa fa-leaf"></i>We Can Deliver On Projects</li>
</ul>
</div>
',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 7,
        'widget_id' => 'bc0c48a0-30fa-4be3-9737-08be285a05e7',
        'style' => 
        array (
        ),
      ),
    ),
    8 => 
    array (
      'title' => '',
      'text' => '<div class="recent-work-title">
<h1>More Ways Than Ever To Display Your Hard Work!</h1>
<p>We\'ve added several useful shortcodes and more amazing blog layouts that allow you to build amazing pages for your websites.</p>
</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'b2c6995e-6aba-41f9-ba7c-fdbbc481428a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => '',
      'count' => '16',
      'type' => 'isotope',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Work_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '14c1b3c8-6249-4503-b679-c204bf4324f9',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Tabs',
      'text' => '[tabs_group type="normal"][tabs title="Home"]Donec faucibus lorem nec iaculis faucibus. Pellentesque placerat nulla eu mi elementum, vitae condimentum metus tincidunt. Mauris rhoncus suscipit diam, eu varius elit. Etiam vehicula commodo erat, sed facilisis nibh dapibus sit amet. Quisque egestas posuere lacus a porta. Morbi dictum varius odio sed cursus. Cras accumsan justo nunc, et mattis ligula euismod cursus. [/tabs][tabs title="Android"]Curabitur suscipit, eros vitae rhoncus blandit, enim nisl iaculis mauris, vitae sollicitudin lectus tortor ut tellus. Fusce dignissim fermentum arcu eu pharetra. Proin tincidunt elit at iaculis imperdiet. Curabitur pellentesque sodales erat eget dapibus. Nam faucibus, ipsum ut consectetur fermentum, nulla massa malesuada mauris, vitae vehicula felis mi vel velit. Mauris in suscipit tortor. Etiam a felis mattis, congue nisi id, tempus elit. Ut quis imperdiet justo. Nam suscipit tristique urna et mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Morbi vitae mollis justo. Morbi tempus molestie imperdiet. Aliquam auctor eros eu nibh molestie, eu posuere metus iaculis. Nulla facilisi. Aenean vitae urna eget nisl aliquet tristique. Curabitur ac lobortis purus, quis imperdiet libero. [/tabs][tabs title="Html"]Vestibulum sed pharetra augue. Duis scelerisque rhoncus nunc, a eleifend elit dapibus sit amet. Sed ac porttitor turpis. Cras pretium ipsum odio, vel blandit velit porttitor sed. Duis dictum ultrices tellus, mollis posuere justo tincidunt quis. Aenean porta ex vel accumsan eleifend. Vivamus dapibus neque nec metus consequat, vel tincidunt dolor scelerisque. Duis dolor arcu, interdum in finibus ut, finibus a turpis. Nam id magna consequat, posuere tortor sed, posuere diam. [/tabs][/tabs_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 10,
        'widget_id' => '5a4423c2-41a2-4704-8d39-ce8a492cd457',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Why Choose Us',
      'text' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 6,
        'cell' => 1,
        'id' => 11,
        'widget_id' => '0c901977-2535-47a0-9f65-de7cf852874c',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    12 => 
    array (
      'src' => 'http://dummy.codinggeek.com/boxy/wp-content/uploads/2016/02/choose.png',
      'href' => 'http://dummy.codinggeek.com/boxy/wp-content/uploads/2016/02/choose.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 1,
        'id' => 12,
        'widget_id' => '8736008f-2081-4d96-a472-9043e0f7db74',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => '',
      'text' => '<div class="recent-work-title">
<h1>Some of Our Recent Post!</h1>
<p>DON\'T MISS IT, WE ALWAYS CREATE AMAZING POST FOR OUR CLIENT.</p>
</div>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 13,
        'widget_id' => '15236907-63ed-46f3-84dc-e50b23682e1d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'title' => '',
      'count' => '3',
      'type' => 'normal',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Posts_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 14,
        'widget_id' => '79751654-d304-4ff4-ae05-c5aa895f491d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'section-pattern2',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'full-width-layout',
        'bottom_margin' => '100px',
        'background' => '#3a3a3a',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 0.55395683453236999,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 0.44604316546763001,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 6,
      'weight' => 0.5,
    ),
    11 => 
    array (
      'grid' => 6,
      'weight' => 0.5,
    ),
    12 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ), 
    ),
  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-boxy'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-boxy'),
    'widgets' => array(
        0 => 
    array (
      'height' => '20',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'c7a21914-64ba-46cc-959b-7c41584a1a0b',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Lightning Fast',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
      'icon' => 'fa-bolt',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'c3b7e8d9-e690-45e3-bcd6-971bfedf1d1b',
        'style' => 
        array (
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Built with Care',
      'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
      'icon' => 'fa-bolt',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'more' => '',
      'more_url' => '',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'widget_id' => '2177bc53-5f77-4052-be37-564c893da11f',
        'style' => 
        array (
        ),
      ),
    ),
    3 => 
    array (
      'title' => '',
      'text' => '[accordion_group][accordion title="Our Solutions"]Donec imperdiet, augue ut efficitur tincidunt, lorem risus maximus dolor, non maximus nunc nulla sit amet risus. Duis ornare, felis ut pellentesque facilisis, turpis quam convallis.[/accordion][accordion title="Our Missions"]

Vestibulum varius erat ut lorem commodo interdum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In aliquet, nisi a hendrerit elementum, velit turpis elementum risus, quis accumsan erat lacus placerat ex. Cras nunc ante, cursus a faucibus sed, dignissim eu enim.[/accordion][accordion title="Our Visions"]
Nullam id neque lacinia nisi blandit tempus elementum at metus. Aliquam et nisi eros. Etiam fermentum mi ac aliquet rhoncus. Nam ultricies ut arcu aliquet condimentum. Maecenas fermentum sapien in rhoncus efficitur. Fusce ante leo, tempor at malesuada eu, varius feugiat tellus.[/accordion][accordion title="Our Plan"] Proin mollis justo eget convallis cursus. Nullam ornare semper nibh, non faucibus turpis consequat at. Nulla et magna feugiat, gravida ex at, congue metus. Curabitur lobortis sagittis leo non malesuada. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.[/accordion][/accordion_group]',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'widget_id' => '4804cb67-42f6-4195-b1c0-4246911e8567',
        'style' => 
        array (
        ),
      ),
    ),
    4 => 
    array (
      'level' => '1',
      'type' => 'normal',
      'content' => 'Our Team',
      'panels_info' => 
      array (
        'class' => 'Wbls_Heading_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '8c59a88a-05a9-441f-a485-94fb7bbc9275',
        'style' => 
        array (
          'class' => 'heading-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'content' => 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus',
            'image_url' => 'http://boxy.webulous.in/wp-content/uploads/2016/07/Our-Team-One.png',
            'title' => 'MITCHEL',
            'designation' => 'Head Officer',
            'linkedin' => 'http://www.google.co.in',
            'google' => 'http://www.google.co.in',
            'twitter' => 'http://www.google.co.in',
            'facebook' => 'http://www.google.co.in',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '7771667c-9f6f-492b-8e6d-42268fddf77f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus',
            'image_url' => 'http://boxy.webulous.in/wp-content/uploads/2016/07/Our-Team-Two.png',
            'title' => 'EMMA',
            'designation' => 'Manager',
            'linkedin' => 'http://www.google.co.in',
            'google' => 'http://www.google.co.in',
            'twitter' => 'http://www.google.co.in',
            'facebook' => 'http://www.google.co.in',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => '51e08e11-839c-40a8-8754-e17b2f0aadc6',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus',
            'image_url' => 'http://boxy.webulous.in/wp-content/uploads/2016/07/Our-Team-Three.png',
            'title' => 'IRISH',
            'designation' => 'Designer',
            'linkedin' => 'http://www.google.co.in',
            'google' => 'http://www.google.co.in',
            'twitter' => 'http://www.google.co.in',
            'facebook' => 'http://www.google.co.in',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '08eee688-0502-451f-880a-6f6581497740',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '0vkfgs5yrjv7ixbe13uq96n7b9',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '68f1ff89-7eb9-42d3-beb8-625d1c5800bf',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'OUR TABS',
      'text' => '[tabs_group type="normal"][tabs title="HOME"]Donec faucibus lorem nec iaculis faucibus. Pellentesque placerat nulla eu mi elementum, vitae condimentum metus tincidunt. Mauris rhoncus suscipit diam, eu varius elit. Etiam vehicula commodo erat, sed facilisis nibh dapibus sit amet. Quisque egestas posuere lacus a porta. Morbi dictum varius odio sed cursus. Cras accumsan justo nunc, et mattis ligula euismod cursus. [/tabs][tabs title="ANDROID"]Curabitur suscipit, eros vitae rhoncus blandit, enim nisl iaculis mauris, vitae sollicitudin lectus tortor ut tellus. Fusce dignissim fermentum arcu eu pharetra. Proin tincidunt elit at iaculis imperdiet. Curabitur pellentesque sodales erat eget dapibus. Nam faucibus, ipsum ut consectetur fermentum, nulla massa malesuada mauris, vitae vehicula felis mi vel velit. Mauris in suscipit tortor. Etiam a felis mattis, congue nisi id, tempus elit. Ut quis imperdiet justo. Nam suscipit tristique urna et mattis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Morbi vitae mollis justo. Morbi tempus molestie imperdiet. Aliquam auctor eros eu nibh molestie, eu posuere metus iaculis. Nulla facilisi. Aenean vitae urna eget nisl aliquet tristique. Curabitur ac lobortis purus, quis imperdiet libero. [/tabs][tabs title="HTML"]Vestibulum sed pharetra augue. Duis scelerisque rhoncus nunc, a eleifend elit dapibus sit amet. Sed ac porttitor turpis. Cras pretium ipsum odio, vel blandit velit porttitor sed. Duis dictum ultrices tellus, mollis posuere justo tincidunt quis. Aenean porta ex vel accumsan eleifend. Vivamus dapibus neque nec metus consequat, vel tincidunt dolor scelerisque. Duis dolor arcu, interdum in finibus ut, finibus a turpis. Nam id magna consequat, posuere tortor sed, posuere diam. [/tabs][/tabs_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '4bcf2c95-bd63-4ce3-a398-acab796fd281',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Skills',
      'panels_info' => 
      array (
        'class' => 'Wbls_Skill_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 7,
        'widget_id' => '5708be06-0aaa-4ede-8050-5dec4392c4b9',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Testimonials',
      'count' => '4',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'widget_id' => '33607173-a9b0-41de-9b77-fc05f1e5450f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'content' => 'Maecenas rutrum non metus sed pellentesque. Etiam vestibulum leo metus',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Buy Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '7e94d316-edb3-43cf-b9c8-dadff9532b27',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background' => '#ffffff',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-black',
        'bottom_margin' => '0px',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-primary cta-bottom',
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 0.5,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 0.5,
    ),
    7 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'wbls-boxy'),
      'description' => __( 'Pre Built layout for features page', 'wbls-boxy'),
      'widgets' => array(
  0 => 
    array (
      'height' => '20',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'f8e6fdfe-18b0-4283-a5d5-16c8cff2bf99',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Responsive Layout',
      'text' => 'Boxy is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
      'icon' => 'fa-mobile-phone',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Awesome Sliders',
      'text' => 'Boxy includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'widget_id' => 'c9f044da-f941-4d29-bfd9-5263449c062e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Font Awesome',
      'text' => ' Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!.',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'widget_id' => 'ec712ddd-7239-438b-90d0-9e7b3da23249',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Typography',
      'text' => 'Boxy loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!. ',
      'icon' => 'fa-font',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Retina Ready',
      'text' => ' Boxy is Retina Ready.Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!.',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 5,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Page Layout',
      'text' => ' Boxy offers many different page layouts so you can quickly and easily create your pages with no hassle!.',
      'icon' => 'fa-copy',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 6,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content.',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'widget_id' => 'c6d3a144-5a13-46eb-b70a-38d1ebcdd61e',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Excellent Support',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!.',
      'icon' => 'fa-thumb-tack',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Advance Admin',
      'text' => 'Boxy uses advanced Redux Framework for theme options panel, you can customize any part of your site quickly and easily!.',
      'icon' => 'fa-asterisk',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 9,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Page Builder',
      'text' => 'Boxy supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 10,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Custom Widgets',
      'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!.',
      'icon' => 'fa-beer',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 11,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Shortcode Builder',
      'text' => 'Boxy inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!.',
      'icon' => 'fa-check',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 12,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => 'Demo Content',
      'text' => 'Boxy includes demo content files. You can quickly setup the site like our demo and get started easily!.',
      'icon' => 'fa-close',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 2,
        'id' => 13,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content.',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 14,
        'widget_id' => '1a557e49-e0c9-41f9-a79c-05faeabed474',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'title' => 'Woo Commerce',
      'text' => 'Boxy has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!.',
      'icon' => 'fa-shopping-cart',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 15,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => 'Testimonials',
      'text' => 'With our testimonial post type, shortcode and widget, Displaying testimonials is a breeze..',
      'icon' => 'fa-mobile-phone',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 16,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'title' => 'Social Media',
      'text' => 'Want your users to stay in touch? No problem, Boxy has Social Media icons all throughout the theme!.',
      'icon' => 'fa-twitter',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 2,
        'id' => 17,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'title' => 'Google Map',
      'text' => 'Boxy includes Goole Map as shortcode and widget. So, you can use it anywhere in your site!.',
      'icon' => 'fa-map-marker',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 18,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'title' => 'Multiple Portfolio',
      'text' => '7 portfolio layouts, 3 blog layouts and multiple other alternate layouts for interior pages!.',
      'icon' => 'fa-list-alt',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 1,
        'id' => 19,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    20 => 
    array (
      'title' => 'Multiple Sidebar',
      'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!.',
      'icon' => 'fa-columns',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'top',
      'more' => 'More info',
      'more_url' => 'http://www.google.com',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 2,
        'id' => 20,
        'widget_id' => '3348665c-bbb0-4387-bbce-df9bdafee367',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    21 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content.',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 21,
        'widget_id' => '1a557e49-e0c9-41f9-a79c-05faeabed474',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-primary',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-primary',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    9 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-primary cta-bottom',
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    9 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    10 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    11 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    12 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    13 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    14 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    15 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    16 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    17 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    18 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    19 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    20 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    21 => 
    array (
      'grid' => 9,
      'weight' => 1,
    ),
    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-boxy'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-boxy'),
      'widgets' => array(
            0 => 
    array (
      'title' => '',
      'text' => '[headline level="3" type="seperator" align="tleft"]Contact Details[/headline]
Etiam in iaculis ante. Curabitur laoreet arcu dui, ut iaculis purus pellentesque ac. Ut ante augue, scelerisque in iaculis sit amet, molestie ut lacus. Donec nec diam eget lorem aliquam dignissim nec id nunc. 

[headline level="6" type="normal" align="tleft"]Address:[/headline]
Praesent imperdiet quam eleifend ligula pulvinar scelerisque.


[headline level="6" type="normal" align="tleft"]Phone Number:[/headline]
+3 045 244 12, +3 045 244 12


[headline level="6" type="normal" align="tleft"]Email:[/headline]
sales@gmail.com


',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '18ef0f9c-a313-48ae-b881-971db2c6b864',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '[headline level="3" type="seperator" align="tleft"]Contact Form[/headline]
[contact-form-7 id="7" title="Contact form 1"]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => '7f136e42-d72b-4277-826a-feaf0e57d5af',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => '',
      'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d6305.992774595653!2d-122.41157430890459!3d37.790124433800656!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858091edff45bd%3A0x70c4586b1202a605!2sUSA+Hostels+San+Francisco!5e0!3m2!1sen!2sin!4v1407318894507" width="1200" height="300" frameborder="0" style="border:0"></iframe>',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'c15182f1-4525-4695-9bb8-f2784bef4738',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.5,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.5,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-boxy'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-boxy'),
    'widgets' =>  array(
      0 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '470ddd97-0258-4af7-ad97-52c45e884c6f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '[toggle title="Lorem ipsum dolor sit amet?" open="1"]
Fusce eu nunc vulputate, suscipit purus ac, scelerisque dui. Cras at ligula vel velit posuere elementum. Sed vel diam a magna malesuada iaculis in ac nunc. Nulla accumsan velit turpis, id imperdiet tortor mattis quis. Praesent vehicula quis elit quis varius. Nulla facilisi. Donec vel eleifend turpis. Proin eleifend vel ipsum ut suscipit. Aenean vulputate feugiat semper.[/toggle]
[gap height="20"]
[toggle title="Proin porttitor neque ac neque ultrices ultrices?" close="0"]
Fusce eu nunc vulputate, suscipit purus ac, scelerisque dui. Cras at ligula vel velit posuere elementum. Sed vel diam a magna malesuada iaculis in ac nunc. Nulla accumsan velit turpis, id imperdiet tortor mattis quis. Praesent vehicula quis elit quis varius. Nulla facilisi. Donec vel eleifend turpis. Proin eleifend vel ipsum ut suscipit. Aenean vulputate feugiat semper.[/toggle]
[gap height="20"]
[toggle title="Etiam cursus eros sed neque accumsan?" close="0"]
Fusce eu nunc vulputate, suscipit purus ac, scelerisque dui. Cras at ligula vel velit posuere elementum. Sed vel diam a magna malesuada iaculis in ac nunc. Nulla accumsan velit turpis, id imperdiet tortor mattis quis. Praesent vehicula quis elit quis varius. Nulla facilisi. Donec vel eleifend turpis. Proin eleifend vel ipsum ut suscipit. Aenean vulputate feugiat semper.[/toggle]
[gap height="20"]
[toggle title="Nullam placerat ante in leo volutpat?" close="0"]
Fusce eu nunc vulputate, suscipit purus ac, scelerisque dui. Cras at ligula vel velit posuere elementum. Sed vel diam a magna malesuada iaculis in ac nunc. Nulla accumsan velit turpis, id imperdiet tortor mattis quis. Praesent vehicula quis elit quis varius. Nulla facilisi. Donec vel eleifend turpis. Proin eleifend vel ipsum ut suscipit. Aenean vulputate feugiat semper.[/toggle]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '6e34ff30-f4be-4983-a25c-d6bcc8bd9076',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'height' => '50',
      'panels_info' => 
      array (
        'class' => 'Wbls_Gap_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '44f0a51a-f78f-408e-9e7b-7dd60f99ed23',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'content' => 'Boxy is responsive drag & drop Multipurpose WordPress theme that is perfect for any website',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '06202c1b-4fcc-41a9-8e07-1dce2791afdf',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-primary cta-bottom',
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-boxy'),
    'description' => __('Pre Built Layout for services page', 'wbls-boxy'),
    'widgets' =>  array(
      0 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'Our Services',
      'panels_info' => 
      array (
        'class' => 'Wbls_Heading_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '43288aea-6a37-48ca-8111-1f4fec6ffe6f',
        'style' => 
        array (
          'class' => 'heading-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '[icon icon="fa-music" size="5x" style="boxy"]',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '9b9a0b4c-3d12-4766-9bff-98be5508c152',
        'style' => 
        array (
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Easy to Use Drag & Drop PageBuilder',
      'text' => 'Maecenas in finibus neque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla porta euismod massa. Nam vehicula turpis et risus vulputate cursus. Nunc ac dolor diam. Donec sollicitudin, quam sit amet sagittis tincidunt, tortor orci dapibus quam, ac congue ligula ligula sed neque. Proin non lobortis sem. Curabitur aliquet posuere massa ut tempus.',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'widget_id' => '6a6c676b-8329-40ea-adea-341783ec5446',
        'style' => 
        array (
        ),
      ),
    ),
    3 => 
    array (
      'title' => '',
      'text' => '[icon icon="fa-mobile" size="5x" style="boxy"]',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 3,
        'widget_id' => '76e5cb0f-e2b9-4bb4-a07d-271fccceafe8',
        'style' => 
        array (
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Responsive & Retina Ready Design',
      'text' => 'Mauris vulputate nulla sed maximus porta. Curabitur non pulvinar leo. Cras posuere velit ut velit commodo suscipit. Maecenas ut tincidunt ex, eu bibendum neque. Donec suscipit vehicula dictum. Mauris libero lectus, consectetur eu orci non, tempus tincidunt massa. Fusce eu eleifend ligula. Quisque scelerisque lacus nec orci fermentum, in vehicula est sagittis.',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 4,
        'widget_id' => '93dd3341-624f-4be5-b277-2e589b0334cb',
        'style' => 
        array (
        ),
      ),
    ),
    5 => 
    array (
      'title' => '',
      'text' => '[icon icon="fa-cutlery" size="5x" style="boxy"]',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '265460ec-0339-41df-b519-2ed87449078e',
        'style' => 
        array (
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Customizable & Page Elements',
      'text' => 'Maecenas in finibus neque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla porta euismod massa. Nam vehicula turpis et risus vulputate cursus. Nunc ac dolor diam. Donec sollicitudin, quam sit amet sagittis tincidunt, tortor orci dapibus quam, ac congue ligula ligula sed neque. Proin non lobortis sem. Curabitur aliquet posuere massa ut tempus.',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 6,
        'widget_id' => '15db2810-7747-4698-bc43-a464291a6434',
        'style' => 
        array (
        ),
      ),
    ),
    7 => 
    array (
      'title' => '',
      'text' => '[icon icon="fa-picture-o" size="5x" style="boxy"]',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 7,
        'widget_id' => 'a5f54f43-ce05-4c8a-b76e-0aa56793202e',
        'style' => 
        array (
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Layer Slider Included',
      'text' => 'Maecenas in finibus neque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla porta euismod massa. Nam vehicula turpis et risus vulputate cursus. Nunc ac dolor diam. Donec sollicitudin, quam sit amet sagittis tincidunt, tortor orci dapibus quam, ac congue ligula ligula sed neque. Proin non lobortis sem. Curabitur aliquet posuere massa ut tempus.',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 8,
        'widget_id' => 'c63f93f6-781b-418a-a052-0bd81a3ffef0',
        'style' => 
        array (
        ),
      ),
    ),
    9 => 
    array (
      'title' => '',
      'text' => '[icon icon="fa-shopping-cart" size="5x" style="boxy"]',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '6b8d2d8d-4171-46b3-86ff-f3d89e15f767',
        'style' => 
        array (
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Woo Commerce Support',
      'text' => 'Maecenas in finibus neque. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla porta euismod massa. Nam vehicula turpis et risus vulputate cursus. Nunc ac dolor diam. Donec sollicitudin, quam sit amet sagittis tincidunt, tortor orci dapibus quam, ac congue ligula ligula sed neque. Proin non lobortis sem. Curabitur aliquet posuere massa ut tempus.',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 10,
        'widget_id' => '26cbb599-8adf-4bcb-bc55-d1dfc291b28a',
        'style' => 
        array (
        ),
      ),
    ),
    11 => 
    array (
      'content' => 'Boxy is responsive drag & drop Multipurpose WordPress theme that is perfect for any website',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 11,
        'widget_id' => 'f6a1eef2-ca01-442e-87f8-146cbdf1b9ae',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    4 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-primary cta-bottom',
        'background_image_attachment' => false,
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.25059952038368999,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.74940047961630996,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 0.25059952038368999,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.74940047961630996,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 0.25059952038368999,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 0.74940047961630996,
    ),
    7 => 
    array (
      'grid' => 4,
      'weight' => 0.25059952038368999,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 0.74940047961630996,
    ),
    9 => 
    array (
      'grid' => 5,
      'weight' => 0.25059952038368999,
    ),
    10 => 
    array (
      'grid' => 5,
      'weight' => 0.74940047961630996,
    ),
    11 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'wbls_boxy_prebuilt_page_layouts');


function wbls_boxy_panels_row_style_fields($fields) {  

    $boxy_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-boxy'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-boxy' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-boxy' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-boxy' ),
        'bounce-animation' => __('bounce-animation','wbls-boxy' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-boxy' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-boxy' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-boxy' ),
        'expandUp-animation' => __('expandUp-animation','wbls-boxy' ),
        'fade-animation' => __('fade-animation','wbls-boxy' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-boxy' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-boxy' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-boxy' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-boxy' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-boxy' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-boxy' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-boxy' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-boxy' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-boxy' ),
        'flip-animation' => __('flip-animation','wbls-boxy' ),
        'flipInX-animation' => __('flipInX-animation','wbls-boxy' ),
        'flipInY-animation' => __('flipInY-animation','wbls-boxy' ),
        'floating-animation' => __('floating-animation','wbls-boxy' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-boxy' ),
        'hatch-animation' => __('hatch-animation','wbls-boxy' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-boxy' ),
        'puffIn-animation' => __('puffIn-animation','wbls-boxy' ),
        'pullDown-animation' => __('pullDown-animation','wbls-boxy' ),
        'pullUp-animation' => __('pullUp-animation','wbls-boxy' ),
        'pulse-animation' => __('pulse-animation','wbls-boxy' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-boxy' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-boxy' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-boxy' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-boxy' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-boxy' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-boxy' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-boxy' ),
        'scale-down-animation' => __('scale-down-animation','wbls-boxy' ),
        'scale-up-animation' => __('scale-up-animation','wbls-boxy' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-boxy' ),
        'slide-left-animation' => __('slide-left-animation','wbls-boxy' ),
        'slide-right-animation' => __('slide-right-animation','wbls-boxy' ),
        'slide-top-animation' => __('slide-top-animation','wbls-boxy' ),
        'slideDown-animation' => __('slideDown-animation','wbls-boxy' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-boxy' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-boxy' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-boxy' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-boxy' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-boxy' ),
        'slideRight-animation' => __('slideRight-animation','wbls-boxy' ),
        'slideUp-animation' => __('slideUp-animation','wbls-boxy' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-boxy' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-boxy' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-boxy' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-boxy' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-boxy' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-boxy' ),
        'swap-animation'  => __('swap-animation','wbls-boxy' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-boxy' ),
        'swing-animation'  => __('swing-animation','wbls-boxy' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-boxy' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-boxy' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-boxy' ), 
        'tossing-animation'  => __('tossing-animation','wbls-boxy' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-boxy' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-boxy' ), 
        'wobble-animation' => __('wobble-animation','wbls-boxy' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-boxy' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'boxy'),
            'type' => 'select',
            'options' => $boxy_animation_name,
    );

    /* Widgets & Row padding top & bottom field */

    $fields['padding_top_bottom'] = array(
      'name' => __('Padding ( Top & Bottom )', 'wbls-boxy'),
      'type' => 'measurement',
      'group' => 'layout',
      'description' => __('Padding around Top and Bottom', 'wbls-boxy'),
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_boxy_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_boxy_panels_row_style_fields');

function wbls_boxy_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    
    /* Widgets & Row padding top & bottom field */
    if(empty($attributes['style'])) $attributes['style'] = '';

    if(!empty($args['padding_top_bottom'])) $attributes['style'] .= 'padding-top: '.esc_attr($args['padding_top_bottom']).'; ';
    if(!empty($args['padding_top_bottom'])) $attributes['style'] .= 'padding-bottom: '.esc_attr($args['padding_top_bottom']).'; ';

    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_boxy_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_boxy_panels_panels_row_style_attributes', 10, 2);

function wbls_boxy_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Animation', 'wbls-boxy'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_boxy_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_boxy_row_style_groups' );


/* widgets bottom margin field  */

add_filter('siteorigin_panels_widget_style_fields','wbls_boxy_panels_widget_style_fields');

if(!function_exists('wbls_boxy_panels_widget_style_fields') ) {

  function wbls_boxy_panels_widget_style_fields($fields) {

    $fields['widget_bottom_margin'] = array(
      'name' => __('Bottom Margin', 'wbls-boxy'),
      'type' => 'measurement',
      'group' => 'layout',
      'description' =>  __('Space below the widget', 'wbls-boxy'),
    );
     return $fields;
  }

}

add_filter('siteorigin_panels_widget_style_attributes','wbls_boxy_panels_panels_widget_style_attributes',10,2);

if(!function_exists('wbls_boxy_panels_panels_widget_style_attributes') ) {
  function wbls_boxy_panels_panels_widget_style_attributes(  $attributes, $args ) {
      if(!empty($args['widget_bottom_margin'])) $attributes['style'] .= 'margin-bottom: '.esc_attr($args['widget_bottom_margin']).'; ';
      return $attributes;
  }
}  
