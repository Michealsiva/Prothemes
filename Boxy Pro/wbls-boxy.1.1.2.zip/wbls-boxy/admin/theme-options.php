<?php
/**
 * Pro customizer options     
 */

add_action('wbls-boxy_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() {   
   
// pro home paeg section 

		Boxy_kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-boxy' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-boxy'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) );

		Boxy_kirki::add_field( 'boxy', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-boxy' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch',
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
				'off' => esc_attr__( 'Disable', 'wbls-boxy' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-boxy'),
			'default'  => 'off',
		) );
		Boxy_kirki::add_field( 'boxy', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-boxy' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-boxy'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-boxy'),
		) );

//  animation section 

Boxy_kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-boxy' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-boxy'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-boxy' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Boxy_kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-boxy' ),
	'description'    => __( 'Custom JS', 'wbls-boxy'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-boxy' ),
	'section'  => 'custom_js_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
) ); 

// Tracking section 

Boxy_kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-boxy' ),
	'description'    => __( 'Tracking Code', 'wbls-boxy'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'analytics',
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-boxy' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ), 
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-boxy' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'2' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-boxy'),
) );

// color scheme section 


Boxy_kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-boxy' ),
	'description'    => __( 'Select your color scheme', 'wbls-boxy'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'color_scheme',
	'label'    => __( 'Select your color scheme', 'wbls-boxy' ),
	'section'  => 'multiple_color_section',
	'type'     => 'palette',
	'choices'     => array(
    '1' => array(
		'#f94242',
	),     
	'2' => array(
		'#4e8ce1',
	),
	'3' => array(
		'#0ca8bf',
	),
	'4' => array(
		'#86af3b',
	),
	'5' => array(
		'#186575',
	),
	'6' => array(
		'#9770fb',
	),
	'7' => array(
		'#cf0271',
	),
	'8' => array(
		'#e45914', 
	),
	'9' => array(
		'#03c4eb',
	),
),
'default' => '1',
//'default'  => 'on',
) );

//Social Network URL Section
Boxy_kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-boxy' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-boxy'),
	'panel'			 => 'social_panel',
) );

Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-boxy' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-boxy'),
) );


// flexslider section //

Boxy_kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-boxy' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-boxy'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-boxy' ),
		'2' => esc_attr__( 'Slide', 'wbls-boxy' )
	),
	'default'  => '2',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-boxy' ),
		'2' => esc_attr__( 'Vertical', 'wbls-boxy' )
	),
	'default'  => '1',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => 'on',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => 'on',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => 'on',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => 'on',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => 'off',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => 'off',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => 'off',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'off' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-boxy' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Boxy_kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-boxy' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-boxy'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-boxy' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'2' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => '2',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-boxy' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-boxy' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-boxy' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'2' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => '2',
) );

//  portfolio settings //

Boxy_kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-boxy' ),
) );

$post_per_page = get_option('posts_per_page');
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-boxy' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-boxy' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-boxy' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-boxy' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-boxy'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-boxy' ),
		2 => __( 'Show Without "All"', 'wbls-boxy' ),
		3 => __( 'Hide', 'wbls-boxy' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Boxy_kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-boxy' ),
	'description'    => __( 'Light Box Settings', 'wbls-boxy'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-boxy' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-boxy' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-boxy' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-boxy' ),
		'4' => esc_attr__( 'light-square', 'wbls-boxy' ),
		'5' => esc_attr__( 'dark-square', 'wbls-boxy' ),
		'6' => esc_attr__( 'facebook', 'wbls-boxy' ),
	),
	'default'  => '1',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-boxy' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-boxy' ),
		'slow' => esc_attr__( 'Slow', 'wbls-boxy' ),
		'normal' => esc_attr__( 'Normal', 'wbls-boxy' ),
	),
	'default'  => 'fast',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-boxy' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-boxy' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'2' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => '2',
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-boxy' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-boxy'),
) );
Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-boxy' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-boxy' ),
		'2' => esc_attr__( 'Disable', 'wbls-boxy' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-boxy' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#f94242',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array( 
		array(
			'element'  => '.gallery-item img,.site-footer .widget_image-box-widget a.more-button,.site-footer .textwidget ul.cnt-address li i,.main-navigation ul.nav-menu > li.current-menu-item > a,
							.comment-navigation .nav-previous a,.widget_recent-work-widget .flex-direction-nav a.flex-prev,
							.widget_recent-work-widget .flex-direction-nav a.flex-next,ul.filter-options li a:hover,
							.portfolio2col:hover,.portfolio-excerpt a.btn-readmore,.flex-container .flex-direction-nav a:hover,
							.portfolio3col:hover,.flex-container p.btn-slider a,.toggle .toggle-content,
							.portfolio4col:hover,.ei-slider-thumbs li.ei-slider-element,.widget .ei-slider-thumbs li.ei-slider-element,
							.portfolio2col_sidebar:hover,.dropcap-circle,.toggle .toggle-title .icn,.widget_testimonial-widget ul li .client-pic,.widget_testimonial-widget .flex-control-nav li a,.widget_image-box-widget .image-box img,.widget_image-box-widget a.more-button,
							.portfolio3col_sidebar:hover,.dropcap-book,.circle-icon-box .circle-icon-wrapper,.circle-icon-box .service,.circle-icon-box .service p.more-button a,
							ul.filter-options li a.selected,.widget_recent-posts-gallery-widget .recent-post:hover,
							.paging-navigation .nav-previous a,.search-form input.search-field,.ui-tabs-panel,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a,
							.tabs-container ul.ui-tabs-nav li a:hover,.widget.widget_ourteam-widget .team-social ul li a,
							.post-navigation .nav-previous a,.comment-navigation .nav-next a,.ui-accordion h3 span.fa,i.boxy,
							.paging-navigation .nav-next a,.site-main .post-navigation .nav-links a span,.widget_social-networks-widget ul li a,
							.share-box ul li a,.tabs-container .ui-tabs-panel,.ui-accordion .ui-accordion-content,
							.post-navigation .nav-next a,.page-links a,.page-navigation ol li a,.site-footer .circle-icon-box p.more-button a,.page-navigation ol li.bpn-current,.page-navigation ol li.bpn-current:hover,a.more-link,
							.flex-recent-posts ul.slides .recent-post:hover, .widget_recent-posts-widget .recent-posts ul.slides .recent-post:hover,.tabs.normal .tabs_container ',
			'property' => 'border-color',
		),
		array(
			'element'  => '.pullright,
																				.pullleft,.withtip.left:after,.tabs.normal ul li .tabulous_active, .tabs.normal ul li a:hover',
			'property' => 'border-left-color',
		),
		array(
			'element'  => ' .withtip.right:after,.site-footer .pullright ,.tabs.normal ul li .tabulous_active, .tabs.normal ul li a:hover',
			'property' => 'border-right-color',
		),
		array(
			'element'  => '.tabs.normal ul li .tabulous_active, .tabs.normal ul li a:hover',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '.withtip.bottom:after ',
			'property' => 'border-bottom-color',
		),
		array(
			'element'  => '.order-total .amount,
							.cart-subtotal .amount,
							a,ul.nav-menu li a:hover,.comment-navigation .nav-previous a:hover,.site-footer a:hover,.site-footer .widget li a:hover,
							.paging-navigation .nav-previous a:hover,.widget a:hover,.site-footer .textwidget ul.cnt-address li a,.widget caption,.widget_rss ul li .rss-date,
							.post-navigation .nav-previous a:hover,.comment-navigation .nav-next a:hover,.site-footer .footer-bottom a,
							.paging-navigation .nav-next a:hover,.site-title a:hover,.site-footer .widget_meta li a:hover,
							.site-footer .widget_pages li a:hover,.entry-meta a:hover,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a,
							.tabs-container ul.ui-tabs-nav li a:hover,.callout-btn a:hover,.ui-accordion .ui-accordion .ui-accordion-header:hover,
							.entry-footer a:hover,blockquote:before,ol.comment-list .comment-metadata a:hover,ol.comment-list .comment-author cite a:hover,.required,
							.site-footer .widget_recent_entries li a:hover,.widget_recent-work-widget .work-title h4 a:hover,.site-footer .widget.widget_recent-work-widget .flex-direction-nav a.flex-prev:hover,
							.site-footer .widget.widget_recent-work-widget .flex-direction-nav a.flex-next:hover,.site-footer .widget_testimonial-widget p.client,
							.site-footer .widget_nav_menu li a:hover,.ei-title h3,.breadcrumb #breadcrumb a:hover,.dropcap,
							.post-navigation .nav-next a:hover,.pullright:before,.widget_image-box-widget h4,
							.pullleft:before,.page-links a:hover,.pullnone:before,.page-navigation ol li a:hover,.page-navigation ol li.bpn-current:hover,a.more-link:hover,.site-main .post-navigation .nav-links a:hover,
							.flex-container .flex-direction-nav a:hover::before,.wide-black .widget_stat-widget .stat',
			'property' => 'color',
		),
		array(
			'element'  => '.site-footer .footer-bottom ul.menu li a:hover,.widget_recent-work-widget .recent_work_overlay a,.ui-accordion .ui-accordion-header-active,.widget_tag_cloud a,.site-footer .widget_tag_cloud a:hover,
							input[type="reset"],.widget.widget_skill-widget .skill-container .skill .skill-percentage,.ui-accordion h3:hover,
							input[type="submit"],.flex-container .flex-control-paging li a.flex-active,.site-footer .widget_image-box-widget a.more-button:hover,.site-footer a.more-button,.flex-control-paging li a.flex-active,
							.flex-control-paging li a:hover,.dropcap-circle,.withtip:before,.callout-widget .callout-btn a,.callout-widget .callout-btn a:hover,
							.dropcap-box,.toggle .toggle-title:hover,.site-footer .footer-bottom ul.menu li.current_page_item a,.circle-icon-box .service p.more-button a:hover,
							.flex-container .flex-control-paging li a:hover,.flex-container p.btn-slider a:hover,
							.btn-slider a:hover,
							.circle-icon-box .circle-icon-wrapper:hover,
							.portfolio-excerpt a.btn-readmore:hover,
							.service p.more-button a:hover,
							.menu-footer-menu-container ul.menu li a:hover,.slicknav_menu,
							.menu-all-pages-container ul.menu li a:hover,.main-navigation ul.nav-menu li li.menu-item-has-children:after,.portfolio-excerpt a.btn-readmore:hover,
							.flex-container .flex-caption p.btn-slider a.flex-recent-posts ul.slides li a.post-readmore:hover .rp-thumb, .widget_recent-posts-widget .recent-posts ul.slides li a.post-readmore:hover .rp-thumb,
							.portfolio2col:hover .portfolio2col_overlay,
							.portfolio2col_sidebar_overlay:hover,
							.portfolio3col:hover .portfolio3col_overlay,.flex-container .flex-caption p.btn-slider a,
							.portfolio4col:hover .portfolio4col_overl',
			'property' => 'background-color',
		),
	),
) );

Boxy_kirki::add_field( 'boxy', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-boxy' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#3a3a3a',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => 'button,
							input,
							select,
							textarea,.widget.widget_ourteam-widget .team-content p,.ui-accordion h3 span.fa,.ui-accordion .ui-accordion-header-active span.fa,
							.main-navigation ul.nav-menu > li.current-menu-item > a,.widget_social-networks-widget ul li a,
							.share-box ul li a,.site-footer .circle-icon-box .service p,.site-footer .circle-icon-box p.more-button a,.site-footer a.more-button:hover,.site-footer .flex-direction-nav a.flex-prev,
							.site-footer .flex-direction-nav a.flex-next,.site-footer .footer-bottom ul.menu li a,.tabs-container ul.ui-tabs-nav li a,.widget.widget_ourteam-widget .team-social ul li a,
							.main-navigation .menu > ul > li.current_page_item > a,ul.nav-menu li a,.comment-navigation .nav-previous a,
							.paging-navigation .nav-previous a,.widget a,.widget_tag_cloud a,.widget_tag_cloud a:hover,.site-title a,.site-description,
							.post-navigation .nav-previous a,.comment-navigation .nav-next a,.site-footer .widget_tag_cloud a,.site-footer .textwidget ul.cnt-address li i,.site-footer .footer-bottom,.site-footer .footer-bottom a:hover,.entry-meta a,
							.entry-footer a,ol.comment-list .comment-author cite a,.flex-container .flex-direction-nav a,
							ol.comment-list .comment-metadata a,.site-footer .circle-icon-box .circle-icon-wrapper p.fa-stack,.site-footer .circle-icon-box .circle-icon-wrapper h3,.flex-container .flex-caption,.flex-container p.btn-slider a,
							.paging-navigation .nav-next a,.site-main .post-navigation .nav-links a,.breadcrumb #breadcrumb a,.alert-message a:hover,.widget_button-widget .btn,.toggle .toggle-title,.toggle .toggle-title .icn,ul.filter-options li a,ul.filter-options li a:hover,
							ul.filter-options li a.selected,.widget_testimonial-widget ul li p.client strong,.widget_recent-posts-gallery-widget h3.widget-title,.widget_recent-posts-gallery-widget h4,#portfolio h4 a:hover,
							.post-navigation .nav-next a,.page-links a,ul.filter-options li a:hover,.page-navigation ol li a,.site-footer .widget_social-networks-widget li a,.page-navigation ol li.bpn-current,.page-navigation ol li.bpn-current:hover,a.more-link',
			'property' => 'color',
		),
		array(
			'element' => '.slicknav_menu li.current-menu-item a,
							.slicknav_menu li a:hover,
							.slicknav_menu .slicknav_row:hover,.slicknav_menu .slicknav_btn,
							.slicknav_menu .slicknav_btn:hover,.tabs-container ul.ui-tabs-nav li.ui-tabs-active a,
							input[type="button"]:hover,.site-footer .widget_image-box-widget a.more-button,
							input[type="reset"]:hover,.widget.widget_skill-widget .skill-container .skill,.widget.widget_skill-widget .skill-container .skill .skill-content span
							input[type="submit"]:hover,.site-footer,.panel-row-style-wide-dark-grey ',
			'property' => 'background-color',
		),
        array(
			'element' => '.slicknav_menu,
				          .search-form input.search-submit:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element' => 'input[type="button"]:active,.site-footer .footer-bottom ul.menu li a,.widget_image-box-widget a.more-button:hover,.ui-accordion .ui-accordion-header-active span.fa,.callout-widget .callout-btn a,
							.widget_recent-work-widget .flex-direction-nav a.flex-prev:hover,
							.widget_recent-work-widget .flex-direction-nav a.flex-next:hover,.flex-container .flex-control-paging li a,
							input[type="reset"]:active,.page-navigation ol li.bpn-current,.page-navigation ol li.bpn-current:hover,
							input[type="submit"]:active,input[type="button"]:focus,.flex-container .flex-direction-nav a,
							input[type="reset"]:focus,.site-main .post-navigation .nav-links a:hover span,
							input[type="submit"]:focus,.comment-navigation .nav-previous a:hover,.widget .ei-slider-thumbs li,
							.paging-navigation .nav-previous a:hover,.tabs-container ul.ui-tabs-nav li a,
							.post-navigation .nav-previous a:hover,.comment-navigation .nav-next a:hover,
							.paging-navigation .nav-next a:hover,button:active,button:focus,
							.post-navigation .nav-next a:hover,.page-links a:hover,.page-navigation ol li a:hover,.page-navigation ol li.bpn-current:hover,a.more-link:hover',  
			'property' => 'border-color',
		),
		array(
			'element' => 'abbr,acronym',
			'property' => 'border-bottom-color',
		),
		
	),
) );

//  slider panel //

Boxy_Kirki::add_panel( 'slider_panel', array(   
	'title'       => __( 'Slider Settings', 'boxy' ),  
	'description' => __( 'Flex slider related options', 'boxy' ), 
	'priority'    => 11,    
) );

//  flexslider section  //

Boxy_Kirki::add_section( 'flex_caption_section', array(
	'title'          => __( 'Flexcaption Settings','boxy' ),
	'description'    => __( 'Flexcaption Related Options', 'boxy'),
	'panel'          => 'slider_panel', // Not typically needed.
) );

Boxy_Kirki::add_field( 'boxy', array(
	'settings' => 'flexcaption_bg',
	'label'    => __( 'Select Flexcaption Background Color', 'boxy' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-container .flex-caption h1, .flex-container .flex-caption h2, .flex-container .flex-caption h3, .flex-container .flex-caption h4, .flex-container .flex-caption h5, .flex-container .flex-caption h6, .flex-container .flex-caption p, .flex-container .flex-caption ul',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Boxy_Kirki::add_field( 'boxy', array(
	'settings' => 'flexcaption_align',
	'label'    => __( 'Select Flexcaption Alignment', 'boxy' ),
	'section'  => 'flex_caption_section',
	'type'     => 'select',
	'default'  => 'right',
	'choices' => array(
		'left' => esc_attr__( 'Left', 'boxy' ),
		'right' => esc_attr__( 'Right', 'boxy' ),
		'center' => esc_attr__( 'Center', 'boxy' ),
		'justify' => esc_attr__( 'Justify', 'boxy' ),
	),
	'output'   => array(
		array(
			'element'  => '.home .flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption,.flexslider .slides .flex-caption h1, .flexslider .slides .flex-caption h2, .flexslider .slides .flex-caption h3, .flexslider .slides .flex-caption h4, .flexslider .slides .flex-caption h5, .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption p,.flexslider .slides .flex-caption',
			'property' => 'text-align',
			//'suffix' => '!important',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
 Boxy_Kirki::add_field( 'boxy', array(
	'settings' => 'flexcaption_bg_position',
	'label'    => __( 'Select Flexcaption Background Horizontal Position', 'boxy' ),
	'tooltip' => __('Select how far from right, Default value Right =  ( in % )','boxy'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'right',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
 Boxy_Kirki::add_field( 'boxy', array(
	'settings' => 'flexcaption_bg_vertical_position',
	'label'    => __( 'Select Flexcaption Background Vertical Position', 'boxy' ),
	'tooltip' => __('Select how far from top, Default value top =  ( in % )','boxy'),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'top',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Boxy_Kirki::add_field( 'boxy', array(
	'settings' => 'flexcaption_bg_width',
	'label'    => __( 'Select Flexcaption Background Width', 'boxy' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '',
	'tooltip' => __('Select Flexcaption Background Width , Default width value ','boxy'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'suffix' => '%',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) ); 
Boxy_Kirki::add_field( 'boxy', array(
	'settings' => 'flexcaption_responsive_bg_width',
	'label'    => __( 'Select Responsive Flexcaption Background Width', 'boxy' ),
	'section'  => 'flex_caption_section',
	'type'     => 'number',
	'default'  => '100',
	'tooltip' => __('Select Responsive Flexcaption Background Width, Default width value 100 ( This value will apply for max-width: 768px )','boxy'),
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 1, 
	),
	'output'   => array(
		array(
			'element'  => '.flexslider .slides .flex-caption,.home .flexslider .slides .flex-caption',
			'property' => 'width',
			'media_query' => '@media (max-width: 768px)',
			'value_pattern' => 'calc($%)',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );
Boxy_Kirki::add_field( 'boxy', array(
	'settings' => 'flexcaption_color',
	'label'    => __( 'Select Flexcaption Font Color', 'boxy' ),
	'section'  => 'flex_caption_section',
	'type'     => 'color',
	'default'  => '',
	'alpha' => true,
	'output'   => array(
		array(
			'element'  => '.flex-caption,.home .flexslider .slides .flex-caption  a,.home .flexslider .slides .flex-caption p,.flexslider .slides .flex-caption p,.home .flexslider .slides .flex-caption h1, .home .flexslider .slides .flex-caption h2, .home .flexslider .slides .flex-caption h3, .home .flexslider .slides .flex-caption h4, .home .flexslider .slides .flex-caption h5, .home .flexslider .slides .flex-caption h6,.flexslider .slides .flex-caption h1,.flexslider .slides .flex-caption h2,.flexslider .slides .flex-caption h3,.flexslider .slides .flex-caption h4,.flexslider .slides .flex-caption h5,.flexslider .slides .flex-caption h6',
			'property' => 'color',
		),
	),
	'active_callback' => array(
		array(
			'setting'  => 'enable_flex_caption_edit',
			'operator' => '==',
			'value'    => true,
		),
    ),
) );

Boxy_Kirki::add_field( 'boxy', array(
	'settings' => 'nav_bg_color',
	'label'    => __( 'Navigation Bar BG Color', 'boxy' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_nav_bg_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.main-navigation',
			'property' => 'background-color',
		),
	),
) );

// typography panel - override //

        $body_font = get_theme_mod('body_family','Acme');		        
	    $body_color = get_theme_mod( 'body_color','#3a3a3a' );   
		$body_size = get_theme_mod( 'body_size','16');
		$body_weight = get_theme_mod( 'body_weight','regular');
		$body_weight == 'bold' ? $body_weight = '400':  $body_weight = 'regular';
		

	Boxy_Kirki::add_section( 'body_font', array(
		'title'          => __( 'Body Font','boxy' ),
		'description'    => __( 'Specify the body font properties', 'boxy'),
		'panel'          => 'typography', // Not typically needed.
	) ); 

	Boxy_Kirki::add_field( 'boxy', array(
		'settings' => 'body',
		'label'    => __( 'Body Settings', 'boxy' ),
		'section'  => 'body_font', 
		'type'     => 'typography',
		'default'     => array(
			'font-family'    => $body_font,
			'variant'        => $body_weight,
			'font-size'      => $body_size.'px',
			'line-height'    => '1.5',
			'letter-spacing' => '0',
			'color'          => $body_color, 
		),
		'output'      => array(
			array(
				'element' => 'body',
				//'suffix' => '!important',
			),
		),
		'active_callback' => array(
			array(
				'setting'  => 'body_typography',
				'operator' => '==',
				'value'    => true,
			),
		),
	) );

}

