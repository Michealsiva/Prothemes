(function( $ ) {

	$(function() {

		docs = $('<a class="boxy-docs doc"></a>')
			.attr('href','http://www.webulousthemes.com/boxy-pro/') 
			.attr('target','_blank')
			.text('Documentation');

		support = $('<a class="boxy-docs question"></a>')
			.attr('href','http://www.webulousthemes.com/support-ticket/')
			.attr('target','_blank')
			.text('Ask a Question');

		$('#customize-info .preview-notice').append(docs);
		$('#customize-info .preview-notice').append(support);

		$('.boxy-docs').on('click',function(e){
			e.stopPropagation();
		});
		
		
	});

})( jQuery );
