<?php
/**
 * magzenpro functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package MagZenPro
 */ 

if ( ! function_exists( 'magzenpro_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function magzenpro_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on magzenpro, use a find and replace
	 * to change 'magzenpro' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'magzenpro', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'magzenpro' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'magzenpro_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );

   /* 
	* Custom Logo 
	*/
	add_theme_support( 'custom-logo' );


	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );


    /*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */ 
    add_image_size( 'magzenpro-highlighted-post', 250,185, true );
	add_image_size( 'magzenpro-thumbnail-large', 380,170, true );
	add_image_size( 'magzenpro-thumbnail-small', 130,90, true );
	add_image_size( 'magzenpro-slider-thumbnail', 700,400, true );
	add_image_size( 'magzenpro-vertical-one', 800,350, true );   
	add_image_size( 'magzenpro-vertical-two', 380,350,  true );
	add_image_size( 'magzenpro-horizontal-one', 200,200, true );
	add_image_size( 'magzenpro-horizontal-two', 200,200, true );
	add_image_size( 'magzenpro-tabbed-post', 100,80, true );
	add_image_size( 'magzenpro-gallery-auto', 150,150, true );


	/* License key - EDD update file */
	require get_template_directory() .  '/inc/updater/theme-updater.php';	
	
}
endif;
add_action( 'after_setup_theme', 'magzenpro_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function magzenpro_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'magzenpro_content_width', 640 );
}
add_action( 'after_setup_theme', 'magzenpro_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function magzenpro_widgets_init() {
	/* register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'magzenpro' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'magzenpro' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) ); */
	register_sidebar( array(
		'name'          => esc_html__( 'MagZen: Sidebar', 'magzenpro' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'magzenpro' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	register_sidebar( array(
		'name'          => __( 'MagZen: Top Full Width Slider Area', 'magzenpro' ),
		'id'            => 'magzen-top-fullwidth-slider-area', 
		'description'   => __( 'Appears on Front Page and Magazine Page template only. You can use the MagZenPro widgets here.','magzenpro' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) ); 

    register_sidebar( array(
		'name'          => __( 'MagZen: Top Full Width Beside Slider Area', 'magzenpro' ),
		'id'            => 'magzen-top-fullwidth-beside-slider-area', 
		'description'   => __( 'Appears on Front Page and Magazine Page template only. You can use the MagZenPro widgets here.','magzenpro' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) ); 

	register_sidebar( array(
		'name'          => __( 'MagZen: Content Area', 'magzenpro' ),
		'id'            => 'magzen-content-area', 
		'description'   => __( 'Appears on Front Page and Magazine Page template only. You can use the MagZenPro widgets here.','magzenpro' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>', 
	) ); 
	register_sidebar( array(  
		'name'          => __( 'Top Left', 'magzenpro' ),
		'id'            => 'top-left',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	register_sidebar( array(
		'name'          => __( 'Top Right', 'magzenpro' ),
		'id'            => 'top-right',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	register_sidebar( array(
		'name'          => __( 'Header Right', 'magzenpro' ),
		'id'            => 'header-right',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );

	register_sidebars( 3, array(
		'name'          => __( 'Footer %d', 'magzenpro' ),
		'id'            => 'footer',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	
}
add_action( 'widgets_init', 'magzenpro_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
require get_template_directory() . '/inc/enqueue.php';

/**
 * Sidebar generator.
 */
require get_template_directory() . '/inc/sidebar-generator.php';

/**
 * MagZenPro Widgets file
 */
require get_template_directory() . '/inc/widgets/widgets.php';

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Load TGM plugin 
 */
require get_template_directory() . '/admin/class-tgm-plugin-activation.php';

/**
 * Load Theme Options Panel
 */
require get_template_directory() . '/customizer/theme-options.php';

/**
 * Demo content 
 */
require get_template_directory() . '/demo/init.php';


/* Woocommerce support */    

add_theme_support('woocommerce');

remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper');
add_action('woocommerce_before_main_content', 'magzenpro_output_content_wrapper');

function magzenpro_output_content_wrapper() {
	echo '<div class="container"><div class="row"><div id="primary" class="content-area eleven columns">';
}

remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end' );
add_action( 'woocommerce_after_main_content', 'magzenpro_output_content_wrapper_end' );

function magzenpro_output_content_wrapper_end () {
	echo "</div>";
}

add_action( 'init', 'magzenpro_remove_wc_breadcrumbs' );
function magzenpro_remove_wc_breadcrumbs() {
   	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}

/* Recommended plugin using TGM */
add_action( 'tgmpa_register', 'magzenpro_register_plugins');
if( !function_exists('magzenpro_register_plugins') ) {
	function magzenpro_register_plugins() {
       /**
		 * Array of plugin arrays. Required keys are name and slug.
		 * If the source is NOT from the .org repo, then source is also required.
		 */
		$plugins = array(

			array(
				'name'     => 'SiteOrigin Panels', // The plugin name.
				'slug'     => 'siteorigin-panels', // The plugin slug (typically the folder name).
				'required' => true, // If false, the plugin is only 'recommended' instead of required.
			),
		);
		/*
		 * Array of configuration settings. Amend each line as needed.
		 *
		 * TGMPA will start providing localized text strings soon. If you already have translations of our standard
		 * strings available, please help us make TGMPA even better by giving us access to these translations or by
		 * sending in a pull-request with .po file(s) with the translations.
		 *
		 * Only uncomment the strings in the config array if you want to customize the strings.
		 */
		$config = array(
			'id'           => 'tgmpa',
			// Unique ID for hashing notices for multiple instances of TGMPA.
			'default_path' => '',
			// Default absolute path to bundled plugins.
			'menu'         => 'tgmpa-install-plugins',
			// Menu slug.
			'parent_slug'  => 'themes.php',
			// Parent menu slug.
			'capability'   => 'edit_theme_options',
			// Capability needed to view plugin install page, should be a capability associated with the parent menu used.
			'has_notices'  => true,
			// Show admin notices or not.
			'dismissable'  => true,
			// If false, a user cannot dismiss the nag message.
			'dismiss_msg'  => '',
			// If 'dismissable' is false, this message will be output at top of nag.
			'is_automatic' => false,
			// Automatically activate plugins after installation or not.
			'message'      => '',
			// Message to output right before the plugins table.
		);

		tgmpa( $plugins, $config );
	}
}
