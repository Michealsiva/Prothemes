<?php
require_once get_template_directory() . '/customizer/options-config.php';
	if( ! class_exists('MagZenPro_Customizer_API_Wrapper') ) {
		require_once get_template_directory() . '/customizer/class.magzenpro-customizer-api-wrapper.php';
	}


MagZenPro_Customizer_API_Wrapper::getInstance($options);
