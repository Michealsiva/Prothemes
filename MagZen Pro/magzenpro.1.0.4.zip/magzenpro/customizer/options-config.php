<?php

	$options = array(
		'capability' => 10,    
		'type' => 'theme_mod',
		'panels' => apply_filters( 'magzenpro_customizer_options', array(
			'magzenpro' => array(  
				'priority'       => 9, 
				'title'          => __('Theme Options', 'magzenpro'),  
				'description'    => __('Theme Options', 'magzenpro'),
				'sections' => array(
					'general' => array(
						'title' => __('General', 'magzenpro'),
						'description' => __('General settings that affects overall site', 'magzenpro'),
						'fields' => array(
							'breadcrumb' => array(
								'type' => 'checkbox',
								'label' => __('Enable Breadcrumb', 'magzenpro'),
								'default' => 0,
								'sanitize_callback' => 'magzenpro_boolean',
							),
							'breadcrumb_char' => array(
								'type' => 'select',
								'label' => __('Select Breadcrumb Character', 'magzenpro'),
								'choices' => array(
									'1' => ' &raquo; ',
									'2' => ' // ',
									'3' => ' > '
								),
								'sanitize_callback' => 'magzenpro_breadcrumb_char_choices',
								'default' => '1',
							),
							'numeric_pagination' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Numeric Page Navigation', 'magzenpro'),
                                'description' => __('Check to display numeric page navigation, instead of Previous Posts / Next Posts links.', 'magzenpro'),
                                'default' => 1,  
                            ),
                            'more_text'  => array(
                                'type' => 'text',
                                'label' => __('Change the read more text as required for your site.', 'magzenpro'),
                                'description' => __('Text to display in case of text too long', 'magzenpro'),
                                'sanitize_callback' => 'magzenpro_footer_copyright',
                                'default' => __('Read More','magzenpro'),
                            ),
						),
					),
					'header' => array(
						'title' => __('Header', 'magzenpro'),
						'description' => __('Header options', 'magzenpro'),
						'fields' => array(
							'logo_title' => array(
								'type' => 'checkbox',
								'label' => __('Logo as Title', 'magzenpro'),
								'default' => 0,
								'sanitize_callback' => 'magzenpro_boolean',
							),
							'tagline' => array(
								'type' => 'checkbox',
								'label' => __('Show site Tagline', 'magzenpro'),
								'default' => 1,
								'sanitize_callback' => 'magzenpro_boolean',
							),
                            'header_show_date' => array( 
                                'type' => 'checkbox',
                                'label' => __('Show Date in Header', 'magzenpro'),
                                'default' => 1,
                                'sanitize_callback' => 'magzenpro_boolean',
                            ),
							'header_search' => array(
                                'type' => 'checkbox',
                                'label' => __('Show Search box in Navigation', 'magzenpro'),
                                'default' => 1,
                                'sanitize_callback' => 'magzenpro_boolean', 
                            ),
                            'header_sticky' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Sticky Header', 'magzenpro'),
                                'default' => 0,
                                'sanitize_callback' => 'magzenpro_boolean', 
                            ),

						),
					),
                    'breaking_news_section' => array(
                        'title' => __('Breaking News', 'magzenpro'),
                        'description' => __('Breaking news related options', 'magzenpro'),
                        'fields' => array(
                            'header_breaking_news' => array(
                                'type' => 'checkbox', 
                                'label' => __('Enable Breaking News', 'magzenpro'),
                                'default' => 1,
                                'sanitize_callback' => 'magzenpro_boolean', 
                            ),
                            'header_breaking_news_allpages' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable to Show Breaking News for all Page', 'magzenpro'),
                                'default' => 0,
                                'sanitize_callback' => 'magzenpro_boolean', 
                            ),
                            'header_breaking_news_title' => array(
                                'type' => 'text',
                                'label' => __('Breaking News Title', 'magzenpro'),
                                'description' => __('BREAKING NEWS', 'magzenpro'),
                                'sanitize_callback' => 'magzenpro_footer_copyright',
                            ), 
                            'breaking_animation_type' => array(
                                'type' => 'select',
                                'label' => __('Choose Animation Style', 'magzenpro'),
                                'description' => __('Choose Animation Style', 'magzenpro'),
                                'choices' => array(
                                    'up' => __('Up','magzenpro'),
                                    'down' => __('Down','magzenpro'),
                                ),
                                'default' => 'down',
                            ),
                            'breaking_duration_time' => array(
                                'type' => 'text',
                                'label' => __('Breaking News Duration Time', 'magzenpro'),
                                'description' => __('Enter the duration time for the breaking news', 'magzenpro'),
                                'default' => 1000,
                            ), 
                            'breaking_speed' => array(
                                'type' => 'text',
                                'label' => __('Breaking News Speed', 'magzenpro'),
                                'description' => __('Enter the speed time for the breaking news', 'magzenpro'),
                                'default' => 500,
                            ), 
                        ),
                    ),
                    'layout_section' => array(
                        'title' => __('Layout', 'magzenpro'),
                        'description' => __('Site Layout related options', 'magzenpro'),
                        'fields' => array(
                            'layout-model' => array(
                                'type' => 'select',
                                'label' => __('Choose Site layout', 'magzenpro'),
                                'choices' => array(
                                    'wide' => __('Wide', 'magzenpro'),
                                    'boxed' => __('Boxed', 'magzenpro'),
                                    'fluid' => __('Fluid', 'magzenpro'), 
                                ),
                                'default' => 'wide', 
                            ),
                           
                        ),
                    ),
					'social_network' => array(
                        'title' => __('Social Networks', 'magzenpro'),
                        'description' => __('Enter your social network URLs here and choose social network widget to visible.', 'magzenpro'),
                        'fields' => array(
                            'digg' => array(
                                'type' => 'text',
                                'label' => __('Digg', 'magzenpro'), 
                                'description' => __('Your Digg link ', 'magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'dribbble' => array(
                                'type' => 'text',
                                'label' => __('Dribbble', 'magzenpro'),
                                'description' => __('Your Dribbble link ', 'magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'facebook' => array(
                                'type' => 'text',
                                'label' => __('Facebook', 'magzenpro'),
                                'description' => __('Your Facebook link', 'magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'twitter' => array(
                                'type' => 'text',
                                'label' => __('Twitter', 'magzenpro'),
                                'description' => __('Your Twitter link', 'magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'google_plus' => array(
                                'type' => 'text',
                                'label' => __('Google +', 'magzenpro'),
                                'description' => __('Your Google Plus', 'magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',

                            ),
                            'linkedin' => array(
                                'type' => 'text',
                                'label' => __('LinkedIn', 'magzenpro'),
                                'description' => __('Your LinkedIn link', 'magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'instagram' => array(
                                'type' => 'text',
                                'label' => __('Instagram', 'magzenpro'),
                                'description' => __('Your Instagram link ', 'magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'flickr' => array(
                                'type' => 'text',
                                'label' => __('Flickr', 'magzenpro'),
                                'description' => __('Your Flickr link', 'magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'youtube' => array(
                                'type' => 'text',
                                'label' => __('YouTube', 'magzenpro'),
                                'description' => __('Your YouTube link', 'magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'vimeo' => array(
                                'type' => 'text',
                                'label' => __('Vimeo', 'magzenpro'),
                                'description' => __('Your Vimeo link', 'magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'pinterest' => array(
                                'type' => 'text',
                                'label' => __('Pinterest', 'magzenpro'),
                                'description' => __('Your Pinterest link','magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'rss' => array(
                                'type' => 'text',
                                'label' => __('RSS', 'magzenpro'),
                                'description' => __('Your RSS link','magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'skype' => array(
                                'type' => 'text',
                                'label' => __('Skype', 'magzenpro'),
                                'description' => __('Your Skype link','magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                            'tumblr' => array(
                                'type' => 'text',
                                'label' => __('Tumblr', 'magzenpro'),
                                'description' => __('Your Tumblr link','magzenpro'),
                                'sanitize_callback' => 'esc_url_raw',
                            ),
                        ),
                    ),
					'footer' => array(
						'title' => __('Footer', 'magzenpro'),
						'description' => __('Footer related options', 'magzenpro'),
						'fields' => array(
							'footer_widgets' => array(
								'type' => 'checkbox',
								'label' => __('Footer Widget Area', 'magzenpro'),
								'default' => 1,
								'sanitize_callback' => 'magzenpro_boolean',
							),
							'copyright' => array(
                                'type' => 'textarea',
                                'label' => __('Footer Copyright Text (Validated that it\'s HTML Allowed)', 'magzenpro'),
                                'description' => __('HTML Allowed. <b>This field is even HTML validated! </b>', 'magzenpro'),
                                'sanitize_callback' => 'magzenpro_footer_copyright',
                            ),
                            'scroll_to_top' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Scroll to Top button', 'magzenpro'),
                                'default' => 1,
                                'sanitize_callback' => 'magzenpro_boolean',
                            ),
						),
					),
					'home' => array(
						'title' => __('Home', 'magzenpro'),
						'description' => __('Please go to Appearance &#8594; Widgets and add widget to the "MagZen:" widget area. You can use the MagZenPro : XXX widgets to set up magazine page.', 'magzenpro'),
						'fields' => array(
							/* 'slider_field' => array(   
								'type' => 'checkbox',
								'label' => __('Enable Home Page Slider Section', 'magzenpro'),
								'default' => 1,
								'sanitize_callback' => 'magzenpro_boolean',
							),
							'slider_cat' => array(
								'type' => 'category',
								'label' => __('Slider Posts Category', 'magzenpro'),
								'sanitize_callback' => 'absint',
							),
							'slider_count' => array(
								'type' => 'text',
								'label' => __('No. of Sliders', 'magzenpro'),
								'sanitize_callback' => 'absint',
								'default' => 3,
							),
							'enable_recent_post_service' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Home Page Recent Post Section', 'magzenpro'),
                                'description' => __('Enable recent post section in home page', 'magzenpro'),
                                'default' => 1,  
                            ),
							'recent_posts_count' => array(
								'type' => 'text',
								'label' => __('No. of Recent Posts', 'magzenpro'),
								'sanitize_callback' => 'absint',
								'default' => 6,
							),*/
                            'enable_magazine_widget_area_content' => array(  
                                'type' => 'checkbox',
                                'label' => __('Enable Magazine Page Widget Area Content', 'magzenpro'),
                                'default' => 1,   
                            ), 
							'enable_magazine_default_content' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Magazine Page Default Content', 'magzenpro'),
                                'default' => 0,   
                            ), 
						),
					),
					'blog' => array(
						'title' => __('Blog', 'magzenpro'),
						'description' => __('Blog Related Posts options', 'magzenpro'),
						'fields' => array(
                            'post_top_meta_date' => array(
                                'type' => 'checkbox',
                                'label' => __('Show top post meta date', 'magzenpro'),
                                'default' => 1,  
                            ),
                            'post_top_meta_author' => array(
                                'type' => 'checkbox',
                                'label' => __('Show top post meta author', 'magzenpro'),
                                'default' => 1,  
                            ),
                            'post_top_meta_comment' => array(
                                'type' => 'checkbox',
                                'label' => __('Show top post meta comment', 'magzenpro'),
                                'default' => 1,  
                            ),
                            'post_top_meta_category' => array(
                                'type' => 'checkbox',
                                'label' => __('Show top post meta category', 'magzenpro'),
                                'default' => 0,  
                            ),
                            'post_top_meta_tag' => array(
                                'type' => 'checkbox',
                                'label' => __('Show top post meta tag', 'magzenpro'),
                                'default' => 0,  
                            ),
                            'post_top_meta_edit' => array(
                                'type' => 'checkbox',
                                'label' => __('Show top post meta edit', 'magzenpro'),
                                'default' => 0,  
                            ),
                            'author_bio_box' => array(
                                'type' => 'checkbox',
                                'label' => __(' Enable Author Bio Box below single post', 'magzenpro'),
                                'description' => __('Show Author information box below single post.', 'magzenpro'),
                                'default' => 0,  
                            ),
                            'related_posts' => array(
                                'type' => 'checkbox',
                                'label' => __('Show Related posts', 'magzenpro'),
                                'description' => __('Show related posts.', 'magzenpro'),
                                'default' => 0,  
                            ),
                            'related_posts_hierarchy' => array(
                                'type' => 'radio',
                                'label' => __('Related Posts Must Be Shown As:', 'magzenpro'),
                                'choices' => array(
                                    '1' => 'Related Posts By Tags',
                                    '2' => 'Related Posts By Categories',      
                                ),
                               'default' => '1',   
                            ),
                            'comments' => array(
                                'type' => 'checkbox',
                                'label' => __(' Show Comments', 'magzenpro'),
                                'description' => __('Show Comments', 'magzenpro'),
                                'default' => 1,  
                            ),
                            'social_sharing_box' => array(
                                'type' => 'checkbox',
                                'label' => __('Show social sharing  box ', 'magzenpro'),
                                'description' => __('Show social sharing options box below single post.', 'magzenpro'),
                                'default' => 1,  
                            ),
						),
					),
                    'social_sharing_box' => array(
                        'title' => __('Social Sharing Box', 'magzenpro'),
                        'description' => __('Social sharing options box below single post', 'magzenpro'),
                        'fields' => array(
                            'facebook_sb' => array(
                                'type' => 'checkbox',
                                'label' => __('Show facebook sharing option in single posts', 'magzenpro'),
                                'description' => __('Show facebook sharing option in single posts.', 'magzenpro'),
                                'default' => 1,  
                            ),
                            'twitter_sb' => array(
                                'type' => 'checkbox',
                                'label' => __('Show twitter sharing option in single posts', 'magzenpro'),
                                'description' => __('Show twitter sharing option in single posts.', 'magzenpro'),                                'default' => 1,  
                            ),
                            'linkedin_sb' => array(
                                'type' => 'checkbox',
                                'label' => __('Show linkedin sharing option in single posts', 'magzenpro'),
                                'description' => __('Show linkedin sharing option in single posts.', 'magzenpro'),
                                'default' => 1,  
                            ),
                            'google-plus_sb' => array(
                                'type' => 'checkbox',
                                'label' => __('Show googleplus sharing option in single posts', 'magzenpro'),
                                'description' => __('Show googleplus sharing option in single posts.', 'magzenpro'),
                                'default' => 1,  
                            ),
                            'email_sb' => array(
                                'type' => 'checkbox',
                                'label' => __('Show email sharing option in single posts', 'magzenpro'),
                                'description' => __('Show email sharing option in single posts.', 'magzenpro'),
                                'default' => 1,  
                            ),
                        ),
                    ),
                    'additional_option_section' => array(  
                        'title' => __('Additional Options', 'magzenpro'),
                        'description' => __('Additional options related to the theme', 'magzenpro'),
                        'fields' => array(
                            'optimize_js' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable to Merge all JS files to One Optimizing JS in order to increase speed.', 'magzenpro'),
                                'default' => 0,  
                            ), 
                        ),
                    ),
				),
			),
           // typography start // 
            'typography' => array(
                'priority'       => 9,
                'title'          => __('Typography & Color', 'magzenpro'),
                'description'    => __('Typography and Link Color Settings', 'magzenpro'),
                'sections' => array(
                    'color_section' => array(  
                        'title' => __('General Color Settings', 'magzenpro'),
                        'fields' => array( 
                            'color_scheme' => array(
                                'type' => 'select',
                                'label' => __('Choose Color Scheme', 'magzenpro'),
                                'choices' => array(
                                    '1' => __('Default','magzenpro'),
                                    '2' => __('Green','magzenpro'), 
                                    '3' => __('Light Green','magzenpro'),
                                    '4' => __('Blue','magzenpro'),
                                    '5' => __('Violet','magzenpro'),
                                    '6' => __('Yellow','magzenpro'),
                                    '7' => __('Orange','magzenpro'),
                                    '8' => __('Red','magzenpro'),
                                ),
                                'default' => '1',
                            ),
                            'custom_primary_color_section' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Custom Primary Color Settings', 'magzenpro'),
                                'default' => 0, 
                            ),
                            'primary_color' => array(
                                'type' => 'color',
                                'label' => __('Primary Color', 'magzenpro'),
                                'sanitize_callback' => 'sanitize_hex_color',
                                'transport' => 'postMessage',
                                'default' => '#f15c22' 
                            ),
                            'custom_secondary_color_section' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Custom Secondary Color Settings', 'magzenpro'),
                                'default' => 0, 
                            ),
                            'secondary_color' => array(
                                'type' => 'color',
                                'label' => __('Secondary Color', 'magzenpro'),
                                'sanitize_callback' => 'sanitize_hex_color',
                                'transport' => 'postMessage',
                                'default' => '#2c3e50'
                            ),
                        ),
                    ),
                    'navigation_font' => array(
                        'title' => __('Navigation Font','magzenpro'),
                        'description' => __('Specify the navigation font properties.','magzenpro'),
                        'fields' => array (
                            'custom_navigation_font' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Custom navigation Settings', 'magzenpro'),
                                'default' => 0,  
                            ),
                            'navigation' => array(
                                'type' => 'typography',
                                'label' => __('navigation Settings', 'magzenpro'),                        
                            ),
                            'navigation_color' => array(
                                'type' => 'color',
                                'label' => __('navigation Color', 'magzenpro'),
                                'sanitize_callback' => 'sanitize_hex_color',
                                'transport' => 'postMessage',
                                'default' => '#ffffff'
                            ),
                        ),
                    ),
                    'body_font' => array(
                        'title' => __('Body Font','magzenpro'),
                        'description' => __('Specify the body font properties.','magzenpro'),
                        'fields' => array (
                            'custom_body_font' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Custom Body Settings', 'magzenpro'),
                                'default' => 0, 
                            ),
                            'body' => array(
                                'type' => 'typography',
                                'label' => __('Body Settings', 'magzenpro'),                        
                            ),
                            'body_color' => array(
                                'type' => 'color',
                                'label' => __('Body Color', 'magzenpro'),
                                'sanitize_callback' => 'sanitize_hex_color',
                                'transport' => 'postMessage',
                                'default' => '#282827'
                            ),
                        ),
                    ),
                    'h1_property' => array(
                        'title' => __('H1 Font Properties','magzenpro'),
                        'description' => __('Specify the h1 font properties.','magzenpro'),
                        'fields' => array (
                            'custom_h1_font' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Custom H1 Settings', 'magzenpro'),
                                'default' => 0, 
                            ),
                            'h1' => array(
                                'type' => 'typography',
                                'label' => __('H1 Settings', 'magzenpro'),
                            ),
                            'h1_color' => array(
                                'type' => 'color',
                                'label' => __('H1 Color', 'magzenpro'),
                                'sanitize_callback' => 'sanitize_hex_color',
                                'transport' => 'postMessage',
                                'default' => '#282827'
                            ),
                        ),
                    ),
                    'h2_property' => array(
                        'title' => __('H2 Font Properties','magzenpro'),
                        'description' => __('Specify the h2 font properties.','magzenpro'),
                        'fields' => array (
                                'custom_h2_font' => array(
                                    'type' => 'checkbox',
                                    'label' => __('Enable Custom H2 Settings', 'magzenpro'),
                                    'default' => 0, 
                                ),
                                'h2' => array(
                                    'type' => 'typography',
                                    'label' => __('H2 Settings', 'magzenpro'),                       
                                ),
                                'h2_color' => array(
                                    'type' => 'color',
                                    'label' => __('H2 Color', 'magzenpro'),
                                    'sanitize_callback' => 'sanitize_hex_color',
                                    'transport' => 'postMessage',
                                    'default' => '#282827'
                                )
                        ),
                    ),
                    'h3_property' => array(
                        'title' => __('H3 Font Properties','magzenpro'),
                        'description' => __('Specify the h3 font properties.','magzenpro'),
                        'fields' => array (
                                'custom_h3_font' => array(
                                    'type' => 'checkbox',
                                    'label' => __('Enable Custom H3 Settings', 'magzenpro'),
                                    'default' => 0, 
                                ),
                                'h3' => array(
                                    'type' => 'typography',
                                    'label' => __('H3 Settings', 'magzenpro'),
                                                              
                                ),
                                'h3_color' => array(
                                    'type' => 'color',
                                    'label' => __('H3 Color', 'magzenpro'),
                                    'sanitize_callback' => 'sanitize_hex_color',
                                    'transport' => 'postMessage',
                                    'default' => '#282827'
                                )
                        ),
                    ),
                    'h4_property' => array(
                        'title' => __('H4 Font Properties','magzenpro'),
                        'description' => __('Specify the h4 font properties.','magzenpro'),
                        'fields' => array (
                            'custom_h4_font' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Custom H4 Settings', 'magzenpro'),
                                'default' => 0, 
                            ),
                            'h4' => array(
                                'type' => 'typography',
                                'label' => __('H4 Settings', 'magzenpro'),                                   
                            ),
                            'h4_color' => array(
                                'type' => 'color',
                                'label' => __('H4 Color', 'magzenpro'),
                                'sanitize_callback' => 'sanitize_hex_color',
                                'transport' => 'postMessage',
                                'default' => '#282827'
                            )  
                        ),
                    ),
                    'h5_property' => array(
                        'title' => __('H5 Font Properties','magzenpro'),
                        'description' => __('Specify the h5 font properties.','magzenpro'),
                        'fields' => array (
                            'custom_h5_font' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Custom H5 Settings', 'magzenpro'),
                                'default' => 0, 
                            ),
                            'h5' => array(
                                'type' => 'typography',
                                'label' => __('H5 Settings', 'magzenpro'),               
                            ),
                            'h5_color' => array(
                                'type' => 'color',
                                'label' => __('H5 Color', 'magzenpro'),
                                'sanitize_callback' => 'sanitize_hex_color',
                                'transport' => 'postMessage',
                                'default' => '#282827'
                            )
                        ),
                    ),
                    'h6_property' => array(
                        'title' => __('H6 Font Properties','magzenpro'),
                        'description' => __('Specify the h6 font properties.','magzenpro'),
                        'fields' => array (
                            'custom_h6_font' => array(
                                'type' => 'checkbox',
                                'label' => __('Enable Custom H6 Settings', 'magzenpro'),
                                'default' => 0, 
                            ),
                            'h6' => array(
                                'type' => 'typography',
                                'label' => __('H6 Settings', 'magzenpro'),
                            ),
                            'h6_color' => array(
                                'type' => 'color',
                                'label' => __('H6 Color', 'magzenpro'),
                                'sanitize_callback' => 'sanitize_hex_color',
                                'transport' => 'postMessage',
                                'default' => '#282827'
                            )  
                        ),
                    ),    
                ),
            ), // typography panel end // 
		) 
	)
	);

function magzenpro_boolean($value) {
	if(is_bool($value)) {
		return $value;
	} else {
		return false;
	}
}

function magzenpro_breadcrumb_char_choices($value='') {
	$choices = array('1','2','3');

	if( in_array($value, $choices)) {
		return $value;
	} else {
		return '1';
	}
}

if ( ! function_exists( 'magzenpro_footer_copyright' ) ) {

    function magzenpro_footer_copyright($string) {
        $allowed_tags = array(    
                            'a' => array(
                            	'href' => array(),
								'title' => array()
                            ),
							'img' => array(
								'src' => array(),  
								'alt' => array(),
							),
							'p' => array(),
							'br' => array(),
							'em' => array(),
                            'strong' => array(),
        );
        return wp_kses( $string,$allowed_tags);

    }
}

