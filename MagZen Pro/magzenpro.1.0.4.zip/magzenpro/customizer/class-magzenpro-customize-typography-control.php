<?php 
/**
 * Customizer Custom Control Class for Typography
 */
if( ! class_exists('MagZenPro_Customize_Typography_Control')) {
	class MagZenPro_Customize_Typography_Control extends WP_Customize_Control {
		public $type = 'typography';

		public function render_content() {
			?>
			<label>
				<span class="customize-control-title"><?php _e('Font Family', 'magzenpro'); ?></span>
				<select <?php $this->link('family'); ?>>
				<?php 
					printf(  '<optgroup label="%1$s">', __( 'Standard Fonts', 'magzenpro' ) );
					$font_manager = new MagZenPro_Font_Manager();
					$standard_fonts =  $font_manager->get_standard_fonts();
					foreach( $standard_fonts as $font => $family ) {
						printf( '<option value="%1$s">%2$s</option>', esc_attr( $family ), esc_html( $font ) );
					}
					printf( '</optgroup>');
					printf( '<optgroup label="%1$s">', __( 'Google Fonts', 'magzenpro') );
					$google_fonts =  $font_manager->get_google_fonts();
					foreach( $google_fonts as $font => $family ) {
						printf( '<option value="%1$s">%2$s</option>', esc_attr( $family ), esc_html( $font ) );
					}
					printf( '</optgroup>');

				?>
				</select>
			</label>
			<label>
				<span class="customize-control-title"><?php _e('Font Weight/Style','magzenpro'); ?></span>
				<select <?php $this->link('weight'); ?>>
					<option value="normal"><?php _e( 'Normal', 'magzenpro' ); ?></option>
					<option value="bold"><?php _e( 'Bold', 'magzenpro' ); ?></option>
				</select>
			</label>
			<label>
				<span class="customize-control-title"><?php _e('Font Size','magzenpro'); ?></span>
				<input type="number" <?php $this->link('size'); ?> min="1" value="<?php $this->value(); ?>">
			</label>
		<?php
		}
	}
}