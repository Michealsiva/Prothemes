<?php
/**
 * MagZenPro Gallery Widget
 *
 * @package MagZenPro 
 */ 

class MagZenPro_Gallery_Widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {  
		parent::__construct(
			'magzenpro-gallery-widget', // Base ID
			sprintf( esc_html__( '%s : Gallery', 'magzenpro' ), wp_get_theme()->Name ), // Name
			array( 'description' => __( 'Display latest posts or posts of specific category, which will be used as a gallery.', 'magzenpro' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 * 
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
        extract( $instance );
        echo $before_widget;

        global $post;
        $instance = wp_parse_args( $instance, array(
			'post_cat' => '',
			'post_count' => 4,
			'post_model' => __('latest','magzenpro'),	
			'gallery_type' => 'custom',
			'title_status'	=> false,	
		) );

        if( isset($post_model) && $post_model == 'latest' ) {
        	$magazine_args = array(
        		'posts_per_page'        => $post_count,
	            'post_type'             => 'post',
	            'post_status'            => 'publish',
	            'ignore_sticky_posts'    => true,
			    'order'                  => 'DESC',
        	);
        }else {   
            $magazine_args = array(
        		'posts_per_page'        => $post_count,
	            'post_type'             => 'post',
	            'post_status'            => 'publish',
	            'ignore_sticky_posts'    => true,
			    'order'                  => 'DESC',
	            'category__in'          => $post_cat
        	);
        }

	    $before_title = '<h4 class="widget-title">';
		$after_title = '</h4>';
		
        // Title
        if( isset($post_cat) && $post_cat && $post_model != 'latest') {
           $post_cat_name = get_the_category_by_ID($post_cat);
          
        }else{
        	$post_cat_name = apply_filters('magzen_recent_post_title', __('Latest Post','magzenpro') );
        }
       

        $title = apply_filters( 'widget_title', $post_cat_name ); 
        if ( ! empty( $title ) && !$title_status ) {
		   echo $before_title .'<span class="mag-divider">'. $title .'</span>'. $after_title;
	    }

    if( $gallery_type != 'auto' ): ?>    

		    <div class="magazine-gallery-wrapper clearfix"><?php	
		        $magazine_featured_posts = new WP_Query( $magazine_args );
		        if( $magazine_featured_posts->have_posts() ) : ?>
				    <div class="gallery-slider format-image"><?php
				       while( $magazine_featured_posts->have_posts() ) : 		    
				            $magazine_featured_posts->the_post(); ?>
						    	<div class="slides-wrapper">
						    		<div class="post-thumb">
						    			<a href="<?php the_permalink(); ?>"><img class="slider-gallery-image" src="<?php the_post_thumbnail_url('magzenpro-thumbnail-large'); ?>"></a>
						    		</div>
						    		<div class="post-content">
						    			<h5 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
						    		    <span class="date-structure">				
				                           <span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-calendar-o"></i><span class="mag-date-formate"><?php the_time('F j, Y'); ?></span></a></span>		
			                            </span>
						    		</div>
						    	</div><?php break; 
				    	endwhile;
				    	wp_reset_postdata();
				    	$magazine_featured_posts->rewind_posts(); ?>
				    </div>
				    <div class="mag-gallery clearfix"><?php
			        	while( $magazine_featured_posts->have_posts() ) : 		    
				            $magazine_featured_posts->the_post();
				            if ( has_post_thumbnail() ) : ?>			   	
			                    <li class="image-gallery-carousel">
								    <div class="mag-gallery-image">	
								    <?php $date_link = get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); 
			                              $date_formate = get_the_time("F j, Y"); ?>				
									<?php the_post_thumbnail( 'magzenpro-thumbnail-large', array('class' => 'mag-gallery-top-post', 'title' => esc_attr( get_the_title() ), 'alt' => esc_attr( get_the_title() ), 'data-link' => esc_attr( get_the_permalink() ), 'data-datelink' => $date_link, 'data-dateformate' => $date_formate ) ); ?>
									</div><!-- .entry-header -->					
							    </li><?php 	
						    endif;      		      		
				        endwhile; ?>
		            </div><?php
		        endif; ?> 
		    </div><?php
		    // Reset Post Data
		    wp_reset_postdata(); 

    else: ?> 
    	    <div class="magazine-auto-gallery-wrapper clearfix"><?php	
		        $magazine_featured_posts = new WP_Query( $magazine_args );?>
		        <ul class="magazine-auto-gallery slides"><?php	
			        while( $magazine_featured_posts->have_posts() ) : 
			            $magazine_featured_posts->the_post();
			            $post_title = get_the_title();
			            if( has_post_thumbnail() || $post_title != ''): ?>			   	
		                    <li class="image-gallery-auto-carousel">
							    <div class="mag-gallery-image"><?php
							    if ( has_post_thumbnail() ) :  ?>
								    <a href="<?php the_permalink(); ?>">					
									    <?php the_post_thumbnail( 'magzenpro-gallery-auto', array('class' => 'mag-gallery-top-post', 'title' => esc_attr( get_the_title() ), 'alt' => esc_attr( get_the_title() ) ) ); ?>
									</a><?php 
								endif; ?>
								<h5 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5> 
								</div><!-- .entry-header -->					
						    </li><?php 	  
					    endif;    		      		
			        endwhile; ?>  
		        </ul>
		    </div><?php
    endif;  

    echo $after_widget;
	}



	/**
	 * Display the flexcount widget form.
	 *
	 * @param array $instance
	 * @return string|void
	 */
	public function form( $instance ) {
		  $instance = wp_parse_args( $instance, array(
			'post_cat' => '',
			'post_count' => 10,
			'post_model' => __('latest','magzenpro'),	
			'gallery_type' => 'custom',
			'title_status'	=> false,	
		) );

	?>


<?php echo '<p style="display:block; margin: 20px 0px;">Layout will be as below:<br><img  src="'. get_template_directory_uri() .'/images/widget-gallery.png"></p>';?>

		<p>
			<label for="<?php echo $this->get_field_id('post_count') ?>"><?php _e('No. of Posts to display', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('post_count') ?>" name="<?php echo $this->get_field_name('post_count') ?>" value="<?php echo esc_attr($instance['post_count']) ?>" />
		</p>

	    <p>
	         <input type="radio" <?php checked($instance['post_model'],'latest') ?> id="<?php echo $this->get_field_id( 'post_model' ); ?>" name="<?php echo $this->get_field_name( 'post_model' ); ?>" value="latest"/><?php _e( 'Show latest Posts', 'magzenpro' );?><br />
	         <input type="radio" <?php checked($instance['post_model'],'category') ?> id="<?php echo $this->get_field_id( 'post_model' ); ?>" name="<?php echo $this->get_field_name( 'post_model' ); ?>" value="category"/><?php _e( 'Show posts from a category', 'magzenpro' );?><br />
	    </p>

		<p>
			<label for="<?php echo $this->get_field_id('post_cat') ?>"><?php _e(' Select Category ', 'magzenpro') ?></label>
			<?php wp_dropdown_categories( array( 'name' => $this->get_field_name( 'post_cat' ),'show_option_all'  => __('All Category','magzenpro'),'show_count' => true, 'selected' =>  $instance['post_cat'] ) ); ?>
		</p>

		<p>
		    <label for="<?php echo $this->get_field_id('gallery_type') ?>"><p>Choose Gallery Style Type</p></label>  
	         <input type="radio" <?php checked($instance['gallery_type'],'custom') ?> id="<?php echo $this->get_field_id( 'gallery_type' ); ?>" name="<?php echo $this->get_field_name( 'gallery_type' ); ?>" value="custom"/><?php _e( 'Custom Scroll', 'magzenpro' );?><br />
	         <input type="radio" <?php checked($instance['gallery_type'],'auto') ?> id="<?php echo $this->get_field_id( 'gallery_type' ); ?>" name="<?php echo $this->get_field_name( 'gallery_type' ); ?>" value="auto"/><?php _e( 'Auto Scroll', 'magzenpro' );?><br />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('title_status') ?>">
                <input type="checkbox" id="<?php echo $this->get_field_id('title_status') ?>" name="<?php echo $this->get_field_name('title_status') ?>" <?php checked( $instance['title_status'] ) ?> />
                <?php _e('Hide the Title', 'magzenpro') ?>  
            </label>
        </p>




		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['post_cat'] = ( ! empty( $new_instance['post_cat'] ) ) ? strip_tags( $new_instance['post_cat'] ) : '';
		$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
		$instance['post_model'] = ( ! empty( $new_instance['post_model'] ) ) ? strip_tags( $new_instance['post_model'] ) : '';
		$instance['gallery_type'] = ( ! empty( $new_instance['gallery_type'] ) ) ? strip_tags( $new_instance['gallery_type'] ) : '';
		$instance['title_status'] = !empty($new_instance['title_status']); 
		return $instance;
	}

} // class Foo_Widget