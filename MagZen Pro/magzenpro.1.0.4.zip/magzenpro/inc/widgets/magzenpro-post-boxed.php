<?php
/**
 * MagZenPro Posts Boxed Widget
 *
 * Display the latest posts from a selected category in a boxed layout. 
 * @package MagZenPro
 */

class MagZenPro_Post_Boxed_Widget extends WP_Widget {  
  
	/**
	 * Register widget with WordPress.
	 */
	function __construct() {
		parent::__construct(
			'magzenpro-post-boxed-widget', // Base ID
			sprintf( esc_html__( '%s : Posts Boxed', 'magzenpro' ), wp_get_theme()->Name ), // Name
			array( 'description' => __( 'Display latest posts or posts of specific category in a boxed layout.', 'magzenpro' ), ) // Args
		);
	}


	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
        extract( $instance );

        global $post;  
        $instance = wp_parse_args( $instance, array(
			'post_cat' => '',
			'post_count' => 4,
			'post_model' => __('latest','magzenpro'),
			'post_layout' => __( 'horizontal', 'magzenpro' ),
			'title_status'	=> false,		
		) );

        if( isset($post_model) && $post_model == 'latest' ) {
        	$magazine_args = array(
        		'posts_per_page'        => $post_count,
	            'post_type'             => 'post',
	            'post_status'            => 'publish',
	            'ignore_sticky_posts'    => true,
			    'order'                  => 'DESC',
        	);
        }else {
            $magazine_args = array(
        		'posts_per_page'        => $post_count,
	            'post_type'             => 'post',
	            'post_status'            => 'publish',
	            'ignore_sticky_posts'    => true,
			    'order'                  => 'DESC',
	            'category__in'          => $post_cat
        	);
        }

        if( isset($post_cat) && $post_cat && $post_model != 'latest') {
           $post_cat_name = get_the_category_by_ID($post_cat);
          
        }else{
        	$post_cat_name = apply_filters('magzen_recent_post_title', __('Latest Post','magzenpro') );
        }

        $title = apply_filters( 'widget_title', $post_cat_name );
        


		echo $before_widget;
	    $before_title = '<h4 class="widget-title">';
		$after_title = '</h4>';
		if($post_layout != 'horizontal') {

			 $magazine_featured_posts = new WP_Query( $magazine_args );
			 $i = 0;
		        if( $magazine_featured_posts->have_posts() ) :
		            if ( ! empty( $title ) && !$title_status ) {
					   echo $before_title .'<span class="mag-divider">'. $title .'</span>'. $after_title;
				    }
		        	while( $magazine_featured_posts->have_posts() ) : 
		        		 $magazine_featured_posts->the_post();
		        		if( isset($i) && $i== 0 ) : ?>
		        		<div class="vertical-head-wrapper">
	                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'large-post clearfix' ); ?>>

							    <header class="entry-header">					
								   <a href="<?php the_permalink() ?>" rel="bookmark"><?php the_post_thumbnail( 'magzenpro-thumbnail-large', array('title' => esc_attr( get_the_title() ), 'alt' => esc_attr( get_the_title() ) ) ); ?></a>
								</header><!-- .entry-header -->					
   
							   	<div class="entry-content">
								    <?php $categories_list = get_the_category_list( __( ' ', 'magzenpro' ) );
										if ( $categories_list ) {
											printf( '<span class="cat-links"> ' . __( '%1$s ', 'magzenpro' ) . '</span>', $categories_list );
										}
									   the_title( sprintf( '<h4 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' ); ?>
						               <div class="magazine-blog-meta">
						                <span class="date-structure">				
					                           <span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-calendar-o"></i><?php the_time('F j, Y'); ?></a></span>		
				                         </span> 
								    <?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
											echo ' <span class="comments-link"><i class="fa fa-comments"></i>';
											comments_popup_link( __( 'No comment', 'magzenpro' ), __( '1 Comment', 'magzenpro' ), __( '%', 'magzenpro' ) );
											echo '</span>';
									    } ?>
										</div><?php
										the_content(); ?>									
								</div><!-- .entry-content -->

						    </article>
						</div>
						    <div class="small-posts-vertical clearfix">
		        <?php   else: ?>
		                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'small-post clearfix' ); ?>>

								<?php if ( has_post_thumbnail() ) : ?>
									<a href="<?php the_permalink() ?>" rel="bookmark"><?php the_post_thumbnail( 'magzenpro-thumbnail-small', array('title' => esc_attr( get_the_title() ), 'alt' => esc_attr( get_the_title() ) ) ); ?></a>
								<?php endif; ?>

									<div class="small-post-content">
								    <?php the_title( sprintf( '<h4 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' ); ?>
							            <div class="magazine-blog-meta">
							                <span class="date-structure">				
						                           <span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-calendar-o"></i><?php the_time('F j, Y'); ?></a></span>		
					                         </span>
									    <?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
												echo ' <span class="comments-link"><i class="fa fa-comments"></i>';
												comments_popup_link( __( 'No comment', 'magzenpro' ), __( '1 Comment', 'magzenpro' ), __( '%', 'magzenpro' ) );
												echo '</span>';
										    } ?>									
									</div>
								</div>

							</article>
		        <?php	endif;
				      	$i++;    	      		      		
		        	endwhile; ?>
		        	</div>
		        	<?php
		        endif;
		        // Reset Post Data
		        wp_reset_postdata();

		}else{
            $magazine_featured_posts = new WP_Query( $magazine_args );
			 $i = 0;
		        if( $magazine_featured_posts->have_posts() ) :
		        	if ( ! empty( $title ) && !$title_status ) {
					   echo $before_title .'<span class="mag-divider">'. $title .'</span>'. $after_title;
				    }
		        	while( $magazine_featured_posts->have_posts() ) : 
		        		 $magazine_featured_posts->the_post();
		        		if( isset($i) && $i == 0 ): ?>
		        		<div class="horizontal-head-wrapper eight columns">
	                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'large-post clearfix' ); ?>>

							    <header class="entry-header">					
								   <a href="<?php the_permalink() ?>" rel="bookmark"><?php the_post_thumbnail( 'magzenpro-thumbnail-large', array('title' => esc_attr( get_the_title() ), 'alt' => esc_attr( get_the_title() ) ) ); ?></a>
								</header><!-- .entry-header -->					

							   	<div class="entry-content">
								    <?php $categories_list = get_the_category_list( __( ' ', 'magzenpro' ) );
										if ( $categories_list ) {
											printf( '<span class="cat-links">' . __( '%1$s ', 'magzenpro' ) . '</span>', $categories_list );
										}
									   the_title( sprintf( '<h4 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' ); ?>
						                <div class="magazine-blog-meta">
							                <span class="date-structure">				
						                           <span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-calendar-o"></i><?php the_time('F j, Y'); ?></a></span>		
					                         </span>
									    <?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
												echo ' <span class="comments-link"><i class="fa fa-comments"></i>';
												comments_popup_link( __( 'No comment', 'magzenpro' ), __( '1 Comment', 'magzenpro' ), __( '% ', 'magzenpro' ) );
												echo '</span>';
										    } ?>
										</div>
							<?php	the_content(); ?>									
								</div><!-- .entry-content -->

						    </article>
						</div>
						     <div class="small-posts-horizontal eight columns clearfix">
		        <?php   else: ?>
		                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'small-post clearfix' ); ?>>

								<?php if ( has_post_thumbnail() ) : ?>
									<a href="<?php the_permalink() ?>" rel="bookmark"><?php the_post_thumbnail( 'magzenpro-thumbnail-small', array('title' => esc_attr( get_the_title() ), 'alt' => esc_attr( get_the_title() ) ) ); ?></a>
								<?php endif; ?>

								<div class="small-post-content">
							      <?php the_title( sprintf( '<h4 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' ); ?>
						               <div class="magazine-blog-meta">
						                <span class="date-structure">				
					                           <span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-calendar-o"></i><?php the_time('F j, Y'); ?></a></span>		
				                         </span>
								    <?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
											echo ' <span class="comments-link"><i class="fa fa-comments"></i>';
											comments_popup_link( __( 'No comment', 'magzenpro' ), __( '1 Comment', 'magzenpro' ), __( '% ', 'magzenpro' ) );
											echo '</span>';
									    } ?>
									</div>									
								</div>

							</article>
		        <?php	endif;
				      	$i++;    	      		      		
		        	endwhile; ?>
		        	</div>
		        	<?php
		        endif;
		        // Reset Post Data
		        wp_reset_postdata();
		}
       
		echo $after_widget;
	}



	/**
	 * Display the flexcount widget form.
	 *
	 * @param array $instance
	 * @return string|void
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( $instance, array(
			'post_cat' => '',
			'post_count' => 4,
			'post_model' => __('latest','magzenpro'),
			'post_layout' => __( 'horizontal', 'magzenpro' ),	
			'title_status'	=> false,	
		) );

	?>

	<?php echo '<p style="display:block; margin: 20px 0px;">Layout will be as below:<br><img  src="'. get_template_directory_uri() .'/images/widget-boxed-vertical.png"></p>';?>
	<?php echo '<p style="display:block; margin: 20px 0px;">Layout will be as below:<br><img  src="'. get_template_directory_uri() .'/images/widget-boxed-horizontal.png"></p>';?>


		<p>
			<label for="<?php echo $this->get_field_id('post_count') ?>"><?php _e('No. of Posts to display', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('post_count') ?>" name="<?php echo $this->get_field_name('post_count') ?>" value="<?php echo esc_attr($instance['post_count']) ?>" />
		</p>

	    <p>
	         <input type="radio" <?php checked($instance['post_model'],'latest') ?> id="<?php echo $this->get_field_id( 'post_model' ); ?>" name="<?php echo $this->get_field_name( 'post_model' ); ?>" value="latest"/><?php _e( 'Show latest Posts', 'magzenpro' );?><br />
	         <input type="radio" <?php checked($instance['post_model'],'category') ?> id="<?php echo $this->get_field_id( 'post_model' ); ?>" name="<?php echo $this->get_field_name( 'post_model' ); ?>" value="category"/><?php _e( 'Show posts from a category', 'magzenpro' );?><br />
	    </p>


		<p>
			<label for="<?php echo $this->get_field_id('post_cat') ?>"><?php _e(' Select Category ', 'magzenpro') ?></label>
			<?php wp_dropdown_categories( array( 'name' => $this->get_field_name( 'post_cat' ),'show_option_all'  => __('All Category','magzenpro'),'show_count' => true, 'selected' =>  $instance['post_cat'] ) ); ?>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('post_layout') ?>"><?php _e('Post Layout', 'magzenpro') ?></label>
			<select id="<?php echo $this->get_field_id('post_layout') ?>" name="<?php echo $this->get_field_name('post_layout') ?>">
				<option value="horizontal" <?php selected($instance['post_layout'], "horizontal") ?>>Horizontal Arrangement</option>
				<option value="vertical" <?php selected($instance['post_layout'], "vertical") ?>>Vertical Arrangement</option>
			</select>
		</p>

		<p>
            <label for="<?php echo $this->get_field_id('title_status') ?>">
                <input type="checkbox" id="<?php echo $this->get_field_id('title_status') ?>" name="<?php echo $this->get_field_name('title_status') ?>" <?php checked( $instance['title_status'] ) ?> />
                <?php _e('Hide the Title', 'magzenpro') ?>  
            </label>
        </p>


		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['post_cat'] = ( ! empty( $new_instance['post_cat'] ) ) ? strip_tags( $new_instance['post_cat'] ) : '';
		$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
		$instance['post_layout'] = ( ! empty( $new_instance['post_layout'] ) ) ? strip_tags( $new_instance['post_layout'] ) : '';
		$instance['post_model'] = ( ! empty( $new_instance['post_model'] ) ) ? strip_tags( $new_instance['post_model'] ) : '';
		$instance['title_status'] = !empty($new_instance['title_status']);
		return $instance;
	}

} // class Foo_Widget