<?php 
get_template_part('inc/widgets/magzenpro-post-boxed');
get_template_part('inc/widgets/magzenpro-highlighted-post');
get_template_part('inc/widgets/magzenpro-featured-slider');
get_template_part('inc/widgets/magzenpro-featured-post');
get_template_part('inc/widgets/magzenpro-author');
get_template_part('inc/widgets/magzenpro-breaking-news');
get_template_part('inc/widgets/magzenpro-tabbed');
get_template_part('inc/widgets/magzenpro-gallery');
get_template_part('inc/widgets/magzenpro-advertisement');
get_template_part('inc/widgets/magzenpro-video');
get_template_part('inc/widgets/magzenpro-heading');
get_template_part('inc/widgets/magzenpro-social-network');
get_template_part('inc/widgets/magzenpro-random-post');
    
add_action('widgets_init','magzenpro_register_magazine_widgets');
if( !function_exists('magzenpro_register_magazine_widgets') ) {
	function magzenpro_register_magazine_widgets() {
		register_widget( 'MagZenPro_Post_Boxed_Widget' );
		register_widget( 'MagZenPro_Highlighted_Post_Widget' );
		register_widget( 'MagZenPro_Featured_Slider_Widget' );
		register_widget( 'MagZenPro_Featured_Post_Widget');
		register_widget( 'MagZenPro_Author_Widget');
		register_widget( 'MagZenPro_Breaking_News_Widget');
		register_widget( 'MagZenPro_Tabbed_Post_Widget');
		register_widget( 'MagZenPro_Gallery_Widget');
		register_widget( 'MagZenPro_Advertisement_Widget');
		register_widget( 'MagZenPro_Video_Widget');
		register_widget( 'MagZenPro_Heading_Widget'); 
		register_widget( 'MagZenPro_Social_Networks_Widget'); 
		register_widget( 'MagZenPro_Random_Posts_Widget');   

	}    
}
