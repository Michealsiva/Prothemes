<?php

/**
 * MagZenPro Author Widget
 */

class MagZenPro_Heading_Widget extends WP_Widget {

	public function __construct() {
		// widget actual processes
		parent::__construct(
			'magzenpro-heading-widget', // Base ID
			sprintf( esc_html__( '%s : Heading', 'magzenpro' ), wp_get_theme()->Name ), // Name
			array( 'description' => __( 'Display Heading', 'magzenpro' ), ) // Args
		);
	}

	public function widget( $args, $instance ) {
		extract( $args );
        extract( $instance );
		echo $before_widget;

	    $before_title = '<h4 class="widget-title">';
		$after_title = '</h4>';
		
		$instance = wp_parse_args( $instance, array(
			'level' => '1',
			'type' => 'normal',
			'content' => '',
		) );

		if( !empty($content) ) {
			if($type == 'normal') {
				$type_class = ' class="title-normal"';
			} else {
				$type_class = ' class="title-divider"';
			}

			$output = '';
			switch ($level) {
				case 1:
					$output .= '<h1' . $type_class . '>' . do_shortcode( $content ) . '</h1>';
					break;

				case 2:
					$output .= '<h2' . $type_class . '>' . do_shortcode( $content ) . '</h2>';
					break;

				case 3:
					$output .= '<h3' . $type_class . '>' . do_shortcode( $content ) . '</h3>';
					break;

				case 4:
					$output .= '<h4' . $type_class . '>' . do_shortcode( $content ) . '</h4>';
					break;

				case 5:
					$output .= '<h5' . $type_class . '>' . do_shortcode( $content ) . '</h5>';
					break;

				case 6:
					$output .= '<h6' . $type_class . '>' . do_shortcode( $content ) . '</h6>';
					break;
			}

		    echo $output;
	    }
	
		echo $after_widget;
	}

	/**
	 * Display the circle icon widget form.
	 *
	 * @param array $instance
	 * @return string|void
	 */
	public function form( $instance ) {

		$instance = wp_parse_args( $instance, array(
			'level' => '1',
			'type' => 'normal',
			'content' => '',
		) );

		?>
		<p>
			<label for="<?php echo $this->get_field_id('level') ?>"><?php _e('Level', 'magzenpro') ?></label>
			<select id="<?php echo $this->get_field_id('level') ?>" name="<?php echo $this->get_field_name('level') ?>">
				<option value="1" <?php selected('1', $instance['level']) ?>><?php esc_html_e('Level 1', 'magzenpro') ?></option>
				<option value="2" <?php selected('2', $instance['level']) ?>><?php esc_html_e('Level 2', 'magzenpro') ?></option>
				<option value="3" <?php selected('3', $instance['level']) ?>><?php esc_html_e('Level 3', 'magzenpro') ?></option>
				<option value="4" <?php selected('4', $instance['level']) ?>><?php esc_html_e('Level 4', 'magzenpro') ?></option>
				<option value="5" <?php selected('5', $instance['level']) ?>><?php esc_html_e('Level 5', 'magzenpro') ?></option>
				<option value="6" <?php selected('6', $instance['level']) ?>><?php esc_html_e('Level 6', 'magzenpro') ?></option>
			</select>
		</p> 
		<p>
			<label for="<?php echo $this->get_field_id('type') ?>"><?php _e('Level', 'magzenpro') ?></label>
			<select id="<?php echo $this->get_field_id('type') ?>" name="<?php echo $this->get_field_name('type') ?>">
				<option value="normal" <?php selected('normal', $instance['type']) ?>><?php esc_html_e('Normal', 'magzenpro') ?></option>
				<option value="divider" <?php selected('divider', $instance['type']) ?>><?php esc_html_e('Divider', 'magzenpro') ?></option>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('content') ?>"><?php _e('Heading', 'magzenpro') ?></label>
			<textarea class="widefat" id="<?php echo $this->get_field_id('content') ?>" name="<?php echo $this->get_field_name('content') ?>"><?php echo ($instance['content']) ?></textarea>
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		return $new_instance;
	}
}
