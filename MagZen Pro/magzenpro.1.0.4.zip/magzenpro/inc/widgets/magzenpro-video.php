<?php

/**
 * MagZenPro Video Widget
 */

class MagZenPro_Video_Widget extends WP_Widget {  

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {  
		parent::__construct(
			'magzenpro-video-widget', // Base ID
			sprintf( esc_html__( '%s : Video', 'magzenpro' ), wp_get_theme()->Name ), // Name
			array( 'description' => __( 'Display Youtube/Vimeo Video ', 'magzenpro' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		echo $args['before_widget'];

		$instance = wp_parse_args( $instance, array(
			'youtube_id' => '',
			'vimeo_id'=> '',
			'title' => '',
			'width' => '560',
			'height' => '315',
		) ); 
        $title = apply_filters( 'widget_title', $instance['title'] );

		$args['before_title'] = '<h4 class="widget-title">';
		$args['after_title'] = '</h4>';
		
        if ( ! empty( $title ) ) {
		   echo $args['before_title'] .'<span class="mag-divider">'. $title .'</span>'. $args['after_title'];
	    } ?>

		<div class="magzen-video">
			<div class="video-content"><?php 
			    $output = '';
			    if($instance['youtube_id']) {
			    	$output .= '<iframe width="'. $instance['width'] .'" height="' . $instance['height'] . '" ';
				    $output .= 'src="http://www.youtube.com/embed/' . $instance['youtube_id'] .'" frameborder="0" allowfullscreen></iframe>';
			    }
			    if($instance['vimeo_id']) {
			    	$output .= '<iframe src="http://player.vimeo.com/video/' .$instance['vimeo_id'].'" ';
				    $output .= 'width="' . $instance['width'] . '" height="' . $instance['height'] .'" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>';
			    }
			    echo $output;
			?></div>
		</div>


		<?php echo $args['after_widget']; 
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( $instance, array(
			'youtube_id' => '',
			'vimeo_id'=> '',
			'title' => '',
			'width' => '560',
			'height' => '315',
		) );
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e('Title', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('title') ?>" name="<?php echo $this->get_field_name('title') ?>" value="<?php echo esc_attr($instance['title']) ?>" />
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('youtube_id') ?>"><?php _e('Youtube Video ID', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('youtube_id') ?>" name="<?php echo $this->get_field_name('youtube_id') ?>" value="<?php echo esc_attr($instance['youtube_id']) ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('vimeo_id') ?>"><?php _e('Vimeo Video ID', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('vimeo_id') ?>" name="<?php echo $this->get_field_name('vimeo_id') ?>" value="<?php echo esc_attr($instance['vimeo_id']) ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('width') ?>"><?php _e('Width (Numerals only)', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('width') ?>" name="<?php echo $this->get_field_name('width') ?>" value="<?php echo esc_attr($instance['width']) ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('height') ?>"><?php _e('Height (Numerals Only)', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('height') ?>" name="<?php echo $this->get_field_name('height') ?>" value="<?php echo esc_attr($instance['height']) ?>" />
		</p>

		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		
		$instance['youtube_id'] = $new_instance['youtube_id'];
		$instance['vimeo_id'] = $new_instance['vimeo_id'];
		$instance['title'] = $new_instance['title'];
		$instance['width'] = $new_instance['width'];
		$instance['height'] = $new_instance['height'];

		return $instance;
	}

} // class Foo_Widget
