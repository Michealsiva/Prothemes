<?php
/**
 * MagZenPro Social Networks Widget.
 *
 */

class MagZenPro_Social_Networks_Widget extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {  
		parent::__construct(
			'magzenpro-social-network-widget', // Base ID
			sprintf( esc_html__( '%s : Social Network', 'magzenpro' ), wp_get_theme()->Name ), // Name
			array( 'description' => __( 'Display Social networks ', 'magzenpro' ), ) // Args
		);
	}


	public function widget( $args, $instance ) {
		extract( $args );
        extract( $instance );

		$instance = wp_parse_args( $instance, array(
			'title' => __("Social Networks", 'magzenpro'),
		) );

	
		echo $before_widget;
		$before_title = '<h4 class="widget-title">';
		$after_title = '</h4>';
		
		if ( ! empty( $title ) ) {
			echo $before_title . $title . $after_title;
		}

		$output = '';
		$output .= '<ul class="magzen-social-widget">';
		$digg = trim( get_theme_mod( 'digg' ) );
		if( $digg ) :
		    $output .= '<li><a href="'. esc_url( $digg ) . '"><i class="fa fa-digg"></i></a></li>';
		endif;

		$dribbble = trim( get_theme_mod( 'dribbble' ) );
		if( $dribbble ) :
		    $output .= '<li><a href="'. esc_url( $dribbble ) . '"><i class="fa fa-dribbble"></i></a></li>';
		endif;

		$facebook = trim( get_theme_mod( 'facebook' ) );
		if( $facebook ) :
		    $output .= '<li><a href="'. esc_url( $facebook ) . '"><i class="fa fa-facebook"></i></a></li>';
		endif;

		$flickr = trim( get_theme_mod( 'flickr' ) );
		if( $flickr ) :
		    $output .= '<li><a href="'. esc_url( $flickr ) . '"><i class="fa fa-flickr"></i></a></li>';
		endif;

		$google_plus = trim( get_theme_mod( 'google_plus' ) );
		if( $google_plus ) :
		    $output .= '<li><a href="'. esc_url( $google_plus ) . '"><i class="fa fa-google-plus"></i></a></li>';
		endif;

		$instagram = trim( get_theme_mod( 'instagram' ) );
		if( $instagram ) :
		    $output .= '<li><a href="'. esc_url( $instagram ) . '"><i class="fa fa-instagram"></i></a></li>';
		endif;

		$linkedin = trim( get_theme_mod( 'linkedin' ) );
		if( $linkedin ) :
		    $output .= '<li><a href="'. esc_url( $linkedin ) . '"><i class="fa fa-linkedin"></i></a></li>';
		endif;

		$pinterest = trim( get_theme_mod( 'pinterest' ) );
		if( $pinterest ) :
		    $output .= '<li><a href="'. esc_url( $pinterest ) . '"><i class="fa fa-pinterest"></i></a></li>';
		endif;

		$rss = trim( get_theme_mod( 'rss' ) );
		if( $rss ) :
		    $output .= '<li><a href="'. esc_url( $rss ) . '"><i class="fa fa-rss"></i></a></li>';
		endif;

		$skype = trim( get_theme_mod( 'skype' ) );
		if( $skype ) :
		    $output .= '<li><a href="'. esc_url( $skype ) . '"><i class="fa fa-skype"></i></a></li>';
		endif;

		$tumblr = trim( get_theme_mod( 'tumblr' ) );
		if( $tumblr ) :
		    $output .= '<li><a href="'. esc_url( $tumblr ) . '"><i class="fa fa-tumblr"></i></a></li>';
		endif;

		$twitter = trim( get_theme_mod( 'twitter' ) );
		if( $twitter ) :
		    $output .= '<li><a href="'. esc_url( $twitter ) . '"><i class="fa fa-twitter"></i></a></li>';
		endif;

		$vimeo = trim( get_theme_mod( 'vimeo' ) );
		if( $vimeo ) :
		    $output .= '<li><a href="'. esc_url( $vimeo ) . '"><i class="fa fa-vimeo-square"></i></a></li>';
		endif;

		$youtube = trim( get_theme_mod( 'youtube' ) );
		if( $youtube ) :
		    $output .= '<li><a href="'. esc_url( $youtube ) . '"><i class="fa fa-youtube"></i></a></li>';
		endif;
		$output .= '</ul>';

		echo $output;


		echo $after_widget;
	}

	/**
	 * Display the skill widget form.
	 *
	 * @param array $instance
	 * @return string|void
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( $instance, array(
			'title' => __("Social Networks", 'magzenpro'),
		) );
		?>

		<p>
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e('Title', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('title') ?>" name="<?php echo $this->get_field_name('title') ?>" value="<?php echo esc_attr($instance['title']) ?>" />
		</p>
		<p>Enter your social network URLs here (Goto Customize => Theme options => Social Networks )</p>

	<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		return $instance;
	}
}
