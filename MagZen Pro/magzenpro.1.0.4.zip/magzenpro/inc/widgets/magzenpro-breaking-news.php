<?php

/**
 * MagZenPro Breaking News Widget
 */

class MagZenPro_Breaking_News_Widget extends WP_Widget {  
         
	/**
	 * Register widget with WordPress.
	 */
	function __construct() {    
		parent::__construct(
			'magzenpro-breaking-news-widget', // Base ID
			sprintf( esc_html__( '%s : Breaking News', 'magzenpro' ), wp_get_theme()->Name ), // Name
			array( 'description' => __( 'Display Breaking News ', 'magzenpro' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
        extract( $instance );

		echo $before_widget;
		$instance = wp_parse_args( $instance, array(
			'count'=> '',
			'title' => '',
			'auto_scroll' => false,

		) ); 
		
		$before_title = '<h4 class="widget-title">';
		$after_title = '</h4>';

        if ( ! empty( $title ) ) {
		   echo $before_title .'<span class="mag-divider">'. $title .'</span>'. $after_title;
	    } 
         
        global $post;    
    	$magazine_args = array( 
    		'posts_per_page'        => $count,
            'post_type'             => 'post',
            'post_status'            => 'publish',
            'ignore_sticky_posts'    => true,
		    'order'                  => 'DESC', 
    	);

    	$magazine_featured_posts = new WP_Query( $magazine_args );
	        if( $magazine_featured_posts->have_posts() ) : ?>
	        <div class="breaking-news-outer-wrapper"><?php
	        if($auto_scroll): ?>
		        <i class="fa fa-arrow-up" id="magzen-bv-prev"></i>
		        <ul class="breakingnews-vertical"><?php
	        endif; 
	        	while( $magazine_featured_posts->have_posts() ) : 		    
		            $magazine_featured_posts->the_post(); ?>
			        <li id="post-<?php the_ID(); ?>" <?php post_class( 'breaking-news-post clearfix' ); ?>>
						<div class="magzen-breaking-news-wrapper">  
						<?php if ( has_post_thumbnail() ) : ?>
							<figure class="magzen-breaking-img-left"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_post_thumbnail( 'magzenpro-thumbnail-small', array('title' => esc_attr( get_the_title() ), 'alt' => esc_attr( get_the_title() ) ) ); ?></a></figure>
						<?php endif; ?>
							<div class="small-post-content">
						    <?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
					            <div class="magazine-blog-meta">
					                <span class="date-structure">				
				                           <span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-calendar-o"></i><?php the_time('F j, Y'); ?></a></span>		
			                         </span>
							    <?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
										echo ' <span class="comments-link"><i class="fa fa-comments"></i>';
										comments_popup_link( __( 'No comment', 'magzenpro' ), __( '1 Comment', 'magzenpro' ), __( '%', 'magzenpro' ) );
										echo '</span>';
								    } ?>									
							    </div>
						    </div>
	                    </div>
					</li><?php
		        endwhile; 
		    if($auto_scroll): ?>
			    </ul>
			    <i class="fa fa-arrow-down" id="magzen-bv-next"></i><?php
		    endif; ?>
		    </div><?php
		    endif; 
	        // Reset Post Data
	        wp_reset_postdata();  ?>


		<?php echo $after_widget; 
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( $instance, array(
			'title' => '',
			'count'=> '',
			'auto_scroll' => false,
		) );
		?>
		<?php echo '<p style="display:block; margin: 20px 0px;">Layout will be as below:<br><img  src="'. get_template_directory_uri() .'/images/widget-breaking-news.png"></p>';?>
		
		<p>
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e('Title', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('title') ?>" name="<?php echo $this->get_field_name('title') ?>" value="<?php echo esc_attr($instance['title']) ?>" />
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('count') ?>"><?php _e('No.of recent post to show as a breaking news:', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('count') ?>" name="<?php echo $this->get_field_name('count') ?>" value="<?php echo esc_attr($instance['count']) ?>" />
		</p>

		<p>
            <label for="<?php echo $this->get_field_id('auto_scroll') ?>">
                <input type="checkbox" id="<?php echo $this->get_field_id('auto_scroll') ?>" name="<?php echo $this->get_field_name('auto_scroll') ?>" <?php checked( $instance['auto_scroll'] ) ?> />
                <?php _e('Enable Auto Scroll', 'magzenpro') ?>
            </label>
        </p>

		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();

		$instance['count'] = $new_instance['count'];
		$instance['title'] = $new_instance['title'];
		$instance['auto_scroll'] = !empty($new_instance['auto_scroll']);
		

		return $instance;
	}

} // class Foo_Widget
