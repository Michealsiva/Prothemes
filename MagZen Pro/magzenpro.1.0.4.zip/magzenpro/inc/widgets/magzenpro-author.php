<?php

/**
 * MagZenPro Author Widget
 */

class MagZenPro_Author_Widget extends WP_Widget {  

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {  
		parent::__construct(
			'magzenpro-author-widget', // Base ID
			sprintf( esc_html__( '%s : Author', 'magzenpro' ), wp_get_theme()->Name ), // Name
			array( 'description' => __( 'Display Author details ', 'magzenpro' ), ) // Args
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
        extract( $instance );

		echo $before_widget;
		$instance = wp_parse_args( $instance, array(
			'content' => '',
			'image_url' => '',
			'href'=> '',
			'title' => '',
			'facebook'=> '',
			'flickr'=> '',
			'linkedin'=> '',
			'instagram'=> '',
			'youtube'=> '',
			'google' => '',
			'twitter' => '',
		) ); 
       
		$before_title = '<h4 class="widget-title">';
		$after_title = '</h4>';
		
        if ( ! empty( $title ) ) {
		    echo $before_title .'<span class="mag-divider">'. $title .'</span>'. $after_title;
	    } ?>

		<div class="magzen-author">
			 <a class="author-img" href="<?php echo esc_url($href); ?>" target="_blank"><img src="<?php echo $image_url;?>"></a>
			 <div class="magzen-author-content"><?php echo $content;?></div>	
			 <?php 
		        if( $instagram != '' || $youtube != '' || $flickr != '' || $linkedin != '' || $google != '' || $twitter != '' || $facebook != '' ) :
					$output = '';
					$output .= '<div class="magzen-author-social">';
						$output .= '<ul>';
						if( isset( $linkedin ) && $linkedin != '') :
					        $output .= '<li><a href="'. esc_url( $linkedin ) .'"><i class="fa fa-linkedin fa-lg"></i></a></li>';
					    endif;
					    if( isset( $google ) && $google != '') :
					        $output .= '<li><a href="'. esc_url( $google ) . '"><i class="fa fa-google-plus fa-lg"></i></a></li>';
					    endif;
					    if( isset( $twitter ) && $twitter != '') :
					        $output .= '<li><a href="' . esc_url( $twitter ) . '"><i class="fa fa-twitter fa-lg"></i></a></li>';
					    endif;
					    if( isset( $facebook ) && $facebook != '' ) :
					        $output .= '<li><a href="' . esc_url( $facebook ) .'"><i class="fa fa-facebook fa-lg"></i></a></li>';
					    endif;
					    if( isset( $flickr ) && $flickr != '' ) :
					        $output .= '<li><a href="' . esc_url( $flickr ) .'"><i class="fa fa-flickr fa-lg"></i></a></li>';
					    endif;
					    if( isset( $instagram ) && $instagram != '' ) :
					        $output .= '<li><a href="' . esc_url( $instagram ) .'"><i class="fa fa-instagram fa-lg"></i></a></li>';
					    endif;
					    if( isset( $youtube ) && $youtube != '' ) :
					        $output .= '<li><a href="' . esc_url( $youtube ) .'"><i class="fa fa-youtube fa-lg"></i></a></li>';
					    endif;
					      $output .= '</ul>';
					$output .= '</div>';
					echo $output;
				endif;
			 ?>
		</div>


		<?php echo $after_widget; 
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( $instance, array(
			'content' => '',
			'image_url' => '',
			'title' => '',
			'href'=> '',
			'facebook'=> '',
			'flickr'=> '',
			'linkedin'=> '',
			'instagram'=> '',
			'youtube'=> '',
			'google' => '',
			'twitter' => '',
		) );
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e('Title', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('title') ?>" name="<?php echo $this->get_field_name('title') ?>" value="<?php echo esc_attr($instance['title']) ?>" />
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('image_url') ?>"><?php _e('Image URL of Author', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('image_url') ?>" name="<?php echo $this->get_field_name('image_url') ?>" value="<?php echo esc_attr($instance['image_url']) ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('href') ?>"><?php _e('Author Link', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('href') ?>" name="<?php echo $this->get_field_name('href') ?>" value="<?php echo esc_attr($instance['href']) ?>" />
		</p>
 
        <p>
			<label for="<?php echo $this->get_field_id( 'content' ); ?>"><?php _e( 'Content:' ); ?></label> 
			<textarea class="widefat" id="<?php echo $this->get_field_id( 'content' ); ?>" name="<?php echo $this->get_field_name( 'content' ); ?>"><?php echo esc_html( $instance['content'] ); ?></textarea>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('facebook') ?>"><?php _e('Facebook URL', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('facebook') ?>" name="<?php echo $this->get_field_name('facebook') ?>" value="<?php echo esc_attr($instance['facebook']) ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('flickr') ?>"><?php _e('Flickr URL', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('flickr') ?>" name="<?php echo $this->get_field_name('flickr') ?>" value="<?php echo esc_attr($instance['flickr']) ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('linkedin') ?>"><?php _e('Linkedin URL', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('linkedin') ?>" name="<?php echo $this->get_field_name('linkedin') ?>" value="<?php echo esc_attr($instance['linkedin']) ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('instagram') ?>"><?php _e('Instagram URL', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('instagram') ?>" name="<?php echo $this->get_field_name('instagram') ?>" value="<?php echo esc_attr($instance['instagram']) ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('youtube') ?>"><?php _e('Youtube URL', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('youtube') ?>" name="<?php echo $this->get_field_name('youtube') ?>" value="<?php echo esc_attr($instance['youtube']) ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('google') ?>"><?php _e('Google URL', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('google') ?>" name="<?php echo $this->get_field_name('google') ?>" value="<?php echo esc_attr($instance['google']) ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('twitter') ?>"><?php _e('Twitter URL', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('twitter') ?>" name="<?php echo $this->get_field_name('twitter') ?>" value="<?php echo esc_attr($instance['twitter']) ?>" />
		</p>

		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$allowed_tags = array(    
							'a' => array(
	        					'href' => array(),
    	    					'title' => array()
    					),
						    'em' => array(),
						    'strong' => array(),
						    'br' => array(),
						);

		$instance['content'] = ( ! empty( $new_instance['content'] ) ) ? wp_kses( $new_instance['content'], $allowed_tags ) : '';
		$instance['image_url'] = $new_instance['image_url'];
		$instance['href'] = $new_instance['href'];
		$instance['title'] = $new_instance['title'];
		$instance['facebook'] = $new_instance['facebook'];
		$instance['flickr'] = $new_instance['flickr'];
		$instance['linkedin'] = $new_instance['linkedin'];
		$instance['instagram'] = $new_instance['instagram'];
		$instance['youtube'] = $new_instance['youtube'];
		$instance['google'] = $new_instance['google'];
		$instance['twitter'] = $new_instance['twitter'];

		return $instance;
	}

} // class Foo_Widget
