<?php  

/**
 * MagZenPro Tabbed Post Widget
 */

class MagZenPro_Tabbed_Post_Widget extends WP_Widget {  

	/**
	 * Register widget with WordPress.
	 */
	function __construct() {  
		parent::__construct(
			'magzenpro-tabbed-post-widget', // Base ID
			sprintf( esc_html__( '%s : Tabbed Post', 'magzenpro' ), wp_get_theme()->Name ), // Name
			array( 'description' => __( 'Display Tabbed Feature Post ', 'magzenpro' ), ) // Args
		);
	}  

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		extract( $args );
        extract( $instance );

		echo $before_widget;
		$instance = wp_parse_args( $instance, array(
			'count'=> '',
			'title' => '',  
		) ); 
	    $before_title = '<h4 class="widget-title">';
		$after_title = '</h4>';
		
        if ( ! empty( $title ) ) {
		    echo $before_title .'<span class="mag-divider">'. $title .'</span>'. $after_title;
	    } 
         
        global $post;   
    	$magazine_popular_args = array(
    		'posts_per_page'         => $count,
            'post_type'              => 'post',
            'post_status'            => 'publish',
            'ignore_sticky_posts'    => true,
		    'order'                  => 'DESC',
		    'orderby'                => 'comment_count',  
    	);
        
/* Popular post */
$popular_post = '';  
 
    	$magazine_popular_posts = new WP_Query( $magazine_popular_args );   
	        if( $magazine_popular_posts->have_posts() ) :
	        	while( $magazine_popular_posts->have_posts() ) : 		    
			        $magazine_popular_posts->the_post(); 
			        $popular_post .= '<article id="post-'. get_the_ID() .'" class="breaking-news-post clearfix">';
						$popular_post .= '<section class="magzen-breaking-news-wrapper">';
							if ( has_post_thumbnail() ) : 
								$popular_post .= '<figure class="magzen-breaking-img-left"><a href="'. get_the_permalink().'" rel="bookmark">'. get_the_post_thumbnail( $magazine_popular_posts->post->ID,'magzenpro-tabbed-post') .'</a></figure>';
							endif;    
							$popular_post .= '<section class="small-post-content">';
							    $popular_post .=  '<h2 class="entry-title"><a href="'.get_the_permalink().'">'.get_the_title().'</a></h2>'; 
						            $popular_post .=  '<section class="magazine-blog-meta">';
						                $popular_post .= '<span class="date-structure">';				
					                           $popular_post .= '<span class="dd"><a class="url fn n" href="'.  get_day_link(get_the_time("Y"), get_the_time("m"),get_the_time("d")). '"><i class="fa fa-calendar-o"></i>'. get_the_time("F j, Y").'</a></span>';		
				                        $popular_post .= '</span>';
								        if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
											$popular_post .=  ' <span class="comments-link"><i class="fa fa-comments"></i>';
											$popular_post .= magzenpro_get_comments_meta();
											$popular_post .=  '</span>';
									    } 									
								    $popular_post .= '</section>';
							$popular_post .= '</section>';
		                $popular_post .= '</section>';
					$popular_post .= '</article>';
		        endwhile;
		    endif; 
	        // Reset Post Data
	        wp_reset_postdata(); 

/* Recent post */
        global $post;   
    	$magazine_recent_args = array(
    		'posts_per_page'        => $count,
            'post_type'             => 'post',
            'post_status'            => 'publish',
            'ignore_sticky_posts'    => true,
		    'order'                  => 'DESC',
    	);
$recent_post = '';  

    	$magazine_recent_posts = new WP_Query( $magazine_recent_args );
	        if( $magazine_recent_posts->have_posts() ) :
	        	while( $magazine_recent_posts->have_posts() ) : 		    
			        $magazine_recent_posts->the_post(); 
			        $recent_post .= '<article id="post-'. get_the_ID() .'" class="breaking-news-post clearfix">';
						$recent_post .= '<section class="magzen-breaking-news-wrapper">';
							if ( has_post_thumbnail() ) : 
								$recent_post .= '<figure class="magzen-breaking-img-left"><a href="'. get_the_permalink().'" rel="bookmark">'. get_the_post_thumbnail( $magazine_recent_posts->post->ID,'magzenpro-tabbed-post') .'</a></figure>';
							endif;    
							$recent_post .= '<section class="small-post-content">';
							    $recent_post .=  '<h2 class="entry-title"><a href="'.get_the_permalink().'">'.get_the_title().'</a></h2>'; 
						            $recent_post .=  '<section class="magazine-blog-meta">';
						                $recent_post .= '<span class="date-structure">';				
					                           $recent_post .= '<span class="dd"><a class="url fn n" href="'.  get_day_link(get_the_time("Y"), get_the_time("m"),get_the_time("d")). '"><i class="fa fa-calendar-o"></i>'. get_the_time("F j, Y").'</a></span>';		
				                        $recent_post .= '</span>';
								        if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
											$recent_post .=  ' <span class="comments-link"><i class="fa fa-comments"></i>';
											$recent_post .= magzenpro_get_comments_meta();
											$recent_post .=  '</span>';
									    } 									
								    $recent_post .= '</section>';
							$recent_post .= '</section>';
		                $recent_post .= '</section>';
					$recent_post .= '</article>';
		        endwhile;
		    endif; 
	        // Reset Post Data
	        wp_reset_postdata(); 

	    /* Comments */
	    $comments_post = '';  
			$comments_post .= '<section class="tabbed-comments-wrapper">';
				$comments = get_comments( array(
				    'number'    =>  $count,
				    'status'    => 'approve'
				) );
				foreach($comments as $comment) : 
					$comments_post .= '<li class="tabbed-comments">';
				        $comments_post .= '<a class="tabbed-commemt-author" href="'.get_permalink($comment->comment_post_ID).'#comment-'.$comment->comment_ID.'"><img src="'.get_avatar_url($comment->user_id,array('size' => 50)).'">'.$comment->comment_author.'</a> '.__('says:','magzenpro');
				         $comments_post .= '<section class="tabbed-comment-content">'.$comment->comment_content.'</section>';
					$comments_post .= '</li>';
				endforeach;
			$comments_post .= '</section>';  
	      

    	$tab_shortcode = '[tabs_group] 
	    	[tabs title="Popular"]'.$popular_post.'
	    	[/tabs]
	    	[tabs title="Recent"]'.$recent_post.'
	    	[/tabs]
	    	[tabs title="Comments"]'.$comments_post.'
	    	[/tabs]
    	[/tabs_group]'; 

         echo do_shortcode($tab_shortcode);
		
		 echo $after_widget;; 
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( $instance, array(
			'title' => '',
			'count'=> '',
		) );
		?>
		<?php echo '<p style="display:block; margin: 20px 0px;">Layout will be as below:<br><img  src="'. get_template_directory_uri() .'/images/widget-tab.png"></p>';?>
		<p>
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e('Title', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('title') ?>" name="<?php echo $this->get_field_name('title') ?>" value="<?php echo esc_attr($instance['title']) ?>" />
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('count') ?>"><?php _e('No.of popular posts, recent posts and comments to display:', 'magzenpro') ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('count') ?>" name="<?php echo $this->get_field_name('count') ?>" value="<?php echo esc_attr($instance['count']) ?>" />
		</p>

		<?php 
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();

		$instance['count'] = $new_instance['count'];
		$instance['title'] = $new_instance['title'];

		return $instance;
	}

} // class Foo_Widget
