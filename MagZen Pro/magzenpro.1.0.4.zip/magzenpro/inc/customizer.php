<?php
/**
 * magzenpro Theme Customizer
 *
 * @package MagZenPro
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */   
function magzenpro_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
}
add_action( 'customize_register', 'magzenpro_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function magzenpro_customize_preview_js() {
	wp_enqueue_script( 'magzenpro_customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'magzenpro_customize_preview_js' );


/* Typography Script */
add_action( 'wp_enqueue_scripts','magzenpro_customizer_enqueue_scripts' );
function magzenpro_customizer_enqueue_scripts() {
	if( get_theme_mod('custom_body_font',false) ) {
		$body_font = get_theme_mod('body_family');
		if($body_font) {
			$body_font_url = magzenpro_theme_font_url($body_font);
			wp_enqueue_style(
				$body_font,
				$body_font_url,
				array(),
				'20150707',
				'all'
			);
		}
	}
	if( get_theme_mod('custom_navigation_font',false) ) {
		$navigation_font = get_theme_mod('navigation_family');
		if($navigation_font) {
			$navigation_font_url = magzenpro_theme_font_url($navigation_font);
			wp_enqueue_style(
				$navigation_font,
				$navigation_font_url,
				array(),
				'20150707',
				'all'
			);
		}
	}
	if( get_theme_mod('custom_h1_font',false) ) {
		$h1_font = get_theme_mod('h1_family');
		if($h1_font) {
			$h1_font_url = magzenpro_theme_font_url($h1_font);
			wp_enqueue_style(
				$h1_font,
				$h1_font_url,
				array(),
				'20150707',
				'all'
			);
		}
	}
	if( get_theme_mod('custom_h2_font',false) ) {
		$h2_font = get_theme_mod('h2_family');
		if($h2_font) {
			$h2_font_url = magzenpro_theme_font_url($h2_font);
			wp_enqueue_style(
				$h2_font,
				$h2_font_url,
				array(),
				'20150707',
				'all'
			);
		}
	}
	if( get_theme_mod('custom_h3_font',false) ) {
		$h3_font = get_theme_mod('h3_family');
		if($h3_font) {
			$h3_font_url = magzenpro_theme_font_url($h3_font);
			wp_enqueue_style(
				$h3_font,
				$h3_font_url,
				array(),
				'20150707',
				'all'
			);
		}
	}
	if( get_theme_mod('custom_h4_font',false) ) {
		$h4_font = get_theme_mod('h4_family');
		if($h4_font) {
			$h4_font_url = magzenpro_theme_font_url($h4_font);
			wp_enqueue_style(
				$h4_font,
				$h4_font_url,
				array(),
				'20150707',
				'all'
			);
		}
	}
    if( get_theme_mod('custom_h5_font',false) ) {
		$h5_font = get_theme_mod('h5_family');
		if($h5_font) {
			$h5_font_url = magzenpro_theme_font_url($h5_font);
			wp_enqueue_style(
				$h5_font,
				$h5_font_url,
				array(),
				'20150707',
				'all'
			);
		}
	}
	if( get_theme_mod('custom_h6_font',false) ) {
		$h6_font = get_theme_mod('h6_family');
		if($h6_font) {
			$h6_font_url = magzenpro_theme_font_url($h6_font);
			wp_enqueue_style(
				$h6_font,
				$h6_font_url,
				array(),
				'20150707',
				'all'
			);
		}
	}

}

/* Typography Styles */
if( get_theme_mod('custom_body_font',false) ) {
	add_action( 'wp_head','magzenpro_customizer_body_custom_css' );

	function magzenpro_customizer_body_custom_css() {
		$body_font = get_theme_mod('body_family','Oxygen,sans-serif');
		$body_color = get_theme_mod( 'body_color','#282827' );
		$body_size = get_theme_mod( 'body_size','16');
		$body_weight = get_theme_mod( 'body_weight','normal'); ?>
	    <style type="text/css">
			body {
				font-family: '<?php echo $body_font; ?>';
				color: <?php echo $body_color; ?>;
				font-size: <?php echo $body_size; ?>px;  
				font-weight: <?php echo $body_weight; ?>; 
			}
		</style><?php
	}
}

/* navigation style */
if( get_theme_mod('custom_navigation_font',false) ) {
	add_action( 'wp_head','magzenpro_customizer_navigation_custom_css' );

	function magzenpro_customizer_navigation_custom_css() {
		$navigation_font = get_theme_mod('navigation_family','Oxygen,sans-serif');
		$navigation_color = get_theme_mod( 'navigation_color','#ffffff' );
		$navigation_size = get_theme_mod( 'navigation_size','16');
		$navigation_weight = get_theme_mod( 'navigation_weight','normal'); ?>
	    <style type="text/css">
			.main-navigation a {
				font-family: '<?php echo $navigation_font; ?>';
				color: <?php echo $navigation_color; ?>;
				font-size: <?php echo $navigation_size; ?>px;  
				font-weight: <?php echo $navigation_weight; ?>; 
			}
		</style><?php
	}
}

if( get_theme_mod('custom_h1_font',false) ) {
	add_action( 'wp_head','magzenpro_customizer_h1_custom_css' );

	function magzenpro_customizer_h1_custom_css() {
		$h1_font = get_theme_mod('h1_family','Poppins,sans-serif');
		$h1_color = get_theme_mod( 'h1_color','#2c3e50' );
		$h1_size = get_theme_mod( 'h1_size','48');
		$h1_weight = get_theme_mod( 'h1_weight','bold');?>
	    <style type="text/css">
			h1 {
				font-family: '<?php echo $h1_font; ?>';
				color: <?php echo $h1_color; ?>;
				font-size: <?php echo $h1_size; ?>px;  
				font-weight: <?php echo $h1_weight; ?>;
		    }
		</style><?php
	}
}

if( get_theme_mod('custom_h2_font',false) ) {
	add_action( 'wp_head','magzenpro_customizer_h2_custom_css' );

	function magzenpro_customizer_h2_custom_css() {
		$h2_font = get_theme_mod('h2_family','Poppins,sans-serif');
		$h2_color = get_theme_mod( 'h2_color','#2c3e50' );
		$h2_size = get_theme_mod( 'h2_size','36');
		$h2_weight = get_theme_mod( 'h2_weight','bold');?>
	    <style type="text/css">
			h2 {
				font-family: '<?php echo $h2_font; ?>';
				color: <?php echo $h2_color; ?>;
				font-size: <?php echo $h2_size; ?>px;  
				font-weight: <?php echo $h2_weight; ?>;
		    }
		</style><?php
	}
}

if( get_theme_mod('custom_h3_font',false) ) {
	add_action( 'wp_head','magzenpro_customizer_h3_custom_css' );

	function magzenpro_customizer_h3_custom_css() {
		$h3_font = get_theme_mod('h3_family','Poppins,sans-serif');
		$h3_color = get_theme_mod( 'h3_color','#2c3e50' );
		$h3_size = get_theme_mod( 'h3_size','30');
		$h3_weight = get_theme_mod( 'h3_weight','bold');?>
	    <style type="text/css">
			h3 {
				font-family: '<?php echo $h3_font; ?>';
				color: <?php echo $h3_color; ?>;
				font-size: <?php echo $h3_size; ?>px;  
				font-weight: <?php echo $h3_weight; ?>;
		    }
		</style><?php
	}
}

if( get_theme_mod('custom_h4_font',false) ) {
	add_action( 'wp_head','magzenpro_customizer_h4_custom_css' );

	function magzenpro_customizer_h4_custom_css() {
		$h4_font = get_theme_mod('h4_family','Poppins,sans-serif');
		$h4_color = get_theme_mod( 'h4_color','#2c3e50' );
		$h4_size = get_theme_mod( 'h4_size','24');
		$h4_weight = get_theme_mod( 'h4_weight','bold');?>
	    <style type="text/css">
			h4 {
				font-family: '<?php echo $h4_font; ?>';
				color: <?php echo $h4_color; ?>;
				font-size: <?php echo $h4_size; ?>px;  
				font-weight: <?php echo $h4_weight; ?>;
		    }
		</style><?php
	}
}

if( get_theme_mod('custom_h5_font',false) ) {
	add_action( 'wp_head','magzenpro_customizer_h5_custom_css' );

	function magzenpro_customizer_h5_custom_css() {
		$h5_font = get_theme_mod('h5_family','Poppins,sans-serif');
		$h5_color = get_theme_mod( 'h5_color','#2c3e50' );
		$h5_size = get_theme_mod( 'h5_size','18');
		$h5_weight = get_theme_mod( 'h5_weight','bold');?>
	    <style type="text/css">
			h5 {
				font-family: '<?php echo $h5_font; ?>';
				color: <?php echo $h5_color; ?>;
				font-size: <?php echo $h5_size; ?>px;  
				font-weight: <?php echo $h5_weight; ?>;
		    }
		</style><?php
	}
}

if( get_theme_mod('custom_h6_font',false) ) {
	add_action( 'wp_head','magzenpro_customizer_h6_custom_css' );

	function magzenpro_customizer_h6_custom_css() {
		$h6_font = get_theme_mod('h6_family','Poppins,sans-serif');
		$h6_color = get_theme_mod( 'h6_color','#2c3e50' );
		$h6_size = get_theme_mod( 'h6_size','16');
		$h6_weight = get_theme_mod( 'h6_weight','bold');?>
	    <style type="text/css">
			h6 {
				font-family: '<?php echo $h6_font; ?>';
				color: <?php echo $h6_color; ?>;
				font-size: <?php echo $h6_size; ?>px;  
				font-weight: <?php echo $h6_weight; ?>;
		    }
		</style><?php
	}
}  


if( get_theme_mod('custom_primary_color_section',false) ) {
	add_action( 'wp_head','magzenpro_customizer_primary_color_custom_css' );

	function magzenpro_customizer_primary_color_custom_css() {	
		$primary_color = get_theme_mod( 'primary_color','#f15c22'); ?>
		
<style type="text/css">
	a, .main-navigation ul li.current-menu-ancestor>a, .main-navigation ul li.current-menu-item>a, .main-navigation ul li.current_page_ancestor>a, .main-navigation ul li.current_page_item>a,.main-navigation li:hover>a,.branding .site-branding .site-title a:hover,
	.breadcrumb-wrapper .breadcrumb a:hover ,.breaknews .breaknews-wrapper a:hover,ol.comment-list .reply:hover:before, ol.comment-list .reply:hover a ,
	.comment-author .fn a,ol.comment-list article .comment-meta .fn ,.comment-metadata a:hover,
	.hentry.post h1 a:hover , .magazine-post-wrapper h4.entry-title:hover,.blog .entry-title a:hover,.magazine-slider-top-meta span:hover a, .magazine-slider-top-meta span:hover i,.cart-subtotal .amount, .order-total .amount,
	.woocommerce #content table.cart a.remove, .woocommerce-page #content table.cart a.remove, .woocommerce-page table.cart a.remove, .woocommerce table.cart a.remove,
	.woocommerce-page .woocommerce-breadcrumb a:hover,.widget_magzenpro-post-boxed-widget .magazine-blog-meta a:hover,.widget_magzenpro-post-boxed-widget .entry-title a:hover, .woocommerce .woocommerce-breadcrumb a:hover,
	.widget-area ul li a:hover,#secondary #recentcomments a:hover,.widget_calendar table td a:hover, .widget_calendar table th a:hover,
	.mag-slider .mag-caption .entry-title a:hover,.mag-slider .mag-caption .magazine-slider-top-meta .fa:hover, .mag-slider .mag-caption .magazine-slider-top-meta a:hover ,.site-footer .widget_calendar table a,.widget-area .widget_rss span,.widget-area .widget_rss a:hover ,.widget_highlighted_post_area .single-highlited-post .highlights-content .entry-title a:hover,
	.widget_highlighted_post_area .single-highlited-post .highlights-content .magazine-slider-top-meta .fa:hover, .widget_highlighted_post_area .single-highlited-post .highlights-content .magazine-slider-top-meta a:hover,
	.widget_magzenpro-breaking-news-widget #magzen-bv-next, .site-footer .footer-widgets a:hover,.widget_magzenpro-breaking-news-widget #magzen-bv-prev,.magzen-breaking-news-wrapper .entry-title a:hover, .magzen-random-news-wrapper .entry-title a:hover ,.magzen-breaking-news-wrapper .magazine-blog-meta .fa:hover, .magzen-breaking-news-wrapper .magazine-blog-meta a:hover, .magzen-random-news-wrapper .magazine-blog-meta .fa:hover, .magzen-random-news-wrapper .magazine-blog-meta a:hover,
	.magazine-gallery-wrapper .post-content .entry-title a:hover,.site-info .left-sidebar .textwidget ul li a:hover,.site-info p a ,.site-footer .footer-widgets .calendar_wrap a:hover ,.magazine-gallery-wrapper .post-content .date-structure .fa:hover, .magazine-gallery-wrapper .post-content .date-structure a:hover ,.magazine-auto-gallery-wrapper .image-gallery-auto-carousel .entry-title a:hover
	 {
		color: <?php echo $primary_color; ?>;
	}

	th a,.nav-links a:hover {
		color: <?php echo $primary_color; ?>!important;
	}

	button, input[type=button], input[type=reset], input[type=submit],.comment-navigation .nav-next a:hover, .comment-navigation .nav-previous a:hover, .entry-body .more-link:hover, .page-links a:hover, .paging-navigation .nav-next a:hover, .paging-navigation .nav-previous a:hover, .post-navigation .nav-next a:hover, .post-navigation .nav-previous a:hover, .posts-navigation .nav-next a:hover, .posts-navigation .nav-previous a:hover,.breadcrumb-wrapper .breadcrumb .txt-bread,
	.breaknews .bn-title ,.top-nav,.share-box ul li a:hover ,.portfolio-readmore a:hover ,.hentry.sticky,.page-links ,.magazine-post-wrapper .image-date,
	.woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce #content div.product .woocommerce-tabs ul.tabs li a:hover, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li a:hover, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page div.product .woocommerce-tabs ul.tabs li a:hover, .woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,
	.woocommerce #content nav.woocommerce-pagination ul li a:focus, .woocommerce #content nav.woocommerce-pagination ul li a:hover, .woocommerce #content nav.woocommerce-pagination ul li span.current, .woocommerce-page #content nav.woocommerce-pagination ul li a:focus, .woocommerce-page #content nav.woocommerce-pagination ul li a:hover, .woocommerce-page #content nav.woocommerce-pagination ul li span.current, .woocommerce-page nav.woocommerce-pagination ul li a:focus, .woocommerce-page nav.woocommerce-pagination ul li a:hover, .woocommerce-page nav.woocommerce-pagination ul li span.current, .woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current,
	.woocommerce a.remove,.widget_calendar table thead,.scroll-to-top ,.widget_search .search-form input[type=submit],.site-footer .widget_text a ,.magzen-author .magzen-author-social li a:hover,
	.widget_tag_cloud a:hover,.site-footer .footer-widgets .widget_calendar table caption,.tabs ul.tab_heading,.widget_magzenpro-post-boxed-widget .entry-content .cat-links a,.slicknav_menu .current-menu-ancestor>a, .slicknav_menu .slicknav_row:hover, .slicknav_menu li.current-menu-item>a, .slicknav_menu li a:hover,.slicknav_menu .slicknav_btn, .slicknav_menu .slicknav_btn:hover
	{
		background-color: <?php echo $primary_color; ?>;
	}

	.woocommerce #content input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce-page #content input.button:hover, .woocommerce-page #respond input#submit:hover, .woocommerce-page a.button:hover, .woocommerce-page button.button:hover, .woocommerce-page input.button:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover ,.mCSB_dragger_bar, .mCSB_dragger_bar
	{
		background-color: <?php echo $primary_color; ?>!important;
	}

	input[type=email]:focus, input[type=password]:focus, input[type=search]:focus, input[type=text]:focus, input[type=url]:focus, textarea:focus,.navigation.pagination .page-numbers.current 
	{ 
		border-color: <?php echo $primary_color; ?>;
	}

	.comment-respond h3:after,.title-divider:after, .widget .widget-title:after {
		border-bottom-color:  <?php echo $primary_color; ?>;
	}

</style><?php
	}
} 


if( get_theme_mod('custom_secondary_color_section',false) ) {
	add_action( 'wp_head','magzenpro_customizer_secondary_color_custom_css' );

	function magzenpro_customizer_secondary_color_custom_css() {	
		$secondary_color = get_theme_mod( 'secondary_color','#2c3e50'); ?>
		
<style type="text/css">
	
	h1, h2, h3, h4, h5, h6 ,.navigation.pagination .page-numbers,.navigation.pagination .page-numbers.current,.branding .site-branding .site-title a ,.breadcrumb-wrapper .breadcrumb a ,
	.breaknews .breaknews-wrapper a,.top-nav li a:hover,.top-nav ul li:hover a ,.cart-right li:hover a,.widget_magzenpro-post-boxed-widget .entry-content .entry-title a ,.widget_magzenpro-post-boxed-widget .entry-title a,.magazine-post-wrapper.magzenpro-horizontal-one .portfolio-readmore a:hover ,.cart-right a:hover, .cart-right li a:hover .fa,.share-box ul li a ,ol.comment-list .reply ,ol.comment-list .reply a,ol.comment-list .reply:before ,.comment-author,
	.comment-author .fn a:hover,ol.comment-list article .comment-meta .fn:hover,.hentry.sticky .magazine-slider-top-meta a:hover, .hentry.sticky .magazine-slider-top-meta i:hover, .hentry.sticky .magazine-slider-top-meta span:hover ,.hentry.sticky .entry-title a:hover,.hentry.sticky a ,.hentry.sticky span:hover a, .hentry.sticky span:hover i ,
	.hentry.sticky .entry-footer a:hover,.magzen-breaking-news-wrapper .entry-title a, .magzen-random-news-wrapper .entry-title a ,.magazine-gallery-wrapper .post-content .entry-title a,.magazine-auto-gallery-wrapper .image-gallery-auto-carousel .entry-title a ,.tabs .tabs_container ,.site-footer .footer-widgets .calendar_wrap thead th,.site-footer .footer-widgets .widget_tag_cloud a,.widget_tag_cloud a ,.widget-area .widget_rss a,.widget-area .widget_rss .widget-title .rsswidget,.widget_search .search-form input[type=search], .hentry.sticky .entry-meta a:hover,.magazine-post-wrapper h4.entry-title,.portfolio-readmore a,.blog .entry-title a
	{
		color: <?php echo $secondary_color; ?>;
	}

	 table tr th:hover a ,.nav-links a ,.widget_search .search-form input[type=search]:focus 
	 {
		color: <?php echo $secondary_color; ?>!important; 
	}

	.nav-wrap,.main-navigation ul ul li ,.comment-navigation .nav-next a, .comment-navigation .nav-previous a, .entry-body .more-link, .page-links a, .paging-navigation .nav-next a, .paging-navigation .nav-previous a, .post-navigation .nav-next a, .post-navigation .nav-previous a, .posts-navigation .nav-next a, .posts-navigation .nav-previous a ,button:hover, input[type=button]:hover, input[type=reset]:hover, input[type=submit]:hover ,.nav-wrap .header-search-box .search-field:focus
	.mag-slider .flex-direction-nav a:hover,.site-footer .widget_text a:hover,.widget_magzenpro-post-boxed-widget .entry-content .cat-links a:hover ,
	.woocommerce #content input.button, .woocommerce #respond input#submit, .woocommerce-page #content input.button, .woocommerce-page #respond input#submit, .woocommerce-page a.button, .woocommerce-page button.button, .woocommerce-page input.button, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button ,.woocommerce #content div.product p.price, .woocommerce #content div.product span.price, .woocommerce-page #content div.product p.price, .woocommerce-page #content div.product span.price, .woocommerce-page div.product p.price, .woocommerce-page div.product span.price, .woocommerce-page ul.products li.product .price, .woocommerce div.product p.price, .woocommerce div.product span.price, .woocommerce ul.products li.product .price ,.woocommerce #content table.cart a.remove:hover, .woocommerce-page #content table.cart a.remove:hover, .woocommerce-page table.cart a.remove:hover, .woocommerce table.cart a.remove:hover ,
	.woocommerce #content nav.woocommerce-pagination ul li a, .woocommerce #content nav.woocommerce-pagination ul li span, .woocommerce-page #content nav.woocommerce-pagination ul li a, .woocommerce-page #content nav.woocommerce-pagination ul li span, .woocommerce-page nav.woocommerce-pagination ul li a, .woocommerce-page nav.woocommerce-pagination ul li span, .woocommerce nav.woocommerce-pagination ul li a, .woocommerce nav.woocommerce-pagination ul li span ,.woocommerce #content nav.woocommerce-pagination ul, .woocommerce #content nav.woocommerce-pagination ul li ,.woocommerce #content div.product .woocommerce-tabs ul.tabs li, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li, .woocommerce-page div.product .woocommerce-tabs ul.tabs li, .woocommerce div.product .woocommerce-tabs ul.tabs li,
	.widget_calendar .calendar_wrap,.widget_calendar table tbody th, .widget_calendar table tbody tr,
	.magzen-author .magzen-author-social li a ,.site-footer,.site-footer .footer-widgets .calendar_wrap tbody tr:nth-child(2n) td, .site-footer .footer-widgets .calendar_wrap tbody tr:nth-child(2n) th, .site-footer .footer-widgets .calendar_wrap tbody tr:nth-child(odd) td, .site-footer .footer-widgets .calendar_wrap tbody tr:nth-child(odd) th ,.slicknav_menu
	{
		background-color: <?php echo $secondary_color; ?>;
	}

	.navigation.pagination .page-numbers ,button:hover, input[type=button]:hover, input[type=reset]:hover, input[type=submit]:hover ,button:active, button:focus, input[type=button]:active, input[type=button]:focus, input[type=reset]:active, input[type=reset]:focus, input[type=submit]:active, input[type=submit]:focus
	{ 
		border-color: <?php echo $secondary_color; ?>;
	}

	abbr, acronym {	
		border-bottom-color:  <?php echo $secondary_color; ?>;
	}

</style><?php
	}
} 