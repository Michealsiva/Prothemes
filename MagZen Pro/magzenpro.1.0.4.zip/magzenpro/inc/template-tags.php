<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package MagZenPro
 */   

/** 
 * Admin Notices
 */
// Add license key activation admin notice    

$license_status= get_option( 'magzen-pro_license_key_status', false );
 
if(  $license_status == false && $license_status != 'valid' )  {
	add_action('admin_notices','magzenpro_activate_license_notice');
	if( !function_exists('magzenpro_activate_license_notice') )  {
		 function magzenpro_activate_license_notice(){
			$output = '';
			$output .= '<div class="update-nag theme-activation">';
			$output .= 'Please <a href="' . admin_url( 'themes.php?page=magzen-pro-license') . '"><strong>Activate MagZenPro License</strong></a> to receive updates and other benefits';
			$output .= '</div>';

			echo $output;
		 }
    }  
}


if ( ! function_exists( 'magzenpro_posted_on' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */ 	
function magzenpro_posted_on() {
	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
	}

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

	$posted_on = sprintf(
		esc_html_x( 'Posted on %s', 'post date', 'magzenpro' ),
		'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
	);

	$byline = sprintf(
		esc_html_x( 'by %s', 'post author', 'magzenpro' ),
		'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	echo '<span class="posted-on">' . $posted_on . '</span><span class="byline"> ' . $byline . '</span>'; // WPCS: XSS OK.

}
endif;

if ( ! function_exists( 'magzenpro_entry_footer' ) ) :
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function magzenpro_entry_footer() {
	// Hide category and tag text for pages.
	if ( 'post' === get_post_type() ) {
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( esc_html__( ', ', 'magzenpro' ) );
		if ( $categories_list && magzenpro_categorized_blog() ) {
			printf( '<span class="cat-links">' . esc_html__( 'Posted in %1$s', 'magzenpro' ) . '</span>', $categories_list ); // WPCS: XSS OK.
		}

		/* translators: used between list items, there is a space after the comma */
		$tags_list = get_the_tag_list( '', esc_html__( ', ', 'magzenpro' ) );
		if ( $tags_list ) {
			printf( '<span class="tags-links">' . esc_html__( 'Tagged %1$s', 'magzenpro' ) . '</span>', $tags_list ); // WPCS: XSS OK.
		}
	}

	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		echo '<span class="comments-link">';
		/* translators: %s: post title */
		comments_popup_link( sprintf( wp_kses( __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'magzenpro' ), array( 'span' => array( 'class' => array() ) ) ), get_the_title() ) );
		echo '</span>';
	}

	edit_post_link(
		sprintf(
			/* translators: %s: Name of current post */
			esc_html__( 'Edit %s', 'magzenpro' ),
			the_title( '<span class="screen-reader-text">"', '"</span>', false )
		),
		'<span class="edit-link">',
		'</span>'
	);
}
endif;

/**
 * Returns true if a blog has more than 1 category.
 *
 * @return bool
 */
function magzenpro_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'magzen_categories' ) ) ) {
		// Create an array of all the categories that are attached to posts.
		$all_the_cool_cats = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,
			// We only need to know if there is more than one category.
			'number'     => 2,
		) );

		// Count the number of categories that are attached to the posts.
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'magzen_categories', $all_the_cool_cats );
	}

	if ( $all_the_cool_cats > 1 ) {
		// This blog has more than 1 category so magzenpro_categorized_blog should return true.
		return true;
	} else {
		// This blog has only 1 category so magzenpro_categorized_blog should return false.
		return false;
	}
}

/**
 * Flush out the transients used in magzenpro_categorized_blog.
 */
function magzenpro_category_transient_flusher() {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	// Like, beat it. Dig?
	delete_transient( 'magzen_categories' );
}
add_action( 'edit_category', 'magzenpro_category_transient_flusher' );
add_action( 'save_post',     'magzenpro_category_transient_flusher' );


/* Theme Related Functions */
if ( ! function_exists( 'magzenpro_post_nav' ) ) :
/**  
 * Display navigation to next/previous post when applicable.
 */
function magzenpro_post_nav() {
	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( get_post()->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous ) {
		return;
	}
	?>
	<nav class="navigation post-navigation clearfix" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Post navigation', 'magzenpro' ); ?></h1>
		<div class="nav-links">
			<?php
				previous_post_link( '<div class="nav-previous">%link</div>', _x( '%title', 'Previous post link', 'magzenpro' ) );
				next_post_link(     '<div class="nav-next">%link</div>',     _x( '%title&nbsp;', 'Next post link',     'magzenpro' ) );
			?>
		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<?php
}
endif;

/**
  * Generates Breadcrumb Navigation
  */
 
 if( ! function_exists( 'magzenpro_breadcrumbs' )) {
 
	function magzenpro_breadcrumbs() {
		/* === OPTIONS === */
		$text['home']     = __( 'Home','magzenpro' ); // text for the 'Home' link
		$text['category'] = __( 'Archive by Category "%s"','magzenpro' ); // text for a category page
		$text['search']   = __( 'Search Results for "%s" Query','magzenpro' ); // text for a search results page
		$text['tag']      = __( 'Posts Tagged "%s"','magzenpro' ); // text for a tag page
		$text['author']   = __( 'Articles Posted by %s','magzenpro' ); // text for an author page
		$text['404']      = __( 'Error 404','magzenpro' ); // text for the 404 page

		$showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
		$showOnHome  = 0; // 1 - show breadcrumbs on the homepage, 0 - don't show
		$breadcrumb_char = get_theme_mod( 'breadcrumb_char', '1' );
		if ( $breadcrumb_char ) {
		 switch ( $breadcrumb_char ) {
		 	case '2' :
		 		$delimiter = ' // ';
		 		break;
		 	case '3':
		 		$delimiter = ' > ';
		 		break;
		 	case '1':
		 	default:
		 		$delimiter = ' &raquo; ';
		 		break;
		 }
		}

		$before      = '<span class="current">'; // tag before the current crumb
		$after       = '</span>'; // tag after the current crumb
		/* === END OF OPTIONS === */

		global $post;
		$homeLink = home_url() . '/';
		$linkBefore = '<span typeof="v:Breadcrumb">';
		$linkAfter = '</span>';
		$linkAttr = ' rel="v:url" property="v:title"';
		$link = $linkBefore . '<a' . $linkAttr . ' href="%1$s">%2$s</a>' . $linkAfter;

		if (is_home() || is_front_page()) {

			if ($showOnHome == 1) echo '<div id="crumbs"><a href="' . $homeLink . '">' . $text['home'] . '</a></div>';

		} else {

			echo '<div id="crumbs" xmlns:v="http://rdf.data-vocabulary.org/#">' . sprintf($link, $homeLink, $text['home']) . $delimiter;

			if ( is_category() ) {
				$thisCat = get_category(get_query_var('cat'), false);
				if ($thisCat->parent != 0) {
					$cats = get_category_parents($thisCat->parent, TRUE, $delimiter);
					$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
					$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
					echo $cats;
				}
				echo $before . sprintf($text['category'], single_cat_title('', false)) . $after;

			} elseif ( is_search() ) {
				echo $before . sprintf($text['search'], get_search_query()) . $after;

			} elseif ( is_day() ) {
				echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;
				echo sprintf($link, get_month_link(get_the_time('Y'),get_the_time('m')), get_the_time('F')) . $delimiter;
				echo $before . get_the_time('d') . $after;

			} elseif ( is_month() ) {
				echo sprintf($link, get_year_link(get_the_time('Y')), get_the_time('Y')) . $delimiter;
				echo $before . get_the_time('F') . $after;

			} elseif ( is_year() ) {
				echo $before . get_the_time('Y') . $after;

			} elseif ( is_single() && !is_attachment() ) {
				if ( get_post_type() != 'post' ) {
					$post_type = get_post_type_object(get_post_type());
					$slug = $post_type->rewrite;
					printf($link, $homeLink . '/' . $slug['slug'] . '/', $post_type->labels->singular_name);
					if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;
				} else {
					$cat = get_the_category(); $cat = $cat[0];
					$cats = get_category_parents($cat, TRUE, $delimiter);
					if ($showCurrent == 0) $cats = preg_replace("#^(.+)$delimiter$#", "$1", $cats);
					$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
					$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
					echo $cats;
					if ($showCurrent == 1) echo $before . get_the_title() . $after;
				}
   
			} elseif ( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ) {
				$post_type = get_post_type_object(get_post_type());
				echo $before . $post_type->labels->singular_name . $after;

			} elseif ( is_attachment() ) {
				$parent = get_post($post->post_parent);
				$cat = get_the_category($parent->ID); $cat = $cat[0];
				$cats = get_category_parents($cat, TRUE, $delimiter);
				$cats = str_replace('<a', $linkBefore . '<a' . $linkAttr, $cats);
				$cats = str_replace('</a>', '</a>' . $linkAfter, $cats);
				echo $cats;
				printf($link, get_permalink($parent), $parent->post_title);
				if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;

			} elseif ( is_page() && !$post->post_parent ) {
				if ($showCurrent == 1) echo $before . get_the_title() . $after;

			} elseif ( is_page() && $post->post_parent ) {
				$parent_id  = $post->post_parent;
				$breadcrumbs = array();
				while ($parent_id) {
					$page = get_page($parent_id);
					$breadcrumbs[] = sprintf($link, get_permalink($page->ID), get_the_title($page->ID));
					$parent_id  = $page->post_parent;
				}
				$breadcrumbs = array_reverse($breadcrumbs);
				for ($i = 0; $i < count($breadcrumbs); $i++) {
					echo $breadcrumbs[$i];
					if ($i != count($breadcrumbs)-1) echo $delimiter;
				}
				if ($showCurrent == 1) echo $delimiter . $before . get_the_title() . $after;

			} elseif ( is_tag() ) {
				echo $before . sprintf($text['tag'], single_tag_title('', false)) . $after;

			} elseif ( is_author() ) {
		 		global $author;
				$userdata = get_userdata($author);
				echo $before . sprintf($text['author'], $userdata->display_name) . $after;

			} elseif ( is_404() ) {
				echo $before . $text['404'] . $after;
			}

			if ( get_query_var('paged') ) {
				if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
				echo __('Page', 'magzenpro' ) . ' ' . get_query_var('paged');
				if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
			}

			echo '</div>';

		}
	
	} // end magzenpro_breadcrumbs()

}



// Related Posts Function by Tags (call using magzenpro_related_posts(); ) /NecessarY/ May be write a shortcode?
if ( ! function_exists( 'magzenpro_related_posts' ) ) :
	function magzenpro_related_posts() {
		echo '<div class="magzen-related-post-gallery"><ul id="magzen-related-posts" class="slides">';	
		global $post;
		$post_hierarchy = get_theme_mod('related_posts_hierarchy','1');
		$relatedposts_per_page  =  get_option('post_per_page') ;
		if($post_hierarchy == '1') {
			$related_post_type = wp_get_post_tags($post->ID);
			$tag_arr = '';
			if($related_post_type) { 
				foreach($related_post_type as $tag) { $tag_arr .= $tag->slug . ','; }
		        $args = array(
		        	'tag' => $tag_arr,
		        	'numberposts' => $relatedposts_per_page, /* you can change this to show more */
		        	'post__not_in' => array($post->ID)
		     	);
		   }
		}else {
			$related_post_type = get_the_category($post->ID); 
			if ($related_post_type) {
				$category_ids = array();
				foreach($related_post_type as $category) {
				     $category_ids = $category->term_id; 
				}  
				$args = array(
					'category__in' => $category_ids,
					'post__not_in' => array($post->ID),
					'numberposts' => $relatedposts_per_page,
		        );
		    }
		}
		if( $related_post_type ) {
	        $related_posts = get_posts($args);
	        if($related_posts) {
	        	foreach ($related_posts as $post) : setup_postdata($post); ?>
		           	<li class="related_post">
		           		<a class="entry-unrelated" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail('recent-work'); ?></a>
		           		<a class="entry-unrelated" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
		           	</li>
		        <?php endforeach; }
		    else {
	            echo '<li class="no_related_post">' . __( 'No Related Posts Yet!', 'magzenpro' ) . '</li>'; 
			 }
		}else{
			echo '<li class="no_related_post">' . __( 'No Related Posts Yet!', 'magzenpro' ) . '</li>';
		}
		wp_reset_query();
		
		echo '</ul></div>';
	}
endif;

if( !function_exists('magzenpro_get_comments_popup_link') ) {
	function magzenpro_get_comments_popup_link( $zero = false, $one = false, $more = false, $css_class = '', $none = false ) {
		global $wpcommentspopupfile, $wpcommentsjavascript;

		$id = get_the_ID();
		$title = get_the_title();
		$number = get_comments_number( $id );

		if ( false === $zero ) {
			/* translators: %s: post title */
			$zero = sprintf( __( 'No Comments<span class="screen-reader-text"> on %s</span>','magzenpro' ), $title );
		}

		if ( false === $one ) {
			/* translators: %s: post title */
			$one = sprintf( __( '1 Comment<span class="screen-reader-text"> on %s</span>','magzenpro' ), $title );
		}

		if ( false === $more ) {
			/* translators: 1: Number of comments 2: post title */
			$more = _n( '%1$s Comment<span class="screen-reader-text"> on %2$s</span>', '%1$s Comments<span class="screen-reader-text"> on %2$s</span>', $number, 'magzenpro' );
			$more = sprintf( $more, number_format_i18n( $number ), $title );
		}

		if ( false === $none ) {
			/* translators: %s: post title */
			$none = sprintf( __( 'Comments Off<span class="screen-reader-text"> on %s</span>','magzenpro' ), $title );
		}

		if ( 0 == $number && !comments_open() && !pings_open() ) {
			return '<span' . ((!empty($css_class)) ? ' class="' . esc_attr( $css_class ) . '"' : '') . '>' . $none . '</span>';
		}

		if ( post_password_required() ) {
			return __('Enter your password to view comments.','magzenpro');
		}

		$link_anchor =  '<a href="';
		if ( $wpcommentsjavascript ) {
			if ( empty( $wpcommentspopupfile ) )
				$home = home_url();
			else
				$home = get_option('siteurl');
			$link_anchor .= $home . '/' . $wpcommentspopupfile . '?comments_popup=' . $id;
			$link_anchor .= '" onclick="wpopen(this.href); return false"';
		} else { 
			if ( 0 == $number ){
				$link_anchor .= get_permalink() . '#respond';	
			} else {
				$link_anchor .= get_comments_link();
			}
			$link_anchor .= '"';
		}

		if ( !empty( $css_class ) ) {
			$link_anchor .= ' class="'.$css_class.'" ';
		}

		$attributes = '';
		$link_anchor .= apply_filters( 'comments_popup_link_attributes', $attributes );
		$link_anchor .= '>';
		$link_anchor .= get_comments_number_text( $zero, $one, $more );
		$link_anchor .= '</a>';
		return $link_anchor;
	}
}

if( !function_exists('magzenpro_get_comments_meta') ) {
	function magzenpro_get_comments_meta() {
		if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			$comments_meta = '<span class="comments-link">';
			$comments_meta .= magzenpro_get_comments_popup_link( __( 'comment', 'magzenpro' ), __( '1 Comment', 'magzenpro' ), __( '%', 'magzenpro' ) );
			$comments_meta .=  '</span>';
			return $comments_meta;

		}	
	}
}


/* MORE TEXT VALUE */

add_filter( 'the_content_more_link','magzenpro_add_more_link_class');   
if(! function_exists('magzenpro_add_more_link_class') ) {
	function magzenpro_add_more_link_class( ) {
		$more_text = get_theme_mod('more_text');
		if( $more_text && !empty( $more_text ) ) {
			$more_link_text = sprintf(__('%1$s','magzenpro'), $more_text );
		}else{
			$more_link_text = __('Read More','magzenpro');
		}
		return '<p class="portfolio-readmore"><a class="btn btn-mini more-link" href="' . get_permalink() . '">'.$more_link_text.'</a></p>';
	} 
}

/* Magazine Post meta details */
if ( ! function_exists( 'magzenpro_entry_top_meta' ) ) : 
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function magzenpro_entry_top_meta() {    
	// Post meta data 	
     $post_top_meta_date = get_theme_mod('post_top_meta_date',true);
     $post_top_meta_author = get_theme_mod('post_top_meta_author',true);
     $post_top_meta_comment = get_theme_mod('post_top_meta_comment',true);
     $post_top_meta_category = get_theme_mod('post_top_meta_category',false);
     $post_top_meta_tag = get_theme_mod('post_top_meta_tag',false);
     $post_top_meta_edit = get_theme_mod('post_top_meta_edit',false);

    if ( 'post' == get_post_type() ) {  
    	if($post_top_meta_date) {
	        // Date
	    	global $post; ?>
		  	    <span class="date-structure">				
					<span class="dd"><a class="url fn n" href="<?php echo get_day_link(get_the_time('Y'), get_the_time('m'),get_the_time('d')); ?>"><i class="fa fa-calendar"></i><?php the_time('j M Y'); ?></a></span>		
				</span><?php 
		}
		if($post_top_meta_author) {
	        // Author  
			printf(
				_x( '%s', 'post author', 'magzenpro' ),
				'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"><i class="fa fa-user"></i> ' . esc_html( get_the_author() ) . '</a></span>'
			);	
		}
		if($post_top_meta_comment) {
		// Comments
			if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
				echo ' <span class="comments-link"><i class="fa fa-comment"></i>';
				comments_popup_link( __( 'Leave a comment', 'magzenpro' ), __( '1 Comment', 'magzenpro' ), __( '% Comments', 'magzenpro' ) );
				echo '</span>';
		    }
		}
	   if($post_top_meta_category) {
            // Category list
			$categories_list = get_the_category_list( __( ', ', 'magzenpro' ) );
			if ( $categories_list ) {
				printf( '<span class="cat-links"><i class="fa fa-folder-open"></i> ' . __( '%1$s ', 'magzenpro' ) . '</span>', $categories_list );
			}
		}
		if($post_top_meta_tag) {
	        // Tags
			$tags_list = get_the_tag_list( '', __( ', ', 'magzenpro' ) );
			if ( $tags_list ) {
				printf( '<span class="tags-links"><i class="fa fa-tags"></i> ' . __( '%1$s ', 'magzenpro' ) . '</span>', $tags_list );
			}
		}
		if($post_top_meta_edit) {
		    // Edit 
		    edit_post_link( __( 'Edit', 'magzenpro' ), '<span class="edit-link"><i class="fa fa-pencil"></i> ', '</span>' );
		}
	}

}

endif;

/* Header Breaking News */
add_action('magzenpro_header_breaking_news','magzenpro_header_breaking_news');
if(! function_exists('magzenpro_header_breaking_news') ) {  
	function magzenpro_header_breaking_news() { ?>
		<div class="breaknews">  
			<div class="container">
				<div class="recent-news-wrapper">
				    <div class="breaknews-wrapper">
						<span class="bn-title mag-divider">
						    <?php $breaking_news_title = get_theme_mod('header_breaking_news_title','BREAKING NEWS');
						        if( $breaking_news_title ) {
						    		printf(__('%1$s','magzenpro'), $breaking_news_title ); 
						    	}else{
						    		printf(__('%1$s','magzenpro'), 'BREAKING NEWS' ); 
						    	} ?>	
						</span>
						<ul class="bn-list newsticker"><?php 
					        $recent_posts = wp_get_recent_posts();
							foreach ($recent_posts as $single_post ){ ?>
								 <li class="bn-content">
					                <a href="<?php echo esc_url( get_permalink($single_post["ID"]) ); ?>" title="<?php echo esc_attr($single_post['post_title']); ?>">
					                    <?php echo esc_html( $single_post['post_title'] ); ?>
					                </a>
					            </li><?php
					       	} ?>
				       </ul>
			        </div>
		       </div>
	       </div>
	    </div><?php     
	}
}

/* Shortcode for tabbed widget */
function magzenpro_remove_wpautop( $content ) { 
	$content = do_shortcode( shortcode_unautop( $content ) ); 
	$content = preg_replace('#^<\/p>|^<br \/>|<p>$#', '', $content);
	return $content;
}

add_shortcode( 'tabs_group', 'magzenpro_tabs_group' );
function magzenpro_tabs_group($atts, $content = null ) {


	if (!preg_match_all('~\[tabs([^\[\]]*)]([^\[\]]+)\[/tabs]~', $content, $matches)) {

		return magzenpro_remove_wpautop( $content );

	} else {  

		$output = '';     
		$output .= '<ul class="tab_heading">';      
		$tab_id = array();
		for($i = 0; $i < count($matches[1]); $i++) {  
			$tab_id[$i] = str_replace(".","",(string)uniqid('tab_',true));
			$output .= '<li><a href="#'.$tab_id[$i].'">' . str_replace(array('title', '"', '&#8221;','=','&#8243;'), '', $matches[1][$i]) . '</a></li>';
		}
		$output .= '</ul>';    
		$output .= '<div class="tabs_container clearfix">';
		for($i = 0; $i < count($matches[2]); $i++) {
			$output .= '<div id="'.$tab_id[$i].'">' . magzenpro_remove_wpautop( $matches[2][$i] ) . '</div>';
		} 
		$output .= '</div>';    
 
		return '<div class="tabs clearfix">' . $output . '</div>';

	}  	
}

/* Page - page layout metabox field add */
add_action( 'add_meta_boxes', 'magzenpro_meta_box_video' );
function magzenpro_meta_box_video()
{
    add_meta_box( 'magzen-page-layout-id', 'Page Layout', 'magzenpro_meta_box_callback', array('page','post') , 'normal', 'high' );
}

function magzenpro_meta_box_callback( $post )
{
    $values = get_post_custom( $post->ID );
    $selected = isset( $values['magzen_metabox_page_layout'] ) ? esc_attr($values['magzen_metabox_page_layout'][0]) : 'right';

    wp_nonce_field( 'my_meta_box_nonce', 'meta_box_nonce' );
    ?>
    
    <p>
     <label for="magzen_metabox_page_layout"><p>Choose Layout</p></label>  
        <input type="radio" id="right" name="magzen_metabox_page_layout" value="right" <?php checked( $selected, 'right' ); ?> >Rigth sidebar<br>
        <input type="radio" id="left" name="magzen_metabox_page_layout" value="left" <?php checked( $selected, 'left' );?> >Left sidebar<br>
        <input type="radio" id="fullwidth" name="magzen_metabox_page_layout" value="fullwidth" <?php checked( $selected, 'fullwidth' ); ?> >Fullwidth<br>
        <input type="radio" id="no-sidebar" name="magzen_metabox_page_layout" value="no-sidebar" <?php checked( $selected, 'no-sidebar' ); ?> >No sidebar content centered<br>
    </p>
    <?php   
}  																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																

add_action( 'save_post', 'magzenpro_meta_box_video_save' );  
function magzenpro_meta_box_video_save( $post_id )
{
    // Bail if we're doing an auto save
    if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

    // if our nonce isn't there, or we can't verify it, bail
    if( !isset( $_POST['meta_box_nonce'] ) || !wp_verify_nonce( $_POST['meta_box_nonce'], 'my_meta_box_nonce' ) ) return;

    // if our current user can't edit this post, bail
    if( !current_user_can( 'edit_post' ) ) return;

    // now we can actually save the data
    $allowed = array('left','right','no-sidebar','fullwidth','a' => array( 
        'href' => array() 
    ));

    // Probably a good idea to make sure your data is set

    if( isset( $_POST['magzen_metabox_page_layout'] ) )
        update_post_meta( $post_id, 'magzen_metabox_page_layout', $_POST['magzen_metabox_page_layout'] );

}

/* Page - primary page layout class */
//add_action('magzenpro_page_primary_class','magzenpro_page_primary_class');
if(!function_exists('magzenpro_page_primary_class')) {
  function magzenpro_page_primary_class($post_id) { 
     $page_layout = get_post_meta( $post_id, 'magzen_metabox_page_layout', true);
     switch ($page_layout) {
     	case 'fullwidth':
     		echo 'sixteen columns alpha';
     		break;
     	case 'no-sidebar':
     		echo 'eleven columns magzen-nosidebar';
     		break;
     	case 'left':
     		echo 'eleven columns omega';
     		break;
     	case 'right':
     		echo 'eleven columns alpha';
     		break;
     	default:
     		echo 'eleven columns';
     		break;
     }
  }
}

/* Page - Sidebar class */
if(!function_exists('magzenpro_page_secondary_class')) {  
  function magzenpro_page_secondary_class($post_id) { 
     $page_layout = get_post_meta( $post_id, 'magzen_metabox_page_layout', true);
     switch ($page_layout) {
     	case 'left':
     		echo ' alpha';
     		break;
     
     	default:
     		echo 'omega';
     		break;
     }
  }
}


/* Page - before primary (left sidebar) */
add_action('magzenpro_page_primary_before','magzenpro_page_primary_before');
if(!function_exists('magzenpro_page_primary_before')) {
  function magzenpro_page_primary_before($post_id) {
     $page_layout = get_post_meta( $post_id, 'magzen_metabox_page_layout', true);
     echo '<div class="left-sidebar-wrapper">';
	     if($page_layout == 'left') {
	     	get_sidebar(); 
	     }
     echo '</div>';
  }
}

/* Page - after primary (right sidebar) */
add_action('magzenpro_page_primary_after','magzenpro_page_primary_after');
if(!function_exists('magzenpro_page_primary_after')) {
  function magzenpro_page_primary_after($post_id) {
     $page_layout = get_post_meta( $post_id, 'magzen_metabox_page_layout', true);
     if($page_layout == 'right' || !$page_layout ) {
     	get_sidebar();
     }
  }
}
 
/* Sticky header */
if( get_theme_mod('header_sticky',false) ) {
	add_action( 'wp_footer', 'magzenpro_sticky_header');
	function magzenpro_sticky_header() { ?>
	    <script type="text/javascript">
		    // Sticky Header Options 
			(function($){
				$(window).scroll(function() {
			    if ($(this).scrollTop() > 150){  
			        $('.nav-wrap').addClass("sticky-nav");
			      }
			      else{
			        $('.nav-wrap').removeClass("sticky-nav");
			      }
			   });
			})(jQuery); 
		</script><?php
	}
}

/* Scroll to top button */
if( get_theme_mod('scroll_to_top',true) ) {
    add_action( 'wp_footer', 'magzenpro_scroll_to_top');
	function magzenpro_scroll_to_top() { ?>
	    <script type="text/javascript">
			// jQuery powered scroll to top
			jQuery(document).ready(function(){
				//Check to see if the window is top if not then display button
				jQuery(window).scroll(function(){ 
					if (jQuery(this).scrollTop() > 100) {
						jQuery('.scroll-to-top').fadeIn();
					} else {
						jQuery('.scroll-to-top').fadeOut();  
					}
				});

				//Click event to scroll to top
				jQuery('.scroll-to-top').click(function(){
					jQuery('html, body').animate({scrollTop : 0},800);
					return false;
				});
				
			});
		</script><?php
	}
}

/* Breaking news script */ 	
add_action( 'wp_footer', 'magzenpro_breaking_news',100); 
function magzenpro_breaking_news() { 
	$breakingnews_animation_type = get_theme_mod('breaking_animation_type','down'); 
	$breakingnews_duration_time = get_theme_mod('breaking_duration_time',1000); 
	$breakingnews_speed = get_theme_mod('breaking_speed',500);  
	?>  
    <script type="text/javascript">
    (function($){
        // Sticky Header Options 
	    $('.newsticker').newsTicker({ 
	        row_height: 35,
	        max_rows: 1,
	        speed: '<?php echo $breakingnews_speed ?>',
	        direction: '<?php echo $breakingnews_animation_type ?>',
	        duration: '<?php echo $breakingnews_duration_time ?>',
	        autostart: 1,
	        pauseOnHover: 1
	    });   
    })(jQuery);
	</script><?php
}

/* Page site style class ( layout )*/
if( !function_exists('magzenpro_site_style_class') ) {        
	function  magzenpro_site_style_class(){
       $site_style = get_theme_mod('layout-model');
	    if( $site_style == 'boxed' )  { 
		  $site_style_class = 'container boxed-container';
		}elseif( $site_style == 'fluid' ){    
	       $site_style_class = 'fluid-container';	 
		}
		else{
			 $site_style_class = '';
		} 
		return $site_style_class; 
	}
}  

/* Page layouts */
add_action( 'wp_footer', 'magzenpro_sitelayout_remove_class',100); 
if( !function_exists('magzenpro_sitelayout_remove_class') ) {        
	function  magzenpro_sitelayout_remove_class(){
		$magzen_site_style = get_theme_mod('layout-model','wide');
		if( $magzen_site_style != 'wide' ) { ?>
		    <script type="text/javascript">
		    (function($){
		      // remove class name alpha and omega
			  $('.columns,.column').removeClass('alpha');
		      $('.columns,.column').removeClass('omega');
		    })(jQuery);
			</script><?php
		}
    }
}