<?php 

/**
 * Enqueue scripts and styles.  
 */
function magzenpro_scripts() {         
	wp_enqueue_style( 'magzenpro-poppins', magzenpro_theme_font_url('Poppins:400,500,600,700'), array(), 20141212 );
	wp_enqueue_style( 'magzenpro-oxygen', magzenpro_theme_font_url('Oxygen:300,400,700'), array(), 20141212 );
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css', array(), 20150224 );
	wp_enqueue_style( 'flexslider', get_template_directory_uri() . '/css/flexslider.css', array(), 20150224 );
	wp_enqueue_style( 'tabulous', get_template_directory_uri() . '/css/tabulous.css', array(), 20150224 );
	wp_enqueue_style( 'mc-scrollbar', get_template_directory_uri() . '/css/mCustomScrollbar.min.css', array(), 20150224 );
	wp_enqueue_style( 'slicknav', get_template_directory_uri() . '/css/slicknav.css' );
	wp_enqueue_style( 'magzenpro-style-header', get_template_directory_uri() .'/style.css' );
 

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {  
		wp_enqueue_script( 'comment-reply' );   
	}

    if( ! get_theme_mod('optimize_js',false) ) {
	    wp_enqueue_script( 'magzenpro-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20120206', true );
		wp_enqueue_script( 'magzenpro-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );
		wp_enqueue_script( 'jquery-flexslider', get_template_directory_uri() . '/js/jquery.flexslider-min.js', array('jquery'), '2.4.0', true );
		wp_enqueue_script( 'news-ticker', get_template_directory_uri() . '/js/jquery.newsTicker.min.js', array('jquery'), '2.4.0', true );
		wp_enqueue_script( 'tabulous', get_template_directory_uri() . '/js/tabulous.js', array('jquery'), '2.4.0', true );
		wp_enqueue_script( 'mc-scrollbar', get_template_directory_uri() . '/js/jquery.mCustomScrollbar.concat.min.js', array('jquery'), '2.4.0', true );
		wp_enqueue_script( 'slicknav', get_template_directory_uri() .'/js/jquery.slicknav.min.js', array('jquery'), '1.0.0', true );
	    wp_enqueue_script( 'doubletaptogo', get_template_directory_uri() . '/js/doubletaptogo.min.js', array('jquery'), '1.0.0', true );
		wp_enqueue_script( 'magzenpro-custom', get_template_directory_uri() . '/js/custom.js', array(), '1.0.0', true );
	}else{
		wp_enqueue_script( 'magzenpro-merge-js', get_template_directory_uri() . '/js/all.min.js', array('jquery'), '1.0.0', true );
	}

    // Stylesheet enqueue
    $color_scheme = get_theme_mod('color_scheme',1);
    switch ($color_scheme) {
    	case '2':
    		wp_enqueue_style( 'magzenpro-style', get_template_directory_uri() . '/css/green.min.css' );
    	    break;
    	case '3':
    		wp_enqueue_style( 'magzenpro-style', get_template_directory_uri() . '/css/light-green.min.css' );
    	    break;
    	case '4':
    		wp_enqueue_style( 'magzenpro-style', get_template_directory_uri() . '/css/blue.min.css' );
    	    break;
    	case '5':
    		wp_enqueue_style( 'magzenpro-style', get_template_directory_uri() . '/css/violet.min.css' );
    	    break;
    	case '6':
    		wp_enqueue_style( 'magzenpro-style', get_template_directory_uri() . '/css/yellow.min.css' );
    	    break;
    	case '7':
    		wp_enqueue_style( 'magzenpro-style', get_template_directory_uri() . '/css/orange.min.css' );
    	    break;
    	case '8':
    		wp_enqueue_style( 'magzenpro-style', get_template_directory_uri() . '/css/red.min.css' );
    	    break;   
    	
    	default:
    		wp_enqueue_style( 'magzenpro-style', get_template_directory_uri() . '/css/default.min.css' );
    	    break;
    }
   


}
add_action( 'wp_enqueue_scripts', 'magzenpro_scripts' );       

/**
 * Register Google fonts.
 *
 * @return string
 */
function magzenpro_theme_font_url($font) {       
	$font_url = '';
	/*
	 * Translators: If there are characters in your language that are not supported
	 * by Font, translate this to 'off'. Do not translate into your own language.
	 */
	if ( 'off' !== _x( 'on', 'Font: on or off', 'magzenpro' ) ) {   
		$font_url = esc_url( add_query_arg( 'family', urlencode($font), "//fonts.googleapis.com/css" ) );
	}

	return $font_url;
}

function magzenpro_admin_enqueue_scripts( $hook ) {  
	if( strpos($hook, 'magzenpro_upgrade') ) {
		wp_enqueue_style( 
			'font-awesome', 
			get_template_directory_uri() . '/css/font-awesome.min.css', 
			array(), 
			'4.3.0', 
			'all' 
		);
		wp_enqueue_style( 
			'magzenpro-admin', 
			get_template_directory_uri() . '/admin/css/admin.css', 
			array(), 
			'1.0.0', 
			'all' 
		);
	}
}
//add_action( 'admin_enqueue_scripts', 'magzenpro_admin_enqueue_scripts' );