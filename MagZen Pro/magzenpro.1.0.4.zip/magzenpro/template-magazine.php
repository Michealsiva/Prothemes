<?php
/**
 * Template Name: Magazine Page
 *
 * Description: A custom page template for displaying the magazine homepage widgets.
 *
 * @package MagZenPro
 */

get_header(); ?>

    <?php do_action('magzen_before_content'); ?>

	<div class="container magzen-top-full-width-wrapper">      
	    <div class="nine columns alpha"><?php 
	        // Display Magazine Page full width slider 
			if( is_active_sidebar( 'magzen-top-fullwidth-slider-area' ) ) : ?> 

				<div id="magazine-page-widgets" class="widget-area clearfix">

					<?php dynamic_sidebar( 'magzen-top-fullwidth-slider-area' ); ?>

				</div><?php 
			endif; ?>
	    </div>
	    <div class="seven columns omega"><?php
	    	// Display Magazine Page full width Beside slider 
			if( is_active_sidebar( 'magzen-top-fullwidth-beside-slider-area' ) ) : ?> 

				<div id="magazine-page-widgets" class="widget-area clearfix">

					<?php dynamic_sidebar( 'magzen-top-fullwidth-beside-slider-area' ); ?>

				</div><?php 
			endif; ?>
	    </div>
	</div>
	
	<div class="container">      


        <?php do_action('magzenpro_page_primary_before',$post->ID); ?>
 
		<div id="primary" class="content-area <?php magzenpro_page_primary_class($post->ID); ?>">

			<main id="main" class="site-main" role="main"> 

				<?php // Display Magazine Content

				if( get_theme_mod('enable_magazine_widget_area_content',true) ) :

					if( is_active_sidebar( 'magzen-content-area' ) ) : ?> 

						<div id="magazine-page-widgets" class="widget-area clearfix">

							<?php dynamic_sidebar( 'magzen-content-area' ); ?>

						</div> 

					<?php // Display Description about Magazine Homepage Widgets when widget area is empty
					else : 
					
						// Display only to users with permission
						if ( current_user_can( 'edit_theme_options' ) ) : ?>

							<p class="empty-widget-area">
								<?php _e( "Please go to Appearance &#8594; Widgets and add widget to the 'MagZen: XXX' widget area. You can use the MagZenPro widgets to set up magazine page.", 'magzenpro' ); ?>
							</p>  
							
						<?php endif;  

					endif; 
				endif;

				if( get_theme_mod('enable_magazine_default_content',false) ) {
                    while ( have_posts() ) : the_post();       
						the_content();
					endwhile; 
				} ?>

			</main><!-- #main -->
		</div><!-- #primary -->

<?php 
do_action('magzenpro_page_primary_after',$post->ID);
get_footer(); 
