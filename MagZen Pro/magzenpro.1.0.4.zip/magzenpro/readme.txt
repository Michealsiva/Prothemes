=== MagZenPro ===
Contributors: Webulous
Tags: featured-images, right-sidebar, sticky-post, translation-ready, custom-background,  custom-menu,  threaded-comments , blog, news
Requires at least: 4.0
Tested up to: 4.8.2
Stable tag: 1.0.4
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

MagZenPro is best suited for all types of site and uses Theme Customizer.

MagZenPro WordPress Theme, Copyright 2017 Webulousthemes

== Description ==
MagZenPro is a perfect responsive magazine style WordPress theme. Suitable for news, newspaper, magazine, publishing, business and any kind of sites. It uses skeleton framework for grids which keeps minimal css. Stylesheet is generated using SASS and so stays DRY. Core feature of WordPress  Has 3 Footer Widget Areas.

== Frequently Asked Questions == 
== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the magzenpro.zip file. Click Install Now.
3. Click Activate to use your new theme right away. 

= Theme Features Usage =
All available options can be used from Appearance->Customize

== Changelog ==
= 1.0.4 = 
* Add Typography section for navigation

= 1.0.3 = 
* Add top meta options

= 1.0.2 = 
* Fix search box issue

= 1.0.1 = 
* License Key Issue Fixed.

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.4 = 
* Add Typography section for navigation


== Resources ==
* {_s}, GPLv3, http://underscores.me/
* {Skeleton}, MIT, https://github.com/dhg/Skeleton#license
* {Flexslider} © 2015 Woo Themes, GPLv2 ,https://github.com/woothemes/FlexSlider
* {FontAwesome} © Dave Gandy, SIL OFL 1.1 and MIT ,https://fortawesome.github.io/Font-Awesome
* screenshot.png © 2015 Pixabay, CC0,
https://pixabay.com/en/girl-music-pink-fashion-listen-1990347/
https://pixabay.com/en/girl-looking-away-1995624/
https://pixabay.com/en/above-adventure-aerial-air-amazing-736879/
