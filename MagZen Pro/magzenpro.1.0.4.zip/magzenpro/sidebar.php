<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package MagZenPro
 */
?>

<div id="secondary" class="widget-area five columns <?php magzenpro_page_secondary_class($post->ID); ?>" role="complementary"><?php
    do_action( 'magzen_before_sidebar' );

    if( function_exists('generated_dynamic_sidebar') ) :   
		generated_dynamic_sidebar(); 
    else : 
	   dynamic_sidebar( 'sidebar-1' );  
	endif;   

	do_action( 'magzen_after_sidebar' ); ?>
</div><!-- #secondary -->
