<?php
/**
 * The template used for displaying page breadcrumb
 *
 * @package MagZenPro
 */

 $breadcrumb = get_theme_mod( 'breadcrumb',true );  

if( $breadcrumb ) : ?>  
	<div class="breadcrumb-wrapper"> 
		<div class="container">
			<div class="breadcrumb clearfix">  
				<div class="sixteen columns">
					<span class="txt-bread"><?php _e('You are here','magzenpro');?></span>
					<?php magzenpro_breadcrumbs(); ?>
				</div>
			</div>
		</div>
	</div><?php 
endif; ?>