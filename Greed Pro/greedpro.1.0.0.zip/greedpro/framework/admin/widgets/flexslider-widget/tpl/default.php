<?php
	echo do_shortcode( '[flexslider id='.$slider.']' );
