<?php
if ( ! empty( $title ) ) {
	echo  '<h4 class="widget-title">'. esc_html( $title ) . '</h4>';  
}

    $output = '';
		$output .= '<div class="recent-posts-wrapper">';

		switch( $type ) {
			case 'normal':
				$output .= '<div class="recent-posts">';
				break;
			case 'slider' :
				$output .= '<div class="recent-posts-slider clearfix">';
				break;
			case 'carousel' :
				$output .= '<div class="recent-posts-carousel">';
				break;
			default:
				$output .= '<div class="recent-posts">';
				break;
		}
		// WP_Query arguments
		$recent_post_args = array (
			'post_type'              => 'post',
			'category_name'          => $cat,
			'post_status'            => 'publish',
			'posts_per_page'         => $count,
			'ignore_sticky_posts'    => true,
			'order'                  => 'DESC',
		);

		// The Query

		$query = new WP_Query( apply_filters( 'recent_posts_args', $recent_post_args ) );
		if( $type == 'normal' || $type =='slider' ) {
		$output .= '<ul class="slides">';

		// The Loop
		if ( $query->have_posts() ) { 
	        if( $type == 'normal' ) {
				$output .= '<div class="latest-posts">';
			}
			while ( $query->have_posts() ) {  
				$query->the_post();	
				if( $type == 'normal' ) {	
					$output .= '<div class="one-third column">';
						$output .= '<div class="latest-post">';
								$output .= '<div class="latest-post-thumb">'; 
										if ( has_post_thumbnail() ) {
											$output .= '<a href="'. get_permalink() . '">'. get_the_post_thumbnail($query->post->ID ,'greed-pro-recent-posts-img').'</a>';
										}
										else {  
											$output .= '<img src="' . get_template_directory_uri()  . '/images/no-image-blog-full-width.png" alt="" >';
										}
								$output .= '</div><!-- .latest-post-thumb -->';
								$output .= '<div class=latest-post-details>';
								    $output .= '<h3><a href="'. get_permalink() . '">' . get_the_title() . '</a></h3>';
									$output .= '<div class="latest-post-content">';
										$output .= '<p>' . get_the_content() . '</p>';
									$output .= '</div><!-- .latest-post-content -->';
									$output .='<div class="entry-meta">';  
											$output .='<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"><i class="fa fa-user"></i></a></span>';
											$output .='<span class="comments-link"><a href="' . esc_url(get_comments_link()) .'"><i class="fa fa-comments"></i></a></span>';
											$output .='<span class="data-structure"><a class="url fn n" href="'. get_day_link( get_the_time('Y'), get_the_time('m'),get_the_time('d')). '"><i class="fa fa-calendar"></i></a></span>';
										$output .='</div><!-- entry-meta -->';
								$output .= '</div><!-- .latest-post-details -->';
							
							
						$output .= '</div><!-- .latest-post -->';
					$output .= '</div>';
				}else {
			    	$output .= '<li>';
						$output .= '<div class="recent-post">';
						$output .= '<div class="rp-thumb">';	              
							if ( has_post_thumbnail() ) {
								$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $query->post->ID ),'genex_material-blog-full-width' );
								$output .= '<img src="' . $image_url[0] . '">';
							} else {
								$output .= '<img src="' . get_template_directory_uri()  . '/images/no-image-blog-full-width.png" alt="" >';     
							}
						$output .= '</div><!-- .rp-thumb -->';
						$output .= '<div class="rp-content flex-caption">';
						$output .= '<h4><a href="'.get_permalink().'">'. get_the_title() . '</a></h4>';
						$output .= get_the_content();
						$output .= '</div><!-- .rp-content -->';
						$output .= '</div>';
						$output .= '</li>';
			    }
			}
		}

		$output .= '</ul>'; 
		}

		else if( $type == 'carousel' ) {
			if ( $query->have_posts() ) {
				$output .= '<div class="latest-posts sixteen columns clearfix">';
				$output .= '<div class="previous-latest-post four columns clearfix"><a href=""></a>';
			    $output .= '</div>';
					$output .= '<ul class="slides eight columns">';
						while ( $query->have_posts() ) {
							$query->the_post(); 
							$output .= '<li class="list-box">';
							    //$output .= '<div class="eight columns">';
								$output .= '<div class="latest-post">';
									$output .= '<div class="latest-post-thumb">'; 
									$recent_post_image = get_the_post_thumbnail($query->post->ID,'greed-recent-post-large-img');
									$image_link = esc_url(get_permalink());
										if ( has_post_thumbnail() ){
											$output .= '<a href="'. esc_url(get_permalink()) . '">'. get_the_post_thumbnail($query->post->ID ,'greed-recent-posts-img', array('srcset' => $recent_post_image , 'link' => $image_link) ).'</a>';
										}
										else {  
											$output .= '<img src="' . get_template_directory_uri()  . '/images/no-image-blog-full-width.png" alt="" >';
										}   
									$output .= '</div><!-- .latest-post-thumb -->';
									$output .= '<div class=latest-post-details>';
										$output .= '<h4><a href="'. esc_url(get_permalink()) . '">' . get_the_title() . '</a></h4>';
										$output .= '<div class="latest-post-content">';
												$output .= '<p>' . get_the_content() . '</p>';
										$output .= '</div><!-- .latest-post-content -->';
										$output .='<div class="entry-meta">';  
											$output .='<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '"><i class="fa fa-user"></i></a></span>';
											$output .='<span class="comments-link"><a href="' . esc_url(get_comments_link()) .'"><i class="fa fa-comments"></i></a></span>';
											$output .='<span class="data-structure"><a class="url fn n" href="'. get_day_link( get_the_time('Y'), get_the_time('m'),get_the_time('d')). '"><i class="fa fa-calendar"></i></a></span>';
										$output .='</div><!-- entry-meta -->';	
									$output .= '</div><!-- .latest-post-details -->';

								$output .= '</div><!-- .latest-post -->';
							    //$output .= '</div>';
							$output .= '</li>';		
						}
					$output .= '</ul>';
					$output .= '<div class="next-latest-post four columns clearfix"><a href=""></a>';	
				    $output .= '</div>';
				$output .= '</div>';
			} 
		}
		$query = null;
		// Restore original Post Data
		wp_reset_postdata();
		$output .= '</div></div>';
		echo $output; 
