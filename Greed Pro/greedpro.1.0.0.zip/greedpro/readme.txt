=== Greed ===
Contributors: Webulous
Tags: custom-menu, featured-images, post-formats, right-sidebar, left-sidebar, sticky-post, threaded-comments, translation-ready, three-columns, two-columns, one-column, flexible-header, custom-background, custom-header, custom-colors, editor-style, full-width-template, rtl-language-support, theme-options, translation-ready
Requires at least: 4.0 
Tested up to: 4.8.2
Stable tag: 1.0.0 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Greed is best suited for all types of site and uses Theme Customizer.
  
== Description ==   
Greed is responsive mulitipurpose theme. Can be used for all kinds of fields like Restarutant, Bloggers, Corporate sites. There is no theme options panel, instead uses Customizer, core feature of WordPress and comes with lots of options to customize. Exposure your site with our theme. Our Pro demo Here. http://www.webulousthemes.com/demo/?theme=greed


== Frequently Asked Questions ==
= Installation =
1. Download and unzip `greedpro` theme
2. Upload the `greedpro` folder to the `/wp-content/themes/` directory
3. Activate the Theme through the 'Themes' menu in WordPress

= Setting Up Front Page =
1. By default, your front page looks like a blog. However, you can make it look like screenshot by following these steps.
2. Go to Dashboard => Appearance => Customize
3. Click on 'Static Front Page'
4. Select 'A static page' radio option
5. Select a static page for 'Front Page' and another page for 'Posts Page'


= How to Use Customizer options =

Go to Dashboard => Appearance => Customize.
Use customizer options   


== Changelog ==   

= 1.0.0 =
	* Initial Release

== Upgrade Notice == 

= 1.0.0 =
	* Initial Release

== Resources ==
* {_s}, GPLv2
* {Skeleton}, MIT
* {Flexslider} © 2015 Woo Themes, GPLv2
* {FontAwesome} © Dave Gandy, SIL OFL 1.1 and MIT   
