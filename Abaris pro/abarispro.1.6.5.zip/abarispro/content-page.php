<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package Webulous
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php global $abaris;

if( isset( $abaris['single_page_featured_image'] ) && $abaris['single_page_featured_image'] ) :
	$single_page_featured_image_size = $abaris['single_page_featured_image_size'] ;
    if ( $single_page_featured_image_size != 2 ) {
        if( has_post_thumbnail() && ! post_password_required() ) :   
		  the_post_thumbnail('blog-large');
	    endif;
	}
endif;   

if( isset( $abaris['page_titlebar_text'] ) && $abaris['page_titlebar_text'] ) : ?>
	<header class="entry-header">
		<h1 class="entry-title"><?php 
		     echo get_webulous_entry_title_before_icon();
		     the_title(); ?>
		</h1>
	</header><!-- .entry-header -->
<?php endif; ?>

	<div class="entry-content">
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'abarispro' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->
	<?php edit_post_link( __( 'Edit', 'abarispro' ), '<footer class="entry-meta"><span class="edit-link"><i class="el el-file-edit"></i> ', '</span></footer>' ); ?>
</article><!-- #post-## -->
