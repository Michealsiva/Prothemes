<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Webulous
 */

get_header(); 
do_action('webulous_single_blog_fullwidth_featured_image'); ?>
		<div class="container"><div class="row">
		
		<?php while( have_posts() ): the_post();
			if( get_post_meta( $post->ID, 'full-width-post', true ) != true ) : ?>
			<?php if( isset( $abaris['layout'] ) && $abaris['layout'] == 2 ) : ?>
				<?php get_sidebar(); ?>
			<?php endif; ?>
		<?php endif;
		endwhile; ?>    

		<?php if( $abaris['breadcrumb'] && function_exists( 'webulous_breadcrumbs' ) ) : ?>
			<div id="breadcrumb" role="navigation">
				<?php webulous_breadcrumbs(); ?>
			</div>
		<?php endif; ?>	
		<?php while( have_posts() ): the_post();
			if( get_post_meta( $post->ID, 'full-width-post', true ) == true ) : ?>
			<div id="primary" class="content-area sixteen columns">
		<?php else : ?>
			<div id="primary" class="content-area two-thirds column">
		<?php endif; endwhile; ?>
			<main id="main" class="site-main" role="main">
			
			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', 'single' ); ?>

				<?php webulous_post_nav(); ?>

				<?php if($abaris['show-social-sharing']): ?>
				<div class="share-box">
					<h4><?php echo __( 'Share this on ...', 'abarispro' ); ?></h4>
					<ul>
						<?php if( $abaris['ss_box_facebook'] ): ?>
						<li>
							<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php the_title(); ?>">
								<i class="fa fa-facebook"></i>
							</a>
						</li>
						<?php endif; ?>
						<?php if($abaris['ss_box_twitter']): ?>
						<li>
							 <a href="http://twitter.com/intent/tweet?url=<?php the_permalink(); ?>">
								<i class="fa fa-twitter"></i>
							</a>
						</li>
						<?php endif; ?>
						<?php if($abaris['ss_box_linkedin']): ?>
						<li>
							<a href="http://linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>">
								<i class="fa fa-linkedin"></i>
							</a>
						</li>
						<?php endif; ?>

						<?php if($abaris['ss_box_googleplus']): ?>
						<li>
							<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>">
								<i class="fa fa-google-plus"></i>
							</a>
						</li>
						<?php endif; ?>
						<?php if($abaris['ss_box_email']): ?>
						<li>
							<a href="mailto:?subject=<?php the_title(); ?>&amp;body=<?php the_permalink(); ?>">
								<i class="fa fa-envelope"></i>
							</a>
						</li>
						<?php endif; ?>
					</ul>
				</div>
				<?php endif; ?>

				<?php if($abaris['show-author-bio']): ?>
				<section class="author-bio clearfix">
					<div class="author-thumb">
						<?php echo get_avatar( get_the_author_meta( 'email' ), '72' ); ?>
					</div>
					<div class="description">
						<h2><?php echo __( 'About the Author:', 'abarispro' ); ?> <?php the_author_posts_link(); ?></h2>
						<p><?php the_author_meta( 'description' ); ?></p>
					</div>
				</section>
				<?php endif; ?>

				<?php if( $abaris['show-related-posts'] && function_exists( 'webulous_related_posts' ) ) : ?>
						<section class="related-posts">
							<?php webulous_related_posts(); ?>
						</section>
				<?php endif;  ?>

				<?php
					if( $abaris['show-comments'] ) :
						// If comments are open or we have at least one comment, load up the comment template
						if ( comments_open() || '0' != get_comments_number() ) :
							comments_template();
						endif;
					endif;
				?>

			<?php endwhile; // end of the loop. ?>

			</main><!-- #main -->
		</div><!-- #primary -->

		<?php while( have_posts() ): the_post();
			if( get_post_meta( $post->ID, 'full-width-post', true ) != true ) : ?>

			<?php if( isset( $abaris['layout'] ) && $abaris['layout'] == 3 ) : ?>
				<?php get_sidebar(); ?>
			<?php endif; ?>

			<?php if( ! isset( $abaris['layout'] ) ) : ?>
				<?php get_sidebar(); ?>
			<?php endif; 
		endif;
		endwhile;
		?>
	</div>
			
		<?php get_footer(); ?>