		</div>
	</div><!-- #content -->
</div><!-- #page -->
<?php if( isset($abaris['analytics-place']) && $abaris['analytics-place'] == 1 ){
	echo $abaris['google-analytics'];
}
?>
<?php wp_footer(); ?>
</body>
</html>