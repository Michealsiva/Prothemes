<?php
/**
 * @package Webulous
 */
global $abaris;
do_action('webulous_blog_layout_class_wrapper_before'); 
?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>> 

			<div class="entry-content">
				<?php if( isset($abaris['featured-image'] ) && $abaris['featured-image'] ) : ?>
					<div class="thumb">
						<?php  
						if( has_post_thumbnail() && ! post_password_required() ) : 
							    if( $abaris['feature-image-size'] == '1' ) :
									the_post_thumbnail('blog-large'); 
								elseif( $abaris['feature-image-size'] == '2' ):
                                    the_post_thumbnail('full'); 
                                elseif( $abaris['feature-image-size'] == '3' ):
                                    the_post_thumbnail('large');
                                elseif( $abaris['feature-image-size'] == '4' ):
                                    the_post_thumbnail('medium');
								endif;
						else:
							echo '<img src="' . WEBULOUS_CHILD_URL . '/images/no-image-blog-large.png" />';
						endif;
						?>     
					</div>
				<?php endif; ?> 

				<div class="entry-body">
					<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( get_webulous_entry_title_before_icon(), '' ); ?></a></h1>
					<?php if ( isset( $abaris['enable_single_post_top_meta'] ) && $abaris['enable_single_post_top_meta'] ): ?>
						<footer class="entry-meta">
							<?php if(function_exists('webulous_entry_top_meta') ) {
							    webulous_entry_top_meta(); 
							} ?>  
					    </footer><!-- .entry-footer -->
				   <?php endif;?> 
					<?php 
						if( isset( $abaris['excerpt-length'] ) && $abaris['excerpt-length'] == 0 ) {
							the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'abarispro' ) );
						} else {
							echo webulous_content_limit();	
						}
					?>
				</div>

				<?php
					wp_link_pages( array(
						'before' => '<div class="page-links">' . __( 'Pages:', 'abarispro' ),
						'after'  => '</div>',
					) );
				?>
				<br class="clear" />
			</div><!-- .entry-content -->
 
			
			<?php if ( isset( $abaris['enable_single_post_bottom_meta'] ) && $abaris['enable_single_post_bottom_meta'] ): ?>
				<footer class="entry-meta">
					<?php if(function_exists('webulous_entry_bottom_meta') ) {
					    webulous_entry_bottom_meta(); 
					} ?>  
			    </footer><!-- .entry-footer -->
			<?php endif;?> 
		</article><!-- #post-## -->
<?php do_action('webulous_blog_layout_class_wrapper_after'); ?>