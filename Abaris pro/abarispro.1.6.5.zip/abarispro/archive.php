<?php
/**
 * The template for displaying Archive pages.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 * @package Webulous
 */
get_header(); ?>
		<div class="container">
			<div class="row">

			<?php if( isset( $abaris['layout'] ) && $abaris['layout'] == 2 ) : ?>
				<?php get_sidebar(); ?>
			<?php endif; ?>

				<div id="primary" class="content-area two-thirds column">
					<main id="main" class="site-main" role="main">

					<?php if ( have_posts() ) : ?>

						<header class="page-header">
							<h1 class="page-title">
								<?php
									if ( is_category() ) :
										printf( __( 'Category: %s', 'abarispro' ), '<span class="vcard">' . single_cat_title( '', false ) . '</span>' );

									elseif ( is_tag() ) :
										printf( __( 'Tag: %s', 'abarispro' ), '<span class="vcard">' . single_tag_title( '', false ) . '</span>' );

									elseif ( is_author() ) :
										printf( __( 'Author: %s', 'abarispro' ), '<span class="vcard">' . get_the_author() . '</span>' );

									elseif ( is_day() ) :
										printf( __( 'Day: %s', 'abarispro' ), '<span>' . get_the_date() . '</span>' );

									elseif ( is_month() ) :
										printf( __( 'Month: %s', 'abarispro' ), '<span>' . get_the_date( _x( 'F Y', 'monthly archives date format', 'abarispro' ) ) . '</span>' );

									elseif ( is_year() ) :
										printf( __( 'Year: %s', 'abarispro' ), '<span>' . get_the_date( _x( 'Y', 'yearly archives date format', 'abarispro' ) ) . '</span>' );

									elseif ( is_tax( 'post_format', 'post-format-aside' ) ) :
										_e( 'Asides', 'abarispro' );

									elseif ( is_tax( 'post_format', 'post-format-gallery' ) ) :
										_e( 'Galleries', 'abarispro');

									elseif ( is_tax( 'post_format', 'post-format-image' ) ) :
										_e( 'Images', 'abarispro');

									elseif ( is_tax( 'post_format', 'post-format-video' ) ) :
										_e( 'Videos', 'abarispro' );

									elseif ( is_tax( 'post_format', 'post-format-quote' ) ) :
										_e( 'Quotes', 'abarispro' );

									elseif ( is_tax( 'post_format', 'post-format-link' ) ) :
										_e( 'Links', 'abarispro' );

									elseif ( is_tax( 'post_format', 'post-format-status' ) ) :
										_e( 'Statuses', 'abarispro' );

									elseif ( is_tax( 'post_format', 'post-format-audio' ) ) :
										_e( 'Audios', 'abarispro' );

									elseif ( is_tax( 'post_format', 'post-format-chat' ) ) :
										_e( 'Chats', 'abarispro' );

									else :
										_e( 'Archives', 'abarispro' );

									endif;
								?>
							</h1>
							<?php
								// Show an optional term description.
								$term_description = term_description();
								if ( ! empty( $term_description ) ) :
									printf( '<div class="taxonomy-description">%s</div>', $term_description );
								endif;
							?>
						</header><!-- .page-header -->

						<?php /* Start the Loop */ ?>
						<?php while ( have_posts() ) : the_post(); ?>

							<?php
								/* Include the Post-Format-specific template for the content.
								 * If you want to override this in a child theme, then include a file
								 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
								 */
								get_template_part( 'content', get_post_format() );
							?>

						<?php endwhile; ?>

						<?php 
							if( $abaris['pagenavi'] && function_exists( 'webulous_pagination' ) ) : 
								webulous_pagination();
							else :
								webulous_posts_nav();
							endif; 
						?>

					<?php else : ?>

						<?php get_template_part( 'content', 'none' ); ?>

					<?php endif; ?>

					</main><!-- #main -->
				</div><!-- #primary -->

				<?php if( isset( $abaris['layout'] ) && $abaris['layout'] == 3 ) : ?>
					<?php get_sidebar(); ?>
				<?php endif; ?>
				
				<?php if( ! isset( $abaris['layout'] ) ) : ?>
					<?php get_sidebar(); ?>
				<?php endif; ?>

		<?php get_footer(); ?>