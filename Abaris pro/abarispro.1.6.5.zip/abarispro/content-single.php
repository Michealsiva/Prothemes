<?php
/**
 * @package Webulous
 */
global $abaris;
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<h1 class="entry-title"><?php the_title(  get_webulous_entry_title_before_icon(),'' ); ?></h1>

        <?php if ( isset( $abaris['enable_single_post_top_meta'] ) && $abaris['enable_single_post_top_meta'] ): ?>
			<footer class="entry-meta">
				<?php if(function_exists('webulous_entry_top_meta') ) {
				    webulous_entry_top_meta(); 
				} ?>  
		    </footer><!-- .entry-footer -->
		<?php endif;?> 

	</header><!-- .entry-header -->  

	<div class="entry-content">
		<?php if( isset( $abaris['single-featured-image'] ) && $abaris['single-featured-image'] ) : ?>
			<?php if( has_post_thumbnail() ) : ?>
				<div class="post-thumb blog-thumb">
					<?php  
						if( has_post_thumbnail() && ! post_password_required() ) : 
							    if( $abaris['single_feature-image-size'] == '1' ) :
									the_post_thumbnail('blog-large'); 
								elseif( $abaris['single_feature-image-size'] == '2' ):
                                    the_post_thumbnail('full'); 
                                elseif( $abaris['single_feature-image-size'] == '3' ):
                                    the_post_thumbnail('large');
                                elseif( $abaris['single_feature-image-size'] == '4' ):
                                    the_post_thumbnail('medium');
								endif;
						endif;
						?> 
				</div>
			<?php endif; ?>
		<?php endif; ?>
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'abarispro' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->
	<?php if( $abaris['show-post-meta'] ) : ?>
		<?php if ( isset( $abaris['enable_single_post_bottom_meta'] ) && $abaris['enable_single_post_bottom_meta'] ): ?>
			<footer class="entry-meta">
				<?php if(function_exists('webulous_entry_bottom_meta') ) {
				    webulous_entry_bottom_meta(); 
				} ?>  
		    </footer><!-- .entry-footer -->
		<?php endif;?> 
	<?php endif; ?>
</article><!-- #post-## -->