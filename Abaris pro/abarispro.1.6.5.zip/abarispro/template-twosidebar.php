<?php
/**
 * Template Name: 2 Sidebar : Right and Left
 */

global $abaris;
get_header(); ?>
		<div class="container"> 
			<div class="row">     
     
				<?php get_sidebar('left'); ?>

				<div id="primary" class="content-area eight columns">
					<main id="main" class="site-main" role="main">

					<?php if ( $abaris['breadcrumb'] && function_exists( 'webulous_breadcrumbs' ) ) : ?>			
						<div id="breadcrumb" role="navigation">
							<?php webulous_breadcrumbs(); ?>
						</div>
					<?php endif; ?>

					<?php if ( have_posts() ) : ?>

						<?php /* Start the Loop */ ?>
						<?php while ( have_posts() ) : the_post(); ?>

							<?php
								/* Include the Post-Format-specific template for the content.
								 * If you want to override this in a child theme, then include a file
								 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
								 */
								get_template_part( 'content-page', get_post_format() );
							?>

						<?php endwhile; ?>

						<?php 
							if( $abaris['pagenavi'] && function_exists( 'webulous_pagination' ) ) : 
								webulous_pagination();
							else :
								webulous_posts_nav();
							endif; 
						?>

					<?php else : ?>

						<?php get_template_part( 'content', 'none' ); ?>

					<?php endif; ?>

					</main><!-- #main -->
				</div><!-- #primary -->  

				<?php get_sidebar(); ?>

				<?php get_footer(); ?>