====================== Licenses ======================
Unless otherwise specified, all the theme files, scripts and images
are licensed under GPLv2

1. This theme uses { _s } theme as base which is licensed under GPLv2 or later
2. This theme uses { Redux Framework } as theme options panel which is licensed under GPLv2 or later
3. This theme uses { Bootstrap } by Twitter and the { Glyphicon } set are licensed under the GPL-compatible [http://www.apache.org/licenses/LICENSE-2.0 Apache License v2.0]
4. This theme uses { Flexslider } which is licensed under GPLv2
5. This theme uses { Elusive Icons Webfont } which is licensed under GPL-compatible SIL Open Font License
6. All images used in this theme is licensed under GPLv2 or later
7. This theme uses { SlickNav } which is licensed under GPL compatible MIT License

Change Log 
v. 1.6.5
   * Fix Responsive menu parent link bug

v. 1.6.4
   * RTL support
   * Fix single clock demo content bug
   * Compatible with site origin widget bundle  
   * Modify twitter share link

v. 1.6.3
	* Added Stats & Recent Post widget
	* Added Orange stylesheet
	* Added more theme options

v. 1.6.2
	* Added license key admin not

v. 1.6.1
	Added Title icon & sidebar title icon option 

v. 1.6.0
	Added Redux single click demo 

v. 1.5.9
	Skill position issue fixed
	
v. 1.5.8
	Removed bt_add_image_size() as it was added to WP Core
	Updated FontAwesome
	Sticky Header Fix for Tablets / Mobiles
	Removed packaged plugins
	
v. 1.5.7
	Add Custom Color Option
	Added Pre Built layouts in Page Builder

v. 1.5.6
	Removed unwanted images
	Added 5 more color schemes
	
v. 1.5.5
	WP v4.2.3 breaks customizer. Fixed.

v. 1.5.4
	Elusive Icon fix throughout template files
	Better the_cotent / the_excerpt
	
v. 1.5.3
	XSS Fix for TGMPA and Custom Metabox scripts

v. 1.5.2
	Elusive Icon Breadcrumb Home Icon Fix
	Adding Landing Page Template
	Multiple Sidebar script doesn't use 'id'. Fixed it.
	
v. 1.5.1
	Updating Elusive Icon files
	Added Sticky Header
	
v. 1.5.0
	sanitization for shortcode urls
	
v. 1.4.9
	Added ability to override registered sidebars
	Added Full Width Slider Option for inner pages
	Our Team Widget: Shows only active social profiles
	
v. 1.4.8
	Custom Navigation link color fix.
	
v. 1.4.7
	CTA Widget in Footer. Incorrect display issue fixed.
	
v. 1.4.6
TEXTDOMAIN Issue. Change TEXTDOMAIN to 'abarispro'

v. 1.4.5
Fixed Menu Issue. Multiple dropdown levels

v. 1.4.4
Fixed Flex Slider Issues

v.1.4.2
Fixed 'excerpt more' issue
Fixed 'CTA' widget for sidebar and footer

v.1.4.1
Added default recent posts widget
Added Blog Template with small thumbnail

v.1.4
Added Jigoshop support
