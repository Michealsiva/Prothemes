<?php
/**
 * Template Name: Full Width Slider
 */

get_header(); ?>
	<?php 
		while( have_posts() ): the_post();
			$slider = false;
			if( get_post_meta( $post->ID, '_slider-shortcode', true ) != '' ) : ?>
				<div class="page-slider">
					<?php echo do_shortcode( get_post_meta( $post->ID, '_slider-shortcode', true ) ); 
					$slider = true; ?>
				</div>
			<?php
			endif;
		endwhile;
	?>
		<div id="content" class="site-content">

		<div class="container">
			<div class="row">

				<div id="primary" class="content-area sixteen columns full-width">
					<main id="main" class="site-main" role="main">
						
						<?php while ( have_posts() ) : the_post(); ?>

							<?php get_template_part( 'content', 'page' ); ?>

							<?php
								// If comments are open or we have at least one comment, load up the comment template
								if ( comments_open() || '0' != get_comments_number() ) :
									comments_template();
								endif;
							?>

						<?php endwhile; // end of the loop. ?>

					</main><!-- #main -->
				</div><!-- #primary -->

			</div><!-- .row -->
			
			<?php get_footer(); ?>