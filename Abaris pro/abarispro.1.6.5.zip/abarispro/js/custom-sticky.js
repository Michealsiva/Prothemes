jQuery(function($){
    // Sticky Header
    $(window).scroll(function() {
      if ($(this).scrollTop() > 200){
        $('.site-header').addClass("sticky-nav");
      }
      else{
        $('.site-header').removeClass("sticky-nav");
      }
  });
});