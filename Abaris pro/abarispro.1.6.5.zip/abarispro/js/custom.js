jQuery(document).ready(function($){
   
    /* Animation */

    jQuery(function($){
        $(document).scroll(function() {
          var divPos =  $('.widget_stat-widget').offset().top;
          var topOfWindow = $(document).scrollTop();
          if( divPos < topOfWindow+500) {
            $(document).unbind('scroll');
            $('.stat-container .stat').each(function () {
              var $this = $(this);
              jQuery({ Counter: 0 }).animate({ Counter: $this.text() }, {
                duration: 3000,
                easing: 'swing',
                step: function () {
                  $this.text(Math.ceil(this.Counter));
                }
              });
            });        
          }
      });
    });
    $(window).scroll(function() {
      var width = $(window).width;
      if(width > 768) {
        if ($(this).scrollTop() > 1){  
          $('.site-header').addClass("sticky-header");
        }
        else{
          $('.site-header').removeClass("sticky-header");
        }
      }
    }); 
          
    if( $.fn.doubleTapToGo ) {
      $( '#site-navigation li:has(ul)' ).doubleTapToGo();
    }

    
    if( $.fn.slicknav ) {
      $('#site-navigation ul.menu').slicknav({   
        allowParentLinks: true,
      }); 
    } 

   if( $.fn.flexslider ) {

     $('.testimonials').flexslider({
      animation: "slide",
      animationLoop: false,
      controlNav: false
     });

     $('.recent-posts-carousel').flexslider({
      animation: "slide",
      animationLoop: false,
      itemWidth:300,
      controlNav: false, 
      itemMargin: 0
    });

    $('.recent-posts-slider').flexslider({
      controlNav: false
    });
     
     $('.flexcarousel').flexslider({
          animation: 'slide',
          animationLoop: true ,
          controlNav: false,
          itemWidth: 250,
          itemMargin: 20,
      });

     $('.recent-work').flexslider({
      animation: "slide",
      animationLoop: true,
      controlNav: false,
      itemWidth: 300,
      itemMargin: 5
     });

    $('.flex-recent-posts').flexslider({
      animation: "slide",
      animationLoop: false,
      controlNav: false,
      itemWidth: 292
      //itemMargin: 30
    });

   }
    


  var icons = {
    header: "fa fa-plus-square",
    activeHeader: "fa fa-minus-square"
  };

  //Accordion
  if( $.fn.accordion ) {
    $( ".accordion" ).accordion({
      heightStyle: "content",
      icons: icons
    });
  }


  $('.alert-close').click(function(){
    $(this).parent().fadeOut('slow', function(){ $(this).remove();});
  });

  $('.toggle-title').click(function() {

    $(this).next().toggle('slow');
    icn = $('.icn i',this).attr('class');
    if( icn == 'fa fa-plus-square' ) {
      $('.icn i',this).attr('class','fa fa-minus-square');
    } else {
      $('.icn i',this).attr('class','fa fa-plus-square');
    }
    //$('.icn',this).html(icn);

  });

  if( $.fn.tabs ) {
    $('.tabs-container').tabs();  
  }

  $( '.img-wrap' ).hoverfold();
  

  var sideBarPos = $('#primary').next().attr('id');
  if( sideBarPos == 'secondary') {
    $('#secondary').addClass('right');
  } else {
    $('#secondary').addClass('left');
  }


  if( $.fn.eislideshow ) {
    $('.ei-slider').eislideshow({
      easing    : 'easeOutExpo',
      titleeasing : 'easeOutExpo',
      titlespeed  : 1200
    });
  }

  if( $.fn.prettyPhoto ) {
    $("a[rel^='prettyPhoto']").prettyPhoto();  
  }
  
  if( $.fn.slicknav ) {
    $('#site-navigation ul.menu').slicknav();  
  }
  
  var imgSizer = {
    Config : {
      imgCache : []
      ,spacer : "/path/to/your/spacer.gif"
    }

    ,collate : function(aScope) {
      var isOldIE = (document.all && !window.opera && !window.XDomainRequest) ? 1 : 0;
      if (isOldIE && document.getElementsByTagName) {
        var c = imgSizer;
        var imgCache = c.Config.imgCache;

        var images = (aScope && aScope.length) ? aScope : document.getElementsByTagName("img");
        for (var i = 0; i < images.length; i++) {
          images[i].origWidth = images[i].offsetWidth;
          images[i].origHeight = images[i].offsetHeight;

          imgCache.push(images[i]);
          c.ieAlpha(images[i]);
          images[i].style.width = "100%";
        }

        if (imgCache.length) {
          c.resize(function() {
            for (var i = 0; i < imgCache.length; i++) {
              var ratio = (imgCache[i].offsetWidth / imgCache[i].origWidth);
              imgCache[i].style.height = (imgCache[i].origHeight * ratio) + "px";
            }
          });
        }
      }
    }

    ,ieAlpha : function(img) {
      var c = imgSizer;
      if (img.oldSrc) {
        img.src = img.oldSrc;
      }
      var src = img.src;
      img.style.width = img.offsetWidth + "px";
      img.style.height = img.offsetHeight + "px";
      img.style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + src + "', sizingMethod='scale')"
      img.oldSrc = src;
      img.src = c.Config.spacer;
    }

    // Ghettomodified version of Simon Willison's addLoadEvent() -- http://simonwillison.net/2004/May/26/addLoadEvent/
    ,resize : function(func) {
      var oldonresize = window.onresize;
      if (typeof window.onresize != 'function') {
        window.onresize = func;
      } else {
        window.onresize = function() {
          if (oldonresize) {
            oldonresize();
          }
          func();
        }
      }
    }
  }

  addLoadEvent(function() {
    imgSizer.collate();
  });

  function addLoadEvent(func) {
    var oldonload = window.onload;
    if (typeof window.onload != 'function') {
      window.onload = func;
    } else {
      window.onload = function() {
        if (oldonload) {
          oldonload();
        }
        func();
      }
    }
  }

  /* Animation */
  $(window).scroll(function() {

    $('.home .site-main .circle-icon-wrapper').each(function(){
    var imagePos = $(this).offset().top;

    var topOfWindow = $(window).scrollTop();
      if (imagePos < topOfWindow+500) {
        $(this).addClass("ab-animation-slide-top");
        $(this).addClass("animated");
      }
    });

    $('.home .site-main .circle-icon-box h4, .home .site-main .circle-icon-box p, .home .site-main .circle-icon-box a').each(function(){
    var imagePos = $(this).offset().top;

    var topOfWindow = $(window).scrollTop();
      if (imagePos < topOfWindow+500) {
        $(this).addClass("ab-animation-slide-bottom");
        $(this).addClass("animated");
      }
    }); 

    $('.home .site-main .widget_list-widget h3, .home .site-main .widget_testimonial-widget h3, .home .site-main .widget_skill-widget h3, .home .site-main .widget_text h3').each(function(){
    var imagePos = $(this).offset().top;

    var topOfWindow = $(window).scrollTop();
      if (imagePos < topOfWindow+500) {
        $(this).addClass("ab-animation-slide-top");
        $(this).addClass("animated");
      }
    });   

    $('.home .site-main .widget_list-widget li').each(function(){
    var imagePos = $(this).offset().top;

    var topOfWindow = $(window).scrollTop();
      if (imagePos < topOfWindow+600) {
        $(this).addClass("ab-animation-slide-fade");
        $(this).addClass("animated");
      }
    });    

    $('.home .site-main .testimonials').each(function(){
    var imagePos = $(this).offset().top;

    var topOfWindow = $(window).scrollTop();
      if (imagePos < topOfWindow+600) {
        $(this).addClass("ab-animation-scale-up");
        $(this).addClass("animated");
      }
    });  

    $('.home .site-main .skill-container').each(function(){
    var imagePos = $(this).offset().top;

    var topOfWindow = $(window).scrollTop();
      if (imagePos < topOfWindow+600) {
        $(this).addClass("ab-animation-slide-bottom");
        $(this).addClass("animated");
      }
    });

    $('.home .site-main .widget_recent-work-widget').each(function(){
    var imagePos = $(this).offset().top;

    var topOfWindow = $(window).scrollTop();
      if (imagePos < topOfWindow+600) {
        $(this).addClass("ab-animation-fade");
        $(this).addClass("animated");
      }
    }); 

    $('.home .content-area .widget_text').each(function(){
    var imagePos = $(this).offset().top;

    var topOfWindow = $(window).scrollTop();
      if (imagePos < topOfWindow+600) {
        $(this).addClass("flipInX");
        $(this).addClass("animated");
      }
    });    

  });

/* Isotope Implementation */
  var $container = $('#portfolio');

  $container.imagesLoaded(function() {
    $container.isotope({
      // options
      itemSelector : '.item',
      layoutMode : 'fitRows'
    });
  });

      var $optionSets = $('#filters .filter-options'),
          $optionLinks = $optionSets.find('a');
          console.log($optionSets);
      $optionLinks.click(function(){
        var $this = $(this);
        // don't proceed if already selected
        if ( $this.hasClass('selected') ) {
          return false;
        }
        var $optionSet = $this.parents('.filter-options');
        $optionSet.find('.selected').removeClass('selected');
        $this.addClass('selected');
  
        // make option object dynamically, i.e. { filter: '.my-filter-class' }
        var options = {},
            key = $optionSet.attr('data-option-key'),
            value = $this.attr('data-option-value');
        // parse 'false' as false boolean
        value = value === 'false' ? false : value;
        options[ key ] = value;
        if ( key === 'layoutMode' && typeof changeLayoutMode === 'function' ) {
          // changes in layout modes need extra logic
          changeLayoutMode( $this, options )
        } else {
          // otherwise, apply new options
          $container.isotope( options );
        }
        
        return false;
      });


      $('.portfolio2col').hover(function() {   
        $(this).addClass('hover');
        $('.portfolio2col_overlay', this).stop(true, false, true).fadeIn();
        $('.portfolio2col_overlay .overlay_icon', this).stop(true, false, true).animate({ left: '42%' }, 300);
      },function(){
        $(this).removeClass('hover');
        $('.portfolio2col_overlay', this).stop(true, false, true).fadeOut();
        $(this).find('.portfolio2col_overlay .overlay_icon').stop(true, false, true).animate({ left: '142%' }, 100, function() {
        $(this).css('left', '-42%');
        });
      });
      $('.portfolio2col_sidebar').hover(function() {
        $(this).addClass('hover');
        $('.portfolio2col_sidebar_overlay', this).stop(true, false, true).fadeIn();
        $('.portfolio2col_sidebar_overlay .overlay_icon', this).stop(true, false, true).animate({ left: '42%' }, 300);
      },function(){
        $(this).removeClass('hover');
        $('.portfolio2col_sidebar_overlay', this).stop(true, false, true).fadeOut();
        $(this).find('.portfolio2col_sidebar_overlay .overlay_icon').stop(true, false, true).animate({ left: '142%' }, 100, function() {
        $(this).css('left', '-42%');
      });
    });

    $('.portfolio3col').hover(function() {
      $(this).addClass('hover');
      $('.portfolio3col_overlay', this).stop(true, false, true).fadeIn();
      $('.portfolio3col_overlay .overlay_icon', this).stop(true, false, true).animate({ left: '42%' }, 300);
    },function(){
      $(this).removeClass('hover');
      $('.portfolio3col_overlay', this).stop(true, false, true).fadeOut();
      $(this).find('.portfolio3col_overlay .overlay_icon').stop(true, false, true).animate({ left: '142%' }, 100, function() {
      $(this).css('left', '-42%');
    });
  });

    $('.portfolio4col').hover(function() {
      $(this).addClass('hover');
      $('.portfolio4col_overlay', this).stop(true, false, true).fadeIn();
      $('.portfolio4col_overlay .overlay_icon', this).stop(true, false, true).animate({ left: '42%' }, 300);
    },function(){
      $(this).removeClass('hover');
      $('.portfolio4col_overlay', this).stop(true, false, true).fadeOut();
      $(this).find('.portfolio4col_overlay .overlay_icon').stop(true, false, true).animate({ left: '142%' }, 100, function() {
      $(this).css('left', '-42%');
    });
  });

  $('.recent-work .work').hover(function() {
    $(this).addClass('hover');
    $('.recent_work_overlay', this).stop(true, false, true).fadeIn();
    $('.recent_work_overlay .overlay_icon', this).stop(true, false, true).animate({ left: '42%' }, 300);

  },function(){
    $(this).removeClass('hover');
    $('.recent_work_overlay', this).stop(true, false, true).fadeOut();
    $(this).find('.recent_work_overlay .overlay_icon').stop(true, false, true).animate({ left: '142%' }, 100, function() {
            $(this).css('left', '-42%');
        });
  });      

 });


