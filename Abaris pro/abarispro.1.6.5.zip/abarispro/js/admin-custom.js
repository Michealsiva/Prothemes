jQuery(function($){
		if( $.fn.iconpicker ) {
		  $('.faip').iconpicker();
	    }
	function format(icon) {
	    var originalOption = icon.element;
	    return '<i class="fa ' + jQuery(originalOption).data('icon') + '"></i> &nbsp;' + icon.text;
	}

	if( jQuery.fn.select2 ) {
		jQuery('select#widget-circleicon-widget-2-icon').select2({
	  		width: "100%",
	  		formatResult: format
		}); 
	}
	

});

