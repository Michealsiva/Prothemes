<?php
/**
 * The Header for our theme.
 * Displays all of the <head> section and everything up till <div id="content">
 * @package Webulous
 *
 */
global $abaris; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php wp_title( '|', true, 'right' ); ?></title>

<?php if( isset( $abaris['ipad-icon-retina'] ) ) : ?>
	<!-- For third-generation iPad with high-resolution Retina display: -->
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo $abaris['ipad-icon-retina']['url']; ?>">
<?php endif; ?>

<?php if( isset( $abaris['iphone-icon-retina'] ) ) : ?>
	<!-- For iPhone with high-resolution Retina display: -->
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo $abaris['iphone-icon-retina']['url']; ?>">
<?php endif; ?>

<?php if( isset( $abaris['ipad-icon'] ) ) : ?>
	<!-- For first- and second-generation iPad: -->
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo $abaris['ipad-icon']['url']; ?>">
<?php endif; ?>

<?php if( isset( $abaris['iphone-icon'] ) ) : ?>
	<!-- For non-Retina iPhone, iPod Touch, and Android 2.1+ devices: -->
	<link rel="apple-touch-icon-precomposed" href="<?php echo $abaris['iphone-icon']['url']; ?>">
<?php endif; ?>

<?php if( isset( $abaris['favicon'] ) ) : ?>
	<link rel="icon" href="<?php echo $abaris['favicon']['url']; ?>">
<?php endif; ?>

	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php if( isset($abaris['analytics-place']) && isset($abaris['google-analytics']) && $abaris['analytics-place'] == 0 ){
	echo $abaris['google-analytics'];
}
?>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<div id="page" class="hfeed site <?php echo webulous_site_style_layout_class(); ?>">
		<div id="content" class="site-content">
