<?php
/*
 * Template Name: Blog Small Image
 */
	global $abaris;
	get_header();
?>

			<div class="container">
				<div class="row">

				<?php if( isset( $abaris['layout'] ) && $abaris['layout'] == 2 ) : ?>
					<?php get_sidebar(); ?>
				<?php endif; ?>

					<div id="primary" class="content-area two-thirds column">
						<main id="main" class="site-main" role="main">

						<?php if ( $abaris['breadcrumb'] && function_exists( 'webulous_breadcrumbs' ) ) : ?>			
							<div id="breadcrumb" role="navigation">
								<?php webulous_breadcrumbs(); ?>
							</div>
						<?php endif; ?>
						
						<?php
							$query_string ="post_type=post&paged=$paged";
							query_posts($query_string);
							$num_of_posts = $wp_query->post_count;
						?>		
							
						<?php if ( have_posts() ) : ?>

							<?php /* Start the Loop */ ?>
							<?php while ( have_posts() ) : the_post(); ?>


							<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

								<header class="entry-header">
									<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(  get_webulous_entry_title_before_icon(), '' ); ?></a></h1>
								</header><!-- .entry-header -->
                                  <?php if ( isset( $abaris['enable_single_post_top_meta'] ) && $abaris['enable_single_post_top_meta'] ): ?>
										<footer class="entry-meta">
											<?php if(function_exists('webulous_entry_top_meta') ) {
											    webulous_entry_top_meta(); 
											} ?>  
									    </footer><!-- .entry-footer -->
								   <?php endif;?>
								<div class="entry-content">
									<?php if( isset($abaris['featured-image'] ) && $abaris['featured-image'] ) : ?>
										<div class="thumb">
											<?php 
												if( has_post_thumbnail() && ! post_password_required() ) : 
													the_post_thumbnail('blog-large'); 
												endif;
											?>
										</div>
									<?php endif; ?>

										<?php global $more; $more = 0; the_content( 'Read More' );; ?>

									<?php
										wp_link_pages( array(
											'before' => '<div class="page-links">' . __( 'Pages:', 'abarispro' ),
											'after'  => '</div>',
										) );
									?>
									<br class="clear" />
								</div><!-- .entry-content -->

							<?php if ( isset( $abaris['enable_single_post_bottom_meta'] ) && $abaris['enable_single_post_bottom_meta'] ): ?>
								<footer class="entry-meta">
									<?php if(function_exists('webulous_entry_bottom_meta') ) {
									    webulous_entry_bottom_meta(); 
									} ?>  
							    </footer><!-- .entry-footer -->
							<?php endif;?> 
							</article><!-- #post-## -->
							<?php endwhile; ?>

							<?php 
								if( $abaris['pagenavi'] && function_exists( 'webulous_pagination' ) ) : 
									webulous_pagination();
								else :
									webulous_posts_nav();
								endif; 
							?>

						<?php else : ?>

							<?php get_template_part( 'content', 'none' ); ?>

						<?php endif; ?>

						</main><!-- #main -->
					</div><!-- #primary -->

					<?php if( isset( $abaris['layout'] ) && $abaris['layout'] == 3 ) : ?>
						<?php get_sidebar(); ?>
					<?php endif; ?>

					<?php if( ! isset( $abaris['layout'] ) ) : ?>
						<?php get_sidebar(); ?>
					<?php endif; ?>

					<?php get_footer(); ?>