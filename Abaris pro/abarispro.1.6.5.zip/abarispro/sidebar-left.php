<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package Webulous
 */
?>
	<div id="secondary" class="widget-area four columns" role="complementary">
		<?php do_action( 'before_sidebar' ); ?>

		<?php if( is_active_sidebar( 'sidebar-left' ) &&  ( is_page_template('template-twosidebar.php') || is_page_template('template-twosidebarleft.php') || is_page_template('template-twosidebarright.php') ) ) {
				dynamic_sidebar( 'sidebar-left' ); 
		}else{ ?>
			<aside id="meta" class="widget">
				<h3 class="widget-title"><?php echo get_webulous_sidebar_entry_title_before_icon();
				 _e( 'Meta', 'abarispro' ); ?></h3>
				<ul>
					<?php wp_register(); ?>
					<li><?php wp_loginout(); ?></li>
					<?php wp_meta(); ?>
				</ul>
			</aside>
	<?php } ?>
	</div><!-- #secondary -->