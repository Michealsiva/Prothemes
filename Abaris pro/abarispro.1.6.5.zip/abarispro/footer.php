<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Webulous
 */
?>

		</div>
	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="footer-top">
			<div class="container">
				<?php
					global $abaris;
					if( $abaris['footer-widgets'] ) {
						get_template_part('footer','widgets');
					} 
				?>
			</div>
		</div>


		<div class="footer-bottom">
			<div class="container">
				<div class="eight columns">
					<?php if( $abaris['footer-text'] ) : ?>
						<p><?php echo do_shortcode($abaris['footer-text']); ?></p>
					<?php else : ?>
						<p>
						<?php do_action( 'webulous_credits' ); ?>
						Powered by <a href="http://wordpress.org/"><?php printf( __( '%s', 'abarispro' ), 'WordPress' ); ?></a>
						<span class="sep"> | </span>
						<?php printf( __( 'Theme: %1$s by %2$s.', 'abarispro' ), 'Abaris', '<a href="http://www.webulous.in" rel="author">Webulous</a>' ); ?>
						</p>
					<?php endif; ?>
				</div>
				<div class="eight columns footer-right">
					<?php dynamic_sidebar( 'footer-nav' ); ?>
				</div>
			</div>
		</div><!-- .site-info -->		
		<div class="scroll-to-top"><i class="fa fa-angle-up"></i></div><!-- .scroll-to-top -->	
	</footer><!-- #colophon -->
</div><!-- #page -->
<?php if( isset($abaris['analytics-place']) && $abaris['analytics-place'] == 1 ){
	echo $abaris['google-analytics'];
}
?>
<?php wp_footer(); ?>
</body>
</html>