<?php
/**
 * The template part for displaying redux slider 
 *
 *
 * @package Webulous
 */
global $abaris;
$slides = $abaris['slides'];
	$output = '';
	if( count($slides) >= 1) {

		$output .= '<div class="flex-container free-home">';
		$output .= '<div class="flexslider">';
		$output .= '<div class="bg-bottom"></div>';					
		$output .= '<ul class="slides">';

		foreach($slides as $slide) {
			$output .= '<li>';

			$output .= '<div class="flex-image"><img src="' . $slide['image'] . '" alt="" ></div>';
			if ( $slide['description'] != '' ) {
				$output .= '<div class="flex-caption">' . $slide['description'] . '</div>';
			}
			$output .= '</li>';
		}

		$output .= '</ul>';
		$output .= '</div><!-- .flexslider -->';
		$output .= '</div><!-- .flex-container -->';
	}
	echo $output;