<?php
/**
 * The Template for displaying all single posts.
 *
 * @package Webulous
 */

get_header(); ?>

		<div class="container">
			<div class="row">

			<?php if ( $abaris['breadcrumb'] && function_exists( 'webulous_breadcrumbs' ) ) : ?>			
				<div id="breadcrumb" class="sixteen columns" role="navigation">
					<?php webulous_breadcrumbs(); ?>
				</div>
			<?php endif; ?>

			<div id="primary" class="content-area">
				<main id="main" class="site-main" role="main">
					<?php if( have_posts() ) : ?>
						<?php while( have_posts() ) : the_post(); ?>

			
							<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article">
						
								<header class="article-header">
							
									<h1 class="entry-title single-title"><?php the_title(); ?></h1>
					
								</header> <!-- end article header -->
								<?php
									$content_width = get_post_meta( $post->ID, 'portfolio_content_width', true );
									if ( $content_width == "full_width") : 
								?>
				
								<section class="article-content">
									<div class="thumbnail">
										<?php the_post_thumbnail( 'full_width' ); ?>
									</div>
									<div class="row">
										<div class="two-thirds column alpha">
											<h3>Project Description</h3>
											<?php the_content(); ?>
										</div>
										<div class="one-third column omega">
											<h4>Project Details</h4>
											<?php
												$project_url = get_post_meta( $post->ID, 'portfolio_project_url', true );
												$project_link_text = get_post_meta( $post->ID, 'portfolio_project_link_text', true );
											?>
											<dl>
												<dt>Skill needed</dt>
												<dd><?php echo the_terms( $post->ID, 'skills', '', ', ', '' ); ?></dd>
												<dt>Category</dt>
												<dd><?php echo get_the_category_list( ', ', '', $post->ID ); ?></dd>
												<dt>Project Website</dt>
												<dd><a href="<?php echo $project_url; ?>"><?php echo $project_link_text; ?></a></dd>
											</dl>
										</div>
									</div>
								</section> <!-- end article section -->
								<?php else : ?>
								<section class="row">
									<div class="thumbnail two-thirds column alpha">
										<?php the_post_thumbnail( 'blog_large' ); ?>
									</div>
									<div class="one-third column omega">
										<h3>Project Description</h3>
										<?php the_content(); ?>
										<h4>Project Details</h4>
										<?php
											$project_url = get_post_meta( $post->ID, 'portfolio_project_url', true );
											$project_link_text = get_post_meta( $post->ID, 'portfolio_project_link_text', true );
										?>
										<dl>
											<dt>Skill needed</dt>
											<dd><?php echo the_terms( $post->ID, 'skills', '', ', ', '' ); ?></dd>
											<dt>Category</dt>
											<dd><?php echo get_the_category_list( ', ', '', $post->ID ); ?></dd>
											<dt>Project Website</dt>
											<dd><a href="<?php echo $project_url; ?>"><?php echo $project_link_text; ?></a></dd>
										</dl>
									</div>
								</section> <!-- end article section -->
								<?php endif; ?>
								

								<section class="related-posts">
									<?php
										if( isset($abaris['show_related_posts']) && $abaris['show_related_posts'] && function_exists( 'nvraj_related_posts' ) ) {
											nvraj_related_posts();
										}
									?>
				
							</article> <!-- end article -->
						<?php endwhile; ?>
						<?php 
							if( $abaris['pagenavi'] && function_exists( 'webulous_pagination' ) ) : 
								webulous_pagination();
							else :
								webulous_posts_nav();
							endif; 
						?>
					<?php else : ?>
							
							<article id="post-not-found">
								
								<header class ="article-header">
									<h1 class="article-title"><?php _e("Page Not Found", 'abarispro'); ?></h1>
								</header>
								
								<section class="article-content">
									<p>
										<?php 
											printf( __('The page you were looking for was not found!. You can return %s or search for the page you were looking for.', 'abarispro'), sprintf( '<a href="%1$s" title="%2$s">%3$s</a>', esc_url( get_home_url() ), esc_attr__('Home', 'abarispro'), esc_attr__('&larr; Home', 'abarispro') )); 
										?>
									</p>
								</section>

								<footer class="article-footer">
									<p>
										<?php 
											_e("This is the error message in the page.php template.", 'abarispro'); 
										?>
									</p>
								</footer>

							</article>
							
					<?php endif; ?>						

				</main><!-- #main -->
			</div><!-- #primary -->

			</div><!-- .row -->
		</div><!-- .container -->
			
		<?php get_footer(); ?>