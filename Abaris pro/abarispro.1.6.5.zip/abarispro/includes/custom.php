<?php
	function webulous_custom_theme_options_js() {
		global $abaris;

		if( $abaris['flexslider_animation'] == 1 ) {
			$animation = 'fade';
		} else {
			$animation = 'slide';
		}

		if( $abaris['flexslider_slide_direction'] == 1 ) {
			$slide_direction = 'horizontal';
		} else {
			$slide_direction = 'vertical';
		}

		switch ($abaris['lightbox_theme']) {
			case 1:
				$lightbox_theme = 'pp_default';
				break;
			case 2:
				$lightbox_theme = 'light_rounded';
				break;			
			case 3:
				$lightbox_theme = 'dark_rounded';
				break;
			case 4:
				$lightbox_theme = 'light_square';
				break;
			case 5:
				$lightbox_theme = 'dark_square';
				break;
			case 6:
				$lightbox_theme = 'facebook';
				break;
			default:
				$lightbox_theme = 'pp_default';
				break;
		}
	?>
	<script type="text/javascript">
		jQuery(document).ready(function($){
			$('.flexslider').flexslider({
				//controlsContainer: ".flex-container",
				animation: "<?php echo $animation; ?>",
				direction: "<?php echo $slide_direction; ?>",
				slideshowSpeed: <?php echo $abaris['flexslider_slideshow_speed']; ?>,
				animationSpeed: <?php echo $abaris['flexslider_animation_speed']; ?>,
				slideshow: <?php echo ( $abaris['flexslider_slideshow'] ) ? 'true' : 'false'; ?>,
				smoothHeight: <?php echo ( $abaris['flexslider_smooth_height'] ) ? 'true': 'false'; ?>,
				directionNav: <?php echo ( $abaris['flexslider_direction_nav'] ) ? 'true' : 'false'; ?>,
				controlNav: <?php echo ( $abaris['flexslider_control_nav'] ) ? 'true' : 'false'; ?>,
				multipleKeyboard: <?php echo ( $abaris['flexslider_keyboard_nav'] ) ? 'true' : 'false'; ?>,
				mousewheel: <?php echo ( $abaris['flexslider_mousewheel_nav'] ) ? 'true' : 'false'; ?>,
				pauseplay: <?php echo ( $abaris['flexslider_pauseplay'] ) ? 'true' : 'false'; ?>,
				randomize: <?php echo ( $abaris['flexslider_randomize'] ) ? 'true' : 'false'; ?>,
				animationLoop: <?php echo ( $abaris['flexslider_animation_loop'] ) ? 'true' : 'false'; ?>,
				pauseOnAction: <?php echo ( $abaris['flexslider_pause_on_action'] ) ? 'true' : 'false'; ?>,
				pauseOnHover: <?php echo ( $abaris['flexslider_pause_on_hover'] ) ? 'true' : 'false'; ?>,
				prevText: "<?php echo $abaris['flexslider_prev_text']; ?>",
				nextText: "<?php echo $abaris['flexslider_next_text']; ?>",
				playText: "<?php echo $abaris['flexslider_play_text']; ?>",
				pauseText: "<?php echo $abaris['flexslider_pause_text']; ?>",
			});
/*
			$('#carousel').elastislide({
				orientation : "<?php echo strtolower($abaris['elastic_orientation']); ?>",
				speed : <?php echo $abaris['elastic_speed']; ?>,
				minItems : <?php echo $abaris['elastic_min_items']; ?>,
				start : <?php echo $abaris['elastic_start'];?>,
			});
*/
			$("a[rel^='prettyPhoto']").prettyPhoto({
				animation_speed: "<?php echo strtolower($abaris['lightbox_animation_speed']); ?>",
				slideshow: <?php echo $abaris['lightbox_slideshow']; ?>,
				autoplay_slideshow: <?php echo ( $abaris['lightbox_autoplay_slideshow'] ) ? 'true' : 'false'; ?>,
				opacity: <?php echo $abaris['lightbox_opacity']; ?>,
				show_title: <?php echo ( $abaris['lightbox_show_title'] ) ? 'true' : 'false'; ?>,
				theme: "<?php echo $lightbox_theme; ?>",
				overlay_gallery: <?php echo ( $abaris['lightbox_overlay_gallery'] ) ? 'true' : 'false'; ?>,
				<?php if( ! $abaris['lightbox_social_tools']) : ?>
					social_tools: false
				<?php endif; ?>
			});
		
		});
	</script>
<?php
	}

	add_action( 'wp_footer', 'webulous_custom_theme_options_js', 100 );