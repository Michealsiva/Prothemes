<?php
/**
 * Easy Digital Downloads Theme Updater
 *
 * @package EDD Sample Theme
 */

// Includes the files needed for the theme updater
if ( !class_exists( 'EDD_Theme_Updater_Admin' ) ) {
	include( dirname( __FILE__ ) . '/theme-updater-admin.php' );
}

// Loads the updater classes
$updater = new EDD_Theme_Updater_Admin(

	// Config settings
	$config = array(
		'remote_api_url' => 'http://webulousthemes.com/', // Site where EDD is hosted
		'item_name' => 'Abaris Pro', // Name of theme 
		'theme_slug' => 'abaris-pro', // Theme slug
		'version' => '1.6.5', // The current version of this theme
		'author' => 'N. Venkat Raj', // The author of this theme
		'download_id' => '', // Optional, used for generating a license renewal link
		'renew_url' => '' // Optional, allows for a custom license renewal link
	),

	// Strings
	$strings = array(
		'theme-license' => __( 'Theme License', 'abarispro' ),
		'enter-key' => __( 'Enter your theme license key.', 'abarispro' ),
		'license-key' => __( 'License Key', 'abarispro' ),
		'license-action' => __( 'License Action', 'abarispro' ),
		'deactivate-license' => __( 'Deactivate License', 'abarispro' ),
		'activate-license' => __( 'Activate License', 'abarispro' ),
		'status-unknown' => __( 'License status is unknown.', 'abarispro' ),
		'renew' => __( 'Renew?', 'abarispro' ),
		'unlimited' => __( 'unlimited', 'abarispro' ),
		'license-key-is-active' => __( 'License key is active.', 'abarispro' ),
		'expires%s' => __( 'Expires %s.', 'abarispro' ),
		'%1$s/%2$-sites' => __( 'You have %1$s / %2$s sites activated.', 'abarispro' ),
		'license-key-expired-%s' => __( 'License key expired %s.', 'abarispro' ),
		'license-key-expired' => __( 'License key has expired.', 'abarispro' ),
		'license-keys-do-not-match' => __( 'License keys do not match.', 'abarispro' ),
		'license-is-inactive' => __( 'License is inactive.', 'abarispro' ),
		'license-key-is-disabled' => __( 'License key is disabled.', 'abarispro' ),
		'site-is-inactive' => __( 'Site is inactive.', 'abarispro' ),
		'license-status-unknown' => __( 'License status is unknown.', 'abarispro' ),
		'update-notice' => __( "Updating this theme will lose any customizations you have made. 'Cancel' to stop, 'OK' to update.", 'abarispro' ),
		'update-available' => __('<strong>%1$s %2$s</strong> is available. <a href="%3$s" class="thickbox" title="%4s">Check out what\'s new</a> or <a href="%5$s"%6$s>update now</a>.', 'abarispro' )
	)

);