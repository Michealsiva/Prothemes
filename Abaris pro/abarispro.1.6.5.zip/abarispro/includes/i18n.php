<?php
	// Makes theme translation ready
	load_theme_textdomain( 'abarispro', WEBULOUS_LANGUAGES_DIR );
