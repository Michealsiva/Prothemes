<?php
	function skills() {

		register_post_type( 'skill', array(
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'query_var' => true,
			'rewrite' => array( 'slug' => 'skill' ),
			'has_archive' => true,
			'hierarchical' => true,
			'taxonomies' => array( 'category' ),
			
			'menu_icon'           => 'dashicons-admin-tools',
			'supports' => array( 'title' ),
			'labels' => array(
				'name' => __( 'Skills', 'abarispro' ),
				'singular_name' => __( 'Skill', 'abarispro' ),
				'add_new' => __( 'Add New Skill', 'abarispro' ),
				'add_new_item' => __( 'Add New Skill', 'abarispro' ),
				'edit_item' => __( 'Edit Skill', 'abarispro' ),
				'new_item' => __( 'New Skill', 'abarispro' ),
				'all_items' => __( 'All Skills', 'abarispro' ),
				'view_item' => __( 'View Skill', 'abarispro' ),
				'search_items' => __( 'Search Skills', 'abarispro' ),
				'not_found' =>  __( 'No Skills Found', 'abarispro' ),
				'not_found_in_trash' => __( 'No Skills Found in Trash', 'abarispro' ),
				'parent_item_colon' => '',
				'menu_name' => 'Skills',
			)
		) );
	}
	add_action( 'init', 'skills' );

	