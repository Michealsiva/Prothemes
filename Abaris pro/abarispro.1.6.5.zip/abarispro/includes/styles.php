<?php

function webulous_custom_styles($custom) {
$custom = '';	
   global $abaris;   

   /* Portfolio templates navigation related css */
   if( isset( $abaris['portfolio_filter_type'] ) && $abaris['portfolio_filter_type'] == '2' ) {
      $custom .= "ul.filter-options li:first-child { display: none; }"."\n";
   }
   if( isset( $abaris['portfolio_filter_type'] ) && $abaris['portfolio_filter_type'] == '3' ) {
      $custom .= "#filters { display: none; }"."\n"; 
   }


  /* Extra options related CSS */

  /* Sticky header position */

  $sticky_header_position = isset($abaris['sticky_header_position']) ? $abaris['sticky_header_position'] : 'top';
     if( $sticky_header_position == 'bottom' ) : ?>
      <style type="text/css" media="screen"> 
             .sticky-nav {
                  top: auto!important;
                  bottom:0; 
                  border-top: 1px solid #ffffff;
              }
              .sticky-nav .sub-menu {
                  top: auto!important;
                  bottom:100%;
              }
      </style>
    <?php endif; 


	//Output all the styles
	wp_add_inline_style( 'webulous-style', $custom );    	
}


add_action( 'wp_enqueue_scripts', 'webulous_custom_styles' );
