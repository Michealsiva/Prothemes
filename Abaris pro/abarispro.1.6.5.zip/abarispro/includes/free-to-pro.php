<?php
	if ( is_admin() && isset($_GET['activated'] ) && $pagenow == 'themes.php' && class_exists('ReduxFrameworkPlugin') ) {
		global $sampleReduxFramework;
		global $options;
		$abaris_free = get_option('abaris');
		//$abaris_free_customizer = get_option('theme_mods_abaris');
		//$abaris_pro = get_option('webulous_options');
		if( $abaris_free ) {
			foreach((array)$abaris_free as $option => $value ) {
				$sampleReduxFramework->ReduxFramework->set($option, $value);   
				/* $home_value = array(
				 	'enabled' => array(),
				 	'disabled' => array()
				 );
			     if( $option =='recent_posts' &&  $value == '1' )  {
			     	$home_value['enabled']['recent_posts'] = 'Recent Posts';
			     }else {
			     	$home_value['disabled']['recent_posts'] = 'Recent Posts';
			     }
			     if( $option == 'why_us' &&  $value == '1')   {
			     	$home_value['enabled']['features'] = 'Features';
			     }else {
			     	$home_value['disabled']['features'] = 'Features';
			     }
			     if( $option =='team-member' &&  $value == '1' )  {
			     	$home_value['enabled']['team'] = 'Team';
			     }else {
			     	$home_value['disabled']['team'] = 'Team';
			     }
			     if( $option =='additional' &&  $value == '1')  {
			     	$home_value['enabled']['extra-info'] = 'Extra Info';
			     }else {
			     	$home_value['disabled']['extra-info'] = 'Extra Info';
			     }
			     if( $option =='services' &&  $value == '1' ) {
			     	$home_value['enabled']['services'] = 'Service';
			     }else {
			     	$home_value['disabled']['services'] = 'Service';
			     }
			     if( $option =='slider' &&  $value == '1')  {
			     	$home_value['enabled']['slider'] = 'Slider';
			     }else {
			     	$home_value['disabled']['slider'] = 'Slider';
			     }
			     if( $option =='default' &&  $value == '1' )  {
			     	$home_value['enabled']['default'] = 'Default';
			     }else {
			     	$home_value['disabled']['default'] = 'Default';
			     }

			     $sampleReduxFramework->ReduxFramework->set('homepage_blocks', $home_value);*/


		
				/* slider setup
		         for( $slide_count = 1 ;  $slide_count < 6; $slide_count++ ) {    
					global $options;
					if ( $option == 'image_upload-1') {
						 $slider_value = array();
						if ( $option == 'image_upload-1' && !empty($value) ) {
						   $slider_value[0]['image'] = $value;
						}
					}
					
					if ( $option == 'image_upload-'.$slide_count ) {
						if(!empty($value)){
							$slider_value[$slide_count-1] = array();
							$slider_value[$slide_count-1]['image'] = $value;	
						}			   
					}  
					if( $option == 'flexcaption-'.$slide_count ){
		              if(!empty($value)){
		                   $slider_value[$slide_count-1]['description'] = $value;
		              }
					}
				   //echo '<pre>', print_r($slider_value),'</pre>';
			    }
			   $sampleReduxFramework->ReduxFramework->set('slides', $slider_value);

				 
		    } */

		 


		 /* //  if ( isset ( $abaris_pro['homepage_blocks']['enabled'] ) ) {
				foreach ($abaris_pro['homepage_blocks']['enabled'] as $key => $value) {
					if ( empty( get_theme_mod( $key ) ) ) {
						unset($key);
						$abaris_pro['homepage_blocks']['disabled'][$key] = 'value';	
					}
					if ( $key == 'features' && empty( get_theme_mod( 'why_us' ) ) )	{
						unset($key);
						$abaris_pro['homepage_blocks']['disabled'][$key] = 'value';	
					}
					if ( $key == 'team' && empty( get_theme_mod( 'team-member' ) ) )	{
						unset($key);
						$abaris_pro['homepage_blocks']['disabled'][$key] = 'value';	
					}
					if ( $key == 'extra-info' && empty( get_theme_mod( 'additional' ) ) )	{
						unset($key);
						$abaris_pro['homepage_blocks']['disabled'][$key] = 'value';	
					}
					//echo '<pre>', print_r($abaris_pro['homepage_blocks']),'</pre>';
				} 
			//} */
			}
				
		}
	}

