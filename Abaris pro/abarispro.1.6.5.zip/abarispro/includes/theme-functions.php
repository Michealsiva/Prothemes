<?php
/**
 * Theme Functions
 *
 * Various functions to use through out site such as breadcrumb, pagination, etc
 *
 * @package Webulous
 *
 * @since 1.0
 *
 */

	// cleaning up excerpt
	add_filter('excerpt_more', 'webulous_excerpt_more');

	// This removes the annoying […] to a Read More link
	function webulous_excerpt_more($excerpt) {
		global $post;
		// edit here if you like
		return '<p class="readmore"><a href="'. get_permalink($post->ID) . '" title="Read '. esc_attr(get_the_title($post->ID)).'">' . __('Read More &rarr;', 'abarispro') . '</a></p>';
	}

	function webulous_excerpt_length( $length ) {
		return 20;
	}
	add_filter( 'excerpt_length', 'webulous_excerpt_length', 999 );

	add_action( 'wp_head', 'webulous_custom_css' );

	function webulous_custom_css() {
		global $abaris;
		if( isset( $abaris['custom-css'] ) ) {
			$custom_css = '<style type="text/css">' . $abaris['custom-css'] . '</style>';
			echo $custom_css;
		}
	}

	add_action( 'wp_footer', 'webulous_custom_js', 99 );
	
	function webulous_custom_js() {
		global $abaris;
		if( isset( $abaris['custom-js'] ) ) {
			$custom_js = '<script type="text/javascript"><!--';
	 		$custom_js .= $abaris['custom-js'];
	 		$custom_js .= '//--><!]]></script>';
	 		echo $custom_js;
		}
	}