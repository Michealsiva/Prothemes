<?php
	function stats() {

		register_post_type( 'stats', array(
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'query_var' => true,
			'rewrite' => array( 'slug' => 'stats' ),
			'has_archive' => true,
			'hierarchical' => true,   
			
			'menu_icon'  => 'dashicons-admin-tools',
			'supports' => array( 'title' ),
			'labels' => array(
				'name' => __( 'Stats', 'abarispro' ),   
				'singular_name' => __( 'Stats', 'abarispro' ),
				'add_new' => __( 'Add New Stats', 'abarispro' ),
				'add_new_item' => __( 'Add New Stats', 'abarispro' ),
				'edit_item' => __( 'Edit Stats', 'abarispro' ),
				'new_item' => __( 'New Stats', 'abarispro' ),
				'all_items' => __( 'All Stats', 'abarispro' ),
				'view_item' => __( 'View Stats', 'abarispro' ),
				'search_items' => __( 'Search Stats', 'abarispro' ),
				'not_found' =>  __( 'No Stats Found', 'abarispro' ),
				'not_found_in_trash' => __( 'No Stats Found in Trash', 'abarispro' ),
				'parent_item_colon' => '',
				'menu_name' => 'Stats',
			)
		) );
	}
	add_action( 'init', 'stats' );

	