<?php
	function portfolios() {

		register_post_type( 'portfolio', array(
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'query_var' => true,
			'rewrite' => array( 'slug' => 'portfolio' ),
			'has_archive' => true,
			'hierarchical' => true,
			'taxonomies' => array( 'category' ),
			
			'menu_position' => 23,
			'menu_icon' => 'dashicons-format-image',
			'supports' => array( 'title', 'editor', 'thumbnail' ),
			'labels' => array(
				'name' => __( 'Projects', 'abarispro' ),
				'singular_name' => __( 'Project', 'abarispro' ),
				'add_new' => __( 'Add New Project', 'abarispro' ),
				'add_new_item' => __( 'Add New Project', 'abarispro' ),
				'edit_item' => __( 'Edit Project', 'abarispro' ),
				'new_item' => __( 'New Project', 'abarispro' ),
				'all_items' => __( 'All Projects', 'abarispro' ),
				'view_item' => __( 'View Project', 'abarispro' ),
				'search_items' => __( 'Search Projects', 'abarispro' ),
				'not_found' =>  __( 'No Projects Found', 'abarispro' ),
				'not_found_in_trash' => __( 'No Projects Found in Trash', 'abarispro' ),
				'parent_item_colon' => '',
				'menu_name' => 'Portfolios',
			)
		) );
	}
	add_action( 'init', 'portfolios' );
/*
	$portfolio_taxonomy_labels = array(  
		'name' => _x( 'Category', 'taxonomy general name', 'abarispro' ),
		'singular_name' => _x( 'Category', 'taxonomy singular name', 'abarispro' ),
		'search_items' =>  __( 'Search Categories', 'abarispro' ),
		'all_items' => __( 'All Categoriess', 'abarispro' ),
		'parent_item' => __( 'Parent Category', 'abarispro' ),
		'parent_item_colon' => __( 'Parent Category:', 'abarispro' ),
		'edit_item' => __( 'Edit Category', 'abarispro' ), 
		'update_item' => __( 'Update Category', 'abarispro' ),
		'add_new_item' => __( 'Add New Category', 'abarispro' ),
		'new_item_name' => __( 'New Category Name', 'abarispro' ),
		'menu_name' => __( 'Categoriess', 'abarispro' ),
	  );
	
	$portfolio_taxonomy_args = array(
		'public' => true, 
		'show_ui' => true,
		'hierarchical' => true,
		'labels' => $portfolio_taxonomy_labels,
		'query_var' => 'portfolio-category'
	);
	
	register_taxonomy( 'portfolio-category', array('portfolio'), $portfolio_taxonomy_args );
*/
	$portfolio_taxonomy_labels = array(  
		'name' => _x( 'Skills', 'taxonomy general name', 'abarispro' ),
		'singular_name' => _x( 'Skill', 'taxonomy singular name', 'abarispro' ),
		'search_items' =>  __( 'Search Skills', 'abarispro' ),
		'all_items' => __( 'All Skills', 'abarispro' ),
		'parent_item' => __( 'Parent Skill', 'abarispro' ),
		'parent_item_colon' => __( 'Parent Skill:', 'abarispro' ),
		'edit_item' => __( 'Edit Skill', 'abarispro' ), 
		'update_item' => __( 'Update Skill', 'abarispro' ),
		'add_new_item' => __( 'Add New Skill', 'abarispro' ),
		'new_item_name' => __( 'New Skill Name', 'abarispro' ),
		'menu_name' => __( 'Skills', 'abarispro' ),
	  );
	
	$portfolio_taxonomy_args = array(
		'public' => true, 
		'show_ui' => true,
		'hierarchical' => true,
		'labels' => $portfolio_taxonomy_labels,
		'query_var' => 'skills'
	);
	
	register_taxonomy( 'skills', array('portfolio'), $portfolio_taxonomy_args );

	// Change the columns for the edit portfolio screen
	function change_portfolio_columns( $cols ) {
		$cols = array(
			'cb' => '<input type="checkbox" />',
			'title' => __( 'Skill', 'abarispro' ),
			'shortcode'     => __( 'Shortcode',  'abarispro' ),
			'skills' => __( 'Skills', 'abarispro' ),
			'date' => __( 'Date', 'abarispro' )
		);
		return $cols;
	}

	add_filter( "manage_edit-portfolio_columns", "change_portfolio_columns" );

	function portfolio_custom_columns( $column, $post_id ) {
		global $post;
		
		switch ( $column) {
    
			case 'shortcode' :
				echo "[portfolio id=" . $post_id . " name=" . $post->post_name . "]";
				break;
				
			case 'skills' :
				$terms = get_the_terms( $post_id, 'skills' );

				/* If terms were found. */
				if ( !empty( $terms ) ) {

					$out = array();

					/* Loop through each term, linking to the 'edit posts' page for the specific term. */
					foreach ( $terms as $term ) {
						$out[] = sprintf( '<a href="%s">%s</a>',
							esc_url( add_query_arg( array( 'post_type' => $post->post_type, 'skills' => $term->slug ), 'edit.php' ) ),
							esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'skills', 'display' ) )
						);
					}

					/* Join the terms, separating them with a comma. */
					echo join( ', ', $out );
				}

				/* If no terms were found, output a default message. */
				else {
						_e( 'No Skills assigned to this project', 'abarispro	' );
					}

				break;
		}
	}

	add_action( "manage_portfolio_posts_custom_column", "portfolio_custom_columns", 100, 2 );	