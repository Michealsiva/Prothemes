<?php

return array(
	'web_application_icons' => __('Web Application Icons', 'abarispro'),
	'form_control_icon' => __('Form Control Icons', 'abarispro'),
	'currency_icons' => __('Currency Icons', 'abarispro'),
	'text_editor_icons' => __('Text Editor Icons', 'abarispro'),
	'directional_icons' => __('Directional Icons', 'abarispro'),
	'video_player_icons' => __('Video Player Icons', 'abarispro'),
	'brand_icons' => __('Brand Icons', 'abarispro'),
	'medical_icons' => __('Medical Icons', 'abarispro'),
);