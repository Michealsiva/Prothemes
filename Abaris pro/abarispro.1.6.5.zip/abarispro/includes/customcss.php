<?php
function webulous_styles_custom() {
	global $abaris;   
	$primary_color = isset($abaris['primary_color']) ? $abaris['primary_color'] : '#ff4200' ;
	$secondary_color = isset($abaris['secondary_color']) ? $abaris['secondary_color'] : '#1f2329' ; 
      
	if( isset($abaris['custom-typography']) && $abaris['custom-typography'] ) : ?>
<!-- Custom CSS Codes
========================================================= -->
<style type="text/css" media="screen">
	<?php
		$custom_fonts = array();
		if( $abaris['bd-typography']['google'] ) :
			if( ! in_array( $abaris['bd-typography']['font-family'], $custom_fonts ) ) :
				$custom_fonts[] = $abaris['bd-typography']['font-family'];
			endif;
			if( ! in_array( $abaris['nav-typography']['font-family'], $custom_fonts ) ) :
				$custom_fonts[] = $abaris['nav-typography']['font-family'];
			endif;
			if( ! in_array( $abaris['h1-typography']['font-family'], $custom_fonts ) ) :
				$custom_fonts[] = $abaris['h1-typography']['font-family'];
			endif;
			if( ! in_array( $abaris['h2-typography']['font-family'], $custom_fonts ) ) :
				$custom_fonts[] = $abaris['h2-typography']['font-family'];
			endif;
			if( ! in_array( $abaris['h3-typography']['font-family'], $custom_fonts ) ) :
				$custom_fonts[] = $abaris['h3-typography']['font-family'];
			endif;
			if( ! in_array( $abaris['h4-typography']['font-family'], $custom_fonts ) ) :
				$custom_fonts[] = $abaris['h4-typography']['font-family'];
			endif;
			if( ! in_array( $abaris['h5-typography']['font-family'], $custom_fonts ) ) :
				$custom_fonts[] = $abaris['h5-typography']['font-family'];
			endif;
			if( ! in_array( $abaris['h6-typography']['font-family'], $custom_fonts ) ) :
				$custom_fonts[] = $abaris['h6-typography']['font-family'];
			endif;
		endif;
	?>

	body{ font-family: "<?php echo $abaris['bd-typography']['font-family']; ?>", sans-serif; font-size: <?php echo $abaris['bd-typography']['font-size']; ?>; font-weight: <?php echo $abaris['bd-typography']['font-weight']; ?>; color: <?php echo $abaris['bd-typography']['color']; ?>; }
	.main-navigation ul li a { font-family: "<?php echo $abaris['nav-typography']['font-family']; ?>", sans-serif; font-size: <?php echo $abaris['nav-typography']['font-size']; ?>; font-weight: <?php echo $abaris['nav-typography']['font-weight']; ?>; color: <?php echo $abaris['nav-typography']['color']; ?>; }
	.main-navigation ul ul li a { font-family: "<?php echo $abaris['nav-typography']['font-family']; ?>", sans-serif; font-size: <?php echo $abaris['nav-typography']['font-size']; ?>; font-weight: <?php echo $abaris['nav-typography']['font-weight']; ?>; color: <?php echo $abaris['nav-typography']['color']; ?>; }
	.main-navigation ul ul ul li a { font-family: "<?php echo $abaris['nav-typography']['font-family']; ?>", sans-serif; font-size: <?php echo $abaris['nav-typography']['font-size']; ?>; font-weight: <?php echo $abaris['nav-typography']['font-weight']; ?>; color: <?php echo $abaris['nav-typography']['color']; ?>; }
	h1{ font-family: "<?php echo $abaris['h1-typography']['font-family']; ?>", sans-serif; font-size: <?php echo $abaris['h1-typography']['font-size']; ?>; font-weight: <?php echo $abaris['h1-typography']['font-weight']; ?>; color: <?php echo $abaris['h1-typography']['color']; ?>; }
	h2{ font-family: "<?php echo $abaris['h2-typography']['font-family']; ?>", sans-serif; font-size: <?php echo $abaris['h2-typography']['font-size']; ?>; font-weight: <?php echo $abaris['h2-typography']['font-weight']; ?>; color: <?php echo $abaris['h2-typography']['color']; ?>; }
	h3{ font-family: "<?php echo $abaris['h3-typography']['font-family']; ?>", sans-serif; font-size: <?php echo $abaris['h3-typography']['font-size']; ?>; font-weight: <?php echo $abaris['h3-typography']['font-weight']; ?>; color: <?php echo $abaris['h3-typography']['color']; ?>; }
	h4{ font-family: "<?php echo $abaris['h4-typography']['font-family']; ?>", sans-serif; font-size: <?php echo $abaris['h4-typography']['font-size']; ?>; font-weight: <?php echo $abaris['h4-typography']['font-weight']; ?>; color: <?php echo $abaris['h4-typography']['color']; ?>; }
	h5{ font-family: "<?php echo $abaris['h5-typography']['font-family']; ?>", sans-serif; font-size: <?php echo $abaris['h5-typography']['font-size']; ?>; font-weight: <?php echo $abaris['h5-typography']['font-weight']; ?>; color: <?php echo $abaris['h5-typography']['color']; ?>; }
	h6{ font-family: "<?php echo $abaris['h6-typography']['font-family']; ?>", sans-serif; font-size: <?php echo $abaris['h6-typography']['font-size']; ?>; font-weight: <?php echo $abaris['h6-typography']['font-weight']; ?>; color: <?php echo $abaris['h6-typography']['color']; ?>; }
	a, h1 a, h2 a, h3 a, h4 a, h5 a, h6 a, h1 a:visited, h2 a:visited, h3 a:visited, h4 a:visited, h5 a:visited, h6 a:visited  { font-weight: inherit; color: <?php echo $abaris['opt-link-color']['regular']; ?>; }
	h1 a:hover, h2 a:hover, h3 a:hover, h4 a:hover, h5 a:hover, h6 a:hover, 
	a:hover, a:hover h1, a:hover h2, a:hover h3, a:hover h4, a:hover h5, a:hover h6 { color: <?php echo $abaris['opt-link-color']['hover']; ?>; } */

/* custom css */   

.order-total .amount,
.cart-subtotal .amount,.woocommerce .woocommerce-breadcrumb a,
.woocommerce-page .woocommerce-breadcrumb a,
table caption,a:hover, h1 a:hover,.site-title a:hover,.site-footer h1, 
.site-footer h2, 
.site-footer h3, 
.site-footer h4, 
.site-footer h5, 
.site-footer h6,
#wp-calendar td a,.pagination a,a.more-link,.services h2,.flex-direction-nav a:hover,
.navigation a,.ui-accordion .ui-accordion-header-active span.fa,
.ui-accordion .ui-accordion-header:hover,
.webulous_page_navi li a,.sticky h1 a,.widget_list-widget ul li .fa,
.comment-navigation .nav-next a,#secondary tfoot td a:hover,
.comment-navigation .nav-previous a,.work:hover h4,
.site-main .search-form input.search-submit,.entry-meta a:hover,.widget li a:hover,.comment-metadata a:hover,
cite.fn a:hover,.feature2 li:before,.home .widget_circleicon-widget h4,
.page-links a,.pagination a:hover,
.site-footer a:hover,.required,.search-form:hover .el-search,
.site-footer .row:nth-of-type(2) p a,.ui-accordion h3,
.site-footer #wp-calendar td#next a:hover, 
.site-footer #wp-calendar td#prev a:hover,.site-footer .widget a:hover,.footer-bottom p a,#breadcrumb a:hover,#breadcrumb span.current
		{
			color: <?php echo $primary_color; ?>; 
		}

.woocommerce #content input.button,
.woocommerce #respond input#submit,
.woocommerce a.button,
.woocommerce button.button,
.woocommerce input.button,
.woocommerce-page #content input.button,
.woocommerce-page #respond input#submit,
.woocommerce-page a.button,
.woocommerce-page button.button,
.woocommerce-page input.button,.main-navigation div > ul > li > a:hover,a.btn-more,p.readmore a:hover,.dropcap-circle,
a.btn-readmore,.widget_search:hover .search-submit,#wp-calendar td#today,.dropcap-box,.toggle-title:hover,
.main-navigation div > ul > li.current_page_item > a,.client-pic img,.recent_work_overlay .fa,
.main-navigation div > ul > li.current_page_ancestor > a,p.btn-slider a,
.slicknav_nav div > ul > li.current_page_item a,.team-social li a:hover,
.slicknav_nav div > ul > li.current_page_ancestor > a,.site-footer .widget_recent-posts-widget .rp-content p.readmore a,
.slicknav_nav ul.children li.current_page_item > a,a.btn-more:hover, 
.form-submit input#submit:hover,a.more-button,.callout-widget a,
.wpcf7-submit:hover,.share-box li a:hover,.site-footer .widget .team-social li a:hover,
.post-password-form input[type="submit"]:hover,.slicknav_menu,
.site-footer .woocommerce #searchform #searchsubmit:hover,
.main-navigation ul.children li.current_page_item > a,.main-navigation div > ul > li.current_page_ancestor li.current_page_item > a,.main-navigation ul ul li:hover > a,.main-navigation ul ul.children li.current_page_item > a,
.scroll-to-top 
		{
			background-color: <?php echo $primary_color; ?>; 
		}

ul.tabs li.ui-tabs-active a,
ul.tabs li a:hover
		{
			border-top-color: <?php echo $primary_color; ?>; 
		}

.flex-caption h2,
.flex-caption h1
		{
			border-left-color: <?php echo $primary_color; ?>; 
		}

/*  secondary color */

.woocommerce #content div.product .stock,
.woocommerce div.product .stock,
.woocommerce-page #content div.product .stock,
.woocommerce-page div.product .stock,#breadcrumb a,.page-template .widget_circleicon-widget h4,.site-footer .search-form .el-search,
.page-template .widget_circleicon-widget p,ul.tabs li a,#portfolio h4 a:hover,.entry-meta a,.widget li a,.comment-metadata a,.filter-options li a,
cite.fn a,ol.comment-list li.pingback .comment-body a:hover,#secondary td,#secondary tfoot td a,h3.widget-title a,.ui-accordion h3,.ui-accordion h3 span.fa,.alert-message a
		{
			color: <?php echo $secondary_color; ?>; 
		}

.woocommerce #content input.button.alt:hover,
.woocommerce #respond input#submit.alt:hover,
.woocommerce a.button.alt:hover,
.woocommerce button.button.alt:hover,
.woocommerce input.button.alt:hover,
.woocommerce-page #content input.button.alt:hover,
.woocommerce-page #respond input#submit.alt:hover,
.woocommerce-page a.button.alt:hover,
.woocommerce-page button.button.alt:hover,.woocommerce .woocommerce-info:before,
.woocommerce-page .woocommerce-info:before,.share-box li a,
.woocommerce .woocommerce-message:before,
.woocommerce-page .woocommerce-message:before,
.woocommerce-page input.button.alt:hover,.woocommerce .woocommerce-info:before,
.woocommerce-page .woocommerce-info:before,.hr_dashed,.withtip:before,.filter-options li a:hover,.callout-widget a:hover,
.filter-options li a.selected
		{
			background-color: <?php echo $secondary_color; ?>; 
		}
		
.woocommerce #content input.button.alt,
.woocommerce #respond input#submit.alt,
.woocommerce a.button.alt,
.woocommerce button.button.alt,
.woocommerce input.button.alt,
.woocommerce-page #content input.button.alt,
.woocommerce-page #respond input#submit.alt,
.woocommerce-page a.button.alt,
.woocommerce-page button.button.alt,
.woocommerce-page input.button.alt,.woocommerce .woocommerce-info,
.woocommerce-page .woocommerce-info,
.woocommerce .woocommerce-message,.author-bio,
.woocommerce-page .woocommerce-message
		{
			border-color: <?php echo $secondary_color; ?>; 
		}

.withtip.top:after
		{
			border-top-color: <?php echo $secondary_color; ?>; 
		}

.withtip.right:after
		{
			border-right-color: <?php echo $secondary_color; ?>; 
		}

.withtip.bottom:after
		{
			border-bottom-color: <?php echo $secondary_color; ?>; 
		}

.withtip.left:after
		{
			border-left-color: <?php echo $secondary_color; ?>; 
		}



</style>

<?php 
	endif;
	/* Menu Navigation alignment */

	if( isset($abaris['header_nav_align']) && $abaris['header_nav_align'] != 'right') : ?>
		<style type="text/css" media="screen"> 
            .main-navigation {
            	text-align: <?php  echo $abaris['header_nav_align'] ?>;
            }
		</style>
    <?php endif; 

     /* Flexcaption related options - visible status  */

	if( isset($abaris['flexcaption_visible_status']) && !$abaris['flexcaption_visible_status'] ) : ?>
		<style type="text/css" media="screen"> 
            .flex-caption {
            	display: none;
            }
		</style>
    <?php endif; 

    /* Flexcaption related options - visible types  */

	if( isset($abaris['flexcaption_visible_type']) && !$abaris['flexcaption_visible_type'] ) : ?>
		<style type="text/css" media="screen"> 
            .flex-caption {
            	display: none;
            }
            .flexslider:hover .flex-caption {
            	display: block;
            }
		</style>
    <?php endif; 

    /* Custom Flexcaption design - bg color  */

	if( isset($abaris['custom_flexcaption_status']) && $abaris['custom_flexcaption_status'] ) : ?>
		<style type="text/css" media="screen"> 
            .flex-caption h2, .flex-caption h1,.flex-caption h3, .flex-caption h4, .flex-caption h5, .flex-caption p, .flex-caption li {
            	background-color: transparent;
            	border-left-color: transparent;  
            }
		</style>
    <?php endif; 

    

}
add_action( 'wp_head', 'webulous_styles_custom', 100 );
?>