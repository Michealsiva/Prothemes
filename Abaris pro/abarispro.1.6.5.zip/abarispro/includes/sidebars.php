<?php
/**
 * Register widgetized area and update sidebar with default widgets.
 */
if( ! function_exists('webulous_widgets_init')) {
	function webulous_widgets_init() {
		register_sidebar( array(
			'name'          => __( 'Sidebar', 'abarispro' ),
			'id'            => 'sidebar-1',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">', 
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">'. get_webulous_sidebar_entry_title_before_icon(),  
			'after_title'   => '</h3>',
		) );  
		register_sidebar( array(
			'name'          => __( 'Sidebar Left', 'abarispro' ), 
			'id'            => 'sidebar-left',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">'. get_webulous_sidebar_entry_title_before_icon(),
			'after_title'   => '</h3>',
	    ) );
	    register_sidebar( array(
			'name'          => __( 'Top Left', 'abarispro' ),
			'id'            => 'top-left',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">', 
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
	    ) );        
		register_sidebar( array(
			'name'          => __( 'Top Right', 'abarispro' ),
			'id'            => 'top-right',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );
		register_sidebar( array(
			'name'          => __( 'Footer 1', 'abarispro' ),
			'id'            => 'footer-1',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) ); 

		register_sidebar( array(
			'name'          => __( 'Footer 2', 'abarispro' ),
			'id'            => 'footer-2',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

		register_sidebar( array(
			'name'          => __( 'Footer 3', 'abarispro' ),
			'id'            => 'footer-3',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

		register_sidebar( array(
			'name'          => __( 'Footer 4', 'abarispro' ),
			'id'            => 'footer-4',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );

		register_sidebar( array(
			'name'          => __( 'Footer Nav', 'abarispro' ),
			'id'            => 'footer-nav',
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		) );
	}
}	
add_action( 'widgets_init', 'webulous_widgets_init' );