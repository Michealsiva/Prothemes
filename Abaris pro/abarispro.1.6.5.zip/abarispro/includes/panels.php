<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */
    
/**
 * Adds default page layouts
 *    
 * @param $layouts
 */
if (!function_exists('webulous_prebuilt_page_layouts') ) {   
function webulous_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'abarispro'),
    'description' => __('Pre Built Layout for  home page', 'abarispro'),
    'widgets' =>  array(
        0 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'Our Services',
      'panels_info' => 
      array (
        'class' => 'Webulous_Heading_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '341688f9-332e-4afd-9636-d98b8c35d962',
        'style' => 
        array (
          'class' => 'headline-divider head-white',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Responsive Design',
      'text' => 'Abaris is fully Responsive, Clean and Modern theme and can adapt to any screen size. Resize your browser window to view it!',
      'icon' => 'fa-adn',
      'icon_background_color' => '#ffffff',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'all_linkable' => true,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '8258793b-95c9-41ef-a910-4c171f0171e0',
        'style' => 
        array (
          'class' => 'fadeInLeft-animation',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Shortcodes and Page Builder',
      'text' => 'Lots of shortcodes comes with Abaris! You can also use our drag and drop widgets along with page builder plugin.',
      'icon' => 'fa-magic',
      'icon_background_color' => '#ffffff',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'all_linkable' => true,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'widget_id' => 'f81150a5-1151-4538-8eda-0ea55e3dac06',
        'style' => 
        array (
          'class' => 'fadeInLeft-animation',
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Awesome Sliders',
      'text' => 'Abaris has 2 awesome sliders. You can setup unlimited slider and use it anywhere on your site',
      'icon' => 'fa-leaf',
      'icon_background_color' => '#ffffff',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'all_linkable' => true,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'widget_id' => '1dd2a4f4-6cdc-47d9-b567-13e1baf3f622',
        'style' => 
        array (
          'class' => 'fadeInLeft-animation',
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'Out Team',
      'panels_info' => 
      array (
        'class' => 'Webulous_Heading_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => 'c46a5df8-40a6-40d4-a4df-9d8d6b62c134',
        'style' => 
        array (
          'class' => 'headline-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'content' => 'Quisque fermentum sollicitudin scelerisque. Sed diam nisl, vehicula in nisi at, semper rutrum ligula. Aliquam id adipiscing eros. Duis euismod aliquam aliquam. In hac habitasse platea dictumst. ',
      'image_url' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/team1.png',
      'title' => 'John Doe',
      'designation' => 'Programmer',
      'linkedin' => 'https://www.linkedln.com',
      'google' => 'https://www.google.com',
      'twitter' => 'https://www.twitter.com',
      'facebook' => 'https://www.facebook.com',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '27ac02d2-fd0f-4021-9d90-648ba0752b41',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'content' => 'Quisque fermentum sollicitudin scelerisque. Sed diam nisl, vehicula in nisi at, semper rutrum ligula. Aliquam id adipiscing eros. Duis euismod aliquam aliquam. In hac habitasse platea dictumst. ',
      'image_url' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/team3.png',
      'title' => 'Sansa stark',
      'designation' => 'Developer',
      'linkedin' => 'https://www.linkedln.com',
      'google' => 'https://www.google.com',
      'twitter' => 'https://www.twitter.com',
      'facebook' => 'https://www.facebook.com',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '4f05abda-6f9d-4ddb-b04b-b34f9631bcc2',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'content' => 'Quisque fermentum sollicitudin scelerisque. Sed diam nisl, vehicula in nisi at, semper rutrum ligula. Aliquam id adipiscing eros. Duis euismod aliquam aliquam. In hac habitasse platea dictumst. ',
      'image_url' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/team2.png',
      'title' => 'Aaliyah',
      'designation' => 'Designer',
      'linkedin' => 'https://www.linkedln.com',
      'google' => 'https://www.google.com',
      'twitter' => 'https://www.twitter.com',
      'facebook' => 'https://www.facebook.com',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 7,
        'widget_id' => 'd2c43274-5f7e-4c7b-8d46-1ca5e15c3dce',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'content' => 'Quisque fermentum sollicitudin scelerisque. Sed diam nisl, vehicula in nisi at, semper rutrum ligula. Aliquam id adipiscing eros. Duis euismod aliquam aliquam. In hac habitasse platea dictumst. ',
      'image_url' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/team4.png',
      'title' => 'Emma',
      'designation' => 'Programmer',
      'linkedin' => 'https://www.linkedln.com',
      'google' => 'https://www.google.com',
      'twitter' => 'https://www.twitter.com',
      'facebook' => 'https://www.facebook.com',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 8,
        'widget_id' => '3201eb47-7ccd-4a9c-b2aa-dc777f71e8b5',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'About Us',
      'panels_info' => 
      array (
        'class' => 'Webulous_Heading_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '20b583b3-536c-488d-9612-3eb6df6be7e7',
        'style' => 
        array (
          'class' => 'headline-divider ',
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'src' => 'http://abaris.webulous.in/wp-content/uploads/2014/10/about.jpg',
      'href' => 'http://abaris.webulous.in/wp-content/uploads/2014/10/about.jpg',
      'panels_info' => 
      array (
        'class' => 'Webulous_Image_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 10,
        'widget_id' => '3dc6c693-264c-4e2d-87de-81c8cb813793',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => '',
      'text' => 'Lorem Ipsum is that it has a more-or-less normal distribution of letters, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque aliquet justo orci, ac lacinia est iaculis a. Ut magna felis, posuere ac venenatis ut, tincidunt quis nunc. Suspendisse lorem nibh, sodales ac lectus et, ultrices gravida urna. Maecenas suscipit sed nisl in varius. Proin eget nisi fringilla, vestibulum lectus eget, tincidunt urna. Mauris tempor nec sapien ultricies tempor. ',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 11,
        'widget_id' => '94df90c2-b03d-4eed-b463-6f107d1c1c68',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'Tabs & Skills',
      'panels_info' => 
      array (
        'class' => 'Webulous_Heading_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 12,
        'widget_id' => '353f8600-98b2-49ca-8455-bf93dbcb3c47',
        'style' => 
        array (
          'class' => 'headline-divider ',
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => '',
      'text' => '[tabs_group][tabs title="2011"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.[/tabs][tabs title="2012"]Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.[/tabs][tabs title="2013"]There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.[/tabs][tabs title="2014"]Suspendisse dignissim, turpis ut tincidunt egestas, sem erat sollicitudin est, eget placerat metus erat in ante. Praesent consequat vitae mi quis tincidunt. Donec aliquet, elit eget varius fringilla, mi justo condimentum purus, aliquam varius sapien mauris quis elit. Praesent placerat iaculis molestie. Donec mauris tellus, tristique quis est in, mattis viverra purus. Nullam ultrices dictum nunc, lacinia blandit purus pharetra quis. Aliquam erat volutpat. Vestibulum quis est non dolor scelerisque hendrerit at at diam. Quisque facilisis tellus sed mi posuere posuere. In in sapien placerat, pretium enim nec, pellentesque nulla. Nam eget odio ac purus sagittis blandit. Quisque id ligula suscipit est sodales accumsan. Quisque blandit hendrerit quam, a posuere felis aliquet non. [/tabs][/tabs_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 13,
        'widget_id' => 'e686bbec-ae8f-4bdc-896f-c905f1c6e7c1',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'title' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_Skill_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 14,
        'widget_id' => '8ea329b1-eddd-47a8-a118-92a706c4e25a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'Our Fun Facts',
      'panels_info' => 
      array (
        'class' => 'Webulous_Heading_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 15,
        'widget_id' => 'f925f462-d354-4630-89d0-84cb3734d85f',
        'style' => 
        array (
          'class' => 'headline-divider head-white',
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => '2218',
      'panels_info' => 
      array (
        'class' => 'Webulous_Stats_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 16,
        'widget_id' => '1b52fbbf-f5f1-45c8-a268-af531460014a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'title' => '2219',
      'panels_info' => 
      array (
        'class' => 'Webulous_Stats_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 1,
        'id' => 17,
        'widget_id' => '1b52fbbf-f5f1-45c8-a268-af531460014a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'title' => '2217',
      'panels_info' => 
      array (
        'class' => 'Webulous_Stats_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 2,
        'id' => 18,
        'widget_id' => '1b52fbbf-f5f1-45c8-a268-af531460014a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'title' => '2220',
      'panels_info' => 
      array (
        'class' => 'Webulous_Stats_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 3,
        'id' => 19,
        'widget_id' => '1b52fbbf-f5f1-45c8-a268-af531460014a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    20 => 
    array (
      'title' => 'Our Portfolio',
      'count' => '9',
      'type' => 'isotope',
      'panels_info' => 
      array (
        'class' => 'Webulous_Recent_Work_Widget',
        'raw' => false,
        'grid' => 10,
        'cell' => 0,
        'id' => 20,
        'widget_id' => '4118879d-7574-41bb-aefd-be6fbeddb539',
        'style' => 
        array (
          'class' => 'headline-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    21 => 
    array (
      'title' => 'Our Testimonials',
      'count' => '3',
      'panels_info' => 
      array (
        'class' => 'Webulous_Testimonial_Widget',
        'raw' => false,
        'grid' => 11,
        'cell' => 0,
        'id' => 21,
        'widget_id' => '5cac049e-0882-452c-916f-6ca555b69894',
        'style' => 
        array (
          'class' => 'headline-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    22 => 
    array (
      'title' => 'Recent Posts',
      'count' => '4',
      'type' => 'normal',
      'panels_info' => 
      array (
        'class' => 'Webulous_Recent_Posts_Widget',
        'raw' => false,
        'grid' => 12,
        'cell' => 0,
        'id' => 22,
        'widget_id' => '87d2f40d-e323-444d-9f12-8774b4efe124',
        'style' => 
        array (
          'class' => 'headline-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    23 => 
    array (
      'slider' => '23',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Webulous_FlexSlider_Widget',
        'raw' => false,
        'grid' => 13,
        'cell' => 0,
        'id' => 23,
        'widget_id' => '7095f511-168b-43e8-90f2-990628dda5f0',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'row_stretch' => 'full',
        'background' => '#1f2329',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '70px',
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'class' => 'full-width-layout',
        'background' => '#1f2329',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_bottom_gap' => '70px',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'row_stretch' => 'full',
        'background' => '#f0f2f3',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '80px',
        'padding_bottom_gap' => '50px',
      ),
    ),
    5 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'row_stretch' => 'full',
        'background' => '#f0f2f3',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_bottom_gap' => '80px',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    7 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'bottom_margin' => '0px',
        'row_stretch' => 'full',
        'background' => '#1f2329',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '80px',
        'padding_bottom_gap' => '50px',
      ),
    ),
    9 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'class' => 'stat-white',
        'row_stretch' => 'full',
        'background' => '#1f2329',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_bottom_gap' => '100px',
      ),
    ),
    10 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    11 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'row_stretch' => 'full',
        'background' => '#f0f2f3',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '70px',
        'padding_bottom_gap' => '70px',
      ),
    ),
    12 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    13 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'row_stretch' => 'full',
        'background' => '#ff7e20',
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '60px',
        'padding_bottom_gap' => '30px',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 0.5,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 0.5,
    ),
    7 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    9 => 
    array (
      'grid' => 5,
      'weight' => 0.5,
    ),
    10 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    11 => 
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    12 => 
    array (
      'grid' => 7,
      'weight' => 0.5,
    ),
    13 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    14 => 
    array (
      'grid' => 9,
      'weight' => 0.25,
    ),
    15 => 
    array (
      'grid' => 9,
      'weight' => 0.25,
    ),
    16 => 
    array (
      'grid' => 9,
      'weight' => 0.25,
    ),
    17 => 
    array (
      'grid' => 9,
      'weight' => 0.25,
    ),
    18 => 
    array (
      'grid' => 10,
      'weight' => 1,
    ),
    19 => 
    array (
      'grid' => 11,
      'weight' => 1,
    ),
    20 => 
    array (
      'grid' => 12,
      'weight' => 1,
    ),
    21 => 
    array (
      'grid' => 13,
      'weight' => 1,
    ),   
    ), 

  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'abarispro'),
    'description' => __( 'Pre Built layout for about us page', 'abarispro'),
    'widgets' => array(
      0 => 
    array (
      'src' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/about-us.png',
      'href' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/about-us.png',
      'panels_info' => 
      array (
        'class' => 'Webulous_Image_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '4713c7eb-0017-49eb-8e01-3c261071427c',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English.The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
[gap height="12"]
Lorem Ipsum is that it has a more-or-less normal distribution of letters, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque aliquet justo orci, ac lacinia est iaculis a. Ut magna felis, posuere ac venenatis ut, tincidunt quis nunc. Suspendisse lorem nibh, sodales ac lectus et, ultrices gravida urna. Maecenas suscipit sed nisl in varius. Proin eget nisi fringilla, vestibulum lectus eget, tincidunt urna. Mauris tempor nec sapien ultricies tempor.
[gap height="12"]
Duis faucibus metus a orci auctor, in dictum leo dignissim. Etiam aliquet, dui id egestas vestibulum, mi enim pulvinar ipsum, eget posuere elit dui vel diam. Integer quis nibh nunc. Nullam aliquam tincidunt tortor, quis tincidunt lorem accumsan non. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla mattis.',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => '0709b101-80a9-4080-9f42-5015231c5caf',
        'style' => 
        array (
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Milestones',
      'text' => '[tabs_group]
[tabs title="2011"]Fusce volutpat felis neque, quis ultrices eros mollis et. Nullam et lectus at turpis tempus pretium. Ut accumsan sem eget arcu semper laoreet. Nulla facilisi. Donec ligula mi, tristique at vulputate quis, laoreet vitae ipsum. Maecenas consectetur elit sit amet nisl tincidunt faucibus. Nulla vitae nunc ac leo vulputate pulvinar. Phasellus non consectetur metus, nec adipiscing enim. Fusce consequat quam eget arcu scelerisque, vel interdum elit malesuada. Phasellus volutpat euismod est sed pretium. Cras tincidunt mi ante, eget vestibulum neque dictum eu. Fusce scelerisque ipsum et eros tincidunt vulputate. Cras nisl erat, imperdiet sit amet lorem sit amet, cursus consequat quam. [/tabs]
[tabs title="2012"]It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for [/tabs]
[tabs title="2013"]It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy.[/tabs]
[tabs title="2014"] Nam commodo ipsum vehicula, dictum leo nec, malesuada quam. Maecenas ante nisi, tincidunt in tincidunt at, interdum id sapien. Phasellus laoreet, justo nec consequat mattis, neque elit blandit quam, id hendrerit purus quam non massa. Ut aliquam eu sem ut mattis. Proin ut erat eget justo posuere mattis vel nec ante. Suspendisse semper ac dui vitae venenatis. Suspendisse facilisis elementum malesuada. Nunc at libero lacinia, mattis elit eget, blandit purus. Nunc vehicula rhoncus vulputate. Pellentesque vel ultricies risus, et tempus orci. In venenatis sagittis eros sit amet ornare. Nam orci lectus, porta in volutpat a, faucibus malesuada neque.[/tabs]
[/tabs_group]',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '219e05c8-7715-49da-bfde-9c58847131e7',
        'style' => 
        array (
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Skills',
      'panels_info' => 
      array (
        'class' => 'Webulous_Skill_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 3,
        'widget_id' => 'a310d326-a286-4e84-a0bb-c95457ad9c84',
        'style' => 
        array (
        ),
      ),
    ),
    4 => 
    array (
      'content' => 'Sed sagittis condimentum odio, sed venenatis orci vehicula eget. In dictum libero odio, ut consectetur urna condimentum vel. ',
      'image_url' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/team1.png',
      'title' => 'John Doe',
      'designation' => 'Designer',
      'linkedin' => 'https://in.linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'https://twitter.com/',
      'facebook' => 'www.facebook.com/‎',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '0ed68797-b0f1-4a17-90b7-f9599b65fa40',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'content' => 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec congue risus sit amet tellus congue pretium. ',
      'image_url' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/team2.png',
      'title' => 'Aaliyah',
      'designation' => 'Front End Designer',
      'linkedin' => 'https://in.linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'https://twitter.com/',
      'facebook' => 'www.facebook.com/‎',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 5,
        'widget_id' => '2572a8b9-384d-4581-8561-31371e7b4394',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'content' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s.',
      'image_url' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/team3.png',
      'title' => 'Sansa Stark',
      'designation' => 'PHP Developer',
      'linkedin' => 'https://in.linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'https://twitter.com/',
      'facebook' => 'www.facebook.com/‎',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 6,
        'widget_id' => '5aa57184-5aa5-4c0a-a7ac-bfbaf11c59c7',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'content' => 'Donec eu nulla vestibulum, feugiat arcu et, tristique nulla. Mauris luctus eu magna in facilisis. Etiam nec mollis metus. ',
      'image_url' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/team4.png',
      'title' => 'Emma ',
      'designation' => 'WordPress Designer',
      'linkedin' => 'https://in.linkedin.com/',
      'google' => 'https://plus.google.com/',
      'twitter' => 'https://twitter.com/',
      'facebook' => 'www.facebook.com/‎',
      'panels_info' => 
      array (
        'class' => 'Webulous_Ourteam_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 7,
        'widget_id' => '7925542d-939e-4ce2-87a5-7d22a6e40a75',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '40px',
      ),
    ),
    1 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    2 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.35203574975174001,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.64796425024825999,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.5,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.5,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 0.5,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 0.5,
    ), 
    ),
  );
  $layouts['features'] = array(
      'name' => __('Features Page', 'abarispro'),
      'description' => __( 'Pre Built layout for features page', 'abarispro'),
      'widgets' => array(
      0 => 
    array (
      'title' => 'Responsive Layout',
      'text' => 'Abaris is fully responsive and can adapt to any screen size. Resize your browser window to view it!',
      'icon' => 'fa-desktop',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '12e56042-62c6-416d-b950-6bf311127676',
        'style' => 
        array (
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Awesome Sliders',
      'text' => 'Abaris includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
      'icon' => 'fa-random',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => 'b64526c8-fd02-415a-bad0-98673b41c1f5',
        'style' => 
        array (
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Font Awesome',
      'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
      'icon' => 'fa-flag',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 2,
        'widget_id' => '08338ab4-ea49-4fe3-aa33-03193b14e0b2',
        'style' => 
        array (
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Retina Ready',
      'text' => 'Abaris is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 3,
        'id' => 3,
        'widget_id' => 'df73e130-9070-4789-8e69-f3f02085f5b4',
        'style' => 
        array (
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Typography',
      'text' => 'Abaris loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
      'icon' => 'fa-font',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '49ddb261-d12c-44b9-9b5f-10782c2cc2df',
        'style' => 
        array (
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Excellent Support',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
      'icon' => 'fa-thumb-tack',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 5,
        'widget_id' => 'b14c488f-e01b-4ce0-af40-44fa200ec6be',
        'style' => 
        array (
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Advanced Admin',
      'text' => 'Aabris uses advanced Redux Framework for theme options panel, you can customize any part of your site quickly and easily!',
      'icon' => 'fa-cog',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 6,
        'widget_id' => '7df51ae1-1e77-4d79-a62f-ce2013af554c',
        'style' => 
        array (
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Page Builder',
      'text' => 'Abaris supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
      'icon' => 'fa-plus',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 3,
        'id' => 7,
        'widget_id' => 'f533f7e7-954a-480c-9fbc-1aaab7e875f4',
        'style' => 
        array (
        ),
      ),
    ),
    8 => 
    array (
      'content' => 'AbarisPro is a multi purpose, Responsive theme with beautiful design and cool CSS3 animations. It uses HTML5, CSS3, Bootstrap Grid system and coded with love and care. It\'s best suited for corporate/portfolio/blog sites. It has advanced theme options panel support to customize various parts of site, footer widget area to accommodate 4 widgets.',
      'title' => 'Fully Customizable Design & Layout',
      'url' => 'http://www.webulous.in/?add-to-cart=21',
      'anchor_text' => 'PURCHASE NOW',
      'panels_info' => 
      array (
        'class' => 'Webulous_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'a6cac201-f80e-40bb-9c5f-18c5882b272b',
        'style' => 
        array (
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Page Layout',
      'text' => 'Abaris offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy (alias)',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '4af90b9e-93e2-46a2-b04d-62052e9be375',
        'style' => 
        array (
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Custom Widget',
      'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
      'icon' => 'fa-beer',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 10,
        'widget_id' => '7089755f-f81b-4151-b230-a0996017a959',
        'style' => 
        array (
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Shortcode Builder',
      'text' => 'Abaris inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
      'icon' => 'fa-check',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 11,
        'widget_id' => 'fbb39445-9301-48ce-b407-1034d48ff7ac',
        'style' => 
        array (
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Demo Content',
      'text' => 'Abaris includes demo content files. You can quickly setup the site like our demo and get started easily!',
      'icon' => 'fa-times',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 3,
        'id' => 12,
        'widget_id' => '9e0e7eea-97e2-4c2e-840c-c598da943769',
        'style' => 
        array (
        ),
      ),
    ),
    13 => 
    array (
      'title' => 'Woo Commerce',
      'text' => 'Abaris has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!',
      'icon' => 'fa-shopping-cart',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 13,
        'widget_id' => '1cb34b7a-f930-42a7-a000-171f4e9b56c5',
        'style' => 
        array (
        ),
      ),
    ),
    14 => 
    array (
      'title' => 'Testimonials',
      'text' => 'With our testimonial post type, shortcode and widget, Displaying testimonials is a breeze.',
      'icon' => 'fa-rocket',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 14,
        'widget_id' => '928993ee-8027-4ef8-9206-f0d6d692fe6c',
        'style' => 
        array (
        ),
      ),
    ),
    15 => 
    array (
      'title' => 'Social Media',
      'text' => 'Want your users to stay in touch? No problem, Abaris has Social Media icons all throughout the theme!',
      'icon' => 'fa-skype',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 15,
        'widget_id' => 'eff7f53a-ae10-4ebe-9f14-5ed0188175e0',
        'style' => 
        array (
        ),
      ),
    ),
    16 => 
    array (
      'title' => 'Google Map',
      'text' => 'Abaris includes Goole Map as shortcode and widget. So, you can use it anywhere in your site!',
      'icon' => 'fa-map-marker',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 3,
        'id' => 16,
        'widget_id' => 'b2581bcd-05d9-4b54-9fee-e62a6ebebfbd',
        'style' => 
        array (
        ),
      ),
    ),
    17 => 
    array (
      'content' => 'AbarisPro is a multi purpose, Responsive theme with beautiful design and cool CSS3 animations. It uses HTML5, CSS3, Bootstrap Grid system and coded with love and care. It\'s best suited for corporate/portfolio/blog sites. It has advanced theme options panel support to customize various parts of site, footer widget area to accommodate 4 widgets.',
      'title' => 'Top Notch Support',
      'url' => 'http://www.webulous.in/?add-to-cart=21',
      'anchor_text' => 'PURCHASE NOW',
      'panels_info' => 
      array (
        'class' => 'Webulous_Cta_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 17,
        'widget_id' => '69f3634f-f784-4644-a4e4-eea3eb0989c4',
        'style' => 
        array (
        ),
      ),
    ),
    18 => 
    array (
      'title' => 'Multiple Portfolio',
      'text' => '7 portfolio layouts, 3 blog layouts and multiple other alternate layouts for interior pages!',
      'icon' => 'fa-list-alt',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 18,
        'widget_id' => 'd0028c60-a58f-496e-b6ba-ac314003088d',
        'style' => 
        array (
        ),
      ),
    ),
    19 => 
    array (
      'title' => 'Multiple Sidebar',
      'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
      'icon' => 'fa-columns',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 1,
        'id' => 19,
        'widget_id' => '40328ecb-e3ec-46c2-b114-2cd7188503c4',
        'style' => 
        array (
        ),
      ),
    ),
    20 => 
    array (
      'title' => 'Customization',
      'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
      'icon' => 'fa-edit (alias)',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 2,
        'id' => 20,
        'widget_id' => 'e59457b3-931a-4764-a813-bca092a89e15',
        'style' => 
        array (
        ),
      ),
    ),
    21 => 
    array (
      'title' => 'Improvement',
      'text' => 'We love our theme and customers. We are committed to improve and add new features to Abaris!',
      'icon' => 'fa-signal',
      'icon_background_color' => '000000',
      'icon_size' => '3x',
      'more' => 'Read More',
      'more_url' => '#',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 3,
        'id' => 21,
        'widget_id' => '7df8d78b-bb98-4045-82f4-5e205dd0d0f4',
        'style' => 
        array (
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '40px',
      ),
    ),
    1 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    4 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    6 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.25,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.25,
    ),
    2 => 
    array (
      'grid' => 0,
      'weight' => 0.25,
    ),
    3 => 
    array (
      'grid' => 0,
      'weight' => 0.25,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.24901960784314001,
    ),
    5 => 
    array (
      'grid' => 1,
      'weight' => 0.25098039215686002,
    ),
    6 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    7 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    8 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 3,
      'weight' => 0.25,
    ),
    10 => 
    array (
      'grid' => 3,
      'weight' => 0.25,
    ),
    11 => 
    array (
      'grid' => 3,
      'weight' => 0.25,
    ),
    12 => 
    array (
      'grid' => 3,
      'weight' => 0.25,
    ),
    13 => 
    array (
      'grid' => 4,
      'weight' => 0.25,
    ),
    14 => 
    array (
      'grid' => 4,
      'weight' => 0.25,
    ),
    15 => 
    array (
      'grid' => 4,
      'weight' => 0.25,
    ),
    16 => 
    array (
      'grid' => 4,
      'weight' => 0.25,
    ),
    17 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    18 => 
    array (
      'grid' => 6,
      'weight' => 0.25,
    ),
    19 => 
    array (
      'grid' => 6,
      'weight' => 0.25,
    ),
    20 => 
    array (
      'grid' => 6,
      'weight' => 0.25,
    ),
    21 => 
    array (
      'grid' => 6,
      'weight' => 0.25,
    ),
    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'abarispro'),
      'description' => __( 'Pre Built layout for contact us page', 'abarispro'),
      'widgets' => array(
        0 => 
    array (
      'title' => 'Get in Touch, Send  Us a Message',
      'text' => 'Sed elementum, nisl sit amet pellentesque dictum, nunc dui vehicula nibh, id congue dui risus faucibus nisl. Nulla tempus interdum nunc a malesuada. Praesent nunc dui, egestas a leo quis, euismod dapibus massa. Fusce vitae velit est. In hac habitasse platea dictumst. Donec varius pharetra sem non tempus. Nunc volutpat, purus in consequat lacinia, urna nisl imperdiet dolor, eget tristique leo mi ac nulla. 

',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'fe2029f8-d5a1-4ec1-97e2-9f2f69a5c893',
        'style' => 
        array (
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d6305.992774595653!2d-122.41157430890459!3d37.790124433800656!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858091edff45bd%3A0x70c4586b1202a605!2sUSA+Hostels+San+Francisco!5e0!3m2!1sen!2sin!4v1407318894507" width="1200" height="300" frameborder="0" style="border:0"></iframe>',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'f1488f63-ca95-42d6-a49e-cf8162ca28d1',
        'style' => 
        array (
        ),
      ),
    ),
    2 => 
    array (
      'title' => '',
      'text' => '[contact-form-7 id="4" title="Contact form 1"]',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => 'ce5f1789-f244-46d0-b48b-c1e58cd82eb4',
        'style' => 
        array (
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '40px',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    ),
  );
  $layouts['faq'] = array (
    'name' => __('Faq Page', 'abarispro'),
    'description' => __('Pre Built Layout for default faq page', 'abarispro'),
    'widgets' =>  array(
       0 => 
    array (
      'title' => '',
      'text' => '[toggle title="In dictum libero odio, ut consectetur urna condimentum vel ?" open="0"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sit amet eleifend massa. Morbi sagittis nisi id commodo venenatis. Morbi urna metus, efficitur eu pharetra at, rutrum id tortor. Ut imperdiet mauris nec massa aliquam ornare et nec ex.[/toggle]

[toggle title="Pellentesque habitant morbi tristique senectus et netus ?" open="0"]Proin lacus lectus, bibendum et nunc eget, maximus aliquet erat. Phasellus dictum dui diam, vel facilisis justo sagittis sed. In vitae varius mi, ornare scelerisque augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; [/toggle]

[toggle title="Morbi consectetur ipsum eu nunc porta ?" open="0"]Aenean a felis eget tellus blandit rhoncus quis egestas nunc. Pellentesque et dui eu metus dictum laoreet et commodo ipsum. Sed varius tincidunt sem quis porta. Nullam sollicitudin commodo augue eu tempor. Cras vitae nunc et leo rutrum maximus finibus vel ex.[/toggle]

[toggle title="In dictum libero odio, ut consectetur urna condimentum vel ?" open="0"]Nunc laoreet nibh nulla, varius lacinia est posuere sed. Cras placerat viverra massa, ac mollis diam venenatis eu. Sed ut sodales sem, sed bibendum leo. Morbi quis imperdiet nisi. Etiam congue pellentesque odio, vel dignissim elit facilisis id. Fusce non sapien[/toggle]

[toggle title="Morbi consectetur ipsum eu nunc porta ?" open="0"] Donec tincidunt nunc maximus eros interdum pharetra. Sed pulvinar auctor malesuada. Praesent malesuada, odio eu egestas bibendum, massa diam vestibulum nunc, ut porttitor est ante at turpis. Ut porta orci metus, nec eleifend nibh luctus sed. Quisque tincidunt est id ante pellentesque consectetur. [/toggle]

[toggle title="Pellentesque habitant morbi tristique senectus et netus ?" open="0"]Interdum et malesuada fames ac ante ipsum primis in faucibus. Etiam volutpat volutpat commodo. Duis mattis cursus hendrerit. Pellentesque et lacinia metus. Quisque egestas ligula nec mauris gravida laoreet. Pellentesque id molestie lectus. Praesent blandit leo auctor quam posuere accumsan.[/toggle]

[toggle title="Sed sagittis condimentum odio, sed venenatis orci vehicula eget ?" open="0"]Nunc egestas at libero eget lobortis. Curabitur a lorem lacinia, laoreet urna sit amet, porttitor est. Vivamus volutpat nisi sapien, in accumsan sem feugiat at. Curabitur sit amet nisi at quam laoreet dignissim fringilla a ex. Proin placerat ipsum a velit interdum, sed imperdiet quam tempor. Nam risus lectus, [/toggle]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '62b4d6bb-7d1b-41ce-ba26-4067cfbff4c9',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    ),
    
  );
  $layouts['services'] = array (
    'name' => __('Services Page', 'abarispro'),
    'description' => __('Pre Built Layout for services page', 'abarispro'),
    'widgets' =>  array(
        0 => 
    array (
      'src' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/our-service.jpg',
      'href' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/our-service.jpg',
      'panels_info' => 
      array (
        'class' => 'Webulous_Image_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'b4ed0ef2-005e-48ac-b3de-04659afc0e8a',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => 'Nullam quis nisl in nibh euismod scelerisque iaculis non ante. Pellentesque eget dictum sapien, et dictum felis. Nulla tempor ante eu convallis dapibus. Donec diam est, pretium a nibh vitae, vestibulum malesuada velit. Donec scelerisque tempor est sit amet porta. Maecenas cursus diam vel accumsan varius. Fusce suscipit euismod ultricies.
[gap height="15"]
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean urna orci, dignissim ac porttitor a, fermentum eget nulla. Praesent nec fermentum est. Vivamus ante sapien, pellentesque eget turpis vel, feugiat interdum tellus. Donec sodales arcu at lacus auctor sollicitudin. Vestibulum eget sodales erat, aliquet scelerisque augue. Duis eget mauris ac neque porttitor bibendum. Etiam vel enim turpis. Vestibulum facilisis aliquam magna in tristique. Aenean sollicitudin mauris urna, vitae eleifend nisl vestibulum eget. Fusce interdum id ligula vel vehicula. Curabitur pellentesque ligula eu justo interdum fringilla.

',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'widget_id' => '49e53ade-d12d-4845-97a4-32ce42b321a7',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    2 => 
    array (
      'title' => 'My Art',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam dolore, nobis sunt doloribus excepturi saepe reiciendis officia cum quibusdam explicabo. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam dolore, nobis sunt doloribus excepturi saepe reiciendis officia cum quibusdam explicabo.',
      'image_url' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/myart.jpg',
      'more' => 'Read More',
      'more_url' => 'http://www.google.com',
      'panels_info' => 
      array (
        'class' => 'Webulous_Image_Box_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '45896609-32f2-4830-bfc7-2a8d69ee6c05',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'My Bike',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam dolore, nobis sunt doloribus excepturi saepe reiciendis officia cum quibusdam explicabo. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam dolore, nobis sunt doloribus excepturi saepe reiciendis officia cum quibusdam explicabo.',
      'image_url' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/bike.jpg',
      'more' => 'Read More',
      'more_url' => 'http://www.google.com',
      'panels_info' => 
      array (
        'class' => 'Webulous_Image_Box_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 3,
        'widget_id' => 'f26be47e-fc62-440c-8b62-5a50c188a050',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'My Shirt',
      'text' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam dolore, nobis sunt doloribus excepturi saepe reiciendis officia cum quibusdam explicabo. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam dolore, nobis sunt doloribus excepturi saepe reiciendis officia cum quibusdam explicabo.',
      'image_url' => 'http://abaris.webulous.in/wp-content/uploads/2016/07/shirt.png',
      'more' => 'Read More',
      'more_url' => 'http://www.venkatraj.com',
      'panels_info' => 
      array (
        'class' => 'Webulous_Image_Box_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 4,
        'widget_id' => '0482d534-63c0-4ec9-9cca-d4e9e8c00c6d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Responsive Design',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English.',
      'icon' => 'fa-magic',
      'icon_background_color' => '#ff4400',
      'icon_size' => '2x',
      'more' => 'Read More',
      'more_url' => '#http://www.google.co.in',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '70e4a84d-fe3e-4a28-ab07-7b9357e28213',
        'style' => 
        array (
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Theme Option',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English.',
      'icon' => 'fa-eye',
      'icon_background_color' => '#ff4400',
      'icon_size' => '2x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 6,
        'widget_id' => '6a8874f2-5d2a-4942-8809-83a01f6273cd',
        'style' => 
        array (
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Multiple Sliders',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English.',
      'icon' => 'fa-phone',
      'icon_background_color' => '#ff4400',
      'icon_size' => '2x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 7,
        'widget_id' => '7cd3d0d9-16db-4497-b1e9-440e65c9e142',
        'style' => 
        array (
        ),
      ),
    ),
    8 => 
    array (
      'title' => '600+Web Fonts',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English.',
      'icon' => 'fa-pencil',
      'icon_background_color' => '#ff4400',
      'icon_size' => '2x',
      'more' => 'Read More',
      'more_url' => 'http://www.google.co.in',
      'box' => '',
      'all_linkable' => '',
      'panels_info' => 
      array (
        'class' => 'Webulous_CircleIcon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 3,
        'id' => 8,
        'widget_id' => 'b490fd6b-7c56-45e1-8f56-bac30a13edd3',
        'style' => 
        array (
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Other Services',
      'text' => '[accordion_group][accordion title="Service 1"]Aenean a cursus elit. Quisque luctus urna quis diam pretium facilisis. Maecenas ultrices, leo sit amet placerat pulvinar, sapien mauris dictum dui, ac feugiat sapien erat sit amet dui. Sed erat magna, bibendum eu varius quis, vestibulum ac sem. Curabitur aliquam lorem ut dolor convallis, nec ultricies arcu aliquam. Aenean consequat ante sapien, sit amet ultricies diam porta id. Sed tristique urna metus, at pellentesque ipsum aliquam faucibus. Fusce ac aliquam dolor. Aliquam consequat viverra nisl, id pretium ipsum viverra vel. Proin commodo dictum neque. Etiam ac enim ligula. Aliquam in lobortis arcu, nec dignissim libero. Nunc tristique at magna eget tempus. 
[gap height="15"]
Cras dolor justo, vehicula vel dolor vel, porta ornare urna. Aliquam volutpat a sapien non porta. Vestibulum dolor nisi, pellentesque vel orci sed, sollicitudin vulputate ante. Praesent laoreet, massa eget fermentum bibendum, risus leo semper felis, at hendrerit sem odio sit amet lacus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Interdum et malesuada fames ac ante ipsum primis in faucibus. Duis porta volutpat tellus luctus molestie. Morbi nibh massa, pulvinar et magna quis, pellentesque ullamcorper turpis. Vivamus vel sollicitudin eros, id eleifend dui. Mauris augue turpis, dignissim sed urna nec, ullamcorper pretium lorem.  [/accordion]
[accordion title="Service 2"] Fusce scelerisque arcu cursus lorem ullamcorper, consectetur mattis tortor aliquet. Aliquam auctor vel mi sodales molestie. Donec blandit eu risus at varius. Phasellus sit amet lacinia augue, eu bibendum felis. Aliquam vestibulum quam commodo mauris volutpat aliquam. Maecenas tincidunt ultricies massa, eu mattis massa lobortis eu. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc id consectetur massa. Vestibulum odio nulla, imperdiet et mollis at, scelerisque vitae tortor. Vestibulum quis odio augue. Sed in scelerisque nibh, nec ultrices nulla. Aliquam hendrerit massa nisl, eget laoreet turpis sodales aliquet. Maecenas non cursus odio. Donec mi libero, viverra a consectetur ut, consectetur id ligula. Integer libero enim, lobortis sed lorem aliquet, ullamcorper semper felis. Praesent sodales eget risus nec fermentum. 
[gap height="15"]
Praesent a bibendum velit, ac fermentum purus. Quisque ullamcorper metus in leo mattis, pulvinar condimentum velit tempus. Nunc vulputate leo pulvinar purus volutpat malesuada. Vivamus malesuada, dolor vitae molestie vestibulum, sapien leo consectetur leo, quis eleifend mauris est et orci. Sed ultrices eget enim eu pulvinar. Curabitur pharetra felis nec commodo molestie.
[/accordion]
[accordion title="Service 3"]Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.[/accordion]
[accordion title="Service 4"]Nulla vel nisi sit amet tortor ultrices lacinia a non nulla. Proin vulputate lobortis justo vel pharetra. Vestibulum tincidunt libero tortor, a accumsan velit sollicitudin quis. Nunc quis ornare nulla, in fringilla enim. Nam bibendum mollis erat quis ullamcorper. Maecenas facilisis elit sit amet leo varius, at pretium nisi consequat. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur id fermentum dui, ut varius sem. Vivamus ultrices turpis pharetra, varius elit et, interdum lacus. Suspendisse potenti. Aenean mollis, eros vitae vulputate hendrerit, odio enim iaculis ipsum, vitae pharetra diam arcu in velit. Phasellus pretium justo gravida tellus malesuada malesuada quis eget quam. Nulla sed auctor odio. 
[gap height="15"]
Praesent tristique feugiat purus ac tempus. Phasellus gravida, turpis et sodales dictum, magna eros hendrerit odio, ut blandit nunc ligula sed tellus. Donec cursus est in laoreet volutpat. Suspendisse risus neque, ullamcorper eu sapien sit amet, commodo accumsan ante. Donec orci tortor, iaculis sed neque nec, aliquam blandit nibh. Donec sed lobortis ligula. Mauris viverra eros augue, sit amet sodales nulla iaculis et. Vivamus sed blandit ipsum. Etiam sed sem suscipit, lacinia nisl ut, dapibus ligula. 
[/accordion][/accordion_group]',
      'filter' => '',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 9,
        'widget_id' => 'cd6338c7-8319-4760-b4cb-046c091a9cdf',
        'style' => 
        array (
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'background_image_repeat' => '',
        'no_margin' => '',
        'padding_top_gap' => '40px',
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    2 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_repeat' => '',
        'no_margin' => '',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.40131578947368002,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.59868421052632004,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    7 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    8 => 
    array (
      'grid' => 2,
      'weight' => 0.25,
    ),
    9 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'webulous_prebuilt_page_layouts');

/**
 * Configure the SiteOrigin page builder settings.
 * 
 * @param $settings
 * @return mixed
 */
function webulous_panels_settings($settings){   
  $settings['home-page'] = true;
  if( $settings['margin-bottom'] == 35 ) {
    $settings['margin-bottom'] = 35;
  }
  $settings['home-page-default'] = 'default-home';
  $settings['responsive'] = 1; //siteorigin_setting( 'layout_responsive' );
  return $settings;
}
add_filter('siteorigin_panels_settings', 'webulous_panels_settings');

/**
 * Add row styles.
 *
 * @param $styles
 * @return mixed
 */
function webulous_panels_row_styles($styles) {
  $styles['full-width-layout'] = __('Full Width Layout', 'abarispro');
  $styles['wide-grey'] = __('Wide Grey', 'abarispro');
  $styles['custom-width'] = __('Custom Width', 'abarispro');
  return $styles;
}
add_filter('siteorigin_panels_row_styles', 'webulous_panels_row_styles');

function webulous_panels_row_style_fields($fields) {

  $fields['top_border'] = array(
    'name' => __('Top Border Color', 'abarispro'),
    'type' => 'color',
  );

  $fields['bottom_border'] = array(
    'name' => __('Bottom Border Color', 'abarispro'),
    'type' => 'color',
  );

  $fields['background'] = array(
    'name' => __('Background Color', 'abarispro'),
    'type' => 'color',
  );

  $fields['background_image'] = array(
    'name' => __('Background Image', 'abarispro'),
    'type' => 'url',
  );

  $fields['background_image_repeat'] = array(
    'name' => __('Repeat Background Image', 'abarispro'),
    'type' => 'checkbox',
  );

  $fields['no_margin'] = array(
    'name' => __('No Bottom Margin', 'abarispro'),
    'type' => 'checkbox',
  );

  return $fields;
}
add_filter('siteorigin_panels_row_style_fields', 'webulous_panels_row_style_fields');

function webulous_panels_panels_row_style_attributes($attr, $style) {
  $attr['style'] = '';

  if(!empty($style['top_border'])) $attr['style'] .= 'border-top: 1px solid '.$style['top_border'].'; ';
  if(!empty($style['bottom_border'])) $attr['style'] .= 'border-bottom: 1px solid '.$style['bottom_border'].'; ';
  if(!empty($style['background'])) $attr['style'] .= 'background-color: '.$style['background'].'; ';
  if(!empty($style['background_image'])) $attr['style'] .= 'background-image: url('.esc_url($style['background_image']).'); ';
  if(!empty($style['background_image_repeat'])) $attr['style'] .= 'background-repeat: repeat; ';

  if(empty($attr['style'])) unset($attr['style']);
  return $attr;
}
add_filter('siteorigin_panels_row_style_attributes', 'webulous_panels_panels_row_style_attributes', 10, 2);

function webulous_panels_panels_row_attributes($attr, $row) {
  if(!empty($row['style']['no_margin'])) {
    if(empty($attr['style'])) $attr['style'] = '';
    $attr['style'] .= 'margin-bottom: 0px;';
  }

  return $attr;
}
add_filter('siteorigin_panels_row_attributes', 'webulous_panels_panels_row_attributes', 10, 2);


/* widgets bottom margin field  */

add_filter('siteorigin_panels_widget_style_fields','wbls_abaris_panels_widget_style_fields');

if(!function_exists('wbls_abaris_panels_widget_style_fields') ) {

  function wbls_abaris_panels_widget_style_fields($fields) {

    $fields['widget_bottom_margin'] = array(
      'name' => __('Bottom Margin', 'abarispro'),
      'type' => 'measurement',
      'group' => 'layout',
      'description' =>  __('Space below the widget', 'abarispro'),
    );
     return $fields;
  }

}

add_filter('siteorigin_panels_widget_style_attributes','wbls_abaris_panels_panels_widget_style_attributes',10,2);

if(!function_exists('wbls_abaris_panels_panels_widget_style_attributes') ) {
  function wbls_abaris_panels_panels_widget_style_attributes(  $attributes, $args ) {
      if(!empty($args['widget_bottom_margin'])) $attributes['style'] .= 'margin-bottom: '.esc_attr($args['widget_bottom_margin']).'; ';
      return $attributes;
  }
}  

/* Animation row panel */

function wbls_abaris_panels_row_style_fields($fields) {  

    $abaris_animation_name = array(
        '' => __(' --- Default --- ', 'abarispro'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','abarispro' ),
        'bigEntrance-animation' => __('bigEntrance-animation','abarispro' ),
        'boingInUp-animation' => __('boingInUp-animation','abarispro' ),
        'bounce-animation' => __('bounce-animation','abarispro' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','abarispro' ),
        'bounceInRight-animation' => __('bounceInRight-animation','abarispro' ),
        'bounceInUp-animation' => __('bounceInUp-animation','abarispro' ),
        'expandUp-animation' => __('expandUp-animation','abarispro' ),
        'fade-animation' => __('fade-animation','abarispro' ),
        'fadeIn-animation' => __('fadeIn-animation','abarispro' ),
        'fadeInDown-animation' => __('fadeInDown-animation','abarispro' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','abarispro' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','abarispro' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','abarispro' ),
        'fadeInRight-animation' => __('fadeInRight-animation','abarispro' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','abarispro' ),
        'fadeInUp-animation' => __('fadeInUp-animation','abarispro' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','abarispro' ),
        'flip-animation' => __('flip-animation','abarispro' ),
        'flipInX-animation' => __('flipInX-animation','abarispro' ),
        'flipInY-animation' => __('flipInY-animation','abarispro' ),
        'floating-animation' => __('floating-animation','abarispro' ),
        'foolishIn-animation' => __('foolishIn-animation','abarispro' ),
        'hatch-animation' => __('hatch-animation','abarispro' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','abarispro' ),
        'puffIn-animation' => __('puffIn-animation','abarispro' ),
        'pullDown-animation' => __('pullDown-animation','abarispro' ),
        'pullUp-animation' => __('pullUp-animation','abarispro' ),
        'pulse-animation' => __('pulse-animation','abarispro' ),
        'rollInLeft-animation' => __('rollInLeft-animation','abarispro' ),
        'rollInRight-animation' => __('rollInRight-animation','abarispro' ),
        'rotateIn-animation' => __('rotateIn-animation','abarispro' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','abarispro' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','abarispro' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','abarispro' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','abarispro' ),
        'scale-down-animation' => __('scale-down-animation','abarispro' ),
        'scale-up-animation' => __('scale-up-animation','abarispro' ),
        'slide-bottom-animation' => __('slide-bottom-animation','abarispro' ),
        'slide-left-animation' => __('slide-left-animation','abarispro' ),
        'slide-right-animation' => __('slide-right-animation','abarispro' ),
        'slide-top-animation' => __('slide-top-animation','abarispro' ),
        'slideDown-animation' => __('slideDown-animation','abarispro' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','abarispro' ),
        'slideInDown-animation' => __('slideInDown-animation','abarispro' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','abarispro' ),
        'slideInRight-animation' => __('slideInRight-animation','abarispro' ),
        'slideLeft-animation' => __('slideLeft-animation','abarispro' ),
        'slideRight-animation' => __('slideRight-animation','abarispro' ),
        'slideUp-animation' => __('slideUp-animation','abarispro' ),
        'spaceInDown-animation' => __('spaceInDown-animation','abarispro' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','abarispro' ),
        'spaceInRight-animation' => __('spaceInRight-animation','abarispro' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','abarispro' ),
        'stretchLeft-animation' => __('stretchLeft-animation','abarispro' ), 
        'stretchRight-animation'  => __('stretchRight-animation','abarispro' ),
        'swap-animation'  => __('swap-animation','abarispro' ),
        'swashIn-animation'  => __('swashIn-animation','abarispro' ),
        'swing-animation'  => __('swing-animation','abarispro' ),
        'tinDownIn-animation' => __('tinDownIn-animation','abarispro' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','abarispro' ),
        'tinUpIn-animation' => __('tinUpIn-animation','abarispro' ), 
        'tossing-animation'  => __('tossing-animation','abarispro' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','abarispro' ),
        'twisterInUp-animation' => __('twisterInUp-animation','abarispro' ), 
        'wobble-animation' => __('wobble-animation','abarispro' ),
        'zoomIn-animation' => __('zoomIn-animation','abarispro' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'abaris'),
            'type' => 'select',
            'options' => $abaris_animation_name,
            'priority' => 4,
    );

    /* Widgets & Row padding top & bottom field */

    $fields['padding_top_gap'] = array(
      'name' => __('Padding ( Top )', 'abarispro'),
      'type' => 'measurement',
      'group' => 'layout',
      'description' => __('Padding Top Gap', 'abarispro'),
    );
    $fields['padding_bottom_gap'] = array(
      'name' => __('Padding ( Bottom )', 'abarispro'),
      'type' => 'measurement',
      'group' => 'layout',
      'description' => __('Padding Bottom Gap', 'abarispro'),
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_abaris_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_abaris_panels_row_style_fields');

function wbls_abaris_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    
    /* Widgets & Row padding top & bottom field */
      
    if(empty($attributes['style'])) $attributes['style'] = '';

    if(!empty($args['padding_top_gap'])) $attributes['style'] .= 'padding-top: '.esc_attr($args['padding_top_gap']).'; ';
    if(!empty($args['padding_bottom_gap'])) $attributes['style'] .= 'padding-bottom: '.esc_attr($args['padding_bottom_gap']).'; ';

    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_abaris_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_abaris_panels_panels_row_style_attributes', 10, 2);

function wbls_abaris_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Theme & Animation', 'abarispro'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_abaris_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_abaris_row_style_groups' );

