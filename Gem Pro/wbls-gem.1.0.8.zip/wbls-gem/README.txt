=== Webulous Gem Pro ===
Contributors: webulous
Donate link: http://www.webulousthemes.com/
Tags: comments, spam
Requires at least: 4.0.0
Tested up to: 4.7
Stable tag: 1.0.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin converts free version of Gem theme into pro version.

== Description ==

This plugin converts free version of Gem theme into pro version.


== Installation ==

1. Upload `wbls-gem` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. This is a screen shot

== Changelog == 

= 1.0.8 =
* Merge Custom css option to WP option


= 1.0.7 =
* Fix single click demo Bug
* Fix Tracking Code bug
* Compatible with site-origin-widget-bundle

= 1.0.6 =
* Fix header already sent issue

= 1.0.5 =
* Fix Breaking News Bug
* Fix home page option while deactivate

= 1.0.4 =
* Added Magazine homepage option
* Arrage the customizer options
* Added Breaking news option
* Added some customizer Options ( page title bar ) 

= 1.0.3 =
* Fix default value type 
* Added admin notice for license
* Fix portfolio text translatable

= 1.0.2 =
* Fix License activation issue

= 1.0.1 =
* Change to kirki customizer
* Added more options

= 1.0.0 =
* Initial release

== Upgrade Notice ==
= 1.0.8 =
* Merge Custom css option to WP option