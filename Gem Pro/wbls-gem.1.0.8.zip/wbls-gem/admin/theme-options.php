<?php
/**
 * Pro customizer options     
 */

add_action('wbls-gem_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() {       
     
// pro home paeg section 

		Gem_Kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-gem' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-gem'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) );
  
		Gem_Kirki::add_field( 'gem', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-gem' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch', 
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
				'off' => esc_attr__( 'Disable', 'wbls-gem' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-gem'),
			'default'  => 'off',
		) );       
	/*	Gem_Kirki::add_field( 'gem', array(   
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-gem' ),
			'section'  => 'pro_home_section', 
			'type'     => 'select', 
			'choices'  => wbls_get_home_slider_group(),    
			'multiple'    => 1,
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-gem'),
			'active_callback' => array(  
				array(
					'setting'  => 'page-builder',     
					'operator' => '==',
					'value'    => true,  
				),
	        ),	      
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-gem'),
		) ); */       
       Gem_Kirki::add_field( 'gem', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-gem' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-gem'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-gem'),
		) ); 

//  animation section 

Gem_Kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-gem' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-gem'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Gem_Kirki::add_field( 'gem', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-gem' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Gem_Kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-gem' ),
	'description'    => __( 'Custom JS', 'wbls-gem'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Gem_Kirki::add_field( 'gem', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-gem' ),
	'section'  => 'custom_js_section',
    'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ),  
) ); 



// Tracking section 

Gem_Kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-gem' ),
	'description'    => __( 'Tracking Code', 'wbls-gem'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'analytics',
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-gem' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ),
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-gem' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'2' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-gem'),
) );

// color scheme section 

Gem_Kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-gem' ),
	'description'    => __( 'Select your color scheme', 'wbls-gem'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Gem_Kirki::add_field( 'gem', array(
	'settings' => 'color_scheme',
	'label'    => __( 'Select your color scheme', 'wbls-gem' ),
	'section'  => 'multiple_color_section',
	'type'     => 'palette',
	'choices'     => array(
    '1' => array(
		'#e5493a',
	),
	'2' => array(
		'#3183D7',
	),
	'3' => array(
		'#37C6F5',
	),
	'4' => array(
		'#3FC35F',
	),
	'5' => array(
		'#FA5623',
	),
	'6' => array(
		'#F62459',
	),
	'7' => array(
		'#D642DC',
	),
),
'default' => '1',
//'default'  => 'on',
) );

//  social network section //

Gem_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Networks','wbls-gem' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-gem' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-gem'),
) );

// flexslider section //

Gem_Kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-gem' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-gem'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-gem' ),
		'2' => esc_attr__( 'Slide', 'wbls-gem' )
	),
	'default'  => '2',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-gem' ),
		'2' => esc_attr__( 'Vertical', 'wbls-gem' )
	),
	'default'  => '1',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => 'on',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => 'on',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => 'on',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => 'on',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(  
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => 'off',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => 'off',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => 'off',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'off' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-gem' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Gem_Kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-gem' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-gem'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-gem' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'2' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => '2',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-gem' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-gem' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-gem' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'2' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => '2',
) );

//  portfolio settings //

Gem_Kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-gem' ),
) );

$post_per_page = get_option('posts_per_page');
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-gem' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-gem' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-gem' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-gem' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-gem'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-gem' ),
		2 => __( 'Show Without "All"', 'wbls-gem' ),
		3 => __( 'Hide', 'wbls-gem' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Gem_Kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-gem' ),
	'description'    => __( 'Light Box Settings', 'wbls-gem'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-gem' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-gem' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-gem' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-gem' ),
		'4' => esc_attr__( 'light-square', 'wbls-gem' ),
		'5' => esc_attr__( 'dark-square', 'wbls-gem' ),
		'6' => esc_attr__( 'facebook', 'wbls-gem' ),
	),
	'default'  => '1',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-gem' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-gem' ),
		'slow' => esc_attr__( 'Slow', 'wbls-gem' ),
		'normal' => esc_attr__( 'Normal', 'wbls-gem' ),
	),
	'default'  => 'fast',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-gem' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-gem' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'2' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => '2',
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-gem' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-gem'),
) );
Gem_Kirki::add_field( 'gem', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-gem' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-gem' ),
		'2' => esc_attr__( 'Disable', 'wbls-gem' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Gem_Kirki::add_field( 'gem', array(
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-gem' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#E5493A',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => '.site-content .navigation a:hover,
							.site-content .more-link:hover,
							.site-content .comment-navigation a:hover,
							.cnt-form .wpcf7-form input[type="text"]:focus,
							.cnt-form .wpcf7-form input[type="email"]:focus,
							.cnt-form .wpcf7-form input[type="tel"]:focus,
							.cnt-form .wpcf7-form input[type="url"]:focus,
							.cnt-form .wpcf7-form input[type="password"]:focus,
							.cnt-form .wpcf7-form input[type="number"]:focus,
							.cnt-form .wpcf7-form textarea:focus,
							.sidebar .dropcap-book ',
			'property' => 'border-color',
		),
		array(
			'element'  => '.main-navigation a:hover:after,
						    .main-navigation a:hover:after,
						    .main-navigation .current_page_item > a:after,
						    .main-navigation .current-menu-item > a:after,
						    .main-navigation .current-menu-parent > a:after,
						    .main-navigation .current_page_ancestor > a:after,
						    .main-navigation .current_page_parent > a:after,
						    .site-header .branding .site-branding:after,
						    .widget_calendar table caption:after,
						    .tabs ul li a:hover:before,
			        		.tabs ul li a.tabulous_active:before,   
			        		.tabs.normal ul li a:hover:before,
			        		.tabs.normal ul li a.tabulous_active:before,
			        		.widget.widget_skill-widget .skill-container .skill .skill-percentage:after,
			        		#filters ul.filter-options li a:before,
			        		a.btn:after,
			  				.widget_button-widget .btn:after,
			  				a.btn-mini:after,
			  				.widget_button-widget .btn.mini:after,
			  				a.btn.btn-small:after,
			  				.widget_button-widget .btn.small:after,
			  				a.btn-large:after,
			  				.widget_button-widget .btn.large:after,
			  				.callout-widget .call-btn a:hover:after,
			  				.wide-dark-grey .callout-widget p.call-btn a:after,.widget_magazine-post-boxed-widget .entry-content .cat-links a:after,.widget_magazine-post-boxed-widget .mag-divider:after,.mag-divider::after',
			'property' => 'border-left-color',
		),
		array(
			'element'  => ' .widget_calendar table caption:before,
						    a.btn:before,
			  				.widget_button-widget .btn:before,
			  				a.btn-mini:before,
			  				.widget_button-widget .btn.mini:before,
			  				a.btn.btn-small:before,
			  				.widget_button-widget .btn.small:before,
			  				a.btn-large:before,
			  				.widget_button-widget .btn.large:before,
			  				.callout-widget .call-btn a:hover:before,
			  				.wide-dark-grey .callout-widget p.call-btn a:before',
			'property' => 'border-right-color',
		),
		array(
			'element'  => '.site-header .social ul#social-widget li a:hover:after,
			  				.header-wrap .social ul li a:hover:after,
			  				.header-wrap .site-header .social ul#social-widget li a:hover:after,
			          		.header-wrap .site-header .social ul.social-widget li a:hover:after,
			          		.home .site-content #primary .post-wrapper-head h2:before,
			          		.widget_social-networks-widget ul li a:hover:after,
			          		.site-header .social .widget_social-networks-widget ul li a:hover:after, 
			          		.site-footer .footer-widgets .widget-title:before,
			          		.hr_fancy:before, .sep:before,
							.sep.tleft:before, h3.widget-title:before,.header-wrap .site-header .social ul#social-widget li a:hover::after, .header-wrap .site-header .social ul.social-widget li a:hover::after, .social ul li a:hover::after, .branding .social .widget_social-networks-widget ul li a:hover::after',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '.home .site-content #primary .post-wrapper-head h2:before,
			  				.site-footer .footer-widgets .widget-title:before,
			  				.hr_fancy:before, .sep:before,
							.sep.tleft:before, h3.widget-title:before,
							.wide-cta:before,.widget_magazine-post-boxed-widget h3.widget-title',
			'property' => 'border-bottom-color',
		),
		array(
			'element'  => 'a:hover,
							a:focus,
							a:active,
					      	.site-header .social ul a:hover,
					      	.header-wrap .site-header .social ul a:hover,
							#recentcomments a,
							.comment-list > li article .comment-meta .comment-author b,
							.comment-list > li article .comment-meta .comment-author a,
							.comment-list > li article .comment-meta .comment-author cite,
							.comment-list > li article .reply i,
							#primary .entry-title a:hover,
							.breadcrumb-wrap .six.breadcrumb a:hover,
							.breadcrumb-wrap .six.breadcrumb a:focus,
							.latest-post-content h1 a:hover,
							.latest-post-content h2 a:hover,
							.latest-post-content h3 a:hover,
							.latest-post-content h4 a:hover,
							.latest-post-content h5 a:hover,
							.latest-post-content h6 a:hover,
							.latest-post-content a.btn-readmore:hover,
							.related-posts ul#webulous-related-posts li a:hover,
							.widget-area .left-sidebar ul a:hover,
							.site-footer .footer-widgets a:hover,
							.site-footer .footer-widgets .widget_calendar table td a,
							.site-footer .footer-widgets #recentcomments a,
							.site-footer .footer-widgets .widget_tag_cloud a:hover,
							.site-footer .footer-widgets .widget_rss ul a,
							.site-footer .footer-widgets button:hover,
						    .site-footer .footer-widgets input[type="button"]:hover,
						    .site-footer .footer-widgets input[type="reset"]:hover,
						    .site-footer .footer-widgets input[type="submit"]:hover,
						    .copyright a,
						    .copyright ul.menu li.current_page_item a,     
			    			.copyright ul.menu a:hover,
			    			.widget.widget_ourteam-widget .team-content h4,
			    			.widget.widget_ourteam-widget:hover .team-social ul li a,
			    			.widget_recent-posts-widget .recent-post .readmore a:hover,
			    			.portfolioeffects:hover .portfolio_overlay p a:hover,
			    			.alert-message a:hover,
							.dropcap.dropcap-default,
							.circle-icon-box:hover h4,
							.widget_testimonial-widget ul li .client strong,
							.siteorigin-panels-stretch .widget_testimonial-widget ul li .client,
							.single-portfolio .one-third dd a,
							.content-area .widget_list-widget ul li i,
							.content-area .widget_list-widget ol li i,
							.site-footer .callout-widget .call-btn a,
							.site-footer .widget_list-widget ul li i,
							.sidebar .dropcap,
							.sidebar .icon-horizontal .icon-title,
							.sidebar .icon-vertical .icon-title,
							.sidebar .widget_list-widget ul li i,
							#secondary.sidebar .widget.widget_ourteam-widget .team-content p,
							#secondary.sidebar .widget.widget_ourteam-widget .team-content h4 span,
							.breadcrumb-wrap .breadcrumb a i:before,
							.order-total .amount,.woocommerce #content table.cart a.remove,
							.woocommerce table.cart a.remove,
							.woocommerce-page #content table.cart a.remove,
							.woocommerce-page table.cart a.remove,
			                .cart-subtotal .amount,
			                .woocommerce .woocommerce-breadcrumb a:hover,
			                 .woocommerce-page .woocommerce-breadcrumb a:hover,
							.page-template-portfolio-2col_text .portfolio-excerpt h3 a:hover,
							.page-template-portfolio-2col_text .portfolio-excerpt h3 a:visited:hover,
							.page-template-portfolio-3col_text .portfolio-excerpt h3 a:hover,
							.page-template-portfolio-3col_text .portfolio-excerpt h3 a:visited:hover,
							.page-template-portfolio-4col_text .portfolio-excerpt h3 a:hover,
							.page-template-portfolio-4col_text .portfolio-excerpt h3 a:visited:hover,.site-footer .footer-bottom ul.menu li a:hover,
							.site-footer .footer-bottom ul.menu li.current_page_item a,
							.site-footer .widget_social-networks-widget ul li a:hover,
							.widget_magazine-featured-slider-widget .magazine-featured-slider-wrapper .flexslider .slides .flex-caption a:hover,.widget_magazine-highlighted-post-widget .single-highlited-post .highlights-content .magazine-slider-top-meta a:hover,#primary .widget_magazine-highlighted-post-widget .single-highlited-post .entry-title a:hover,#secondary .footer-widgets h1 a:hover,.site-footer .footer-widgets h1:hover,
							.breaknews .breaknews-wrapper ul .bn-content a:hover',
			'property' => 'color',
		),
		array(
			'element'  => 'th a,
							.site-header .social .recentcomments a,
							.header-wrap .site-header .social .recentcomments a,
							.left-sidebar .recentcomments a,
							.left-sidebar .widget_rss a,
							.ei-title h3,
							#secondary .btn-white:hover,
			  				#secondary .widget_button-widget .btn.white:hover',
			'property' => 'color',
			'suffix' => '!important',
		),
		array(
			'element'  => 'button,
							input[type="button"],
							input[type="reset"],
							input[type="submit"],
							.footer-widgets .textwidget .wpcf7-form input.wpcf7-submit,
							.main-navigation a:hover,
							.main-navigation .current_page_item > a,
							.main-navigation .current-menu-item > a,
							.main-navigation .current-menu-parent > a,
							.main-navigation .current_page_ancestor > a,
							.main-navigation .current_page_parent > a,
							.main-navigation .current_page_item a,
							.main-navigation .current-menu-item a,
							.main-navigation .current-menu-parent > a,
							.main-navigation .current_page_parent > a,
							.slicknav_menu .slicknav_btn,
							.slicknav_nav a.slicknav_row:hover,
			    			.slicknav_nav a:hover,
			    			.slicknav_nav .current_page_item a,
			    			.site-content .more-link,
			    			.site-content .page-links a:hover,
			    			.webulous_page_navi li a:hover,
			    			.webulous_page_navi li.bpn-next-link a:hover,
			    			.webulous_page_navi li.bpn-prev-link a:hover,
			    			.webulous_page_navi li.bpn-current,
			    			.site-header .branding .site-branding,
			    			.site-header .branding .site-branding:before,
			    			.site-header .social ul#social-widget li a:hover,
			    			.header-wrap .social ul li a:hover,
			    			.header-wrap .site-header .social ul#social-widget li a:hover,
			        		.header-wrap .site-header .social ul.social-widget li a:hover,
			        		.home .flexslider .slides .flex-caption a,
			    			.home .flexslider .slides .flex-caption p a,
			    			.home .site-content #primary .post-wrapper-head h2:after,
			    			.share-box ul li a:hover,
							.widget_calendar table #today,
							.widget_calendar table caption,
							.widget_tag_cloud a:hover,
							.widget_social-networks-widget ul li a:hover,
						    .site-header .social .widget_social-networks-widget ul li a:hover,
						    .site-footer .widget_social-networks-widget ul li a,
							.site-footer .footer-widgets .widget-title:after,
							.widget.widget_ourteam-widget .team-content h4:after,
							.widget.widget_ourteam-widget:hover,
							.widget.widget_skill-widget .skill-container .skill .skill-percentage span,
							.ui-accordion .ui-accordion-header-active,
							.ui-accordion .ui-accordion-header:hover,
							.widget_recent-work-widget .recent_work_overlay .icon-link,
			  				.widget_recent-work-widget .recent_work_overlay .icon-zoom,
			  				.widget_recent-work-widget .portfolio4col:hover .overlay_icon a:hover,
			  				#filters ul.filter-options li a,
			  				.recent-work-container .work:hover .recent_work_overlay a:hover,
			  				.portfolioeffects:hover .portfolio_link_icons a:hover,
			  				.flexslider .slides .flex-caption a,
			    			.flexslider .slides .flex-caption p a,
			    			.widget_recent-work-widget ul.flex-direction-nav a,
			    			.widget_recent-posts-widget .recent-posts-carousel ul.flex-direction-nav a,
			    			.recent-posts-slider .flex-direction-nav a,
			    			.widget_recent-posts-widget .recent-posts-carousel .flex-control-nav li a.flex-active,
			    			.recent-posts-slider .flex-control-paging li a.flex-active,
			    			.flex-control-nav li a.flex-active,
			    			.widget_flexslider-widget .flexcarousel .flex-direction-nav a:hover,
			    			.widget .ei-slider-thumbs li.ei-slider-element,
							ul.ei-slider-thumbs li.ei-slider-element,
							.hr_default,
							.hr_solid,
							a.btn,
							.widget_button-widget .btn,
							.dropcap-circle,
							.dropcap-box,
							.dropcap-book,
							.hr_fancy:after, .sep:after,
							.sep.tleft:after, h3.widget-title:after,
							.pullnone,
							.pullnone .quote-simple,
							.pullleft,
							.pullright,
							.pullleft .quote-simple,
			  				.pullright .quote-simple,
			  				.toggle .toggle-title,
			  				.circle-icon-box .icon-wrapper,
			  				.icon-right .icon-wrapper,
							.icon-left .icon-wrapper,
							.callout-widget .call-btn a:hover,
							.wide-cta,
							.wide-dark-grey .callout-widget p.call-btn a,
							.widget_wbls-image-widget i,
							.widget_stat-widget .stats-icon-wrap,
							.our-services .textwidget:after,
							.flex-slider-title h3.widget-title:after,
							.not-found-inner,
							.cnt-form .wpcf7-form input[type="submit"],
							.wide-cta,.widget.widget_ourteam-widget .our-team:hover,
							.wide-default,
							#secondary.sidebar .callout-widget,
							.sidebar .dropcap-circle,
							.sidebar .dropcap-box,
							.sidebar .icon-horizontal .fa-stack,.woocommerce #content div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce-page div.product .woocommerce-tabs ul.tabs li a:hover,
							.woocommerce #content div.product .woocommerce-tabs ul.tabs li.active,
							.woocommerce div.product .woocommerce-tabs ul.tabs li.active,
							.woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active,
							.woocommerce-page div.product .woocommerce-tabs ul.tabs li.active,
							.sidebar .icon-vertical .fa-stack,.woocommerce #content nav.woocommerce-pagination ul li a:focus,
							.woocommerce #content nav.woocommerce-pagination ul li a:hover,
							.woocommerce #content nav.woocommerce-pagination ul li span.current,
							.woocommerce nav.woocommerce-pagination ul li a:focus,
							.woocommerce nav.woocommerce-pagination ul li a:hover,
							.woocommerce nav.woocommerce-pagination ul li span.current,
							.woocommerce-page #content nav.woocommerce-pagination ul li a:focus,
							.woocommerce-page #content nav.woocommerce-pagination ul li a:hover,
							.woocommerce-page #content nav.woocommerce-pagination ul li span.current,
							.woocommerce-page nav.woocommerce-pagination ul li a:focus,
							.woocommerce-page nav.woocommerce-pagination ul li a:hover,
							.woocommerce-page nav.woocommerce-pagination ul li span.current,
							#secondary.sidebar .widget_testimonial-widget .testimonial-container .testimonials,
							.circle-icon-box .circle-icon-wrapper,.woocommerce a.remove,.widget_ourteam-widget:hover .our-team,.portfolioeffects .portfolio_overlay,.search-form input.search-submit,.widget_magazine-post-boxed-widget .entry-content .cat-links a,.widget_magazine-post-boxed-widget .mag-divider,.mag-divider',
			'property' => 'background-color',
		),
		array(
			'element'  => '.main-navigation .sub-menu .current_page_item > a,   	
				            .main-navigation .sub-menu .current-menu-item > a,
							.main-navigation .sub-menu .current_page_ancestor > a,
							.site-content .comment-navigation a:hover,
							#primary .sticky,
							.entry-content blockquote:after,
							.site-main .search-form input.search-submit,
							.site-footer .scroll-to-top,
							.tabs ul li a.tabulous_active,
							.tabs ul li a:hover,
							.tabs.normal ul li a.tabulous_active,
							.tabs.normal ul li a:hover,
							.widget.widget_ourteam-widget ul.team-social li a:hover,.woocommerce #content input.button:hover,
							.woocommerce #respond input#submit:hover,.woocommerce a.button:hover,
							.woocommerce button.button:hover,
							.woocommerce input.button:hover,
							.woocommerce-page #content input.button:hover,.woocommerce-page a.button:hover,
							.woocommerce-page #respond input#submit:hover,
							.woocommerce-page button.button:hover,
							.woocommerce-page input.button:hover,.dropcap-book',
			'property' => 'background-color',
			'suffix' => '!important',
		),
	),
) );

Gem_Kirki::add_field( 'gem', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-gem' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#222222',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.site-content .navigation a,
							.site-content .more-link,
							.site-content .comment-navigation a,
							.webulous_page_navi li.bpn-current,
							.header-wrap .social ul li a,
							.comment-list > li article .comment-meta .comment-author b:hover,
							.comment-list > li article .comment-meta .comment-author a:hover,
							.comment-list > li article .comment-meta .comment-author cite:hover,
							.comment-list > li article .reply:hover i,
							#primary .sticky .entry-meta a,
					  		#primary .sticky .entry-footer a,
					  		.latest-post-content a.btn-readmore,
					  		.related-posts ul#webulous-related-posts li:hover a,
					  		.site-footer .footer-widgets .widget_archive select,
						    .site-footer .footer-widgets .widget_categories select,
						    .site-footer .footer-widgets .textwidget select,
						    .widget.widget_ourteam-widget .team-content h4 span,
						    .widget_recent-posts-widget .recent-post .readmore a,
						    .alert-message a,
						    .icon-right .icon-title,
							.icon-left .icon-title,
							.icon-right a.link-title,
							.icon-right .icon-title,
							.icon-right .fa-stack,
							.icon-left a.link-title,
							.icon-left .icon-title,
							.icon-left .fa-stack,
							.widget_testimonial-widget ul li .client,
							.single-portfolio .one-third dd a:hover,
							.gem-process.white-bg,
			  				.gem-process.white-bg h3.widget-title,
			  				.gem-process.white-bg .textwidget h4,
			  				.not-found-inner a:hover,
			  				.cnt-address .widget_text p:nth-of-type(1),
							.cnt-address .textwidget p:nth-of-type(1),
							#secondary.sidebar .widget_testimonial-widget h3',
			'property' => 'color',
		),
		array(
			'element' => 'table tr th:hover a,
			  				.site-header .social .recentcomments a:hover	
							.header-wrap .site-header .social .recentcomments a:hover,
							#primary .sticky a:hover,
							#primary .sticky span:hover,
							#primary .sticky time:hover,
							.left-sidebar .recentcomments a:hover,
							.left-sidebar .widget_rss a:hover,
							.wide-cta .call-btn a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),
		array(
			'element' => 'button:hover,
							input[type="button"]:hover,
							input[type="reset"]:hover,
							input[type="submit"]:hover,
							.footer-widgets .textwidget .wpcf7-form input.wpcf7-submit:hover,
							#nav-wrap,
							.main-navigation ul ul li,
							.site-content .more-link:hover,
							.webulous_page_navi li a,
							.webulous_page_navi li.bpn-next-link a,
			  				.webulous_page_navi li.bpn-prev-link a,
			  				.home .flexslider .slides .flex-caption a:hover,
			      			.home .flexslider .slides .flex-caption p a:hover,
			      			.home .flexslider .flex-control-paging li a,
			      			.share-box ul li a,
			      			.site-footer .widget_social-networks-widget ul li a:hover,
			      			#secondary select,
							.footer-widgets select,
							.widget.widget_ourteam-widget ul.team-social li a,
							.widget.widget_ourteam-widget:hover .team-social ul li a:hover,
							.widget.widget_skill-widget .skill-container .skill .skill-percentage,
							.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link,
							.widget_recent-work-widget .portfolio4col .overlay_icon a,
							#filters ul.filter-options li a:hover,
						    #filters ul.filter-options li a.selected,
						    .recent-work-container .recent_work_overlay a.icon-zoom,
						    .portfolioeffects .portfolio_link_icons a,
						    .flexslider .slides .flex-caption a:hover,
			      			.flexslider .slides .flex-caption p a:hover,
			      			.flexslider .flex-control-paging li a,
			      			.widget_recent-work-widget ul.flex-direction-nav a:hover,
			      			.widget_recent-posts-widget .recent-posts-carousel ul.flex-direction-nav a:hover,
			      			.recent-posts-slider .flex-direction-nav a:hover,
			      			.widget_recent-posts-widget .recent-posts-carousel .flex-control-nav li a,
			      			.recent-posts-slider .flex-control-paging li a,
			      			.flex-control-nav li a,
			      			.wide-default .widget_flexslider-widget .flexcarousel .flex-direction-nav a:hover,
			      			.page-slider ul.ei-slider-thumbs li a,
			      			a.btn-white:hover,
			  				.widget_button-widget .btn.white:hover,
			  				.toggle .toggle-title:hover,
			  				.circle-icon-box:hover .circle-icon-wrapper,
			  				.callout-widget .call-btn a,
			  				.wide-dark-grey .callout-widget p.call-btn a:hover,
			  				.widget_wbls-image-widget .image-widget-overlay:hover i:hover,
			  				.error-404.not-found .page-header,
			  				.cnt-form .wpcf7-form input[type="submit"]:hover,
			  				.site-footer .widget_social-networks-widget ul li a,
			  				#secondary.sidebar .callout-widget p.call-btn a:hover',
			'property' => 'background-color',
		),
        array(
			'element' => '.slicknav_menu,
				          .search-form input.search-submit:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),
		array(
			'element' => '.page-numbers,
				         .gem-process.white-bg .textwidget img',  
			'property' => 'border-color',
		),
		array(
			'element' => '.site-content .nav-next a span,
							.withtip.left:after,
							.home .flexslider .slides .flex-caption a:after,
			      			.home .flexslider .slides .flex-caption p a:after,
			      			.home .flexslider .flex-direction-nav .flex-nav-next a,
			      			#filters ul.filter-options li a:hover:before,
			        		#filters ul.filter-options li a.selected:before,
			        		.flexslider .slides .flex-caption a:after,
			      			.flexslider .slides .flex-caption p a:after,
			      			.flexslider .flex-direction-nav .flex-nav-next a,
			      			.widget_button-widget .btn.white:hover:after,
			      			.callout-widget .call-btn a:after,
			      			.wide-dark-grey .callout-widget p.call-btn a:hover:after,
			      			.widget_testimonial-widget .flex-direction-nav a.flex-next:hover',
			'property' => 'border-left-color',
		),
		array(
			'element' => 'abbr,acronym,.withtip.bottom:after',
			'property' => 'border-bottom-color',
		),
        array(
			'element' => '.withtip.right:after,.page-numbers:last-child,
			      			.site-content .nav-previous a span,
			      			.home .flexslider .flex-direction-nav .flex-nav-prev a,
			      			.flexslider .flex-direction-nav .flex-nav-prev a,
			      			a.btn-white:hover:before,
			    			.widget_button-widget .btn.white:hover:before,
			    			.callout-widget .call-btn a:before,
			    			.wide-dark-grey .callout-widget p.call-btn a:hover:before,
			    			.widget_testimonial-widget .flex-direction-nav a.flex-prev:hover',
			'property' => 'border-right-color',
		),
        array(
			'element' => '.widget_recent-work-widget .work:hover .recent_work_overlay .icon-link:after',
			'property' => 'border-top-color',
		),
		array(
			'element' => '.site-footer .widget_social-networks-widget ul li a:after',
			'property' => 'border-top-color',
			'suffix' => '!important',
		),
		
	),
) );
}

