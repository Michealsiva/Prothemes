<div class="services-wrapper clearfix">
     <div class="service">
        <div class="service-featured">
	    	<?php if( has_post_thumbnail() ) : ?>
                <a href="<?php echo esc_url( get_permalink() ); ?>"><div class="overlay2"></div>                                                      <?php the_post_thumbnail('wbls-gem_service-img'); ?></a>
	    	<?php endif; ?>
    	</div>
    	<div class="service-content">
    	    <?php the_title( sprintf( '<h5><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h5>' ); ?>
	    	<?php the_content( __( 'Read More', 'wbls-gem' ) ); ?>
    	</div>
    </div>
</div>

