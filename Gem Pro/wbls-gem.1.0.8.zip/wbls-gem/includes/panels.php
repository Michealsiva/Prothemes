<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 *
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts
 *
 * Adds default page layouts to SiteOrigin Page Builder prebuilt layout section
 *
 * @param $layouts 
 */
if ( ! class_exists('Wbls_Prebuilt_Layouts')) {

    class Wbls_Prebuilt_Layouts {
        public function layouts($layouts) {     
           $layouts['default-home'] = array (
                'name' => __('Default Home', 'wbls-gem'),
                'description' => __('Pre Built Layout for  home page', 'wbls-gem'),
                'widgets' =>  array(  
                   0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '1',
            'type' => 'separator',
            'content' => 'Theme Features',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Responsive Layout',
            'text' => 'Gem is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
            'icon' => 'fa-mobile-phone',
            'icon_background_color' => '',
            'icon_size' => '4x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Awesome Slider',
            'text' => 'Gem includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
            'icon' => 'fa-random',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Font Awesome',
            'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
            'icon' => 'fa-flag',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'content-center',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '57610ac903ee0',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '1',
            'type' => 'separator',
            'content' => 'Meet the Gem
',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'JAMES HARRISON',
            'designation' => 'CEO & Founder',
            'image_url' => 'http://gem.webulous.in/wp-content/uploads/2016/02/250.png',
            'linkedin' => 'www.linked.in.com',
            'google' => 'www.googleplus.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'MARTHA PARKER',
            'designation' => 'Senior Manager',
            'image_url' => 'http://gem.webulous.in/wp-content/uploads/2016/02/250-2.png',
            'linkedin' => 'www.linked.in.com',
            'google' => 'www.googleplus.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'MARK SHAEFFER',
            'designation' => 'Web Designer',
            'image_url' => 'http://gem.webulous.in/wp-content/uploads/2016/02/250-4.png',
            'linkedin' => 'www.linked.in.com',
            'google' => 'www.googleplus.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'CLARA DOE',
            'designation' => 'Customer Relations',
            'image_url' => 'http://gem.webulous.in/wp-content/uploads/2016/02/250-5-1.png',
            'linkedin' => 'www.linked.in.com',
            'google' => 'www.googleplus.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'content-center',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'background_image' => '',
              'bottom_border' => '',
              'background' => '',
              'top_border' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '57610ac903f49',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'cover',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Why Choose Us',
      'text' => '<img src="http://gem.webulous.in/wp-content/uploads/2016/02/why-choose-us.png" />

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and 

<a href="#" class="btn btn-black btn-small">Read More</a>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Skills',
      'panels_info' => 
      array (
        'class' => 'Wbls_Skill_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'src' => 'http://gem.webulous.in/wp-content/uploads/2016/02/Home-2_03.png',
      'href' => 'http://gem.webulous.in/wp-content/uploads/2016/02/Home-2_03.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 4,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => '',
      'text' => '<h2>Theme Looks Good On</h2>
<h5>Different types of Devices</h5>

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.

<a class="btn red large" target="_self" href="http://webulousthemes.com/">Buy Now</a> <a class="btn black large" target="_self" href="http://webulousthemes.com/">Purchase Now</a>',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 5,
        'style' => 
        array (
          'class' => 'top-features',
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Our Tabs',
      'text' => '[tabs_group type="normal"][tabs title="Web Development"]Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.[/tabs][tabs title="Designs"]It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English.[/tabs][tabs title="Photography"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae,  Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/tabs][/tabs_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 6,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Accordion',
      'text' => '[accordion_group][accordion title="Awesome Design"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est.[/accordion][accordion title="Improved Documentation"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae,  Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/accordion][accordion title="Clean Coded"]senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/accordion][/accordion_group]',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 7,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'Recent Projects',
      'panels_info' => 
      array (
        'class' => 'Wbls_Heading_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 8,
        'style' => 
        array (
          'class' => 'content-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Recent Work',
      'count' => '12',
      'type' => 'isotope',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Work_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 9,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Testimonials',
      'count' => '4',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 10,
        'style' => 
        array (
          'class' => 'fadeInUpBig-animation',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'Latest Blog Posts',
      'panels_info' => 
      array (
        'class' => 'Wbls_Heading_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 11,
        'style' => 
        array (
          'class' => 'content-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => '',
      'count' => '6',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_Recent_Posts_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 12,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'content' => 'Duis aliquam velit velit, quis consequat lectus vehicula eget. Mauris quis sem a odio pellentesque facilisis eu nec erat. Vestibulum semper mi ut erat euismod tristique',
      'title' => 'Webulous Themes',
      'url' => 'http://webulousthemes.com/',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 13,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'slider' => 'home-clients',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 9,
        'cell' => 0,
        'id' => 14,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'aboutus',
        'background_display' => 'tile',
        'animation_class' => 'fadeInUpBig-animation',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_image_attachment' => false,
        'background_display' => 'cover',
        'animation_class' => 'fadeInUpBig-animation',
      ),
    ),
    2 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'wide-pattern animation-row4',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'animation_class' => 'fadeInUpBig-animation',
      ),
    ),
    3 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'animation_class' => 'fadeInUpBig-animation',
      ),
    ),
    4 => 
    array (
      'cells' => 2,
      'style' => 
      array (
        'class' => 'animation-row6',
        'background_display' => 'tile',
        'animation_class' => 'flipInX-animation',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-grey',
        'bottom_margin' => '0px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'animation_class' => 'fadeInUpBig-animation',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'row_stretch' => 'full',
        'background_image_attachment' => 548,
        'background_display' => 'cover',
        'animation_class' => 'fadeInUpBig-animation',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'padding' => '0px',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'animation_class' => 'fadeInUpBig-animation',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta',
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'animation_class' => 'fadeInUpBig-animation',
      ),
    ),
    9 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_image_attachment' => false,
        'background_display' => 'tile',
        'animation_class' => 'fadeInUpBig-animation',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 0.5,
    ),
    4 => 
    array (
      'grid' => 3,
      'weight' => 0.5,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 0.5,
    ),
    6 => 
    array (
      'grid' => 4,
      'weight' => 0.5,
    ),
    7 => 
    array (
      'grid' => 4,
      'weight' => 0.5,
    ),
    8 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    11 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
    12 => 
    array (
      'grid' => 9,
      'weight' => 1,
    ),
                ),
            );

            $layouts['about-us'] = array(
                'name' => __('About Us', 'wbls-gem'),
                'description' => __( 'Pre Built layout for about us page', 'wbls-gem'),
                'widgets' => array(
                     0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '1',
            'type' => 'separator',
            'content' => 'About Our Company',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://gem.webulous.in/wp-content/uploads/2016/03/about.png',
            'href' => 'http://gem.webulous.in/wp-content/uploads/2016/03/about.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '',
            'list' => '*Sed suscipit nibh at lectus egestas aliquet.
*Nam et leo rhoncus nisl pulvinar blandit ac id augue.
*Fusce ultricies augue a turpis ultricies pulvinar.',
            'icon' => 'fa-check',
            'color' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_List_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '',
            'text' => '<a class="btn red btn-normal" target="_self" href="http://webulousthemes.com/">Buy Now</a> ',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 4,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => 'content-center',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '56e6b3d616790',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '620',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => '621',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => '622',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => '623',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 3,
        'id' => 4,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '1',
            'type' => 'separator',
            'content' => 'Meet the Gem',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'content-center',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => ' JAMES HARRISON',
            'designation' => 'CEO & Founder',
            'image_url' => 'http://gem.webulous.in/wp-content/uploads/2016/02/250-4.png',
            'linkedin' => 'www.likedln.com',
            'google' => 'www.google.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex. Nam aliquet ultrices porta.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'MARTHA PARKER',
            'designation' => 'Senior Manager',
            'image_url' => 'http://gem.webulous.in/wp-content/uploads/2016/02/250-5-1.png',
            'linkedin' => 'www.likedln.com',
            'google' => 'www.google.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex. Nam aliquet ultrices porta.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'MARK SHAEFFER',
            'designation' => 'Web Designer',
            'image_url' => 'http://gem.webulous.in/wp-content/uploads/2016/02/250-4.png',
            'linkedin' => 'www.likedln.com',
            'google' => 'www.google.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex. Nam aliquet ultrices porta.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'CLARA DOE',
            'designation' => 'Customer Relations',
            'image_url' => 'http://gem.webulous.in/wp-content/uploads/2016/02/250-5-1.png',
            'linkedin' => 'www.likedln.com',
            'google' => 'www.google.com',
            'twitter' => 'www.twitter.com',
            'facebook' => 'www.facebook.com',
            'content' => 'Mauris vulputate semper consequat. Praesent viverra neque maximus fermentum arcu sed ultrices ex. Nam aliquet ultrices porta.',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '56e6b41306b14',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 2,
        'cell' => 0,
        'id' => 5,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Testimonials',
      'count' => '4',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 6,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet consectetur adipiscing elit. Morbi viverra tempus ullamcorpe. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 7,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_display' => 'cover',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),   
                ),
            );

            $layouts['features'] = array(
                'name' => __('Features Page', 'wbls-gem'),
                'description' => __( 'Pre Built layout for features page', 'wbls-gem'),
                'widgets' => array(
                           0 => 
    array (
      'title' => 'Responsive Layout',
      'text' => 'Gem is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Awesome Slider',
      'text' => 'Gem includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 1,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Font Awesome',
      'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 2,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Typography',
      'text' => 'Gem loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
      'icon' => 'fa-font',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Retina Ready',
      'text' => 'Gem is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 4,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Excellent Support',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
      'icon' => 'fa-support',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 5,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 6,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'title' => 'Customization',
      'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
      'icon' => 'fa-cog',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Page Builder',
      'text' => 'Gem supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 1,
        'id' => 8,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Page Layout',
      'text' => 'Gem offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 2,
        'id' => 9,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Custom Widget',
      'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
      'icon' => 'fa-beer',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 10,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Shortcode Builder',
      'text' => 'Gem includes lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
      'icon' => 'fa-check',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 11,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Demo Content',
      'text' => 'Gem includes demo content files. You can quickly setup the site like our demo and get started easily!',
      'icon' => 'fa-close',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 12,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 13,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'title' => 'Woo Commerce  ',
      'text' => 'Gem has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!',
      'icon' => 'fa-beer',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 14,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'title' => 'Testimonials',
      'text' => 'With our testimonial post type, shortcode and widget, Displaying testimonials is a breeze.',
      'icon' => 'fa-rocket',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 1,
        'id' => 15,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => 'Social Media',
      'text' => 'Want your users to stay in touch? No problem, Gem has Social Media icons all throughout the theme!',
      'icon' => 'fa-skype',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 2,
        'id' => 16,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'title' => 'Google Map',
      'text' => 'Gem includes Google Map as shortcode and widget. So, you can use it anywhere in your site!',
      'icon' => 'fa-map-marker',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'grid' => 7,
        'cell' => 0,
        'id' => 17,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
    18 => 
    array (
      'title' => ' Multiple Portfolio',
      'text' => '7 portfolio layouts, 3 blog layouts and multiple other alternate layouts for interior pages!',
      'icon' => 'fa-list-alt',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 18,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'title' => 'Multiple Sidebar',
      'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
      'icon' => 'fa-copy',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 2,
        'id' => 19,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    4 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta',
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    7 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    1 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 0,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    8 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    9 => 
    array (
      'grid' => 3,
      'weight' => 0.33333333333333331,
    ),
    10 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    11 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    12 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    13 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    14 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    15 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    16 => 
    array (
      'grid' => 6,
      'weight' => 0.33333333333333331,
    ),
    17 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    18 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    19 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
                ),
            );

            $layouts['contact-us'] = array(
                'name' => __('Contact Us Page', 'wbls-gem'),
                'description' => __( 'Pre Built layout for contact us page', 'wbls-gem'),
                'widgets' => array(
                        0 => 
    array (
      'title' => '',
      'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387145.86626889417!2d-74.2581879779189!3d40.70531105474913!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sin!4v1454914074669" width="1200" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>',
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'filter' => false,
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Company Information',
            'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.

<span>[icon icon="fa-map-marker" size="" style=""]  <b>Address</b></span>  Sunrise Street, 243 Avenue, Manhattan, NV City, NY

<span>[icon icon="fa-phone" size="" style=""]  <b>Phone Number</b></span>  (012)-345-6789 - (012)-345-6789

<span>[icon icon="fa-envelope" size="" style=""]  <b>Email</b></span>  <a href="mailto:information@domain.com">information@domain.com</a>




',
            'filter' => 'on',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Social_Networks_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Get in Touch',
            'text' => 'Cras sodales nisi at ultrices malesuada. Donec sodales mattis cursus. Nam feugiat feugiat felis sit amet tincidunt. 
[contact-form-7 id="410" title="Contact form 1"]',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => 'cnt-form',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.40008044410055998,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.59991955589944002,
          ),
        ),
      ),
      'builder_id' => '56b59c12ae715',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'class' => 'cnt-address',
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
                ),
            );

            $layouts['faq'] = array (
                'name' => __('Faq Page', 'wbls-gem'),
                'description' => __('Pre Built Layout for default faq page', 'wbls-gem'),
                'widgets' =>  array(
                    0 => 
    array (
      'level' => '1',
      'type' => 'separator',
      'content' => 'Faq\'s',
      'panels_info' => 
      array (
        'class' => 'Wbls_Heading_Widget',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'class' => 'content-center',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '',
      'text' => '[toggle title="Vivamus semper tincidunt tincidunt." open="0"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title=" Donec facilisis fringilla faucibus. " open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.[/toggle][gap height="20"]

[toggle title=" Fusce ultricies sapien libero pharetra." open="0"]Vivamus semper tincidunt tincidunt. Nunc ultrices est massa, id laoreet mauris eleifend eu. Donec dictum felis mauris, quis vestibulum risus tempus id. Nulla vulputate vehicula dui, non faucibus lorem congue sit amet.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="Maecenas ut pretium mauris." open="0"]Nam quis interdum nulla. Donec porttitor nibh est, eu tempus nisi pellentesque ac. Maecenas ut pretium mauris. Quisque nunc justo, placerat non luctus euismod, placerat sit amet ex. Nunc molestie nisl ac molestie ultricies.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title="Quisque  placerat luctus euismod." open="0"]Aenean convallis ipsum felis, eu commodo nulla vestibulum a. Praesent rhoncus elit sed libero mollis, quis ullamcorper risus mattis. Morbi rutrum nunc nec nisl porta malesuada. Suspendisse vel diam mattis, gravida sapien non, bibendum leo.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leoNunc sit amet justo lectus. Curabitur vel ipsum ac nisi malesuada pellentesque. Aenean aliquet tempus eros et volutpat. Aliquam non tincidunt erat. Vivamus sit amet massa sem. Nulla nec risus eget elit iaculis lobortis fringilla ac lorem. Fusce scelerisque id ipsum ac pulvinar.[/toggle][gap height="20"]

[toggle title="Curabitur ac egestas dolor  dapibus ." open="0"]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.[/toggle][gap height="20"]

[toggle title=" Aliquam non tincidunt erat. " open="0"]Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.[/toggle][gap height="20"]

[toggle title=" Sed varius tincidunt metus eu aliquam.  " open="0"]Sed varius tincidunt metus eu aliquam. Sed sollicitudin lectus at nibh faucibus, eu sagittis enim consequat. In hac habitasse platea dictumst. In blandit viverra elit, commodo porttitor augue pharetra semper. Nulla finibus est nunc, sed porta turpis vehicula at. Aliquam blandit malesuada euismod.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin purus ex, dapibus et ultricies vel, egestas sit amet turpis. Vestibulum dictum purus vitae dapibus egestas. In malesuada tellus id pulvinar tincidunt. Cras gravida metus mi.[/toggle][gap height="20"]
',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
                 ),
            );
            $layouts['services'] = array (
                'name' => __('Services Page', 'wbls-gem'),
                'description' => __('Pre Built Layout for services page', 'wbls-gem'),
                'widgets' =>  array(
                0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '1',
            'type' => 'separator',
            'content' => 'Exclusive Services',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'content-center',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://gem.webulous.in/wp-content/uploads/2016/03/four-1.png',
            'href' => 'http://gem.webulous.in/wp-content/uploads/2016/03/four-1.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Who We Are',
            'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'src' => 'http://gem.webulous.in/wp-content/uploads/2016/03/one-2.png',
            'href' => 'http://gem.webulous.in/wp-content/uploads/2016/03/one-2.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Mission & Vision',
            'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 4,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'src' => 'http://gem.webulous.in/wp-content/uploads/2016/03/six-1.png',
            'href' => 'http://gem.webulous.in/wp-content/uploads/2016/03/six-1.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 2,
              'id' => 5,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'title' => 'Our Support',
            'text' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry.',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 6,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
        ),
      ),
      'builder_id' => '56e6b620a0f78',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => '620',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => '621',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => '622',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => '623',
      'panels_info' => 
      array (
        'class' => 'Wbls_Stats_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 3,
        'id' => 4,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'level' => '1',
            'type' => 'separator',
            'content' => 'Our Business Process',
            'panels_info' => 
            array (
              'class' => 'Wbls_Heading_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'content-center',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '1. Analysis',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pretium placerat arcu non luctus.',
            'icon' => 'fa-signal',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => true,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '2. Design',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pretium placerat arcu non luctus.',
            'icon' => 'fa-paint-brush',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '3.Development',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pretium placerat arcu non luctus.',
            'icon' => 'fa-code',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '4.Support',
            'text' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pretium placerat arcu non luctus.',
            'icon' => 'fa-support',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'top',
            'more' => '',
            'more_url' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '56b5842c0325d',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 5,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'Purchase Now',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 6,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 4,
      'style' => 
      array (
        'class' => 'wide-grey',
        'background_display' => 'tile',
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-cta',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    4 => 
    array (
      'grid' => 1,
      'weight' => 0.25,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
                ),
            );

            return $layouts;
        }

        public function wbls_gem_panels_row_style_fields($fields) {

                $gem_animation_name = array(
                    '' => __(' --- Default --- ', 'wbls-gem'),
                    'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-gem' ),
                    'bigEntrance-animation' => __('bigEntrance-animation','wbls-gem' ),
                    'boingInUp-animation' => __('boingInUp-animation','wbls-gem' ),
                    'bounce-animation' => __('bounce-animation','wbls-gem' ),
                    'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-gem' ),
                    'bounceInRight-animation' => __('bounceInRight-animation','wbls-gem' ),
                    'bounceInUp-animation' => __('bounceInUp-animation','wbls-gem' ),
                    'expandUp-animation' => __('expandUp-animation','wbls-gem' ),
                    'fade-animation' => __('fade-animation','wbls-gem' ),
                    'fadeIn-animation' => __('fadeIn-animation','wbls-gem' ),
                    'fadeInDown-animation' => __('fadeInDown-animation','wbls-gem' ),
                    'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-gem' ),
                    'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-gem' ),
                    'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-gem' ),
                    'fadeInRight-animation' => __('fadeInRight-animation','wbls-gem' ),
                    'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-gem' ),
                    'fadeInUp-animation' => __('fadeInUp-animation','wbls-gem' ),
                    'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-gem' ),
                    'flip-animation' => __('flip-animation','wbls-gem' ),
                    'flipInX-animation' => __('flipInX-animation','wbls-gem' ),
                    'flipInY-animation' => __('flipInY-animation','wbls-gem' ),
                    'floating-animation' => __('floating-animation','wbls-gem' ),
                    'foolishIn-animation' => __('foolishIn-animation','wbls-gem' ),
                    'hatch-animation' => __('hatch-animation','wbls-gem' ),
                    'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-gem' ),
                    'puffIn-animation' => __('puffIn-animation','wbls-gem' ),
                    'pullDown-animation' => __('pullDown-animation','wbls-gem' ),
                    'pullUp-animation' => __('pullUp-animation','wbls-gem' ),
                    'pulse-animation' => __('pulse-animation','wbls-gem' ),
                    'rollInLeft-animation' => __('rollInLeft-animation','wbls-gem' ),
                    'rollInRight-animation' => __('rollInRight-animation','wbls-gem' ),
                    'rotateIn-animation' => __('rotateIn-animation','wbls-gem' ),
                    'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-gem' ),
                    'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-gem' ),
                    'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-gem' ),
                    'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-gem' ),
                    'scale-down-animation' => __('scale-down-animation','wbls-gem' ),
                    'scale-up-animation' => __('scale-up-animation','wbls-gem' ),
                    'slide-bottom-animation' => __('slide-bottom-animation','wbls-gem' ),
                    'slide-left-animation' => __('slide-left-animation','wbls-gem' ),
                    'slide-right-animation' => __('slide-right-animation','wbls-gem' ),
                    'slide-top-animation' => __('slide-top-animation','wbls-gem' ),
                    'slideDown-animation' => __('slideDown-animation','wbls-gem' ),
                    'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-gem' ),
                    'slideInDown-animation' => __('slideInDown-animation','wbls-gem' ),
                    'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-gem' ),
                    'slideInRight-animation' => __('slideInRight-animation','wbls-gem' ),
                    'slideLeft-animation' => __('slideLeft-animation','wbls-gem' ),
                    'slideRight-animation' => __('slideRight-animation','wbls-gem' ),
                    'slideUp-animation' => __('slideUp-animation','wbls-gem' ),
                    'spaceInDown-animation' => __('spaceInDown-animation','wbls-gem' ),
                    'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-gem' ),
                    'spaceInRight-animation' => __('spaceInRight-animation','wbls-gem' ), 
                    'spaceInUp-animation'  => __('spaceInUp-animation','wbls-gem' ),
                    'stretchLeft-animation' => __('stretchLeft-animation','wbls-gem' ), 
                    'stretchRight-animation'  => __('stretchRight-animation','wbls-gem' ),
                    'swap-animation'  => __('swap-animation','wbls-gem' ),
                    'swashIn-animation'  => __('swashIn-animation','wbls-gem' ),
                    'swing-animation'  => __('swing-animation','wbls-gem' ),
                    'tinDownIn-animation' => __('tinDownIn-animation','wbls-gem' ), 
                    'tinRightIn-animation'  => __('tinRightIn-animation','wbls-gem' ),
                    'tinUpIn-animation' => __('tinUpIn-animation','wbls-gem' ), 
                    'tossing-animation'  => __('tossing-animation','wbls-gem' ),
                    'twisterInDown-animation'  => __('twisterInDown-animation','wbls-gem' ),
                    'twisterInUp-animation' => __('twisterInUp-animation','wbls-gem' ), 
                    'wobble-animation' => __('wobble-animation','wbls-gem' ),
                    'zoomIn-animation' => __('zoomIn-animation','wbls-gem' ),
                );

                $fields['animation_class'] = array(
                        'name' => __('Animation Class', 'gem'),
                        'type' => 'select',
                        'options' => $gem_animation_name,
                );

                return $fields;
        }

        public function wbls_gem_panels_panels_row_style_attributes( $attributes, $args ) {
              if( !empty( $args['animation_class'] ) ) {
                  $attributes['class'][] =  $args['animation_class']; 
                }

                if( !empty( $args['class'] ) ) {
                  $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
                }
                return $attributes;
        }

        public function wbls_gem_row_style_groups( $groups ) {
              $groups['theme'] = array(
                  'name' => __('Animation', 'wbls-gem'),
              );

              return $groups;
            
        } 

    }

}

