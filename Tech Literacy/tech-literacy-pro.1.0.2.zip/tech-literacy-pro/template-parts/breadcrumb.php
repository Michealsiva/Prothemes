<?php
/**
 * The template used for displaying page breadcrumb
 *
 * @package TechLiteracyPro
 */

/* search box */
if( !is_front_page() ) : ?>
	<div id="search-style" class="search-box-wrapper">
	    <?php get_search_form(); ?>
	</div><?php 
endif; 

$global_page_title_bar =  get_theme_mod('global_page_title_bar'); 

if( empty($global_page_title_bar) && is_page()) { 
	$page_title_bar = get_post_meta( $post->ID, '_gx_page_title_bar', true );
	$page_title_text = get_post_meta( $post->ID, '_gx_page_title_text', true );
	$page_breadcrumb = get_post_meta( $post->ID, '_gx_page_breadcrumb', true );  	
}else{
	$page_title_bar	=  get_theme_mod('page_titlebar'); 
	$page_title_text = get_theme_mod('page_titlebar_text'); 
	$page_breadcrumb = get_theme_mod('breadcrumb'); 
}   


if( is_404() || is_search()) { ?>   
	<div class="breadcrumb">
		<div class="container">
			<div class="sixteen columns"> 
				<div class="breadcrumb-left">  
					<h2 class="page-title"><?php
					  is_404() ? _e( 'Oops! That page can&rsquo;t be found.', 'techliteracy_pro' ) : printf( __( 'Search Results for: %s', 'techliteracy_pro' ), '<span>' . get_search_query() . '</span>' );?>
					</h2>
				</div>
			</div> 
		</div>
	</div><?php
}else{  
	if( !isset($page_title_bar) || $page_title_bar != 2 ) : ?>    
	   <div class="breadcrumb">   
		 <div class="container">
				<div class="eight columns"><?php
				if( !isset($page_title_text) || empty($page_title_text) ) : ?>
					<div class="breadcrumb-left">
					     <?php is_archive() ?  the_archive_title( '<h4>', '</h4>' ): the_title('<h4>','</h4>'); ?>			
				    </div>
				<?php endif; ?>	
				</div>
				<div class="eight columns"><?php  
					if( function_exists('is_bbpress') && is_bbpress()) { ?>
						<div class="breadcrumb-right">
	                         <?php bbp_breadcrumb(); ?>
	                    </div><?php
					}elseif( ( !isset( $page_breadcrumb) || empty($page_breadcrumb ) ) && function_exists('techliteracy_pro_breadcrumbs') ) { ?>
						<div class="breadcrumb-right">
							<?php techliteracy_pro_breadcrumbs(); ?> 
						</div><?php 
					} ?>	
			    </div>
			            	
			</div>
		</div><?php 
	endif; 	
}

