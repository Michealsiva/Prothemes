<?php
/**
 * @package TechLiteracyPro
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
 
		<?php
		$single_featured_image = get_theme_mod( 'single_featured_image',true );
		$single_featured_image_size = get_theme_mod ('single_featured_image_size',1);
		if (isset($single_featured_image_size) && $single_featured_image_size != 3  && $single_featured_image ) { ?>
		    <div class="post-thumb blog-thumb"><?php
			    if( has_post_thumbnail() && ! post_password_required() ) : 
			        if ( $single_featured_image_size == 1 ) : 
						the_post_thumbnail('tech-literacy-blog-large-width'); 
				    else: 
						the_post_thumbnail('tech-literacy-small-featured-image-width');		
					endif;
			    endif;?>
		    </div><?php
		} ?>

        <header class="entry-header">	
			<h3 class="entry-title"><?php the_title( '','' ); ?></h3>
			<?php if ( get_theme_mod('enable_single_post_top_meta',true ) ): ?>
				    <div class="entry-meta">
				    <?php if(function_exists('techliteracy_pro_entry_top_meta') ) {
				         techliteracy_pro_entry_top_meta();
				     } ?>
					</div><!-- .entry-meta -->
			<?php endif; ?>
	   </header><!-- .entry-header -->

	<div class="entry-content">
	
		<?php the_content(); 
		    wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'techliteracy_pro' ),
				'after'  => '</div>',
			) );
		?>
	
	</div><!-- .entry-content -->

<?php if ( get_theme_mod('enable_single_post_bottom_meta', false ) ): ?>
	<footer class="entry-meta">
	<?php if(function_exists('techliteracy_pro_entry_bottom_meta') ) {
		    techliteracy_pro_entry_bottom_meta();
		} ?>
	</footer><!-- .entry-footer -->
<?php endif;?>

</article><!-- #post-## -->

	<?php techliteracy_pro_post_nav(); ?>
