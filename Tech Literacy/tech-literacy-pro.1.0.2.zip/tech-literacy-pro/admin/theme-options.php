<?php  
/**
 * Created by PhpStorm.
 * User: venkat
 * Date: 2/5/16
 * Time: 4:32 PM        
 */      
          
include_once( get_template_directory() . '/admin/kirki/kirki.php' );   
include_once( get_template_directory() . '/admin/kirki-helpers/class-theme-kirki.php' ); 
     

TechLiteracy_Kirki::add_config( 'techliteracy_pro', array(     
    'capability'    => 'edit_theme_options',                  
    'option_type'   => 'theme_mod',          
) );               
     
// Flat option start //   

//  site identity section // 

TechLiteracy_Kirki::add_section( 'title_tagline', array(
    'title'          => __( 'Site Identity','techliteracy_pro' ),
    'description'    => __( 'Site Header Options', 'techliteracy_pro'),       
    'priority'       => 8,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'logo_title',
    'label'    => __( 'Enable Logo as Title', 'techliteracy_pro' ),
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'priority' => 5,
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => 'off',   
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'tagline',
    'label'    => __( 'Show site Tagline', 'techliteracy_pro' ), 
    'section'  => 'title_tagline',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => 'on',
) );  

// home panel //

TechLiteracy_Kirki::add_panel( 'home_options', array(     
    'title'       => __( 'Home', 'techliteracy_pro' ),
    'description' => __( 'Home Page Related Options', 'techliteracy_pro' ),     
) );  

  
// home page type section

TechLiteracy_Kirki::add_section( 'home_type_section', array(
    'title'          => __( 'PRO Home - General Settings','techliteracy_pro' ),
    'description'    => __( 'Home Page options', 'techliteracy_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(  
    'settings' => 'enable_home_default_content',
    'label'    => __( 'Enable Home Page Default Content', 'techliteracy_pro' ),
    'section'  => 'home_type_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'off',  
    'tooltip' => __('Use pagebuilder to built pro home page (or) Use prebuilt layout','techliteracy_pro'),
) );  


// Search section 

TechLiteracy_Kirki::add_section( 'search_field_section', array(
    'title'          => __( 'Search Section','techliteracy_pro' ),
    'description'    => __( 'Home Page Search Related Options', 'techliteracy_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(  
    'settings' => 'search_field_status',  
    'label'    => __( 'Enable Home Page Search Section', 'techliteracy_pro' ),
    'section'  => 'search_field_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ),
    ),
    'default'  => 'on',
) );
 
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'search_heading',
    'label'    => __( 'Search Heading', 'techliteracy_pro' ),
    'section'  => 'search_field_section',
    'type'     => 'text',
    'default'  => __('How We Can Help You Today?'),
    'active_callback' => array(
        array(
            'setting'  => 'search_field_status',
            'operator' => '==',
            'value'    => true,
        ),                                                                                                                                                                                                                                                                                                                                                                          
    ),
) );

// service section 

TechLiteracy_Kirki::add_section( 'service_section', array(
    'title'          => __( 'Service Section','techliteracy_pro' ),
    'description'    => __( 'Home Page - Service Related Options', 'techliteracy_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(  
    'settings' => 'service_field',  
    'label'    => __( 'Enable Service Section', 'techliteracy_pro' ),
    'section'  => 'service_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ),
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Service section in home page','techliteracy_pro'),
) );

for ( $i = 1 ; $i <= 3 ; $i++ ) {
    //Create the settings Once, and Loop through it.
    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'service_section_icon_'.$i,
        'label'    => sprintf(__( 'Service Section Icons #%1$s', 'techliteracy_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'text',
        'description' => sprintf(__( '%1$s (fa fa-apple) ', 'techliteracy_pro' ), '<a href="http://fontawesome.io/icons/">Type FontAwesome icons</a>' ),          
        'active_callback' => array(
            array(
                'setting'  => 'service_field',
                'operator' => '==',
                'value'    => true,
            ),                                                                                                                                                                                                                                                                                                                                                                          
        ),
    ) );

    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'service_'.$i,
        'label'    => sprintf(__( 'Service Section #%1$s', 'techliteracy_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'dropdown-pages', 
        'active_callback' => array(
            array(
                'setting'  => 'service_field',
                'operator' => '==',
                'value'    => true,
            ),                                                                                                                                                                                                                                                                                                                                                                          
        ),        
    ) );

    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'service_color_'.$i,
        'label'    => sprintf(__( 'Choose Service Section Icons #%1$s', 'techliteracy_pro' ), $i ),
        'section'  => 'service_section',
        'type'     => 'color', 
        'active_callback' => array(
            array(
                'setting'  => 'service_field',
                'operator' => '==',
                'value'    => true,
            ),                                                                                                                                                                                                                                                                                                                                                                          
        ),        
    ) );
}

// latest blog section 

TechLiteracy_Kirki::add_section( 'latest_blog_section', array(
    'title'          => __( 'Latest Blog Section','techliteracy_pro' ),
    'description'    => __( 'Home Page - Latest Blog Options', 'techliteracy_pro'),
    'panel'          => 'home_options', // Not typically needed. 
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'enable_recent_post_service',
    'label'    => __( 'Enable Recent Post Section', 'techliteracy_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),

    'default'  => 'on',
    'tooltip' => __('Enable recent post section in home page','techliteracy_pro'),
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'recent_posts_count',
    'label'    => __( 'No. of Recent Posts', 'techliteracy_pro' ),
    'section'  => 'latest_blog_section',
    'type'     => 'number',
    'choices' => array(
        'min' => 2,
        'max' => 99,
        'step' => 2,
    ),
    'default'  => 6,
    'active_callback' => array(
        array(
            'setting'  => 'enable_recent_post_service',
            'operator' => '==',
            'value'    => true,
        ),

    ),
) );

// general panel      

TechLiteracy_Kirki::add_panel( 'general_panel', array(   
    'title'       => __( 'General Settings', 'techliteracy_pro' ),  
    'description' => __( 'general settings', 'techliteracy_pro' ),         
) );
//  Page title bar section // 

TechLiteracy_Kirki::add_section( 'header-pagetitle-bar', array(   
    'title'          => __( 'Page Title Bar & Breadcrumb','techliteracy_pro' ),
    'description'    => __( 'Page Title bar related options', 'techliteracy_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) ); 
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'global_page_title_bar',
    'label'    => __( 'Check the box if you want to use a global page title bar settings. This option overrides the page options', 'techliteracy_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'checkbox',
    'default' => '0',
) );   

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'page_titlebar',  
    'label'    => __( 'Page Title Bar', 'techliteracy_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( 'Show Bar and Content', 'techliteracy_pro' ),
        2 => __('Hide','techliteracy_pro'),
    ),
    'default' => 1,
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'page_titlebar_text',  
    'label'    => __( 'Page Title Bar Text', 'techliteracy_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        0 => __( 'Show', 'techliteracy_pro' ),
        1 => __( 'Hide', 'techliteracy_pro' ), 
    ),
    'default' => 0,
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'breadcrumb',  
    'label'    => __( 'Hide Breadcrumb', 'techliteracy_pro' ),
    'section'  => 'header-pagetitle-bar', 
    'type'     => 'checkbox',
    'default'  => 0,
) ); 

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'breadcrumb_char',
    'label'    => __( 'Breadcrumb Character', 'techliteracy_pro' ),
    'section'  => 'header-pagetitle-bar',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        1 => __( ' >> ', 'techliteracy_pro' ),
        2 => __( ' / ', 'techliteracy_pro' ),
        3 => __( ' > ', 'techliteracy_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'breadcrumb',
            'operator' => '==',
            'value'    => 0,
        ),
    ),
    //'sanitize_callback' => 'allow_htmlentities'
) );

//  pagination section // 

TechLiteracy_Kirki::add_section( 'general-pagination', array(   
    'title'          => __( 'Pagination','techliteracy_pro' ),
    'description'    => __( 'Pagination related options', 'techliteracy_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'numeric_pagination',
    'label'    => __( 'Numeric Pagination', 'techliteracy_pro' ),   
    'section'  => 'general-pagination',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Numbered', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Next/Previous', 'techliteracy_pro' )
    ),
    'default'  => 'on',
) );

// skin color panel 

TechLiteracy_Kirki::add_panel( 'skin_color_panel', array(   
    'title'       => __( 'Skin Color', 'techliteracy_pro' ),  
    'description' => __( 'Color Settings', 'techliteracy_pro' ),         
) );
// color scheme section 

TechLiteracy_Kirki::add_section( 'multiple_color_section', array(
    'title'          => __( 'Color Scheme','techliteracy_pro' ),
    'description'    => __( 'Select your color scheme', 'techliteracy_pro'),
    'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 9,
) );  

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'color_scheme',
    'label'    => __( 'Select your color scheme', 'techliteracy_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'palette',
    'choices'     => array( 
        '1' => array(
            '#e74b3c',
        ),
        '2' => array(
            '#ff5b15',
        ),
        '3' => array( 
            '#00be5d',
        ),
        '4' => array(
            '#6684cf',
        ), 
        '5' => array(
            '#ff5498',
        ),
        '6' => array(
            '#caa91d',
        ),
    ),
    'default' => '1',
//'default'  => 'on',
) );

/* custom color stylesheet */

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'enable_custom_color_scheme',
    'label'    => __( 'Enable Custom color scheme', 'techliteracy_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => 'off',
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'custom_color_scheme',
    'label'    => __( 'Select custom color scheme', 'techliteracy_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'color',
    'default'  => '#e74b3c',
    'alpha'  => false,
    'active_callback' => array(
        array (
            'setting'  => 'enable_custom_color_scheme',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

/* pagebuilder style override */
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'enable_so_custom_color',
    'label'    => __( 'Enable this Option to change color choosen by pagebuilder', 'techliteracy_pro' ),
    'section'  => 'multiple_color_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => 'off',
    'tooltip' => __('while change the color scheme this option is also change the pagebuilder row and widget related option color in order to match color scheme','techliteracy_pro'),

) );

// typography panel //  

TechLiteracy_Kirki::add_panel( 'typography', array( 
    'title'       => __( 'Typography', 'techliteracy_pro' ),
    'description' => __( 'Typography and Link Color Settings', 'techliteracy_pro' ),
) );
   
    TechLiteracy_Kirki::add_section( 'typography_section', array(
        'title'          => __( 'General Settings','techliteracy_pro' ),
        'description'    => __( 'General Settings', 'techliteracy_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );
        

    TechLiteracy_Kirki::add_section( 'body_font', array(
        'title'          => __( 'Body Font','techliteracy_pro' ),
        'description'    => __( 'Specify the body font properties', 'techliteracy_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) ); 

    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'body_typography',
        'label'    => __( 'Enable Custom body Settings', 'techliteracy_pro' ),
        'section'  => 'body_font',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
            'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
        ),
        'tooltip' => __('Turn on to body typography and turn off for default typography','techliteracy_pro'),
        'default'  => 'off',
    ) );


    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'body',
        'label'    => __( 'Body Settings', 'techliteracy_pro' ),
        'section'  => 'body_font', 
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto', 
            'variant'        => 'regular',
            'font-size'      => '16px',  
            'line-height'    => '1.5',
            'letter-spacing' => '0',
            'color'          => '#27323d', 
        ),
        'output'      => array(
            array(
                'element' => 'body',
                //'suffix' => '!important',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'body_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );


    TechLiteracy_Kirki::add_section( 'heading_section', array(
        'title'          => __( 'Heading Font','techliteracy_pro' ),
        'description'    => __( 'Specify typography of H1, H2, H3, H4, H5, H6', 'techliteracy_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'heading_one_typography',
        'label'    => __( 'Enable Custom H1 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
            'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
        ),
        'tooltip' => __('Turn on to H1 typography and turn off for default typography','techliteracy_pro'),
        'default'  => 'off',
    ) );


    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'h1',  
        'label'    => __( 'H1 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '48px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#27323d',
        ),
        'output'      => array(
            array(
                'element' => 'h1',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_one_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );
    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'heading_two_typography',
        'label'    => __( 'Enable Custom H2 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
            'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
        ),
        'tooltip' => __('Turn on to H2 typography and turn off for default typography','techliteracy_pro'),
        'default'  => 'off',
    ) );


    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'h2',
        'label'    => __( 'H2 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '36px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#27323d',
        ),
        'output'      => array(
            array(
                'element' => 'h2',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_two_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'heading_three_typography',
        'label'    => __( 'Enable Custom H3 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
            'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
        ),
        'tooltip' => __('Turn on to H3 typography and turn off for default typography','techliteracy_pro'),
        'default'  => 'off',
    ) );


    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'h3',
        'label'    => __( 'H3 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default' => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '30px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#27323d',
        ),
        'output'      => array(
            array(
                'element' => 'h3',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_three_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'heading_four_typography',
        'label'    => __( 'Enable Custom H4 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
            'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
        ),
        'tooltip' => __('Turn on to H4 typography and turn off for default typography','techliteracy_pro'),
        'default'  => 'off',
    ) );


    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'h4',
        'label'    => __( 'H4 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '24px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#27323d',
        ),
        'output'      => array(
            array(
                'element' => 'h4',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_four_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'heading_five_typography',
        'label'    => __( 'Enable Custom H5 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
            'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
        ),
        'tooltip' => __('Turn on to H5 typography and turn off for default typography','techliteracy_pro'),
        'default'  => 'off',
    ) );



    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'h5',
        'label'    => __( 'H5 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '18px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#27323d',
        ),
        'output'      => array(
            array(
                'element' => 'h5',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_five_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );

    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'heading_six_typography',
        'label'    => __( 'Enable Custom H6 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
            'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
        ),
        'tooltip' => __('Turn on to H6 typography and turn off for default typography','techliteracy_pro'),
        'default'  => 'off',
    ) );



    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'h6',
        'label'    => __( 'H6 Settings', 'techliteracy_pro' ),
        'section'  => 'heading_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto', 
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8',
            'letter-spacing' => '0',
            'color'          => '#27323d',
        ),
        'output'      => array(
            array(
                'element' => 'h6',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'heading_six_typography',
                'operator' => '==',
                'value'    => true,
            ),
        ),
        
    ) );

    // navigation font 
    TechLiteracy_Kirki::add_section( 'navigation_section', array(
        'title'          => __( 'Navigation Font','techliteracy_pro' ),
        'description'    => __( 'Specify Navigation font properties', 'techliteracy_pro'),
        'panel'          => 'typography', // Not typically needed.
    ) );

    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'navigation_font_status',
        'label'    => __( 'Enable Navigation Font Settings', 'techliteracy_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
            'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
        ),
        'tooltip' => __('Turn on to Navigation Font typography and turn off for default typography','techliteracy_pro'),
        'default'  => 'off',
    ) );

    TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
        'settings' => 'navigation_font',
        'label'    => __( 'Navigation Font Settings', 'techliteracy_pro' ),
        'section'  => 'navigation_section',
        'type'     => 'typography',
        'default'     => array(
            'font-family'    => 'Roboto',
            'variant'        => '700',
            'font-size'      => '16px',
            'line-height'    => '1.8', 
            'letter-spacing' => '0',
            'color'          => '#ffffff',
        ),
        'output'      => array(
            array(
                'element' => '.main-navigation a',
            ),
        ),
        'active_callback' => array(
            array(
                'setting'  => 'navigation_font_status',
                'operator' => '==',
                'value'    => true,
            ),
        ),
    ) );



// header panel //  

TechLiteracy_Kirki::add_panel( 'header_panel', array(     
    'title'       => __( 'Header', 'techliteracy_pro' ),
    'description' => __( 'Header Related Options', 'techliteracy_pro' ), 
) );  

/* STICKY HEADER section */     
  
TechLiteracy_Kirki::add_section( 'stricky_header', array(
    'title'          => __( 'Sticky Menu','techliteracy_pro' ),
    'description'    => __( 'sticky header', 'techliteracy_pro'),
    'panel'          => 'header_panel', // Not typically needed.
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(    
    'settings' => 'sticky_header',
    'label'    => __( 'Enable Sticky Header', 'techliteracy_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => 'on',
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'sticky_header_position',
    'label'    => __( 'Enable Sticky Header Position', 'techliteracy_pro' ),
    'section'  => 'stricky_header',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'top'  => esc_attr__( 'Top', 'techliteracy_pro' ),
        'bottom' => esc_attr__( 'Bottom', 'techliteracy_pro' )
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'sticky_header',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'top',
) );

TechLiteracy_Kirki::add_section( 'header_search_box', array(
    'title'          => __( 'Header Search Box','techliteracy_pro' ),
    'description'    => __( 'Header Search box', 'techliteracy_pro'),
    'panel'          => 'header_panel', // Not typically needed.
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(    
    'settings' => 'header_search',
    'label'    => __( 'Enable Header Search Box', 'techliteracy_pro' ),
    'section'  => 'header_search_box',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => 'on',
) );
/*
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'header_top_margin',
    'label'    => __( 'Header Top Margin', 'techliteracy_pro' ),
    'description' => __('Select the top margin of header in pixels','techliteracy_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'header_bottom_margin',
    'label'    => __( 'Header Bottom Margin', 'techliteracy_pro' ),
    'description' => __('Select the bottom margin of header in pixels','techliteracy_pro'),
    'section'  => 'header',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1,
    ),
    //'default'  => '213',
) );*/

TechLiteracy_Kirki::add_section( 'header_image', array(
    'title'          => __( 'Header Background Image','techliteracy_pro' ),
    'description'    => __( 'Custom Header Image options', 'techliteracy_pro'),
    'panel'          => 'header_panel', // Not typically needed.  
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(   
    'settings' => 'header_bg_size',
    'label'    => __( 'Header Background Size', 'techliteracy_pro' ),
    'section'  => 'header_image',
    'type'     => 'radio-buttonset', 
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'techliteracy_pro' ),
        'contain' => esc_attr__( 'Contain', 'techliteracy_pro' ),
        'auto'  => esc_attr__( 'Auto', 'techliteracy_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'techliteracy_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Header Background Image Size','techliteracy_pro'),
) );

/*TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'header_height',
    'label'    => __( 'Header Background Image Height', 'techliteracy_pro' ),
    'section'  => 'header_image',
    'type'     => 'number',
    'choices' => array(
        'min' => 100,
        'max' => 600,
        'step' => 1,
    ),
    'default'  => '213',
) ); */
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'header_bg_repeat',
    'label'    => __( 'Header Background Repeat', 'techliteracy_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'techliteracy_pro'),
        'repeat' => esc_attr__('Repeat', 'techliteracy_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','techliteracy_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'repeat',  
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'header_bg_position', 
    'label'    => __( 'Header Background Position', 'techliteracy_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'techliteracy_pro'),
        'center center' => esc_attr__('Center Center', 'techliteracy_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'techliteracy_pro'),
        'left top' => esc_attr__('Left Top', 'techliteracy_pro'),
        'left center' => esc_attr__('Left Center', 'techliteracy_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'techliteracy_pro'),
        'right top' => esc_attr__('Right Top', 'techliteracy_pro'),
        'right center' => esc_attr__('Right Center', 'techliteracy_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'center center',  
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'header_bg_attachment',
    'label'    => __( 'Header Background Attachment', 'techliteracy_pro' ),
    'section'  => 'header_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'techliteracy_pro'),
        'fixed' => esc_attr__('Fixed', 'techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.header-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_image',
            'operator' => '!=',
            'value'    => 'remove-header',
        ),
    ),
    'default'  => 'scroll',  
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'header_overlay',
    'label'    => __( 'Enable Header( Background ) Overlay', 'techliteracy_pro' ),
    'section'  => 'header_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => 'off',
) );
  
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'header_overlay_color',
    'label'    => __( 'Header Overlay ( Background )color', 'techliteracy_pro' ),
    'section'  => 'header_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'output'   => array(
        array(
            'element'  => '.overlay-header',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'header_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

/*
/* e-option start */
/*
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'custon_favicon',
    'label'    => __( 'Custom Favicon', 'techliteracy_pro' ),
    'section'  => 'header',
    'type'     => 'upload',
    'default'  => '',
) ); */
/* e-option start */ 
/* Blog page section */


/* Blog panel */

TechLiteracy_Kirki::add_panel( 'blog_panel', array(     
    'title'       => __( 'Blog', 'techliteracy_pro' ),
    'description' => __( 'Blog Related Options', 'techliteracy_pro' ),     
) ); 
TechLiteracy_Kirki::add_section( 'blog', array(
    'title'          => __( 'Blog Page','techliteracy_pro' ),
    'description'    => __( 'Blog Related Options', 'techliteracy_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
  
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'blog_layout',
    'label'    => __( 'Select Blog Page Layout you prefer', 'techliteracy_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1  => esc_attr__( 'Default ( One Column )', 'techliteracy_pro' ),
        2 => esc_attr__( 'Two Columns ', 'techliteracy_pro' ),
        3 => esc_attr__( 'Three Columns ( Without Sidebar ) ', 'techliteracy_pro' ),
        4 => esc_attr__( 'Two Columns With Masonry', 'techliteracy_pro' ),
        5 => esc_attr__( 'Three Columns With Masonry ( Without Sidebar ) ', 'techliteracy_pro' ),
        6 => esc_attr__( 'Blog FullWidth', 'techliteracy_pro' ),
    ),
    'default'  => 1,
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'featured_image',
    'label'    => __( 'Enable Featured Image', 'techliteracy_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for blog page','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'more_text',
    'label'    => __( 'More Text', 'techliteracy_pro' ),
    'section'  => 'blog',
    'type'     => 'text',
    'description' => __('Text to display in case of text too long','techliteracy_pro'),
    'default' => __('Read More','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'featured_image_size',
    'label'    => __( 'Choose the Featured Image Size for Blog Page', 'techliteracy_pro' ),
    'section'  => 'blog',
    'type'     => 'select',
    'multiple'  => 1,
    'choices' => array(
        1 => esc_attr__( 'Large Featured Image', 'techliteracy_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'techliteracy_pro' ),
        3 => esc_attr__( 'Original Size', 'techliteracy_pro' ),
        4 => esc_attr__( 'Medium', 'techliteracy_pro' ),
        5 => esc_attr__( 'Large', 'techliteracy_pro' ), 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Set large and medium image size: Goto Dashboard => Settings => Media', 'techliteracy_pro') ,
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'enable_single_post_top_meta',
    'label'    => __( 'Enable to display top post meta data', 'techliteracy_pro' ),
    'section'  => 'blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'single_post_top_meta',
    'label'    => __( 'Activate and Arrange the Order of Top Post Meta elements', 'techliteracy_pro' ),
    'section'  => 'blog',
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'techliteracy_pro' ),
        2 => esc_attr__( 'author', 'techliteracy_pro' ),
        3 => esc_attr__( 'comment', 'techliteracy_pro' ),
        4 => esc_attr__( 'category', 'techliteracy_pro' ),
        5 => esc_attr__( 'tags', 'techliteracy_pro' ),
        6 => esc_attr__( 'edit', 'techliteracy_pro' ),
    ),
    'default'  => array(1, 2, 3,6),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_top_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','techliteracy_pro'),

) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'enable_single_post_bottom_meta',
    'label'    => __( 'Enable to display bottom post meta data', 'techliteracy_pro' ),
    'section'  => 'blog', 
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'tooltip' => __('Enable to Display Top Post Meta Details. This will reflect for blog page, single blog page, blog full width & blog large templates','techliteracy_pro'),
    'default'  => 'off',
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'single_post_bottom_meta',
    'label'    => __( 'Activate and arrange the Order of Bottom Post Meta elements', 'techliteracy_pro' ),
    'section'  => 'blog',    
    'type'     => 'sortable',
    'choices'     => array(
        1 => esc_attr__( 'date', 'techliteracy_pro' ),
        2 => esc_attr__( 'author', 'techliteracy_pro' ),
        3 => esc_attr__( 'comment', 'techliteracy_pro' ),
        4 => esc_attr__( 'category', 'techliteracy_pro' ),
        5 => esc_attr__( 'tags', 'techliteracy_pro' ),
        6 => esc_attr__( 'edit', 'techliteracy_pro' ),
    ),
    'default'  => array(4,5),
    'active_callback' => array(
        array(
            'setting'  => 'enable_single_post_bottom_meta',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Click above eye icon in order to activate the field, This will reflect for blog page, single blog page, blog full width & blog large templates','techliteracy_pro'),
) );


/* Single Blog page section */

TechLiteracy_Kirki::add_section( 'single_blog', array(
    'title'          => __( 'Single Blog Page','techliteracy_pro' ),
    'description'    => __( 'Single Blog Page Related Options', 'techliteracy_pro'),
    'panel'          => 'blog_panel', // Not typically needed.
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'single_featured_image',
    'label'    => __( 'Enable Single Post Featured Image', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Enable Featured Image for Single Post Page','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'single_featured_image_size',
    'label'    => __( 'Choose the featured image display type for Single Post Page', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Large Featured Image', 'techliteracy_pro' ),
        2 => esc_attr__( 'Small Featured Image', 'techliteracy_pro' ),
        3 => esc_attr__( 'FullWidth Featured Image', 'techliteracy_pro' ),
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'author_bio_box',
    'label'    => __( 'Enable Author Bio Box below single post', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'off',
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'related_posts',
    'label'    => __( 'Show Related Posts', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'off',
    'tooltip' => __('Show the Related Post for Single Blog Page','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'related_posts_hierarchy',
    'label'    => __( 'Related Posts Must Be Shown As:', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'radio',
    'choices' => array(
        1  => esc_attr__( 'Related Posts By Tags', 'techliteracy_pro' ),
        2 => esc_attr__( 'Related Posts By Categories', 'techliteracy_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'related_posts',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'tooltip' => __('Select the Hierarchy','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'comments',
    'label'    => __( ' Show Comments', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
    'tooltip' => __('Show the Comments for Single Blog Page','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'social_sharing_box',
    'label'    => __( 'Show social sharing options box below single post', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
) );

//social sharing box section

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'facebook_sb',
    'label'    => __( 'Enable facebook sharing option below single post', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'twitter_sb',
    'label'    => __( 'Enable twitter sharing option below single post', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'linkedin_sb',
    'label'    => __( 'Enable linkedin sharing option below single post', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'google-plus_sb',
    'label'    => __( 'Enable googleplus sharing option below single post', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'email_sb',
    'label'    => __( 'Enable email sharing option below single post', 'techliteracy_pro' ),
    'section'  => 'single_blog',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
    'active_callback' => array(
        array (
            'setting'  => 'social_sharing_box',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );
/* FOOTER SECTION 
footer panel */

TechLiteracy_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'techliteracy_pro' ),
    'description' => __( 'Footer Related Options', 'techliteracy_pro' ),     
) );  

TechLiteracy_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','techliteracy_pro' ),
    'description'    => __( 'Footer related options', 'techliteracy_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'techliteracy_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','techliteracy_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'techliteracy_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'techliteracy_pro' ),
        2  => esc_attr__( '2', 'techliteracy_pro' ),
        3  => esc_attr__( '3', 'techliteracy_pro' ),
        4  => esc_attr__( '4', 'techliteracy_pro' ),
    ),
    'default'  => 3,
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'techliteracy_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'techliteracy_pro' ),
    'description' => __('Select the top margin of footer in pixels','techliteracy_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

TechLiteracy_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','techliteracy_pro' ),
    'description'    => __( 'Custom Footer Image options', 'techliteracy_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'techliteracy_pro' ),
        'contain' => esc_attr__( 'Contain', 'techliteracy_pro' ),
        'auto'  => esc_attr__( 'Auto', 'techliteracy_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'techliteracy_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'techliteracy_pro'),
        'repeat' => esc_attr__('Repeat', 'techliteracy_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','techliteracy_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',   
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'techliteracy_pro'),
        'center center' => esc_attr__('Center Center', 'techliteracy_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'techliteracy_pro'),
        'left top' => esc_attr__('Left Top', 'techliteracy_pro'),
        'left center' => esc_attr__('Left Center', 'techliteracy_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'techliteracy_pro'),
        'right top' => esc_attr__('Right Top', 'techliteracy_pro'),
        'right center' => esc_attr__('Right Center', 'techliteracy_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'techliteracy_pro'),
        'fixed' => esc_attr__('Fixed', 'techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => 'off',
) );
  
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer_image',
            'property' => 'background-color',
        ),
    ),
) );


// single page section //

TechLiteracy_Kirki::add_section( 'single_page', array(
    'title'          => __( 'Single Page','techliteracy_pro' ),
    'description'    => __( 'Single Page Related Options', 'techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'single_page_featured_image',
    'label'    => __( 'Enable Single Page Featured Image', 'techliteracy_pro' ),
    'section'  => 'single_page',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'single_page_featured_image_size',
    'label'    => __( 'Single Page Featured Image Size', 'techliteracy_pro' ),
    'section'  => 'single_page',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( 'Normal', 'techliteracy_pro' ),
        2 => esc_attr__( 'FullWidth', 'techliteracy_pro' ) 
    ),
    'default'  => 1,
    'active_callback' => array(
        array(
            'setting'  => 'single_page_featured_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
) );

// Layout section //

TechLiteracy_Kirki::add_section( 'layout', array( 
    'title'          => __( 'Layout','techliteracy_pro' ),
    'description'    => __( 'Layout Related Options', 'techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'site-style',
    'label'    => __( 'Site Style', 'techliteracy_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'wide' =>  esc_attr__('Wide', 'techliteracy_pro'),
        'boxed' =>  esc_attr__('Boxed', 'techliteracy_pro'),
        'fluid' =>  esc_attr__('Fluid', 'techliteracy_pro'),  
        //'static' =>  esc_attr__('Static ( Non Responsive )', 'techliteracy_pro'),
    ),
    'default'  => 'wide',
    'tooltip' => __('Choose the default site layout.','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'global_sidebar_layout',
    'label'    => __( 'Check the box if you want to use a global sidebar on all pages. This option overrides the page options', 'techliteracy_pro' ),
    'section'  => 'layout',
    'type'     => 'checkbox',
    'default' => '0',
) );


TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'sidebar_position',
    'label'    => __( 'Main Layout', 'techliteracy_pro' ),
    'section'  => 'layout',
    'type'     => 'radio-image',   
    'description' => __('Select main content and sidebar arrangement.','techliteracy_pro'),
    'choices' => array(
        'left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cl.png',
        'right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/2cr.png',
        'two-sidebar' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cm.png',  
        'two-sidebar-left' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cl.png',
        'two-sidebar-right' =>  get_template_directory_uri() . '/admin/kirki/assets/images/3cr.png',
        'fullwidth' =>  get_template_directory_uri() . '/admin/kirki/assets/images/1c.png',
        'no-sidebar' =>  get_template_directory_uri() . '/images/no-sidebar.png',
    ),
    'default'  => 'right', 
    'tooltip' => __('global sidebar on all pages. This option overrides the page layout sidebar options','techliteracy_pro'),
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'body_top_margin',
    'label'    => __( 'Body Top Margin', 'techliteracy_pro' ),
    'description' => __('Select the top margin of body element in pixels','techliteracy_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-top',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'body_bottom_margin',
    'label'    => __( 'Body Bottom Margin', 'techliteracy_pro' ),
    'description' => __('Select the bottom margin of body element in pixels','techliteracy_pro'),
    'section'  => 'layout',
    'type'     => 'number',
    'choices' => array(
        'min' => 0,
        'max' => 200,
        'step' => 1,
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'margin-bottom',
            'units'    => 'px',
        ),
    ),
    'default'  => 0,
) );

/* LAYOUT SECTION  */
/*
TechLiteracy_Kirki::add_section( 'layout', array(
    'title'          => __( 'Layout','techliteracy_pro' ),   
    'description'    => __( 'Layout settings that affects overall site', 'techliteracy_pro'),
    'panel'          => 'techliteracy_pro_options', // Not typically needed.
) );



TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'primary_sidebar_width',
    'label'    => __( 'Primary Sidebar Width', 'techliteracy_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'techliteracy_pro' ),
        '2' => __( 'Two Column', 'techliteracy_pro' ),
        '3' => __( 'Three Column', 'techliteracy_pro' ),
        '4' => __( 'Four Column', 'techliteracy_pro' ),
        '5' => __( 'Five Column ', 'techliteracy_pro' ),
    ),
    'default'  => '5',  
    'tooltip' => __('Select the width of the Primary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'secondary_sidebar_width',
    'label'    => __( 'Secondary Sidebar Width', 'techliteracy_pro' ),
    'section'  => 'layout',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => __( 'One Column', 'techliteracy_pro' ),
        '2' => __( 'Two Column', 'techliteracy_pro' ),
        '3' => __( 'Three Column', 'techliteracy_pro' ),
        '4' => __( 'Four Column', 'techliteracy_pro' ),
        '5' => __( 'Five Column ', 'techliteracy_pro' ),
    ),            
    'default'  => '5',  
    'tooltip' => __('Select the width of the Secondary Sidebar. Please note that the values represent grid columns. The total width of the page is 16 columns, so selecting 5 here will make the primary sidebar to have a width of approximately 1/3 ( 4/16 ) of the total page width.','techliteracy_pro'),
) ); 

*/

/* FOOTER SECTION 
footer panel */

TechLiteracy_Kirki::add_panel( 'footer_panel', array(     
    'title'       => __( 'Footer', 'techliteracy_pro' ),
    'description' => __( 'Footer Related Options', 'techliteracy_pro' ),     
) );  

TechLiteracy_Kirki::add_section( 'footer', array(
    'title'          => __( 'Footer','techliteracy_pro' ),
    'description'    => __( 'Footer related options', 'techliteracy_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_widgets',
    'label'    => __( 'Footer Widget Area', 'techliteracy_pro' ),
    'description' => sprintf(__('Select widgets, Goto <a href="%1$s"target="_blank"> Customizer </a> => Widgets','techliteracy_pro'),admin_url('customize.php') ),
    'section'  => 'footer',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
) );
/* Choose No.Of Footer area */
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_widgets_count',
    'label'    => __( 'Choose No.of widget area you want in footer', 'techliteracy_pro' ),
    'section'  => 'footer',
    'type'     => 'radio-buttonset',
    'choices' => array(
        1  => esc_attr__( '1', 'techliteracy_pro' ),
        2  => esc_attr__( '2', 'techliteracy_pro' ),
        3  => esc_attr__( '3', 'techliteracy_pro' ),
        4  => esc_attr__( '4', 'techliteracy_pro' ),
    ),
    'default'  => 4,
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'copyright',
    'label'    => __( 'Footer Copyright Text', 'techliteracy_pro' ),
    'section'  => 'footer',
    'type'     => 'textarea',
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_top_margin',
    'label'    => __( 'Footer Top Margin', 'techliteracy_pro' ),
    'description' => __('Select the top margin of footer in pixels','techliteracy_pro'),
    'section'  => 'footer',
    'type'     => 'number',
    'choices' => array(
        'min' => 1,
        'max' => 1000,
        'step' => 1, 
    ),
    'output'   => array(
        array(
            'element'  => '.site-footer',
            'property' => 'margin-top',
            'units' => 'px',
        ),
    ),
    'default'  => 0,
) );

/* CUSTOM FOOTER BACKGROUND IMAGE 
footer background image section  */

TechLiteracy_Kirki::add_section( 'footer_image', array(
    'title'          => __( 'Footer Image','techliteracy_pro' ),
    'description'    => __( 'Custom Footer Image options', 'techliteracy_pro'),
    'panel'          => 'footer_panel', // Not typically needed.
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_bg_image',
    'label'    => __( 'Upload Footer Background Image', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-image',
        ),
    ),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_bg_size',
    'label'    => __( 'Footer Background Size', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'radio-buttonset',
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'techliteracy_pro' ),
        'contain' => esc_attr__( 'Contain', 'techliteracy_pro' ),
        'auto'  => esc_attr__( 'Auto', 'techliteracy_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'techliteracy_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',
    'tooltip' => __('Footer Background Image Size','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_bg_repeat',
    'label'    => __( 'Footer Background Repeat', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'techliteracy_pro'),
        'repeat' => esc_attr__('Repeat', 'techliteracy_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','techliteracy_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_bg_position',
    'label'    => __( 'Footer Background Position', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'techliteracy_pro'),
        'center center' => esc_attr__('Center Center', 'techliteracy_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'techliteracy_pro'),
        'left top' => esc_attr__('Left Top', 'techliteracy_pro'),
        'left center' => esc_attr__('Left Center', 'techliteracy_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'techliteracy_pro'),
        'right top' => esc_attr__('Right Top', 'techliteracy_pro'),
        'right center' => esc_attr__('Right Center', 'techliteracy_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'center center',  
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_bg_attachment',
    'label'    => __( 'Footer Background Attachment', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'techliteracy_pro'),
        'fixed' => esc_attr__('Fixed', 'techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.footer-image',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'footer_bg_image',
            'operator' => '=',
            'value'    => true,
        ),
    ),
    'default'  => 'scroll',  
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_overlay',
    'label'    => __( 'Enable Footer( Background ) Overlay', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => 'off',
) );
  
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'footer_overlay_color',
    'label'    => __( 'Footer Overlay ( Background )color', 'techliteracy_pro' ),
    'section'  => 'footer_image',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#E5493A', 
    'active_callback' => array(
        array(
            'setting'  => 'footer_overlay',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'output'   => array(
        array(
            'element'  => '.overlay-footer',
            'property' => 'background-color',
        ),
    ),
) );


 if( class_exists( 'WooCommerce' ) ) {
    TechLiteracy_Kirki::add_section( 'woocommerce_section', array(
        'title'          => __( 'WooCommerce','techliteracy_pro' ),
        'description'    => __( 'Theme options related to woocommerce', 'techliteracy_pro'),
        'priority'       => 11, 
        'theme_supports' => '', // Rarely needed.
    ) );
    TechLiteracy_Kirki::add_field( 'woocommerce', array(
        'settings' => 'woocommerce_sidebar',
        'label'    => __( 'Enable Woocommerce Sidebar', 'techliteracy_pro' ),
        'description' => __('Enable Sidebar for shop page','techliteracy_pro'),
        'section'  => 'woocommerce_section',
        'type'     => 'switch',
        'choices' => array(
            'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
            'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
        ),

        'default'  => 'on',
    ) );
}
    
// background color ( rename )

TechLiteracy_Kirki::add_section( 'colors', array(
    'title'          => __( 'Background Color','techliteracy_pro' ),
    'description'    => __( 'This will affect overall site background color', 'techliteracy_pro'),
    //'panel'          => 'skin_color_panel', // Not typically needed.
    'priority' => 11,
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'general_background_color',
    'label'    => __( 'General Background Color', 'techliteracy_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'alpha' => true,
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-color',
        ),
    ),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'content_background_color',
    'label'    => __( 'Content Background Color', 'techliteracy_pro' ),
    'section'  => 'colors',
    'type'     => 'color',
    'description' => __('when you are select boxed layout content background color will reflect the grid area','techliteracy_pro'), 
    'alpha' => true, 
    'default'  => '#ffffff',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'general_background_image',
    'label'    => __( 'General Background Image', 'techliteracy_pro' ),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-image',
        ),
    ),
) );

// background image ( general & boxed layout ) //


TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'general_background_repeat',
    'label'    => __( 'General Background Repeat', 'techliteracy_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'techliteracy_pro'),
        'repeat' => esc_attr__('Repeat', 'techliteracy_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','techliteracy_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'general_background_size',
    'label'    => __( 'General Background Size', 'techliteracy_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'techliteracy_pro' ),
        'contain' => esc_attr__( 'Contain', 'techliteracy_pro' ),
        'auto'  => esc_attr__( 'Auto', 'techliteracy_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'techliteracy_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-size',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'general_background_attachment',
    'label'    => __( 'General Background Attachment', 'techliteracy_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'techliteracy_pro'),
        'fixed' => esc_attr__('Fixed', 'techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image',
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'general_background_position',
    'label'    => __( 'General Background Position', 'techliteracy_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'techliteracy_pro'),
        'center center' => esc_attr__('Center Center', 'techliteracy_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'techliteracy_pro'),
        'left top' => esc_attr__('Left Top', 'techliteracy_pro'),
        'left center' => esc_attr__('Left Center', 'techliteracy_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'techliteracy_pro'),
        'right top' => esc_attr__('Right Top', 'techliteracy_pro'),
        'right center' => esc_attr__('Right Center', 'techliteracy_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => 'body',
            'property' => 'background-position',
        ),
    ),
    'active_callback'    => array(
        array(
            'setting'  => 'general_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );


/* CONTENT BACKGROUND ( boxed background image )*/

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(  
    'settings' => 'content_background_image',
    'label'    => __( 'Content Background Image', 'techliteracy_pro' ),
    'description' => __('when you are select boxed layout content background image will reflect the grid area','techliteracy_pro'),
    'section'  => 'background_image',
    'type'     => 'upload',
    'default'  => '',
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-image',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
    ),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'content_background_repeat',
    'label'    => __( 'Content Background Repeat', 'techliteracy_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'no-repeat' => esc_attr__('No Repeat', 'techliteracy_pro'),
        'repeat' => esc_attr__('Repeat', 'techliteracy_pro'),
        'repeat-x' => esc_attr__('Repeat Horizontally','techliteracy_pro'),
        'repeat-y' => esc_attr__('Repeat Vertically','techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-repeat',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'repeat',  
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'content_background_size',
    'label'    => __( 'Content Background Size', 'techliteracy_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices' => array(
        'cover'  => esc_attr__( 'Cover', 'techliteracy_pro' ),
        'contain' => esc_attr__( 'Contain', 'techliteracy_pro' ),
        'auto'  => esc_attr__( 'Auto', 'techliteracy_pro' ),
        'inherit'  => esc_attr__( 'Inherit', 'techliteracy_pro' ),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-size',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'cover',  
) );

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'content_background_attachment',
    'label'    => __( 'Content Background Attachment', 'techliteracy_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'scroll' => esc_attr__('Scroll', 'techliteracy_pro'),
        'fixed' => esc_attr__('Fixed', 'techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-attachment',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'fixed',  
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'content_background_position',
    'label'    => __( 'Content Background Position', 'techliteracy_pro' ),
    'section'  => 'background_image',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'center top' => esc_attr__('Center Top', 'techliteracy_pro'),
        'center center' => esc_attr__('Center Center', 'techliteracy_pro'),
        'center bottom' => esc_attr__('Center Bottom', 'techliteracy_pro'),
        'left top' => esc_attr__('Left Top', 'techliteracy_pro'),
        'left center' => esc_attr__('Left Center', 'techliteracy_pro'),
        'left bottom' => esc_attr__('Left Bottom', 'techliteracy_pro'),
        'right top' => esc_attr__('Right Top', 'techliteracy_pro'),
        'right center' => esc_attr__('Right Center', 'techliteracy_pro'),
        'right bottom' => esc_attr__('Right Bottom', 'techliteracy_pro'),
    ),
    'output'   => array(
        array(
            'element'  => '.boxed-container',
            'property' => 'background-position',
        ),
    ),
    'active_callback' => array(
        array(
            'setting'  => 'site-style',
            'operator' => '==',
            'value'    => 'boxed',
        ),
        array(
            'setting'  => 'content_background_image', 
            'operator' => '==',
            'value'    => true,
        ),
    ),
    'default'  => 'center top',  
) );

/* pro theme options */

//  animation section 

TechLiteracy_Kirki::add_section( 'animation_section', array(
    'title'          => __( 'Animation','techliteracy_pro' ),
    'description'    => __( 'Animation that affects overall site', 'techliteracy_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );    

TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'animation_effect',
    'label'    => __( 'Enable Animation Effect', 'techliteracy_pro' ),   
    'section'  => 'animation_section',
    'type'     => 'switch',
    'choices' => array(
        'on'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        'off' => esc_attr__( 'Disable', 'techliteracy_pro' ) 
    ),
    'default'  => 'on',
) );

// custom JS section

TechLiteracy_Kirki::add_section( 'custom_js_section', array(
    'title'          => __( 'Custom JS','techliteracy_pro' ),
    'description'    => __( 'Custom JS', 'techliteracy_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
 TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'custom_js',
    'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'techliteracy_pro' ),
    'section'  => 'custom_js_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
) ); 


// Tracking section 

TechLiteracy_Kirki::add_section( 'analytics_section', array(
    'title'          => __( 'Tracking Code','techliteracy_pro' ),
    'description'    => __( 'Tracking Code', 'techliteracy_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'analytics',
    'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'techliteracy_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'code',  
    'choices'     => array(
        'language' => 'javascript',  
        'theme'    => 'monokai',
        'height'   => 250, 
    ), 
    'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'analytics_place',
    'label'    => __( 'Enable to Load Tracking Code in Footer', 'techliteracy_pro' ),
    'section'  => 'analytics_section',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        '2' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => '2',
    'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','techliteracy_pro'),
) );


//  lightbox section //

TechLiteracy_Kirki::add_section( 'light_box', array(
    'title'          => __( 'Light Box','techliteracy_pro' ),
    'description'    => __( 'Light Box Settings', 'techliteracy_pro'),
    'panel'          => 'general_panel', // Not typically needed.
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'lightbox_theme',
    'label'    => __( 'Lightbox Theme', 'techliteracy_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        '1' => esc_attr__( 'pp_default', 'techliteracy_pro' ),
        '2' => esc_attr__( 'light-rounded', 'techliteracy_pro' ),
        '3' => esc_attr__( 'dark-rounded', 'techliteracy_pro' ),
        '4' => esc_attr__( 'light-square', 'techliteracy_pro' ),
        '5' => esc_attr__( 'dark-square', 'techliteracy_pro' ),
        '6' => esc_attr__( 'facebook', 'techliteracy_pro' ),
    ),
    'default'  => '1',
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'lightbox_animation_speed',
    'label'    => __( 'Animation Speed', 'techliteracy_pro' ),
    'section'  => 'light_box',
    'type'     => 'select',
    'multiple'    => 1,
    'choices'     => array(
        'fast' => esc_attr__( 'Fast', 'techliteracy_pro' ),
        'slow' => esc_attr__( 'Slow', 'techliteracy_pro' ),
        'normal' => esc_attr__( 'Normal', 'techliteracy_pro' ),
    ),
    'default'  => 'fast',
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'lightbox_slideshow',
    'label'    => __( 'Autoplay Gallery Speed', 'techliteracy_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 100,
        'step' => 10,
    ),
    'default'  => 50,
    'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'lightbox_autoplay_slideshow',
    'label'    => __( 'Enable Autoplay Gallery', 'techliteracy_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array(
        '1'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        '2' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => '2',
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'lightbox_opacity',
    'label'    => __( 'Select Background Opacity', 'techliteracy_pro' ),
    'section'  => 'light_box',
    'type'     => 'number',
    'choices'     => array(
        'min'  => 0,
        'max'  => 1,
        'step' => 0.1,
    ),
    'default'  => 0.5,
    'tooltip' => __('Enter 0.1 to 1.0','techliteracy_pro'),
) );
TechLiteracy_Kirki::add_field( 'techliteracy_pro', array(
    'settings' => 'lightbox_overlay_gallery',
    'label'    => __( 'Show Gallery Thumbnails', 'techliteracy_pro' ),
    'section'  => 'light_box',
    'type'     => 'switch',
    'choices' => array( 
        '1'  => esc_attr__( 'Enable', 'techliteracy_pro' ),
        '2' => esc_attr__( 'Disable', 'techliteracy_pro' )
    ),
    'default'  => '1',
) );


 

         
do_action('techliteracy_pro_child_customizer_options');
