<?php
/**
 * Internationalization helper.
 *
 * @package     Kirki
 * @category    Core
 * @author      Aristeides Stathopoulos
 * @copyright   Copyright (c) 2016, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/https://opensource.org/licenses/MIT
 * @since       1.0
 */

if ( ! class_exists( 'Kirki_l10n' ) ) {

	/**
	 * Handles translations
	 */
	class Kirki_l10n {

		/**
		 * The plugin textdomain
		 *
		 * @access protected
		 * @var string
		 */
		protected $textdomain = 'techliteracy_pro';

		/**
		 * The class constructor.
		 * Adds actions & filters to handle the rest of the methods.
		 *
		 * @access public
		 */
		public function __construct() {

			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		}

		/**
		 * Load the plugin textdomain
		 *
		 * @access public
		 */
		public function load_textdomain() {

			if ( null !== $this->get_path() ) {
				load_textdomain( $this->textdomain, $this->get_path() );
			}
			load_plugin_textdomain( $this->textdomain, false, Kirki::$path . '/languages' );

		}

		/**
		 * Gets the path to a translation file.
		 *
		 * @access protected
		 * @return string Absolute path to the translation file.
		 */
		protected function get_path() {
			$path_found = false;
			$found_path = null;
			foreach ( $this->get_paths() as $path ) {
				if ( $path_found ) {
					continue;
				}
				$path = wp_normalize_path( $path );
				if ( file_exists( $path ) ) {
					$path_found = true;
					$found_path = $path;
				}
			}

			return $found_path;

		}

		/**
		 * Returns an array of paths where translation files may be located.
		 *
		 * @access protected
		 * @return array
		 */
		protected function get_paths() {

			return array(
				WP_LANG_DIR . '/' . $this->textdomain . '-' . get_locale() . '.mo',
				Kirki::$path . '/languages/' . $this->textdomain . '-' . get_locale() . '.mo',
			);

		}

		/**
		 * Shortcut method to get the translation strings
		 *
		 * @static
		 * @access public
		 * @param string $config_id The config ID. See Kirki_Config.
		 * @return array
		 */
		public static function get_strings( $config_id = 'global' ) {

			$translation_strings = array(
				'background-color'      => esc_attr__( 'Background Color', 'techliteracy_pro' ),
				'background-image'      => esc_attr__( 'Background Image', 'techliteracy_pro' ),
				'no-repeat'             => esc_attr__( 'No Repeat', 'techliteracy_pro' ),
				'repeat-all'            => esc_attr__( 'Repeat All', 'techliteracy_pro' ),
				'repeat-x'              => esc_attr__( 'Repeat Horizontally', 'techliteracy_pro' ),
				'repeat-y'              => esc_attr__( 'Repeat Vertically', 'techliteracy_pro' ),
				'inherit'               => esc_attr__( 'Inherit', 'techliteracy_pro' ),
				'background-repeat'     => esc_attr__( 'Background Repeat', 'techliteracy_pro' ),
				'cover'                 => esc_attr__( 'Cover', 'techliteracy_pro' ),
				'contain'               => esc_attr__( 'Contain', 'techliteracy_pro' ),
				'background-size'       => esc_attr__( 'Background Size', 'techliteracy_pro' ),
				'fixed'                 => esc_attr__( 'Fixed', 'techliteracy_pro' ),
				'scroll'                => esc_attr__( 'Scroll', 'techliteracy_pro' ),
				'background-attachment' => esc_attr__( 'Background Attachment', 'techliteracy_pro' ),
				'left-top'              => esc_attr__( 'Left Top', 'techliteracy_pro' ),
				'left-center'           => esc_attr__( 'Left Center', 'techliteracy_pro' ),
				'left-bottom'           => esc_attr__( 'Left Bottom', 'techliteracy_pro' ),
				'right-top'             => esc_attr__( 'Right Top', 'techliteracy_pro' ),
				'right-center'          => esc_attr__( 'Right Center', 'techliteracy_pro' ),
				'right-bottom'          => esc_attr__( 'Right Bottom', 'techliteracy_pro' ),
				'center-top'            => esc_attr__( 'Center Top', 'techliteracy_pro' ),
				'center-center'         => esc_attr__( 'Center Center', 'techliteracy_pro' ),
				'center-bottom'         => esc_attr__( 'Center Bottom', 'techliteracy_pro' ),
				'background-position'   => esc_attr__( 'Background Position', 'techliteracy_pro' ),
				'background-opacity'    => esc_attr__( 'Background Opacity', 'techliteracy_pro' ),
				'on'                    => esc_attr__( 'ON', 'techliteracy_pro' ),
				'off'                   => esc_attr__( 'OFF', 'techliteracy_pro' ),
				'all'                   => esc_attr__( 'All', 'techliteracy_pro' ),
				'cyrillic'              => esc_attr__( 'Cyrillic', 'techliteracy_pro' ),
				'cyrillic-ext'          => esc_attr__( 'Cyrillic Extended', 'techliteracy_pro' ),
				'devanagari'            => esc_attr__( 'Devanagari', 'techliteracy_pro' ),
				'greek'                 => esc_attr__( 'Greek', 'techliteracy_pro' ),
				'greek-ext'             => esc_attr__( 'Greek Extended', 'techliteracy_pro' ),
				'khmer'                 => esc_attr__( 'Khmer', 'techliteracy_pro' ),
				'latin'                 => esc_attr__( 'Latin', 'techliteracy_pro' ),
				'latin-ext'             => esc_attr__( 'Latin Extended', 'techliteracy_pro' ),
				'vietnamese'            => esc_attr__( 'Vietnamese', 'techliteracy_pro' ),
				'hebrew'                => esc_attr__( 'Hebrew', 'techliteracy_pro' ),
				'arabic'                => esc_attr__( 'Arabic', 'techliteracy_pro' ),
				'bengali'               => esc_attr__( 'Bengali', 'techliteracy_pro' ),
				'gujarati'              => esc_attr__( 'Gujarati', 'techliteracy_pro' ),
				'tamil'                 => esc_attr__( 'Tamil', 'techliteracy_pro' ),
				'telugu'                => esc_attr__( 'Telugu', 'techliteracy_pro' ),
				'thai'                  => esc_attr__( 'Thai', 'techliteracy_pro' ),
				'serif'                 => _x( 'Serif', 'font style', 'techliteracy_pro' ),
				'sans-serif'            => _x( 'Sans Serif', 'font style', 'techliteracy_pro' ),
				'monospace'             => _x( 'Monospace', 'font style', 'techliteracy_pro' ),
				'font-family'           => esc_attr__( 'Font Family', 'techliteracy_pro' ),
				'font-size'             => esc_attr__( 'Font Size', 'techliteracy_pro' ),
				'font-weight'           => esc_attr__( 'Font Weight', 'techliteracy_pro' ),
				'line-height'           => esc_attr__( 'Line Height', 'techliteracy_pro' ),
				'font-style'            => esc_attr__( 'Font Style', 'techliteracy_pro' ),
				'letter-spacing'        => esc_attr__( 'Letter Spacing', 'techliteracy_pro' ),
				'top'                   => esc_attr__( 'Top', 'techliteracy_pro' ),
				'bottom'                => esc_attr__( 'Bottom', 'techliteracy_pro' ),
				'left'                  => esc_attr__( 'Left', 'techliteracy_pro' ),
				'right'                 => esc_attr__( 'Right', 'techliteracy_pro' ),
				'center'                => esc_attr__( 'Center', 'techliteracy_pro' ),
				'justify'               => esc_attr__( 'Justify', 'techliteracy_pro' ),
				'color'                 => esc_attr__( 'Color', 'techliteracy_pro' ),
				'add-image'             => esc_attr__( 'Add Image', 'techliteracy_pro' ),
				'change-image'          => esc_attr__( 'Change Image', 'techliteracy_pro' ),
				'no-image-selected'     => esc_attr__( 'No Image Selected', 'techliteracy_pro' ),
				'add-file'              => esc_attr__( 'Add File', 'techliteracy_pro' ),
				'change-file'           => esc_attr__( 'Change File', 'techliteracy_pro' ),
				'no-file-selected'      => esc_attr__( 'No File Selected', 'techliteracy_pro' ),
				'remove'                => esc_attr__( 'Remove', 'techliteracy_pro' ),
				'select-font-family'    => esc_attr__( 'Select a font-family', 'techliteracy_pro' ),
				'variant'               => esc_attr__( 'Variant', 'techliteracy_pro' ),
				'subsets'               => esc_attr__( 'Subset', 'techliteracy_pro' ),
				'size'                  => esc_attr__( 'Size', 'techliteracy_pro' ),
				'height'                => esc_attr__( 'Height', 'techliteracy_pro' ),
				'spacing'               => esc_attr__( 'Spacing', 'techliteracy_pro' ),
				'ultra-light'           => esc_attr__( 'Ultra-Light 100', 'techliteracy_pro' ),
				'ultra-light-italic'    => esc_attr__( 'Ultra-Light 100 Italic', 'techliteracy_pro' ),
				'light'                 => esc_attr__( 'Light 200', 'techliteracy_pro' ),
				'light-italic'          => esc_attr__( 'Light 200 Italic', 'techliteracy_pro' ),
				'book'                  => esc_attr__( 'Book 300', 'techliteracy_pro' ),
				'book-italic'           => esc_attr__( 'Book 300 Italic', 'techliteracy_pro' ),
				'regular'               => esc_attr__( 'Normal 400', 'techliteracy_pro' ),
				'italic'                => esc_attr__( 'Normal 400 Italic', 'techliteracy_pro' ),
				'medium'                => esc_attr__( 'Medium 500', 'techliteracy_pro' ),
				'medium-italic'         => esc_attr__( 'Medium 500 Italic', 'techliteracy_pro' ),
				'semi-bold'             => esc_attr__( 'Semi-Bold 600', 'techliteracy_pro' ),
				'semi-bold-italic'      => esc_attr__( 'Semi-Bold 600 Italic', 'techliteracy_pro' ),
				'bold'                  => esc_attr__( 'Bold 700', 'techliteracy_pro' ),
				'bold-italic'           => esc_attr__( 'Bold 700 Italic', 'techliteracy_pro' ),
				'extra-bold'            => esc_attr__( 'Extra-Bold 800', 'techliteracy_pro' ),
				'extra-bold-italic'     => esc_attr__( 'Extra-Bold 800 Italic', 'techliteracy_pro' ),
				'ultra-bold'            => esc_attr__( 'Ultra-Bold 900', 'techliteracy_pro' ),
				'ultra-bold-italic'     => esc_attr__( 'Ultra-Bold 900 Italic', 'techliteracy_pro' ),
				'invalid-value'         => esc_attr__( 'Invalid Value', 'techliteracy_pro' ),
				'add-new'           	=> esc_attr__( 'Add new', 'techliteracy_pro' ),
				'row'           		=> esc_attr__( 'row', 'techliteracy_pro' ),
				'limit-rows'            => esc_attr__( 'Limit: %s rows', 'techliteracy_pro' ),
				'open-section'          => esc_attr__( 'Press return or enter to open this section', 'techliteracy_pro' ),
				'back'                  => esc_attr__( 'Back', 'techliteracy_pro' ),
				'reset-with-icon'       => sprintf( esc_attr__( '%s Reset', 'techliteracy_pro' ), '<span class="dashicons dashicons-image-rotate"></span>' ),
				'text-align'            => esc_attr__( 'Text Align', 'techliteracy_pro' ),
				'text-transform'        => esc_attr__( 'Text Transform', 'techliteracy_pro' ),
				'none'                  => esc_attr__( 'None', 'techliteracy_pro' ),
				'capitalize'            => esc_attr__( 'Capitalize', 'techliteracy_pro' ),
				'uppercase'             => esc_attr__( 'Uppercase', 'techliteracy_pro' ),
				'lowercase'             => esc_attr__( 'Lowercase', 'techliteracy_pro' ),
				'initial'               => esc_attr__( 'Initial', 'techliteracy_pro' ),
				'select-page'           => esc_attr__( 'Select a Page', 'techliteracy_pro' ),
				'open-editor'           => esc_attr__( 'Open Editor', 'techliteracy_pro' ),
				'close-editor'          => esc_attr__( 'Close Editor', 'techliteracy_pro' ),
				'switch-editor'         => esc_attr__( 'Switch Editor', 'techliteracy_pro' ),
				'hex-value'             => esc_attr__( 'Hex Value', 'techliteracy_pro' ),
			);

			// Apply global changes from the kirki/config filter.
			// This is generally to be avoided.
			// It is ONLY provided here for backwards-compatibility reasons.
			// Please use the kirki/{$config_id}/l10n filter instead.
			$config = apply_filters( 'kirki/config', array() );
			if ( isset( $config['i18n'] ) ) {
				$translation_strings = wp_parse_args( $config['i18n'], $translation_strings );
			}

			// Apply l10n changes using the kirki/{$config_id}/l10n filter.
			return apply_filters( 'kirki/' . $config_id . '/l10n', $translation_strings );

		}
	}
}
