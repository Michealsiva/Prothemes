<?php

	/**
	 * Created by PhpStorm.
	 * User: venkat
	 * Date: 26/11/15
	 * Time: 11:10 AM
	 */
if( ! class_exists( 'TechLiteracy_Pro_Theme_templates' ) ) {  
	class TechLiteracy_Pro_Theme_templates {

      
        public function techliteracy_pro_heading_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/heading.php';   
        }
        public function techliteracy_pro_iconbox_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/icon-box.php';   
        }
        public function techliteracy_pro_recentpost_template_file( $filename, $instance, $widget  ) {
            return get_stylesheet_directory() . '/pro/framework-customization/widgets/recentpost.php';   
        }
 
	}
}

         
