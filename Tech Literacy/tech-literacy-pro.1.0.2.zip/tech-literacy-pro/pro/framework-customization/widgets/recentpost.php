<?php

    $output = '';
		$output .= '<div class="recent-posts-wrapper">';

		switch( $type ) {
			case 'normal':
				$output .= '<div class="recent-posts">';
				break;
			case 'slider' :
				$output .= '<div class="recent-posts-slider clearfix">';
				break;
			case 'carousel' :
				$output .= '<div class="recent-posts-carousel">';
				break;
			default:
				$output .= '<div class="recent-posts">';
				break;
		}

		$output .= '<ul class="slides">';


			// WP_Query arguments
			$recent_post_args = array (
				'post_type'              => 'post',
				'category_name'          => $cat,
				'post_status'            => 'publish',
				'posts_per_page'         => $count,
				'ignore_sticky_posts'    => true,
				'order'                  => 'DESC',   
			);

		// The Query
		$query = new WP_Query( apply_filters( 'recent_posts_args', $recent_post_args ) );

		// The Loop
		if ( $query->have_posts() ) {
	        while ( $query->have_posts() ) {
				$query->the_post();	
				if( $type == 'normal' ) {	
					$output .= '<div class="one-third column latest-post-wrapper">';
					$output .= '<div class="latest-post clearfix">';
							$output .= '<div class="latest-post-thumb"><a href="'. esc_url(get_permalink()) . '">'; 
									if ( has_post_thumbnail() ) {
										$output .= get_the_post_thumbnail($query->post->ID ,'tech-literacy-recent-posts-img');
									}
									else {
										$output .= '<img src="' . esc_url(get_stylesheet_directory_uri()) . '/images/no-image.png" alt="" >';
									} 
							$output .= '</a></div><!-- .latest-post-thumb -->';
							$output .= '<div class="latest-post-content-wrapper">';
							  $output .= '<h6><a href="'. esc_url(get_permalink()) . '">' . get_the_title() . '</a></h6>';
								/*$output .= '<div class="latest-post-content">' . get_the_content() . '</div>';
								$output .='<div class="entry-meta">';
									$output .='<span class="data-structure"><h2 class="dd">' . get_the_time('j').'</h2><span class="month">' . get_the_time('F').'</span></span>';
									//$output .= tech_literacy_get_author();
									//$output .= tech_literacy_get_comments_meta();
								$output .='</div><!-- entry-meta -->';*/
							$output .= '</div><!-- .latest-post-content-wrapper -->';
				    $output .= '</div>';	
					$output .= '</div><!-- .latest-post -->';
				}elseif( $type == 'carousel' ) {
				        $output .= '<li>';
						$output .= '<div class="latest-post clearfix">';
							$output .= '<div class="latest-post-thumb"><a href="'. esc_url(get_permalink()) . '">'; 
									if ( has_post_thumbnail() ) {
										$output .= get_the_post_thumbnail($query->post->ID ,'tech-literacy-recent-posts-img');
									}
									else {
										$output .= '<img src="' . esc_url(get_stylesheet_directory_uri()) . '/images/no-image.png" alt="" >';
									} 
							$output .= '</a></div><!-- .latest-post-thumb -->';
							$output .= '<div class="latest-post-content-wrapper">';
							  $output .= '<h6><a href="'. esc_url(get_permalink()) . '">' . get_the_title() . '</a></h6>';
								/*$output .= '<div class="latest-post-content">' . get_the_content() . '</div>';
								$output .='<div class="entry-meta">';
									$output .='<span class="data-structure"><h2 class="dd">' . get_the_time('j').'</h2><span class="month">' . get_the_time('F').'</span></span>';
									//$output .= tech_literacy_get_author();
									//$output .= tech_literacy_get_comments_meta();
								$output .='</div><!-- entry-meta -->';*/
							$output .= '</div><!-- .latest-post-content-wrapper -->';
				    $output .= '</div>';
					$output .= '</li>';
			    }else {
			    	$output .= '<li>';
						$output .= '<div class="latest-post clearfix">';
							$output .= '<div class="slider-post-thumb"><a href="'. esc_url(get_permalink()) . '">'; 
									if ( has_post_thumbnail() ) {
		                                $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $query->post->ID ), array(1200,400) );
										$output .= '<img src="' . $image_url[0] . '">';									}
									else {
										$output .= '<img src="' . esc_url(get_stylesheet_directory_uri()) . '/images/no-image.png" alt="" >';
									} 
							$output .= '</a></div><!-- .latest-post-thumb -->';
							$output .= '<div class="latest-post-content-wrapper">';
							  $output .= '<h6><a href="'. esc_url(get_permalink()) . '">' . get_the_title() . '</a></h6>';
								/*$output .= '<div class="latest-post-content">' . get_the_content() . '</div>';
								$output .='<div class="entry-meta">';
									$output .='<span class="data-structure"><h2 class="dd">' . get_the_time('j').'</h2><span class="month">' . get_the_time('F').'</span></span>';
									//$output .= tech_literacy_get_author();
									//$output .= tech_literacy_get_comments_meta();
								$output .='</div><!-- entry-meta -->';*/
							$output .= '</div><!-- .latest-post-content-wrapper -->';
				    $output .= '</div>';
						
						$output .= '</li>';
			    }
			}
		}

		$query = null;

		// Restore original Post Data
		wp_reset_postdata();
		$output .= '</ul>';
		$output .= '</div></div>';
		echo $output; 
