<?php
/*
Widget Name: Latest & Popular Articles
Description: Display Latest & Popular articles
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class TL_Latest_Article_Widget extends SiteOrigin_Widget {
 
	function __construct() {

		parent::__construct(

		// The unique id for your widget.
			'tl-latest-article-widget',

			// The name of the widget for display purposes.
			__('Latest & Popular articles', 'techliteracy_pro'),

			array(
				'description' => __('Display Latest & Popular articles', 'techliteracy_pro'),
				//'help'        => 'https://www.webulousthemes.com/docs/widgets/populat-articles',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			),
            false
		);
	}

	function initialize_form() {
		return array(
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Title', 'techliteracy_pro' )
			),
			'article_type' => array(  
				'type' => 'select',
				'label' => __('Latest Product Type', 'techliteracy_pro'),
				'default' => 'latest',
				'options' => array(
					'latest' => __( 'Latest', 'techliteracy_pro' ),
					'popular' => __( 'Popular', 'techliteracy_pro' ),
				),
			),
			'article_count' => array(
				'type' => 'number',
				'label' => __('Number of Latest Products to be Display', 'techliteracy_pro'),
			),

			'order' => array(
				'type' => 'select',
				'label' => __('Order', 'techliteracy_pro'),
				'default' => 'desc',
				'options' => array(
					'asc' => __( 'ASC', 'techliteracy_pro' ),
					'desc' => __( 'DESC', 'techliteracy_pro' ),
				),
			),
		);
	}
	function get_template_variables( $instance, $args ) {  
		return array(
			'title'           => ! empty( $instance['title'] ) ? $instance['title'] : '',
			'article_type'          => ! empty( $instance['article_type'] ) ? $instance['article_type'] : '',
			'article_count' => $instance['article_count'],
			'order' => $instance['order'],
		);
	}
	
	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class TL_Latest_Article_Widget

siteorigin_widget_register('tl-latest-article-widget', __FILE__, 'TL_Latest_Article_Widget');