<?php
/**
 * @var $title
 * @var $article_type
 * @var $article_count
 * @var $order
 */
 
if ( ! empty( $title ) ) {
	echo $before_title. '<h4 class="widget-title">' . esc_html( $title ) . '</h4>'. $after_title; 
}

	//WP Query args

	$query_args = array (
	    'posts_per_page'         => $article_count,
        'post_type'              => 'post',
        'post_status'            => 'publish',
        'ignore_sticky_posts'    => true,
	    'order'                  => $order,
	    
	);

	if( $article_type == 'popular' ) {
		$query_args['orderby'] ='comment_count';
	}



	// The Query
	$latest_query = new WP_Query( apply_filters( 'latest_query_args', $query_args) ); ?>

		<ul class="latest-article clearfix"><?php 
			if ( $latest_query->have_posts() ) {
				while ( $latest_query->have_posts() ) : $latest_query->the_post(); ?>
						<li>
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						</li><?php 
				endwhile;
			}  
			// Reset Post Data
	        wp_reset_postdata(); ?>
		</ul><!--/.products-->