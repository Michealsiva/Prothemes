<?php
/*
Widget Name: Upcoming and Latest Events 
Description: Display Upcoming events
Author: N. Venkat Raj
Author URI: https://www.webulousthemes.com
Widget URI: todo
Video URI: todo
*/
class Finrelief_Recent_Events_Widget extends SiteOrigin_Widget {

	function __construct() {  

		parent::__construct(

		// The unique id for your widget.
			'finrelief-recent-events-widget',

			// The name of the widget for display purposes.
			__('Upcoming Events', 'framework'),   

			array(
				'description' => __('Display Upcoming Events', 'framework'),
				'help'        => 'https://www.webulousthemes.com/docs/widgets/recent-event',
				'has_preview' => false,
			),

			//The $control_options array, which is passed through to WP_Widget
			array(
			)

		);
	}

	function get_widget_form() {
		return 	$form_options = array(
				'title' => array (
					'type' =>'text',
					'label'=>__('Title','framework'),
				),
				'count' => array(
					'type' => 'number',
					'label' => __( 'Recent Post Count', 'framework' ),
					'default' => 6,
				),
		);
	}
 

	function get_template_variables( $instance, $args ) {
		return array(
			'title' => ! empty( $instance['title'] ) ? $instance['title'] : '',
			'count' => ! empty( $instance['count'] ) ? $instance['count'] : 5 ,
		);
	}

	function get_template_name($instance) {
		return 'default';
	}

	function get_style_name($instance) {
		return '';
	}

} // class Accordion_Widget

siteorigin_widget_register('finrelief-recent-events-widget', __FILE__, 'Finrelief_Recent_Events_Widget');