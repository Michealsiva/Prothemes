<?php
if ( ! empty( $title ) ) {
	echo $args['before_title'] . esc_html( $title ) . $args['after_title']; 
} ?>
    
		<div class="ec-recent-events-wrapper">

		<ul class="ec-events-list clearfix"> <?php
 

			// WP_Query arguments
			$recent_post_args = array (
				'post_type'              => 'tribe_events',
				'post_status'            => 'publish',
				'posts_per_page'         => $count,
			);

		// The Query
		$query = new WP_Query( apply_filters( 'recent_events_args', $recent_post_args ) );

		// The Loop
		if ( $query->have_posts() ) { 
			while ( $query->have_posts() ) {  
				$query->the_post();	
				if( class_exists('Tribe__Events__Main') ) {	
					$start_date = tribe_get_start_date( $query->post->ID , true, 'j' );
					$start_month = tribe_get_start_date( $query->post->ID , true, 'M' );
					$event_date = tribe_events_event_schedule_details($query->post->ID);
					$venue_id = get_post_meta( $query->post->ID, '_EventVenueID', true );
					$event_city = get_post_meta( $venue_id, '_VenueCity', true );
					$event_country = get_post_meta( $venue_id, '_VenueCountry', true );
					$event_details = Tribe__Events__API::get_and_flatten_event_meta($query->post->ID); 
		            //echo '<pre>',print_r($event_details),'</pre>'; ?>
			        <div class="eight columns">
						<div class="event-charity-wrapper clearfix">
							<div class="ec-start-date-wrapper">
								<?php echo '<span class="ec-start-date">'. $start_date .'</span><br>' . $start_month; ?>
							</div>
							<div class="ec-content">
							   	<h5><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h5>
			                    <p><i class="fa fa-clock-o"></i><?php echo $event_date; ?></p>
			                    <p><i class="fa fa-map-marker"></i><?php echo $event_city.' , '.$event_country; ?></p>
							</div>
						</div>
				    </div><?php
				}
			}
		}

		$query = null;

		// Restore original Post Data
		wp_reset_postdata(); ?>
		</ul>
		</div>
