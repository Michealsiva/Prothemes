<?php


/**
 * Integrates this theme with SiteOrigin Page Builder.
 *
 * @package finrelief Pro
 * @since 1.0
 * @license GPL 2.0   
 */
    

/**    
 * Adds default page layouts
 *
 * Adds default page layouts to SiteOrigin Page Builder prebuilt layout section
 *
 * @param $layouts        
 */
if ( ! class_exists('FinRelief_Pro_Prebuilt_Layouts')) { 

    class FinRelief_Pro_Prebuilt_Layouts { 
        public function layouts($layouts) {     
           $layouts['default-home'] = array ( 
				'name' => __('FinRelief Pro Home', 'finrelief_pro'),
				'description' => __('Pre Built Layout for  home page', 'finrelief_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/home.json',

			);

			$layouts['about-us'] = array(
				'name' => __('About Us Page', 'finrelief_pro'),
				'description' => __( 'Pre Built layout for about us page', 'finrelief_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/about-us.json',
			);

			$layouts['contact-us'] = array(
				'name' => __('Contact Us Page', 'finrelief_pro'),
				'description' => __( 'Pre Built layout for contact us page', 'finrelief_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/contact-us.json',
			);

			$layouts['faq'] = array (
				'name' => __('FAQ Page', 'finrelief_pro'),
				'description' => __('Pre Built Layout for faq page', 'finrelief_pro'),
				'filename' => get_template_directory() . '/pro/prebuilt/faq.json',
			);
    		return $layouts; 
        }     

    }

}


