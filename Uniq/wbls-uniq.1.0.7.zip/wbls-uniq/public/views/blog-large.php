<?php 
/*
	Template Name: Blog Large 
 */
 	get_header();
get_template_part('breadcrumb'); ?>
	      	   

	<div id="content" class="site-content">
		<div class="container">
		<?php do_action('wbls_uniq_two_sidebar_left'); ?>

		
		<div id="primary" class="content-area <?php wbls_uniq_layout_class(); ?> columns">

			<main id="main" class="site-main blog-content" role="main">

				<?php
					$query_string ="post_type=post&paged=$paged";
					query_posts($query_string);
					$num_of_posts = $wp_query->post_count;
				?>		
					
<?php if ( have_posts() ) : ?>
<?php /* Start the Loop */ ?>
	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<div class="entry-content">        
			<?php	$featured_image = get_theme_mod('featured_image',true); 
			     if( $featured_image ) : ?>    
					<div class="thumb blog-thumb">
						<?php
							if( function_exists( 'wbls_uniq_featured_image' ) ) :
							wbls_uniq_featured_image();
	        endif;
		  ?>
					</div>
				<?php endif; ?>

				  	    <div class="entry-body">
								<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1>
								<header class="entry-header">
									<?php if ( 'post' == get_post_type() ) : // Hide category and tag text for pages on Search ?>
										<span class="posted-on">
				  							<span class="dd"><?php the_time('j') ?></span><br>
											<span class="mm-yy"><?php the_time('M Y') ?></span>
										</span>
										<?php if ( get_theme_mod('enable_single_post_top_meta',true ) ): ?>
										<div class="entry-meta">
											<?php if(function_exists('wbls_uniq_entry_top_meta') ) {
							     wbls_uniq_entry_top_meta();
							} ?>
										</div><!-- .entry-meta -->
									<?php endif;?>
									<?php endif; ?>
									<br class="clear">
								</header><!-- .entry-header -->
								<div class="entry-content">
				<?php echo '<div class="blog-content">' . get_the_content('Readmore','wbls-uniq') . '</div>'; ?>
			</div>
			<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
				<footer class="entry-footer">
						<?php if(function_exists('wbls_uniq_entry_bottom_meta') ) {
							     wbls_uniq_entry_bottom_meta();
							} ?>
				</footer><!-- .entry-footer -->
			<?php endif;?>			
		</div>	
				<?php
					wp_link_pages( array(
						'before' => '<div class="page-links">' . __( 'Pages:', 'wbls-uniq' ),
						'after'  => '</div>',
					) );
				?>
					
			</div><!-- .entry-content -->
			
		</article><!-- #post-## -->
     <?php endwhile; ?>

		<?php 
			if(  get_theme_mod ('numeric_pagination',true) && function_exists( 'wbls_uniq_pagination' ) ) : 
					wbls_uniq_pagination();
				else :
					wbls_uniq_posts_nav();     
				endif; 
		?>

		<?php else : ?>

			<?php get_template_part( 'content', 'none' ); ?>

		<?php endif; ?>   

		</main><!-- #main -->
	</div><!-- #primary -->

	<?php do_action('wbls_uniq_two_sidebar_right'); ?>


<?php get_footer(); ?>