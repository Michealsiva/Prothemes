<?php 
/*
	Template Name: Blog Full Width
 */
 	get_header();
?>
	<div class="breadcrumb-wrap">
		<div class="container">
			<div class="ten columns">
				<header class="entry-header">
					<h1 class="entry-title"><?php the_title(); ?></h1>
				</header><!-- .entry-header -->				
			</div>
			<div class="six columns">
				<?php $breadcrumb = get_theme_mod( 'breadcrumb',true ); 
				if( $breadcrumb ) : ?>
					<div id="breadcrumb" role="navigation">
						<?php wbls_uniq_breadcrumbs(); ?>    
					</div>
				<?php else:  ?>         
					&nbsp;
				<?php endif; ?>
			</div>
			
		</div>
	</div>    	   

	<?php do_action('uniq_before_content'); ?>

	<div id="content" class="site-content container">

		<div id="primary" class="content-area sixteen columns">

			<main id="main" class="site-main" role="main">

				<?php
					$query_string ="post_type=post&paged=$paged";
					query_posts($query_string);
					$num_of_posts = $wp_query->post_count;
				?>		
					
<?php if ( have_posts() ) : ?>
<?php /* Start the Loop */ ?>
	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<div class="entry-content-wrap">        
			<?php	$featured_image = get_theme_mod('featured_image',true); 
			     if( $featured_image ) : ?>    
					<div class="thumb blog-thumb">
							<?php if( has_post_thumbnail() && ! post_password_required() ) :   
									the_post_thumbnail('wbls-uniq-blog-full-width'); 							
								endif;
						?>
					</div>
				<?php endif; ?>

				<div class="entry-body">
					<h1 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title( '', '' ); ?></a></h1>
					<header class="entry-header">
						<?php if ( 'post' == get_post_type() ) : // Hide category and tag text for pages on Search ?>
							<span class="posted-on">
								<span class="dd"><?php the_time('j') ?></span><br>
								<span class="mm-yy"><?php the_time('M Y') ?></span>
							</span>
							<?php if ( get_theme_mod('enable_single_post_top_meta',true ) ): ?>
							<div class="entry-meta">
								<?php if(function_exists('wbls_uniq_entry_top_meta') ) {
							     wbls_uniq_entry_top_meta();
							} ?>
							</div><!-- .entry-meta -->
							<?php endif;?>
						<?php endif; ?>
						<br class="clear">
					</header><!-- .entry-header -->
					<div class="entry-content">
				<?php echo '<div class="blog-content">' . get_the_content('Readmore','wbls-uniq') . '</div>'; ?>
			</div>
		<?php if ( get_theme_mod('enable_single_post_bottom_meta', true ) ): ?>
				<footer class="entry-footer">
				<?php if(function_exists('wbls_uniq_entry_bottom_meta') ) {
				     wbls_uniq_entry_bottom_meta();
				} ?>
				</footer><!-- .entry-footer -->
			<?php endif;?>			
		</div>
				<?php
					wp_link_pages( array(
						'before' => '<div class="page-links">' . __( 'Pages:', 'wbls-uniq' ),
						'after'  => '</div>',
					) );
				?>
			</div><!-- .entry-content -->
			
		</article><!-- #post-## -->
     <?php endwhile; ?>

		<?php 
			if(  get_theme_mod ('numeric_pagination',true) && function_exists( 'wbls_uniq_pagination' ) ) : 
					wbls_uniq_pagination();
				else :
					wbls_uniq_posts_nav();     
				endif; 
		?>

		<?php else : ?>

			<?php get_template_part( 'content', 'none' ); ?>

		<?php endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->
	</div>
		
<?php get_footer(); ?>