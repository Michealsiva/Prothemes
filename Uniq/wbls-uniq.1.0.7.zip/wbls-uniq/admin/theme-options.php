<?php
/**
 * Pro customizer options     
 */

add_action('wbls-uniq_pro_customizer_options','pro_customizer_options');

function pro_customizer_options() { 
    
 
// pro home page section 

		Uniq_Kirki::add_section( 'pro_home_section', array(
			'title'          => __( 'Pro: Use Page Builder','wbls-uniq' ),
			'description'    => __( 'Use Page Builder in order to set the custom pro home page design', 'wbls-uniq'),
			'panel'          => 'home_options', // Not typically needed. 
			'priority'     => 9,
		) );

		Uniq_Kirki::add_field( 'uniq', array(
			'settings' => 'page-builder',
			'label'    => __( 'Use Page Builder', 'wbls-uniq' ),
			'section'  => 'pro_home_section',
			'type'     => 'switch',
			'choices' => array(
				'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
				'off' => esc_attr__( 'Disable', 'wbls-uniq' )
			),
			'tooltip' => __('Check this to disable theme options for home page content and use page builder to enter content','wbls-uniq'),
			'default'  => 'off',
		) );
		Uniq_Kirki::add_field( 'uniq', array(
			'settings' => 'flexslider',
			'label'    => __( 'Enter FlexSlider shortcode (FlexSlider for Home Page)', 'wbls-uniq' ),
			'section'  => 'pro_home_section',
			'type'     => 'text',
			'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-uniq'),
			'active_callback' => array(
				array(
					'setting'  => 'page-builder',
					'operator' => '==',
					'value'    => true,
				),
	        ),
	        'description' => __('FlexSlider for Home Page. Create Flexsldier ( Goto Dashboard => Flex Sliders => Add New Slide ) and  Enter a FlexSlider shortcode  to be displayed on Home Page','wbls-uniq'),
		) );

//  animation section 

Uniq_Kirki::add_section( 'animation_section', array(
	'title'          => __( 'Animation','wbls-uniq' ),
	'description'    => __( 'Animation that affects overall site', 'wbls-uniq'),
	'panel'          => 'general_panel', // Not typically needed.
) );  

Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'animation_effect',
	'label'    => __( 'Enable Animation Effect', 'wbls-uniq' ),   
	'section'  => 'animation_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' ) 
	),
	'default'  => 'on',
) );

// custom JS section

Uniq_Kirki::add_section( 'custom_js_section', array(
	'title'          => __( 'Custom JS','wbls-uniq' ),
	'description'    => __( 'Custom JS', 'wbls-uniq'),
	'panel'          => 'general_panel', // Not typically needed.
) );
 Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'custom_js',
	'label'    => __( 'Custom Javascript: Quickly add some Javascript to your theme by adding it to this block.  Validate that it\'s javascript!', 'wbls-uniq' ),
	'section'  => 'custom_js_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ),
) ); 


// Tracking section 

Uniq_Kirki::add_section( 'analytics_section', array(
	'title'          => __( 'Tracking Code','wbls-uniq' ),
	'description'    => __( 'Tracking Code', 'wbls-uniq'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'analytics',
	'label'    => __( 'Tracking Code :Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. Validate that it\'s javascript!', 'wbls-uniq' ),
	'section'  => 'analytics_section',
	'type'     => 'code',  
    'choices'     => array(
      'language' => 'javascript',  
      'theme'    => 'monokai',
      'height'   => 250,
    ),
	'tooltip' => __('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme. <b>Validate that it\'s javascript!</b>','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'analytics_place',
	'label'    => __( 'Enable to Load Tracking Code in Footer', 'wbls-uniq' ),
	'section'  => 'analytics_section',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'2' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => '2',
	'tooltip' => __('Check to load analytics in footer. Uncheck to load in header.','wbls-uniq'),
) );

// color scheme section 

Uniq_Kirki::add_section( 'multiple_color_section', array(
	'title'          => __( 'Color Scheme','wbls-uniq' ),
	'description'    => __( 'Select your color scheme', 'wbls-uniq'),
	'panel'          => 'skin_color_panel', // Not typically needed.
	'priority' => 9,
) );  

Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'color_scheme',
	'label'    => __( 'Select your color scheme', 'wbls-uniq' ),
	'section'  => 'multiple_color_section',
	'type'     => 'palette',
	'choices'     => array(
    '1' => array(
		'#3dad66',
	),
	'11' => array(
		'#3dad66',
	),
	'2' => array(
		'#45b6de',
	),
	'3' => array(
		'#484fe1',
	),
	'4' => array(
		'#ff7e20',
	),
	'5' => array(
		'#d58a62',
	),
	'6' => array(
		'#89b927',
	),
	'7' => array(
		'#de3c2f',
	),
	'8' => array(
		'#f6ac03',
	),
	'9' => array(
		'#db4678',
	),
	'10' => array(
		'#b244ab',
	),
),
'default' => '1',
//'default'  => 'on',
) );

//social network URL
Uniq_Kirki::add_section( 'social_network', array(
	'title'          => __( 'Social Network URL','wbls-uniq' ),
	'description'    => __( 'Enter the link below and Use Social Network widget to display these links in your page.', 'wbls-uniq'),
	'panel'			 => 'social_panel',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'digg',
	'label'    => __( 'Digg', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Digg link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'dribbble',
	'label'    => __( 'Dribbble', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Dribbble link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'facebook',
	'label'    => __( 'Facebook', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Facebook link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'twitter',
	'label'    => __( 'Twitter', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Twitter link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'google_plus',
	'label'    => __( 'Google +', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Google Plus link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'linkedin',
	'label'    => __( 'LinkedIn', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your LinkedIn link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'instagram',
	'label'    => __( 'Instagram', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Instagram link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flickr',
	'label'    => __( 'Flickr', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Flickr link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'youtube',
	'label'    => __( 'YouTube', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your YouTube link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'vimeo',
	'label'    => __( 'Vimeo', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Vimeo link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'pinterest',
	'label'    => __( 'Pinterest', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Pinterest link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'rss',
	'label'    => __( 'RSS', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your RSS link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'skype',
	'label'    => __( 'Skype', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Skype link','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'tumblr',
	'label'    => __( 'Tumblr', 'wbls-uniq' ),
	'section'  => 'social_network',
	'type'     => 'text',
	'tooltip' => __('Enter Your Tumblr link','wbls-uniq'),
) );

// flexslider section //

Uniq_Kirki::add_section( 'flex_slider_section', array(
	'title'          => __( 'Flex Slider','wbls-uniq' ),
	'description'    => __( 'Flex Slider Settings', 'wbls-uniq'),
	'panel'          => 'slider_panel', // Not typically needed.
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'slider_type',  
	'label'    => __( 'Select slider position', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Behind Header', 'wbls-uniq' ),
		'2' => esc_attr__( 'Below Header', 'wbls-uniq' )
	),
	'default'  => '1',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'animation',  
	'label'    => __( 'Select slider animation effect', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Fade', 'wbls-uniq' ),
		'2' => esc_attr__( 'Slide', 'wbls-uniq' )
	),
	'default'  => '2',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'slide_direction',
	'label'    => __( 'Select slide direction', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'radio-buttonset',
	'choices' => array(
		'1'  => esc_attr__( 'Horizontal', 'wbls-uniq' ),
		'2' => esc_attr__( 'Vertical', 'wbls-uniq' )
	),
	'default'  => '1',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_slideshow_speed',
	'label'    => __( 'Slideshow Speed', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the delay between each slide animation (in milliseconds)','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'number',
	'choices'     => array(
		'min'  => '0',
		'max'  => '100',
		'step' => '1',
	),
	'default'  => 50,
	'tooltip' => __('Set the duration of each slide animation (in milliseconds)','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_slideshow',
	'label'    => __( 'Enable Animate the slideshows automatically', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => 'on',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_smooth_height',
	'label'    => __( 'Enable to Adjust the height of the slideshow', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Adjust the height of the slideshow to the height of the current slide','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_direction_nav',
	'label'    => __( 'Enable  Display the "Previous/Next" Buttons', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => 'on',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_control_nav',
	'label'    => __( 'Enable Display the slideshow pagination', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => 'on',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_keyboard_nav',
	'label'    => __( 'Enable Keyboard Navigation', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => 'on',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_mousewheel_nav',
	'label'    => __( 'Enable Mouse Wheel Navigation', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => 'off',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_pauseplay',
	'label'    => __( 'Enable Pause / Play event', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => 'off',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_randomize',
	'label'    => __( 'Enable Random Slides', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch', 
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Randomize the order of slides in slideshows','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_animation_loop',
	'label'    => __( 'Enable Loop Slideshow animations', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => 'off',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_pause_on_action',
	'label'    => __( 'Enable Pause On Action while navigation', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => 'on',
	'tooltip' => __('Enable Pause the slideshow autoplay when using the pagination or "Previous/Next" navigation','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_pause_on_hover',
	'label'    => __( 'Enable Pause On Action while hovering the slides', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'switch',
	'choices' => array(
		'on'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'off' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => 'off',
	'tooltip' => __('Enable to Pause the slideshow autoplay when hovering over a slide','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_prev_text',
	'label'    => __( 'The text to display on the "Previous" button', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Prev',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_next_text',
	'label'    => __( 'The text to display on the "Next" button', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Next',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_play_text',
	'label'    => __( 'The text to display on the "Play" button', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Play',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'flexslider_pause_text',
	'label'    => __( 'The text to display on the "Pause" button', 'wbls-uniq' ),
	'section'  => 'flex_slider_section',
	'type'     => 'text',
	'default'  => 'Pause',
) );

// flexcarousel section //
Uniq_Kirki::add_section( 'flex_carousel', array(
	'title'          => __( 'Flex Carousel Slider','wbls-uniq' ),
	'description'    => __( 'Flex Carousel Settings', 'wbls-uniq'),
	'panel'          => 'slider_panel', // Not typically needed.
) ); 
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'carousel_animation_loop',
	'label'    => __( 'Loop through carousel items?', 'wbls-uniq' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'2' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => '2',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'carousel_item_width',
	'label'    => __( 'Carousel item width', 'wbls-uniq' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'default'  => 200,
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'carousel_item_margin',
	'label'    => __( 'Carousel item margin', 'wbls-uniq' ),
	'section'  => 'flex_carousel',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 99999,
		'step' => 1,
	),
	'output'   => array(
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-left',    
			'units' => 'px',    
		),
		array(
			'element'  => '.flexcarousel li',
			'property' => 'margin-right',    
			'units' => 'px',    
		),
	),
	'default'  => 5,
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'carousel_pagination',
	'label'    => __( 'Enable Carousel Pagination', 'wbls-uniq' ),
	'section'  => 'flex_carousel',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'2' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => '2',
) );

//  portfolio settings //

Uniq_Kirki::add_section( 'portfolio_settings', array(
	'title'          => __( 'Portfolio Settings','wbls-uniq' ),
) );

$post_per_page = get_option('posts_per_page');
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'portfolio_two_column_count',
	'label'    => __( 'Portfolio Two column Count', 'wbls-uniq' ),
	'section'  => 'portfolio_settings', 
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 2 Col Portfolio,2 Col Portfolio Sidebar,2 Col Portfolio Text )','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(   
	'settings' => 'portfolio_three_column_count',
	'label'    => __( 'Portfolio Three column Count', 'wbls-uniq' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',   
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	), 
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 3 Col Portfolio,3 Col Portfolio Sidebar,3 Col Portfolio Text )','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'portfolio_four_column_count',
	'label'    => __( 'Portfolio Four column Count', 'wbls-uniq' ),
	'section'  => 'portfolio_settings',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1000,
		'step' => 1,
	),
	'default'  => $post_per_page,
	'tooltip' => __('No. of Items to show  ( This count will reflect the following templates: 4 Col Portfolio,4 Col Portfolio Text )','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'portfolio_filter',
	'label'    => __( 'Show Portfolio Filters', 'wbls-uniq' ),
	'description' => __('Choose to show or hide the portfolio filters.','wbls-uniq'),
	'section'  => 'portfolio_settings',  
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		1 => __( 'Show', 'wbls-uniq' ),
		2 => __( 'Show Without "All"', 'wbls-uniq' ),
		3 => __( 'Hide', 'wbls-uniq' ),
	),
	'default'  => 1,
) );

//  lightbox section //

Uniq_Kirki::add_section( 'light_box', array(
	'title'          => __( 'Light Box','wbls-uniq' ),
	'description'    => __( 'Light Box Settings', 'wbls-uniq'),
	'panel'          => 'general_panel', // Not typically needed.
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'lightbox_theme',
	'label'    => __( 'Lightbox Theme', 'wbls-uniq' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'1' => esc_attr__( 'pp_default', 'wbls-uniq' ),
		'2' => esc_attr__( 'light-rounded', 'wbls-uniq' ),
		'3' => esc_attr__( 'dark-rounded', 'wbls-uniq' ),
		'4' => esc_attr__( 'light-square', 'wbls-uniq' ),
		'5' => esc_attr__( 'dark-square', 'wbls-uniq' ),
		'6' => esc_attr__( 'facebook', 'wbls-uniq' ),
	),
	'default'  => '1',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'lightbox_animation_speed',
	'label'    => __( 'Animation Speed', 'wbls-uniq' ),
	'section'  => 'light_box',
	'type'     => 'select',
	'multiple'    => 1,
	'choices'     => array(
		'fast' => esc_attr__( 'Fast', 'wbls-uniq' ),
		'slow' => esc_attr__( 'Slow', 'wbls-uniq' ),
		'normal' => esc_attr__( 'Normal', 'wbls-uniq' ),
	),
	'default'  => 'fast',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'lightbox_slideshow',
	'label'    => __( 'Autoplay Gallery Speed', 'wbls-uniq' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 100,
		'step' => 10,
	),
	'default'  => 50,
	'tooltip' => __('If autoplay is set to true, select the slideshow speed in ms. (Default: 5000, 1000 ms = 1 second)','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'lightbox_autoplay_slideshow',
	'label'    => __( 'Enable Autoplay Gallery', 'wbls-uniq' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array(
		'1'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'2' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => '2',
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'lightbox_opacity',
	'label'    => __( 'Select Background Opacity', 'wbls-uniq' ),
	'section'  => 'light_box',
	'type'     => 'number',
	'choices'     => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.1,
	),
	'default'  => 0.5,
	'tooltip' => __('Enter 0.1 to 1.0','wbls-uniq'),
) );
Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'lightbox_overlay_gallery',
	'label'    => __( 'Show Gallery Thumbnails', 'wbls-uniq' ),
	'section'  => 'light_box',
	'type'     => 'switch',
	'choices' => array( 
		'1'  => esc_attr__( 'Enable', 'wbls-uniq' ),
		'2' => esc_attr__( 'Disable', 'wbls-uniq' )
	),
	'default'  => '1',
) );
		
/* OVERWRITE CUSTOMIZER COLOR */

Uniq_Kirki::add_field( 'uniq', array(     
	'settings' => 'primary_color',
	'label'    => __( 'Primary color', 'wbls-uniq' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#3DAD66',
	'alpha'  => true,
	'active_callback' => array(
		array (
			'setting'  => 'enable_primary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element'  => 'button:hover,
							input[type="button"]:hover,
							input[type="reset"]:hover,
							input[type="submit"]:hover,button:focus,
							input[type="button"]:focus,
							input[type="reset"]:focus,
							input[type="submit"]:focus,
							button:active,
							input[type="button"]:active,.widget_image-box-widget a.more-button:hover,
							input[type="reset"]:active,
							input[type="submit"]:active,input[type="text"]:focus,
							input[type="email"]:focus,.widget_image-box-widget .image-box img,
							input[type="url"]:focus,.dropcap-box,
							input[type="password"]:focus,.flexslider .flex-caption a:hover,
							input[type="search"]:focus,.our-team:hover .team-content p,
							textarea:focus,ol.comment-list li.byuser article,ol.comment-list li.byuser .comment-author img ',
			'property' => 'border-color',
		),
		array(
			'element'  => '.withtip.left:after ',
			'property' => 'border-left-color',
		),
		array(
			'element'  => ' .withtip.right:after,h3.widget-title:after',
			'property' => 'border-right-color',
		),
		array(
			'element'  => '.branding .site-branding:after,.withtip.top:after',
			'property' => 'border-top-color',
		),
		array(
			'element'  => '.widget-area h4.widget-title,.withtip.bottom:after',
			'property' => 'border-bottom-color',
		),
		array(
			'element'  => 'a:visited,.widget-area ul li a:hover,.stat-container .icon-wrapper .fa,.callout-widget a:hover,.ui-accordion .ui-accordion-header:hover,.site-footer .footer-widgets a:hover,.site-footer .footer-widgets .widget_calendar a,.site-info .widget_nav_menu a:hover,
							.site-info .menu a:hover,.widget_calendar table th a,.tabs-container .ui-tabs-panel ol li,.siteorigin-panels-stretch .widget_recent-work-widget h4 a:hover,
							.wide-pattern-black .widget_recent-work-widget h4 a:hover,.wide-bg .stat-container .icon-wrapper .fa,
							.panel-row-style .stat-container .icon-wrapper .fa,.toggle .toggle-title:hover,.flex-direction-nav a:hover,.breadcrumb-wrap #breadcrumb a,
							.tabs-container .ui-tabs-panel ul li,.siteorigin-panels-stretch .icon-horizontal a.link-title,
							.siteorigin-panels-stretch .icon-horizontal .fa-stack,.content-area .widget_list-widget ul li i, .content-area .widget_list-widget ol li i,
							.siteorigin-panels-stretch .icon-vertical a.link-title,
							.siteorigin-panels-stretch .icon-vertical .fa-stack,
							.wide-pattern-black .icon-horizontal a.link-title,
							.wide-pattern-black .icon-horizontal .fa-stack,.error-404.not-found .page-header .page-title,
							.wide-pattern-black .icon-vertical a.link-title,
							.wide-pattern-black .icon-vertical .fa-stack,.siteorigin-panels-stretch .icon-horizontal a.link-title i,
							.siteorigin-panels-stretch .icon-horizontal .fa-stack i,.related-posts ul#webulous-related-posts li a:hover,
							.siteorigin-panels-stretch .icon-vertical a.link-title i,.entry-body .header-entry-meta,
							.siteorigin-panels-stretch .icon-vertical .fa-stack i,.entry-body .entry-title-meta span:hover,
							.wide-pattern-black .icon-horizontal a.link-title i,
							.wide-pattern-black .icon-horizontal .fa-stack i,.entry-body .entry-title-meta a:hover,
							.wide-pattern-black .icon-vertical a.link-title i,
							.wide-pattern-black .icon-vertical .fa-stack i,.ui-accordion h3:hover span.ui-icon.fa,.widget-area .widget_rss a,.widget_calendar table td a,.comment-metadata a:hover,.hentry.sticky .entry-meta .posted-on a:hover,.hentry.post h1 a:hover,.branding .top-nav ul li a:hover,.branding .top-nav .social ul li a:hover',
			'property' => 'color',
		),
		/*array(
			'element'  => 'th a,
							.site-header .social .recentcomments a,
							.header-wrap .site-header .social .recentcomments a,
							.left-sidebar .recentcomments a,
							.left-sidebar .widget_rss a,
							.ei-title h3,
							#secondary .btn-white:hover,
			  				#secondary .widget_button-widget .btn.white:hover',
			'property' => 'color',
			'suffix' => '!important',
		),*/
		array(
			'element'  => 'button:hover,.circle-icon-box .icon-wrapper p.fa-stack:after, .sep:after,
							input[type="button"]:hover,.flex-direction-nav a.flex-prev:after,.widget_testimonial-widget .flex-control-nav a.flex-active,
							.widget_testimonial-widget .flex-control-nav a:hover,.stat-container .icon-wrapper h4:after,
							.flex-direction-nav a.flex-prev:before,.withtip:before,.wide-bg .stat-container .icon-wrapper h4:after,
							.panel-row-style .stat-container .icon-wrapper h4:after,.icon-horizontal .icon-wrapper,
							.icon-vertical .icon-wrapper,.siteorigin-panels-stretch .icon-horizontal:hover .icon-wrapper,
							.siteorigin-panels-stretch .icon-vertical:hover .icon-wrapper,.page-template-blog-fullwidth .entry-body a.more-link,
							.page-template-blog-large .entry-body a.more-link,.cnt-form .wpcf7-form input[type="submit"]:hover,
							.archive.category .entry-body a.more-link,
							.wide-pattern-black .icon-horizontal:hover .icon-wrapper,
							.wide-pattern-black .icon-vertical:hover .icon-wrapper,
							.flex-direction-nav a.flex-next:before,.site-footer a.btn,
							.flex-direction-nav a.flex-next:after,.widget_flexslider-widget .flexcarousel ol.flex-control-nav.flex-control-paging li a.flex-active,
							input[type="reset"]:hover,blockquote:before,.widget.widget_ourteam-widget .team-social ul li a,.portfolioeffects .portfolio_link_icons a,
							input[type="submit"]:hover,.main-navigation ul ul a,.main-navigation .current_page_item > a,.navigation a:hover,.widget_social-networks-widget ul li a,
							.share-box ul li a,.our-team:hover .team-content h4,.our-team:hover .team-content h4:before, .our-team:hover .team-content h4:after,
							.more-link:hover,.site-header-sticky,blockquote,.widget_tag_cloud a,.portfolio-excerpt a.btn-readmore,
							.portfolio-excerpt a.more-link,.flexslider .flex-caption a:hover,
							.home.blog .site-header-sticky,.hentry.sticky,.footer-widgets .widget_recent-posts-widget .recent-posts-slider .flex-control-paging li a.flex-active,
							.page-template-page-full-width-slider .site-header-sticky,.widget_calendar table caption,.site-footer .footer-widgets .widget_calendar td#today,
							.comment-navigation a:hover,.branding .site-branding,.ui-accordion h3:hover:before,.widget.widget_skill-widget .skill-container .skill-content .skill-title:after,
							.main-navigation .current-menu-item > a,#filters ul.filter-options li a:hover:after, #filters ul.filter-options li a.selected:after,.nav-links .meta-nav:hover,
							.more-link .meta-nav:hover,a.more-link:hover .meta-nav,
							.dropcap-circle,.pullnone,.pullnone:before,.pullleft,
							.pullright,.pullleft:before,.circle-icon-box:after,.widget_image-box-widget a.more-button,
							.pullright:before,
							.dropcap-box,.dropcap-book,.webulous_page_navi li a:hover,.webulous_page_navi li.bpn-next-link a:hover,
							.webulous_page_navi li.bpn-prev-link a:hover,.widget_recent-work-widget .portfolioeffects .overlay_icon a:hover,
							  .widget_recent-work-widget .work .overlay_icon a:hover,.webulous_page_navi li.bpn-current',
			'property' => 'background-color',
		),
		/*array(
			'element'  => '.main-navigation .sub-menu .current_page_item > a,   	
				            .main-navigation .sub-menu .current-menu-item > a,
							.main-navigation .sub-menu .current_page_ancestor > a,
							.site-content .comment-navigation a:hover,
							#primary .sticky,
							.entry-content blockquote:after,
							.site-main .search-form input.search-submit,
							.site-footer .scroll-to-top,
							.tabs ul li a.tabulous_active,
							.tabs ul li a:hover,
							.tabs.normal ul li a.tabulous_active,
							.tabs.normal ul li a:hover,
							.widget.widget_ourteam-widget ul.team-social li a:hover,.woocommerce #content input.button:hover,
							.woocommerce #respond input#submit:hover,.woocommerce a.button:hover,
							.woocommerce button.button:hover,
							.woocommerce input.button:hover,
							.woocommerce-page #content input.button:hover,.woocommerce-page a.button:hover,
							.woocommerce-page #respond input#submit:hover,
							.woocommerce-page button.button:hover,
							.woocommerce-page input.button:hover,.dropcap-book',
			'property' => 'background-color',
			'suffix' => '!important',
		),*/
	),
) );

Uniq_Kirki::add_field( 'uniq', array(
	'settings' => 'secondary_color',
	'label'    => __( 'Secondary Color', 'wbls-uniq' ),
	'section'  => 'primary_color_field',
	'type'     => 'color',
	'default'  => '#4c4c4c',
	'alpha'  => true,
	'active_callback' => array(
		array(
			'setting'  => 'enable_secondary_color',
			'operator' => '==',
			'value'    => true,
		),
	),
	'output' => array(
		array(
			'element' => '.webulous_page_navi li.bpn-current,.ui-accordion h3,.widget.widget_ourteam-widget .team-content h4,ol.comment-list .reply a:hover,.comment-author cite.fn a:hover,ol.comment-list li.byuser .comment-metadata a:hover,.hentry.sticky h1.entry-title a:hover,.hentry.sticky a,.hentry.sticky .entry-footer a:hover,
.hentry.sticky .entry-meta a:hover,.circle-icon-box .more-button a:hover,
button,
input,
select,
textarea,h1, h2, h3, h4, h5, h6,
.ui-accordion .ui-accordion-header-active,.icon-horizontal .icon-title,.icon-horizontal .service,
.icon-vertical .service,.related-posts ul#webulous-related-posts li:hover a,.cnt-form .wpcf7-form input[type="submit"],
.icon-vertical .icon-title,.circle-icon-box .icon-wrapper p.fa-stack i,.siteorigin-panels-stretch .widget.widget_ourteam-widget .team-content h4,
.wide-pattern-black .widget.widget_ourteam-widget .team-content h4,.widget.widget_skill-widget .skill-container .skill-content .txt-count,.page-links a:hover,.entry-header .posted-on .dd,.widget-area .widget_rss a:hover',
			'property' => 'color',
		),
		/*array(
			'element' => 'table tr th:hover a,
			  				.site-header .social .recentcomments a:hover	
							.header-wrap .site-header .social .recentcomments a:hover,
							#primary .sticky a:hover,
							#primary .sticky span:hover,
							#primary .sticky time:hover,
							.left-sidebar .recentcomments a:hover,
							.left-sidebar .widget_rss a:hover,
							.wide-cta .call-btn a:hover',
			'property' => 'color',
			'suffix' => '!important',
		),*/
		array(
			'element' => '.nav-wrap,.main-navigation ul.menu > li > a:hover,.portfolio-excerpt a.btn-readmore:hover,
.portfolio-excerpt a.more-link:hover,.portfolioeffects:hover .portfolio_link_icons a:hover,.ui-accordion .ui-accordion-content,.main-navigation ul.menu > li.current_page_item > a,.main-navigation ul.menu li:hover a,.navigation a,
.more-link,a.more-link .meta-nav,.webulous_page_navi li a,.webulous_page_navi li.bpn-next-link a,
.webulous_page_navi li.bpn-prev-link a,.widget_tag_cloud a:hover,.widget_social-networks-widget ul li a:hover,
.share-box ul li a:hover,#filters ul.filter-options li a:after,.widget.widget_ourteam-widget .team-social ul li a:hover,
.comment-navigation a,.widget_recent-work-widget .portfolioeffects .overlay_icon a,.flex-direction-nav a.flex-next:hover:after,
.flex-direction-nav a.flex-next:hover:before,.callout-widget a,.widget_testimonial-widget .flex-control-nav a,
.flex-direction-nav a.flex-prev:hover:before,.toggle .toggle-content,.icon-horizontal:hover .icon-wrapper,
.icon-vertical:hover .icon-wrapper,.page-template-blog-fullwidth .entry-body a.more-link:hover,
.page-template-blog-large .entry-body a.more-link:hover,.cnt-form,.cnt-form .wpcf7-form input,
.cnt-form .wpcf7-form textarea,
button,
input[type="button"],
input[type="reset"],
input[type="submit"],.nav-wrap::before,.wide-pattern-black,.site-footer,
.archive.category .entry-body a.more-link:hover,.wide-pattern-green,
.flex-direction-nav a.flex-prev:hover:after,.toggle .toggle-title .icn,
.widget_recent-work-widget .work .overlay_icon a,.ui-accordion .ui-accordion-header-active:before,.ui-accordion h3:before,.nav-links .meta-nav,.more-link .meta-nav,.widget.widget_skill-widget .skill-container .skill .skill-percentage',
			'property' => 'background-color',
		),
       /* array(
			'element' => '.slicknav_menu,
				          .search-form input.search-submit:hover ',
			'property' => 'background-color',
			'suffix' => '!important',
		),*/
		array(
			'element' => '.ui-accordion h3,.ui-accordion .ui-accordion-content,.stat-container .icon-wrapper .fa:after,#filters ul.filter-options li a:hover,
#filters ul.filter-options li a.selected,.toggle .toggle-title,.toggle .toggle-content',  
			'property' => 'border-color',
		),
		/*array(
			'element' => '.site-content .nav-next a span,
							.withtip.left:after,
							.home .flexslider .slides .flex-caption a:after,
			      			.home .flexslider .slides .flex-caption p a:after,
			      			.home .flexslider .flex-direction-nav .flex-nav-next a,
			      			#filters ul.filter-options li a:hover:before,
			        		#filters ul.filter-options li a.selected:before,
			        		.flexslider .slides .flex-caption a:after,
			      			.flexslider .slides .flex-caption p a:after,
			      			.flexslider .flex-direction-nav .flex-nav-next a,
			      			.widget_button-widget .btn.white:hover:after,
			      			.callout-widget .call-btn a:after,
			      			.wide-dark-grey .callout-widget p.call-btn a:hover:after,
			      			.widget_testimonial-widget .flex-direction-nav a.flex-next:hover',
			'property' => 'border-left-color',
		),*/
		array(
			'element' => '.site-header-sticky,
.home.blog .site-header-sticky,
.page-template-page-full-width-slider .site-header-sticky,abbr, acronym',
			'property' => 'border-bottom-color',
		),
        array(
			'element' => '.nav-wrap:after,.cnt-details h3.widget-title:after',
			'property' => 'border-right-color',
		),
        array(
			'element' => '.widget_social-networks-widget ul li a:hover:after
        .share-box ul li a:hover:after,.portfolioeffects:hover .portfolio_link_icons a:hover:after,
		{',
			'property' => 'border-top-color',
		),
		/*array(
			'element' => '.site-footer .widget_social-networks-widget ul li a:after',
			'property' => 'border-top-color',
			'suffix' => '!important',
		),*/
		
	),
) );
}

