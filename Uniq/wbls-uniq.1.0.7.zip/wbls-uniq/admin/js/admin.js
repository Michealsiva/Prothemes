(function( $ ) {

	$(function() {

		docs = $('<a class="uniq-docs doc"></a>')
			.attr('href','http://www.webulousthemes.com/uniq-pro/') 
			.attr('target','_blank')
			.text('Documentation');

		support = $('<a class="uniq-docs question"></a>')
			.attr('href','http://www.webulousthemes.com/support-ticket/')
			.attr('target','_blank')
			.text('Ask a Question');

		$('#customize-info .preview-notice').append(docs);
		$('#customize-info .preview-notice').append(support);

		$('.uniq-docs').on('click',function(e){
			e.stopPropagation();
		});
		
		
	});

})( jQuery );
