=== Webulous Uniq Pro ===
Contributors: webulous
Donate link: http://www.webulousthemes.com/
Tags: comments, spam
Requires at least: 4.0.0
Tested up to: 4.7.2
Stable tag: 1.0.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin converts free version of Uniq theme into pro version.

== Description ==

This plugin converts free version of Uniq theme into pro version.


== Installation ==

1. Upload `wbls-uniq` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. This is a screen shot

== Changelog == 
= 1.0.7 =
* Fix Speed optimization works

= 1.0.6 =
* Merge Custom css option to WP option

= 1.0.5 =
* Fix Tracking code bug
* Fix single clock demo content bug
* Compatible with site origin widget bundle

= 1.0.4 =
* Style Enhacement & Added admin notice for license
* Added More options
* Customizer Changed to kirki 

= 1.0.3 =
* Fix License activation issue

= 1.0.2 =
* Change Update file & Enable License Key Activation 

= 1.0.1 =
* Fix Responsive design bug

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.7 =
* Fix Speed optimization works