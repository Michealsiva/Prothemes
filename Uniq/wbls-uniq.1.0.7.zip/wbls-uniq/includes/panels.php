<?php
/**
 * Integrates this theme with SiteOrigin Page Builder.
 * 
 * @package webulous
 * @since 1.0
 * @license GPL 2.0
 */

/**
 * Adds default page layouts
 *
 * @param $layouts
 */
if (!function_exists('wbls_uniq_prebuilt_page_layouts') ) {     
function wbls_uniq_prebuilt_page_layouts($layouts){
  $layouts['default-home'] = array (
    'name' => __('Default Home', 'wbls-uniq'),
    'description' => __('Pre Built Layout for  home page', 'wbls-uniq'),
    'widgets' =>  array(
      0 => 
    array (
      'title' => 'Our Services',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => 'e8bbfd42-d4f6-4e8a-b40a-b3c075fb9066',
        'style' => 
        array (
          'class' => 'content-center btm-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'type' => 'circle',
      'title' => 'RESPONSIVE LAYOUT',
      'text' => 'Uniq is fully responsive and can adapt to any screen size. Resize your browser window to view it!.',
      'icon' => 'fa-mobile-phone',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://www.google.com',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => 'b79b6fa9-7423-40fe-b01b-0748eb8d6cfb',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
    2 => 
    array (
      'type' => 'circle',
      'title' => 'AWESOME SLIDER',
      'text' => 'Uniq includes two types of slider. You can use both Flex and Elastic sliders anywhere in your site.',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://www.google.com',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'widget_id' => '88092112-980a-40e1-b37a-80fa7cdd8851',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
    3 => 
    array (
      'type' => 'circle',
      'title' => 'RETINA READY',
      'text' => 'Uniq is Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '5x',
      'more' => 'More Info',
      'more_url' => 'http://www.google.com',
      'panels_info' => 
      array (
        'class' => 'Wbls_CircleIcon_Widget',
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'widget_id' => 'd2f4376c-b01d-4fb3-9ed0-ea1bcd7c5ccb',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
    4 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Running Facts',
            'text' => '',
            'filter' => false,
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '59950927-c291-46d5-a5f2-a7bee92dc610',
              'style' => 
              array (
                'class' => 'content-center txtcolor-white btm-divider',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '318',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'dfbfbf0b-d00c-4082-9eff-e0e14fe0a523',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '319',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '1cb372b0-4f08-4036-a5bc-882c8b99af87',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '321',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => 'dded4ddb-0b4f-49d4-994d-909d54891897',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '322',
            'panels_info' => 
            array (
              'class' => 'Wbls_Stats_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 3,
              'id' => 4,
              'widget_id' => 'c4c1539d-ffc0-42d0-b878-f046ee9d84b6',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 4,
            'style' => 
            array (
              'id' => '',
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'collapse_order' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.25,
          ),
        ),
      ),
      'builder_id' => '57776c3c7c536',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '39d4753b-4f19-42b4-a466-90f987f25df8',
        'style' => 
        array (
          'class' => 'btm-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Portfolio',
            'text' => 'Easy gallery created with standard WordPress galleries we all know and love!',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '4ad1a41c-b6e8-4043-b847-ae61105b0274',
              'style' => 
              array (
                'class' => 'content-center btm-divider',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'count' => '12',
            'type' => 'isotope',
            'panels_info' => 
            array (
              'class' => 'Wbls_Recent_Work_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'dfd4058d-cd37-4375-bbc3-9e857b1b717f',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '57776c3c7c5cf',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 5,
        'widget_id' => '5ff330a7-8323-4c93-97f2-caded1eeeff4',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Team',
            'text' => '',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'bccf1c55-592f-493e-95fd-03cfcdb7554c',
              'style' => 
              array (
                'class' => 'content-center txtcolor-white btm-divider',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. Sed consequat, est in consectetur dapibus, turpis ligula vehicula sapien.',
            'image_url' => 'http://uniq.webulous.in/wp-content/uploads/2016/07/Our-team-one.png',
            'title' => 'John Doe',
            'designation' => ' Manager',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '06ec989a-5940-4228-a397-66405cd640d1',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. Sed consequat, est in consectetur dapibus, turpis ligula vehicula sapien.',
            'image_url' => 'http://uniq.webulous.in/wp-content/uploads/2016/07/Our-team-Three.png',
            'title' => 'Aaleyah',
            'designation' => ' Designer',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => 'de74e8a8-f8e1-4e71-9b9a-53d690f46761',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'content' => 'Vivamus nec massa quis ligula pulvinar sodales. Donec sit amet placerat ipsum. Sed consequat, est in consectetur dapibus, turpis ligula vehicula sapien.',
            'image_url' => 'http://uniq.webulous.in/wp-content/uploads/2016/07/Our-team-Two.png',
            'title' => 'Christon Bale',
            'designation' => 'Programmer',
            'linkedin' => 'http://linkedin.com/',
            'google' => 'http://google.com/',
            'twitter' => 'http://twitter.com/',
            'facebook' => 'http://facebook.com',
            'panels_info' => 
            array (
              'class' => 'Wbls_Ourteam_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 3,
              'widget_id' => 'fd63cbc4-a80c-468e-bfbc-4c97c17ba468',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333332998,
          ),
        ),
      ),
      'builder_id' => '57776c3c7c628',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 6,
        'widget_id' => 'a78fbb5e-688d-46e0-87b5-fcc50d7bb860',
        'style' => 
        array (
          'class' => 'btm-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Our Services',
            'text' => '',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => 'aa753913-996b-4213-973d-b4ce31292b72',
              'style' => 
              array (
                'class' => 'content-center btm-divider',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://uniq.webulous.in/wp-content/uploads/2016/07/About-Us.png',
            'href' => 'http://uniq.webulous.in/wp-content/uploads/2016/07/About-Us.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => '4df7c86f-b96f-4aeb-96e4-9d7f2cda607c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'WHO WE ARE?',
            'text' => 'Aliquam malesuada tristique turpis vel vestibulum. Integer dolor eros, pretium ut ullamcorper ac, fringilla in leo. Sed sed nisi dictum, maximus eros ut, fringilla ipsum. Suspendisse fermentum nisl nibh, pulvinar efficitur sem semper sit amet. Donec venenatis erat felis, in eleifend urna congue ut. Ut quis luctus turpis, vel fermentum erat.


',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'grid' => 1,
              'cell' => 0,
              'id' => 2,
              'widget_id' => 'cf17ddc9-eda1-47d5-a8d6-0cc8068d7a17',
              'style' => 
              array (
                'class' => 'text-style',
                'widget_css' => '',
                'animation_class' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
            'filter' => false,
          ),
          3 => 
          array (
            'title' => 'Skills',
            'panels_info' => 
            array (
              'class' => 'Wbls_Skill_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 3,
              'widget_id' => '48ac7c3f-fcab-41bb-bfdb-d3c46238f077',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => 'header-ld-border',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.50023355850396001,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.49976644149603999,
          ),
        ),
      ),
      'builder_id' => '57776bf3350d4',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 7,
        'widget_id' => '65495fbe-f53b-4733-b344-8f14c81951a0',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Testimonials',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 8,
        'widget_id' => 'a0afcfce-8b91-4e82-947a-4e7d6f01cd30',
        'style' => 
        array (
          'class' => 'content-center txtcolor-white btm-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Testimonials',
      'count' => '4',
      'panels_info' => 
      array (
        'class' => 'Wbls_Testimonial_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 9,
        'widget_id' => '8346be79-b065-4a81-8145-f0b7bf157fc7',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Our Clients',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 10,
        'widget_id' => 'c545baac-9e9d-48c8-9c57-70937054f4e2',
        'style' => 
        array (
          'class' => 'content-center btm-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'slider' => 'clients',
      'type' => 'carousel',
      'panels_info' => 
      array (
        'class' => 'Wbls_FlexSlider_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 11,
        'widget_id' => '31453775-a60d-40bb-b9c4-96b7a7d20e7d',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi viverra tempus ullamcorper. Curabitur tincidunt libero vel iaculis mollis.
',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulouthemes.com',
      'anchor_text' => 'PURCHASE NOW',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 12,
        'widget_id' => '263dd44d-ecb8-4213-8dd5-35d7c65bf533',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-black',
        'background_display' => 'tile',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-black',
        'background_display' => 'tile',
      ),
    ),
    5 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-black',
        'padding' => '130px',
        'row_stretch' => 'full',
        'background_display' => 'cover',
      ),
    ),
    7 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    8 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-green',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    5 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    6 => 
    array (
      'grid' => 4,
      'weight' => 1,
    ),
    7 => 
    array (
      'grid' => 5,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    9 => 
    array (
      'grid' => 7,
      'weight' => 1,
    ),
    10 => 
    array (
      'grid' => 8,
      'weight' => 1,
    ),
     
    ),
  );

  $layouts['about-us'] = array(
    'name' => __('About Us', 'wbls-uniq'),
    'description' => __( 'Pre Built layout for about us page', 'wbls-uniq'),
    'widgets' => array(
            0 => 
    array (
      'title' => 'About Us',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '8a8f43bd-ceae-4fe9-a180-667d7d7c9b30',
        'style' => 
        array (
          'class' => 'content-center btm-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'src' => 'http://uniq.webulous.in/wp-content/uploads/2016/07/img-layout.png',
      'href' => 'http://uniq.webulous.in/wp-content/uploads/2016/07/img-layout.png',
      'panels_info' => 
      array (
        'class' => 'Wbls_Image_Widget',
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '9b636595-f11c-4d5a-bc62-8b2bd95b34ff',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Vestibulum vel euismod purus, a venenatis ligula.',
      'text' => 'Proin malesuada congue pharetra. Quisque nec ipsum eget felis ultrices tristique et eu justo. Nullam diam libero, facilisis et neque vitae, auctor dignissim tortor. Mauris mollis sapien magna, eget posuere mauris vestibulum eget.purus non ex euismod vulputate. Mauris eleifend id urna at congue. Pellentesque luctus nunc tortor.

Integer ut neque a justo sodales suscipit a ut elit. Mauris vel convallis risus, at venenatis sapien. Sed id pretium massa. Pellentesque commodo eleifend nisl, at dictum nisi. Nam scelerisque purus a libero sollicitudin, quis molestie arcu suscipit. Nunc felis tortor, lacinia nec arcu ut.',
      'filter' => true,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'widget_id' => '0e746cd5-4259-403f-b4dd-a2608c556ac0',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Testimonials',
            'text' => '',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'content-center txtcolor-white btm-divider',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Testimonials',
            'count' => '4',
            'panels_info' => 
            array (
              'class' => 'Wbls_Testimonial_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '56b5eec603c2a',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 3,
        'widget_id' => 'c623e978-aa52-4cd6-b50d-27046b6f357f',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris commodo sem vitae rhoncus venenatis. Quisque malesuada neque eget suscipit pulvinar.',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'PURCHASE NOW',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 4,
        'widget_id' => '1fe5b06a-d3b5-4eaf-9df3-0f69244512d6',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 2,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'padding' => '100px',
        'row_stretch' => 'full',
        'background_image_attachment' => 12,
        'background_display' => 'cover',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-green',
        'padding' => '100px',
        'row_stretch' => 'full',
        'background_image_attachment' => 137,
        'background_display' => 'cover',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.5,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.5,
    ),
    3 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    4 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    ),
  );

  $layouts['features'] = array(
      'name' => __('Features Page', 'wbls-uniq'),
      'description' => __( 'Pre Built layout for features page', 'wbls-uniq'),
      'widgets' => array(
  0 => 
    array (
      'title' => '',
      'text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'class' => 'content-center btm-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'title' => 'Responsive Layout',
      'text' => 'UniqPro is fully responsive and can adapt to any screen size. Resize your browser window to view it!',
      'icon' => 'fa-mobile',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'title' => 'Awesome Slider',
      'text' => 'UniqPro includes Flex slider. You can use Flex slider anywhere in your site.',
      'icon' => 'fa-random',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 1,
        'id' => 2,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'title' => 'Font Awesome',
      'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
      'icon' => 'fa-flag',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 1,
        'cell' => 2,
        'id' => 3,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    4 => 
    array (
      'title' => 'Typography',
      'text' => 'UniqPro  loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
      'icon' => 'fa-font',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 4,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    5 => 
    array (
      'title' => 'Retina Ready',
      'text' => 'UniqPro  is Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
      'icon' => 'fa-magic',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 1,
        'id' => 5,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    6 => 
    array (
      'title' => 'Excellent Support ',
      'text' => 'We truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!t sizes!',
      'icon' => 'fa-thumb-tack',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 2,
        'id' => 6,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    7 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ',
      'title' => 'Webulous Themes',
      'url' => 'http://webulousthemes.com',
      'anchor_text' => 'PURCHASE NOW',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 7,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    8 => 
    array (
      'title' => 'Customization',
      'text' => 'With advanced theme options, page options & extensive docs, its never been easier to customize a theme!',
      'icon' => 'fa-cog',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'box' => false,
      'all_linkable' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 0,
        'id' => 8,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    9 => 
    array (
      'title' => 'Page Builder',
      'text' => 'UniqPro supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
      'icon' => 'fa-plus',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 1,
        'id' => 9,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    10 => 
    array (
      'title' => 'Page Layouts',
      'text' => 'UniqPro offers many different page layouts so you can quickly and easily create your pages with no hassle!',
      'icon' => 'fa-copy (alias)',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 4,
        'cell' => 2,
        'id' => 10,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    11 => 
    array (
      'title' => 'Custom Widget',
      'text' => 'We offer many custom widgets that are stylized and ready for use. Simply drag & drop into place to activate!',
      'icon' => 'fa-camera',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 0,
        'id' => 11,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    12 => 
    array (
      'title' => 'Shortcode Builder',
      'text' => 'UniqPro inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
      'icon' => 'fa-check',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 1,
        'id' => 12,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    13 => 
    array (
      'title' => 'Demo Content',
      'text' => 'UniqPro includes demo content files. You can quickly setup the site like our demo and get started easily!',
      'icon' => 'fa-times',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 5,
        'cell' => 2,
        'id' => 13,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    14 => 
    array (
      'content' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ',
      'title' => 'Webulous Themes',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'PURCHASE NOW',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 6,
        'cell' => 0,
        'id' => 14,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    15 => 
    array (
      'title' => 'Woo Commerce',
      'text' => 'UniqPro has full design/code integration for WooCommerce, your shop will look as good as the rest of your site!',
      'icon' => 'fa-shopping-cart',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 0,
        'id' => 15,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    16 => 
    array (
      'title' => 'Social Media',
      'text' => 'Want your users to stay in touch? No problem, Outliner has Social Media icons all throughout the theme!',
      'icon' => 'fa-skype',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 1,
        'id' => 16,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    17 => 
    array (
      'title' => 'Google Map',
      'text' => 'UniqPro  includes Google Map as shortcode and widget. So you can use it anywhere in your site!',
      'icon' => 'fa-map-marker',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 7,
        'cell' => 2,
        'id' => 17,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    18 => 
    array (
      'title' => 'Multiple Portfolio',
      'text' => '8 portfolio layouts, 1 blog layouts and alternate layouts for interior pages!',
      'icon' => 'fa-list-alt',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 0,
        'id' => 18,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    19 => 
    array (
      'title' => 'Multiple Sidebar',
      'text' => 'Unlimited sidebars allow you to create custom sidebars that match the style and layout of pages!',
      'icon' => 'fa-columns',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'all_linkable' => false,
      'box' => false,
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'raw' => false,
        'grid' => 8,
        'cell' => 1,
        'id' => 19,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    20 => 
    array (
      'title' => 'Improvement',
      'text' => 'We love our theme customers. We are committed to improve and add new features to UniqPro!',
      'icon' => 'fa-edit (alias)',
      'icon_background_color' => '',
      'icon_size' => '3x',
      'icon_placement' => 'left',
      'more' => '',
      'more_url' => '',
      'panels_info' => 
      array (
        'class' => 'Wbls_Icon_Widget',
        'grid' => 8,
        'cell' => 2,
        'id' => 20,
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
      'box' => false,
      'all_linkable' => false,
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-green',
        'background_display' => 'tile',
      ),
    ),
    4 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    5 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    6 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-green',
        'background_display' => 'tile',
      ),
    ),
    7 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
    8 => 
    array (
      'cells' => 3,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    2 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    3 => 
    array (
      'grid' => 1,
      'weight' => 0.33333333333333331,
    ),
    4 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    5 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    6 => 
    array (
      'grid' => 2,
      'weight' => 0.33333333333333331,
    ),
    7 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
    8 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    9 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    10 => 
    array (
      'grid' => 4,
      'weight' => 0.33333333333333331,
    ),
    11 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    12 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    13 => 
    array (
      'grid' => 5,
      'weight' => 0.33333333333333331,
    ),
    14 => 
    array (
      'grid' => 6,
      'weight' => 1,
    ),
    15 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    16 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    17 => 
    array (
      'grid' => 7,
      'weight' => 0.33333333333333331,
    ),
    18 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    19 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    20 => 
    array (
      'grid' => 8,
      'weight' => 0.33333333333333331,
    ),
    ),
  );

  $layouts['contact-us'] = array(
      'name' => __('Contact Us Page', 'wbls-uniq'),
      'description' => __( 'Pre Built layout for contact us page', 'wbls-uniq'),
      'widgets' => array(
        0 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d6305.992774595653!2d-122.41157430890459!3d37.790124433800656!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858091edff45bd%3A0x70c4586b1202a605!2sUSA+Hostels+San+Francisco!5e0!3m2!1sen!2sin!4v1407318894507" width="1200" height="300" frameborder="0" style="border:0"></iframe>',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => true,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '55c4346b3e964',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Contact Us',
            'text' => '<i class="fa fa-map-marker"></i> 1234 Baker street, New york R23, First Floor,  <i class="fa fa-envelope"></i> info@gmail.com <i class="fa fa-phone"></i> +1234 456 7890',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => 'cnt-details',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[contact-form-7 id="6" title="Contact form 1"]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => 'cnt-form',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '100px',
              'row_stretch' => 'full',
              'background' => '',
              'background_image_attachment' => '329',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '5678f14d28dbc',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    ),
  );

  $layouts['faq'] = array (
    'name' => __('Faq Page', 'wbls-uniq'),
    'description' => __('Pre Built Layout for default faq page', 'wbls-uniq'),
    'widgets' =>  array(
      0 => 
    array (
      'title' => 'Faq\'s',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'style' => 
        array (
          'class' => 'content-center btm-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => '',
            'text' => '[toggle title="How can install this new version?" open="0" type="polygon"]It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\'.[/toggle]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => '',
            'text' => '[toggle title="Curabitur imperdiet porttitor enim vel consequat" open="0" type="polygon"]Nullam sed varius orci, sed sodales libero. Vestibulum pulvinar lectus id placerat rutrum. Vestibulum pellentesque hendrerit erat a elementum. Vestibulum non gravida ligula. Donec mauris mi, pulvinar at scelerisque a, fermentum sit amet lorem. Nunc consequat lobortis odio, a rhoncus ex pellentesque nec.[/toggle]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 1,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => '',
            'text' => '[toggle title="Duis efficitur elementum ante" open="0" type="polygon"]Fusce efficitur tempus felis eu porta. Nullam in mollis urna. Pellentesque fermentum blandit lectus, suscipit porttitor lorem viverra quis. Suspendisse nec tempus diam. Suspendisse dignissim, mauris vitae tempus fringilla, magna neque efficitur lacus, rhoncus fringilla justo est eu tortor.[/toggle]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 2,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => '',
            'text' => '[toggle title="Ut iaculis quis ipsum vitae sodales" open="0" type="polygon"]Pellentesque eu suscipit nisi. Curabitur a laoreet lacus, in cursus tortor. Nunc imperdiet nulla eu risus varius, ac rutrum elit mattis. Ut ultrices at urna ac viverra. Fusce id diam mollis, ullamcorper nibh vitae, congue tellus.[/toggle]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 3,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => '',
            'text' => '[toggle title="Nullam sed accumsan augue" open="0" type="polygon"]Suspendisse posuere faucibus lacus vel ornare. Sed pellentesque erat ut sem sagittis, vel convallis mauris ultrices. Proin libero metus, facilisis sit amet nulla sed, pretium elementum tortor. Aliquam mattis felis a odio ornare, nec maximus orci aliquet. Nunc sit amet ultrices sem.[/toggle]
',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 4,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => '',
            'text' => '[toggle title="Praesent iaculis hendrerit viverra" open="0" type="polygon"]Nulla suscipit urna in nunc pellentesque, non suscipit purus scelerisque. Donec lobortis blandit nulla, at finibus libero interdum et. Aenean lobortis, ligula in aliquet porttitor, erat lorem hendrerit nulla, vel auctor ex leo sit amet massa. Ut consectetur, diam vitae rhoncus rhoncus, libero mi facilisis velit, ut aliquet ex magna ut tortor. Aliquam at euismod turpis, vitae pulvinar nunc[/toggle]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 5,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          6 => 
          array (
            'title' => '',
            'text' => '[toggle title="Quisque vestibulum vehicula consectetur." open="0" type="polygon"]In eu condimentum quam. Sed egestas augue at neque dignissim gravida. Vivamus vel purus sed risus facilisis scelerisque quis a dolor. Duis a mi quis erat ultrices aliquam. Suspendisse porta lobortis est ac tempor. Proin sed nulla dictum, condimentum nisi sed, condimentum arcu. Duis fringilla mollis diam, eget gravida mi euismod eu[/toggle]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 6,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          7 => 
          array (
            'title' => '',
            'text' => '[toggle title=" Mauris molestie lorem id ex tempus porttitor." open="0" type="polygon"]Nunc sagittis et augue non facilisis. Etiam auctor ultrices dui a maximus. Pellentesque diam leo, suscipit eget urna at, blandit condimentum arcu. Sed vestibulum tempus nibh, eget pellentesque nisi malesuada nec. Etiam consectetur ornare diam, non placerat velit rutrum interdum. Integer vehicula egestas neque, eu ornare purus imperdiet eget. In tristique ut metus vitae faucibus.[/toggle]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 7,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          8 => 
          array (
            'title' => '',
            'text' => '[toggle title="Vestibulum sem sapien, posuere vitae imperdiet." open="0" type="polygon"]Morbi condimentum sapien nulla, id rhoncus sem pharetra id. Nam in quam mi. Integer eleifend quis enim vitae dignissim. Nunc pulvinar lorem sed velit tincidunt, quis convallis nisl blandit. Maecenas fermentum viverra magna quis consequat. Aliquam erat volutpat. Quisque viverra vulputate est, efficitur posuere turpis viverra eu. Donec laoreet condimentum diam, vitae feugiat elit.[/toggle]',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 8,
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
        ),
      ),
      'builder_id' => '55c0422032983',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'raw' => false,
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris commodo sem vitae rhoncus venenatis. Quisque malesuada neque eget suscipit pulvinar.',
      'title' => 'WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'PURCHASE NOW',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'style' => 
        array (
          'class' => 'wide-pattern-green',
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    ),
    
  );

  $layouts['services'] = array (
    'name' => __('Services Page', 'wbls-uniq'),
    'description' => __('Pre Built Layout for services page', 'wbls-uniq'),
    'widgets' =>  array(
      0 => 
    array (
      'title' => 'Our Services',
      'text' => '',
      'filter' => false,
      'panels_info' => 
      array (
        'class' => 'WP_Widget_Text',
        'raw' => false,
        'grid' => 0,
        'cell' => 0,
        'id' => 0,
        'widget_id' => '37e1d220-4ef5-494b-8fec-81a8294ac034',
        'style' => 
        array (
          'class' => 'content-center btm-divider',
          'background_display' => 'tile',
        ),
      ),
    ),
    1 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Responsive Layout',
            'text' => 'UniqPro is fully responsive and can adapt to any screen size. Resize your browser window to view it!',
            'icon' => 'fa-mobile',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '86fa6db1-8065-4113-8c73-e73e113c63b1',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'title' => 'Awesome Slider',
            'text' => 'UniqPro includes Flex slider. You can use Flex slider anywhere in your site.',
            'icon' => 'fa-random',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 1,
              'id' => 1,
              'widget_id' => 'ed2c5960-77f9-475a-a644-c38740e8417b',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'title' => 'Font Awesome',
            'text' => 'Font Awesome icons are fully integrated into the theme. Use them anywhere in your site in 6 different sizes!',
            'icon' => 'fa-flag',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 0,
              'cell' => 2,
              'id' => 2,
              'widget_id' => '2b9d405e-3c4c-4d43-8ec0-7b0f5016380e',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          3 => 
          array (
            'title' => 'Typography',
            'text' => 'UniqPro  loves typography, you can choose from over 500+ Google Fonts and Standard Fonts to customize your site!',
            'icon' => 'fa-font',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 0,
              'id' => 3,
              'widget_id' => '378b3a93-dde9-4f02-a07b-fb8a63c6054d',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          4 => 
          array (
            'title' => 'Retina Ready',
            'text' => 'UniqProis Retina Ready. So, Everything looks amazingly sharp and crisp on high resolution retina displays of all sizes!',
            'icon' => 'fa-magic',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 4,
              'widget_id' => 'ac1c0779-1f69-4097-8d00-be07eb4959f5',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          5 => 
          array (
            'title' => 'Excellent Support ',
            'text' => 'e truly care about our customers and theme\'s performance. We assure you that you will get the best after sale support like never before!',
            'icon' => 'fa-thumb-tack',
            'icon_background_color' => '',
            'icon_size' => '3x',
            'icon_placement' => 'left',
            'more' => '',
            'more_url' => '',
            'all_linkable' => '',
            'panels_info' => 
            array (
              'class' => 'Wbls_Icon_Widget',
              'raw' => false,
              'grid' => 1,
              'cell' => 2,
              'id' => 5,
              'widget_id' => '60aed16c-6eed-4a81-bdb7-766ad0dd1fca',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'white-title',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
          1 => 
          array (
            'cells' => 3,
            'style' => 
            array (
              'class' => 'white-title',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '0',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          1 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          2 => 
          array (
            'grid' => 0,
            'weight' => 0.33333333333333331,
          ),
          3 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          4 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
          5 => 
          array (
            'grid' => 1,
            'weight' => 0.33333333333333331,
          ),
        ),
      ),
      'builder_id' => '57765c2854669',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 1,
        'cell' => 0,
        'id' => 1,
        'widget_id' => '44911943-ac53-4a8e-b6a1-f417b5eeb7b1',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    2 => 
    array (
      'panels_data' => 
      array (
        'widgets' => 
        array (
          0 => 
          array (
            'title' => 'Lorem Ipsum',
            'text' => '',
            'filter' => '',
            'panels_info' => 
            array (
              'class' => 'WP_Widget_Text',
              'raw' => false,
              'grid' => 0,
              'cell' => 0,
              'id' => 0,
              'widget_id' => '03d84e50-2706-4650-890f-4a51fa6d9e07',
              'style' => 
              array (
                'class' => 'content-center txtcolor-white btm-divider',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
          1 => 
          array (
            'src' => 'http://uniq.webulous.in/wp-content/uploads/2016/07/service-tablet.png',
            'href' => 'http://uniq.webulous.in/wp-content/uploads/2016/07/service-tablet.png',
            'panels_info' => 
            array (
              'class' => 'Wbls_Image_Widget',
              'grid' => 1,
              'cell' => 0,
              'id' => 1,
              'widget_id' => 'e6251f36-a6e7-406f-82c8-675e8cd19e65',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
                'link_color' => '',
              ),
            ),
          ),
          2 => 
          array (
            'panels_data' => 
            array (
              'widgets' => 
              array (
                0 => 
                array (
                  'title' => 'Page Builder',
                  'text' => 'UniqPro supports Page Builder. All our shortcodes can be used as widgets too. You can drag and drop our widgets with page builder visual editor.',
                  'icon' => 'fa-plus',
                  'icon_background_color' => '',
                  'icon_size' => '3x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => true,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 0,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                1 => 
                array (
                  'title' => 'Shortcode Builder',
                  'text' => 'UniqPro inclues lots of shortcodes, and our shortcode builder, users can easily build custom pages!',
                  'icon' => 'fa-check',
                  'icon_background_color' => '',
                  'icon_size' => '3x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'all_linkable' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 1,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
                2 => 
                array (
                  'title' => 'Page Layouts',
                  'text' => 'UniqPro  offers many different page layouts so you can quickly and easily create your pages with no hassle!',
                  'icon' => 'fa-copy (alias)',
                  'icon_background_color' => '',
                  'icon_size' => '3x',
                  'icon_placement' => 'left',
                  'more' => '',
                  'more_url' => '',
                  'all_linkable' => '',
                  'panels_info' => 
                  array (
                    'class' => 'Wbls_Icon_Widget',
                    'raw' => false,
                    'grid' => 0,
                    'cell' => 0,
                    'id' => 2,
                    'style' => 
                    array (
                      'class' => '',
                      'widget_css' => '',
                      'padding' => '',
                      'background' => '',
                      'background_image_attachment' => '0',
                      'background_display' => 'tile',
                      'border_color' => '',
                      'font_color' => '',
                    ),
                  ),
                ),
              ),
              'grids' => 
              array (
                0 => 
                array (
                  'cells' => 1,
                  'style' => 
                  array (
                  ),
                ),
              ),
              'grid_cells' => 
              array (
                0 => 
                array (
                  'grid' => 0,
                  'weight' => 1,
                ),
              ),
            ),
            'builder_id' => '55bb2104036c8',
            'panels_info' => 
            array (
              'class' => 'SiteOrigin_Panels_Widgets_Layout',
              'raw' => false,
              'grid' => 1,
              'cell' => 1,
              'id' => 2,
              'widget_id' => '050607e3-1105-4271-b58e-b1871993d24c',
              'style' => 
              array (
                'class' => '',
                'widget_css' => '',
                'padding' => '',
                'background' => '',
                'background_image_attachment' => '0',
                'background_display' => 'tile',
                'border_color' => '',
                'font_color' => '',
              ),
            ),
          ),
        ),
        'grids' => 
        array (
          0 => 
          array (
            'cells' => 1,
            'style' => 
            array (
            ),
          ),
          1 => 
          array (
            'cells' => 2,
            'style' => 
            array (
              'class' => '',
              'cell_class' => '',
              'row_css' => '',
              'bottom_margin' => '',
              'gutter' => '',
              'padding' => '',
              'row_stretch' => '',
              'background' => '',
              'background_image_attachment' => '',
              'background_display' => 'tile',
              'border_color' => '',
            ),
          ),
        ),
        'grid_cells' => 
        array (
          0 => 
          array (
            'grid' => 0,
            'weight' => 1,
          ),
          1 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
          2 => 
          array (
            'grid' => 1,
            'weight' => 0.5,
          ),
        ),
      ),
      'builder_id' => '57765c285470c',
      'panels_info' => 
      array (
        'class' => 'SiteOrigin_Panels_Widgets_Layout',
        'grid' => 2,
        'cell' => 0,
        'id' => 2,
        'widget_id' => '2ddfb743-3568-46b9-a20a-f49d6bb8acab',
        'style' => 
        array (
          'background_image_attachment' => false,
          'background_display' => 'tile',
        ),
      ),
    ),
    3 => 
    array (
      'content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris commodo sem vitae rhoncus venenatis. Quisque malesuada neque eget suscipit pulvinar.',
      'title' => ' WEBULOUS THEMES',
      'url' => 'http://www.webulousthemes.com',
      'anchor_text' => 'PURCHASE NOW',
      'panels_info' => 
      array (
        'class' => 'Wbls_Cta_Widget',
        'raw' => false,
        'grid' => 3,
        'cell' => 0,
        'id' => 3,
        'widget_id' => 'a49e4e31-594c-4969-93b8-bff3e3025a09',
        'style' => 
        array (
          'background_display' => 'tile',
        ),
      ),
    ),
  ),
  'grids' => 
  array (
    0 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    1 => 
    array (
      'cells' => 1,
      'style' => 
      array (
      ),
    ),
    2 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'padding' => '150px',
        'row_stretch' => 'full',
        'background_image_attachment' => 12,
        'background_display' => 'cover',
      ),
    ),
    3 => 
    array (
      'cells' => 1,
      'style' => 
      array (
        'class' => 'wide-pattern-green',
        'background_display' => 'tile',
      ),
    ),
  ),
  'grid_cells' => 
  array (
    0 => 
    array (
      'grid' => 0,
      'weight' => 1,
    ),
    1 => 
    array (
      'grid' => 1,
      'weight' => 1,
    ),
    2 => 
    array (
      'grid' => 2,
      'weight' => 1,
    ),
    3 => 
    array (
      'grid' => 3,
      'weight' => 1,
    ),
   ),
    
  );

  return $layouts;
}
}
add_filter('siteorigin_panels_prebuilt_layouts', 'wbls_uniq_prebuilt_page_layouts');

 function wbls_uniq_panels_row_style_fields($fields) {  

    $uniq_animation_name = array(
        '' => __(' --- Default --- ', 'wbls-uniq'),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-uniq' ),
        'bigEntrance-animation' => __('bigEntrance-animation','wbls-uniq' ),
        'boingInUp-animation' => __('boingInUp-animation','wbls-uniq' ),
        'bounce-animation' => __('bounce-animation','wbls-uniq' ),
        'bounceInLeft-animation' => __('bounceInLeft-animation','wbls-uniq' ),
        'bounceInRight-animation' => __('bounceInRight-animation','wbls-uniq' ),
        'bounceInUp-animation' => __('bounceInUp-animation','wbls-uniq' ),
        'expandUp-animation' => __('expandUp-animation','wbls-uniq' ),
        'fade-animation' => __('fade-animation','wbls-uniq' ),
        'fadeIn-animation' => __('fadeIn-animation','wbls-uniq' ),
        'fadeInDown-animation' => __('fadeInDown-animation','wbls-uniq' ),
        'fadeInDownBig-animation' => __('fadeInDownBig-animation','wbls-uniq' ),
        'fadeInLeft-animation' => __('fadeInLeft-animation','wbls-uniq' ),
        'fadeInLeftBig-animation' => __('fadeInLeftBig-animation','wbls-uniq' ),
        'fadeInRight-animation' => __('fadeInRight-animation','wbls-uniq' ),
        'fadeInRightBig-animation' => __('fadeInRightBig-animation','wbls-uniq' ),
        'fadeInUp-animation' => __('fadeInUp-animation','wbls-uniq' ),
        'fadeInUpBig-animation' => __('fadeInUpBig-animation','wbls-uniq' ),
        'flip-animation' => __('flip-animation','wbls-uniq' ),
        'flipInX-animation' => __('flipInX-animation','wbls-uniq' ),
        'flipInY-animation' => __('flipInY-animation','wbls-uniq' ),
        'floating-animation' => __('floating-animation','wbls-uniq' ),
        'foolishIn-animation' => __('foolishIn-animation','wbls-uniq' ),
        'hatch-animation' => __('hatch-animation','wbls-uniq' ),
        'lightSpeedIn-animation' => __('lightSpeedIn-animation','wbls-uniq' ),
        'puffIn-animation' => __('puffIn-animation','wbls-uniq' ),
        'pullDown-animation' => __('pullDown-animation','wbls-uniq' ),
        'pullUp-animation' => __('pullUp-animation','wbls-uniq' ),
        'pulse-animation' => __('pulse-animation','wbls-uniq' ),
        'rollInLeft-animation' => __('rollInLeft-animation','wbls-uniq' ),
        'rollInRight-animation' => __('rollInRight-animation','wbls-uniq' ),
        'rotateIn-animation' => __('rotateIn-animation','wbls-uniq' ),
        'rotateInDownLeft-animation' => __('rotateInDownLeft-animation','wbls-uniq' ),
        'rotateInDownRight-animation' => __('rotateInDownRight-animation','wbls-uniq' ),
        'rotateInUpLeft-animation' => __('rotateInUpLeft-animation','wbls-uniq' ),
        'rotateInUpRight-animation' => __('rotateInUpRight-animation','wbls-uniq' ),
        'scale-down-animation' => __('scale-down-animation','wbls-uniq' ),
        'scale-up-animation' => __('scale-up-animation','wbls-uniq' ),
        'slide-bottom-animation' => __('slide-bottom-animation','wbls-uniq' ),
        'slide-left-animation' => __('slide-left-animation','wbls-uniq' ),
        'slide-right-animation' => __('slide-right-animation','wbls-uniq' ),
        'slide-top-animation' => __('slide-top-animation','wbls-uniq' ),
        'slideDown-animation' => __('slideDown-animation','wbls-uniq' ),
        'slideExpandUp-animation' => __('slideExpandUp-animation','wbls-uniq' ),
        'slideInDown-animation' => __('slideInDown-animation','wbls-uniq' ),
        'slideInLeft-animation' => __('bouslideInLeft-animation','wbls-uniq' ),
        'slideInRight-animation' => __('slideInRight-animation','wbls-uniq' ),
        'slideLeft-animation' => __('slideLeft-animation','wbls-uniq' ),
        'slideRight-animation' => __('slideRight-animation','wbls-uniq' ),
        'slideUp-animation' => __('slideUp-animation','wbls-uniq' ),
        'spaceInDown-animation' => __('spaceInDown-animation','wbls-uniq' ),
        'spaceInLeft-animation' => __('spaceInLeft-animation','wbls-uniq' ),
        'spaceInRight-animation' => __('spaceInRight-animation','wbls-uniq' ), 
        'spaceInUp-animation'  => __('spaceInUp-animation','wbls-uniq' ),
        'stretchLeft-animation' => __('stretchLeft-animation','wbls-uniq' ), 
        'stretchRight-animation'  => __('stretchRight-animation','wbls-uniq' ),
        'swap-animation'  => __('swap-animation','wbls-uniq' ),
        'swashIn-animation'  => __('swashIn-animation','wbls-uniq' ),
        'swing-animation'  => __('swing-animation','wbls-uniq' ),
        'tinDownIn-animation' => __('tinDownIn-animation','wbls-uniq' ), 
        'tinRightIn-animation'  => __('tinRightIn-animation','wbls-uniq' ),
        'tinUpIn-animation' => __('tinUpIn-animation','wbls-uniq' ), 
        'tossing-animation'  => __('tossing-animation','wbls-uniq' ),
        'twisterInDown-animation'  => __('twisterInDown-animation','wbls-uniq' ),
        'twisterInUp-animation' => __('twisterInUp-animation','wbls-uniq' ), 
        'wobble-animation' => __('wobble-animation','wbls-uniq' ),
        'zoomIn-animation' => __('zoomIn-animation','wbls-uniq' ),
    );

    $fields['animation_class'] = array(
            'name' => __('Animation Class', 'uniq'),
            'type' => 'select',
            'options' => $uniq_animation_name,
    );

    return $fields;
}

add_filter('siteorigin_panels_row_style_fields', 'wbls_uniq_panels_row_style_fields');
add_filter('siteorigin_panels_widget_style_fields', 'wbls_uniq_panels_row_style_fields');

function wbls_uniq_panels_panels_row_style_attributes( $attributes, $args ) {
  if( !empty( $args['animation_class'] ) ) {
      $attributes['class'][] =  $args['animation_class']; 
    }

    if( !empty( $args['class'] ) ) {
      $attributes['class'] = array_merge( $attributes['class'], explode(' ', $args['class']) );
    }
    return $attributes;
}
add_filter('siteorigin_panels_row_style_attributes', 'wbls_uniq_panels_panels_row_style_attributes', 10, 2);
add_filter('siteorigin_panels_widget_style_attributes', 'wbls_uniq_panels_panels_row_style_attributes', 10, 2);

function wbls_uniq_row_style_groups( $groups ) {
  $groups['theme'] = array(
      'name' => __('Animation', 'wbls-uniq'),
  );

  return $groups;
}

add_filter( 'siteorigin_panels_row_style_groups', 'wbls_uniq_row_style_groups' );
add_filter( 'siteorigin_panels_widget_style_groups', 'wbls_uniq_row_style_groups' );